"""Fleet manifest schema and CE-internal identifier guard."""

from __future__ import annotations

import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable

from ..fleet_manifest import (
    CONTRACT,
    FleetManifestValidationError,
    iter_fleet_manifest_paths,
    load_fleet_manifest,
)
from ..identity_denylist import (
    IdentityDenylist,
    IdentityDenylistError,
    IdentityDenylistUnavailable,
    find_identity_matches,
    load_identity_denylist,
)
from ..reporting import CheckResult, ValidationError, make_error
from . import register

CHECK_NAME = "fleet_manifest_guard"
CODE_INTERNAL_IDENTIFIER = "fleet_manifest_internal_identifier"
CODE_IDENTITY_DENYLIST_UNAVAILABLE = "fleet_manifest_identity_denylist_unavailable"
CODE_IDENTITY_DENYLIST_INVALID = "fleet_manifest_identity_denylist_invalid"


@dataclass(frozen=True)
class InternalPattern:
    label: str
    pattern: re.Pattern[str]


INTERNAL_REGEX_PATTERNS = (
    InternalPattern("internal tailnet IP range", re.compile(r"(?<![\d.])100\.(?:\d{1,3}\.){2}\d{1,3}(?![\d.])")),
    InternalPattern("internal shared App", re.compile(r"\b(?:internal\s+shared\s+app|ce\s+shared\s+app|shared\s+ce\s+app)\b", re.IGNORECASE)),
    InternalPattern("herdr socket path", re.compile(r"(?:^|[\s:=])(?:/[^\s]*herdr[^\s]*\.sock|herdr[^\s]*\.sock)\b", re.IGNORECASE)),
    InternalPattern("internal brain endpoint", re.compile(r"\b(?:https?://)?[a-z0-9.-]*brain[a-z0-9.-]*:\d{2,5}\b", re.IGNORECASE)),
    InternalPattern("internal vLLM endpoint", re.compile(r"\b(?:https?://)?[a-z0-9.-]*vllm[a-z0-9.-]*:\d{2,5}\b", re.IGNORECASE)),
)


def _json_pointer(parts: tuple[str, ...]) -> str:
    if not parts:
        return "/"
    escaped = [part.replace("~", "~0").replace("/", "~1") for part in parts]
    return "/" + "/".join(escaped)


def _string_nodes(value: Any, parts: tuple[str, ...] = ()) -> Iterable[tuple[tuple[str, ...], str]]:
    if isinstance(value, dict):
        for key, child in value.items():
            key_text = str(key)
            yield ((*parts, key_text), key_text)
            yield from _string_nodes(child, (*parts, key_text))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from _string_nodes(child, (*parts, str(index)))
    elif isinstance(value, str):
        yield (parts, value)


@lru_cache(maxsize=1)
def _runtime_identity_denylist() -> IdentityDenylist | None:
    return load_identity_denylist(required=False)


def _internal_identifier_errors(
    path: Path, data: dict[str, Any], denylist: IdentityDenylist | None
) -> list[ValidationError]:
    errors: list[ValidationError] = []
    seen: set[tuple[str, str]] = set()
    for parts, value in _string_nodes(data):
        pointer = _json_pointer(parts)
        if denylist is not None:
            for match in find_identity_matches(value, denylist):
                key = (pointer, ",".join(match.categories))
                if key in seen:
                    continue
                seen.add(key)
                categories = ", ".join(match.categories)
                errors.append(
                    make_error(
                        CODE_INTERNAL_IDENTIFIER,
                        path,
                        pointer,
                        f"fleet manifest contains CE-internal identifier from runtime denylist category {categories}",
                        CONTRACT,
                    )
                )
        for internal in INTERNAL_REGEX_PATTERNS:
            if internal.pattern.search(value):
                key = (pointer, internal.label)
                if key in seen:
                    continue
                seen.add(key)
                errors.append(
                    make_error(
                        CODE_INTERNAL_IDENTIFIER,
                        path,
                        pointer,
                        f"fleet manifest contains {internal.label}",
                        CONTRACT,
                    )
                )
    return errors


@register(
    CHECK_NAME,
    [
        "fleet-manifest-schema",
        CODE_INTERNAL_IDENTIFIER,
        CODE_IDENTITY_DENYLIST_UNAVAILABLE,
        CODE_IDENTITY_DENYLIST_INVALID,
    ],
)
def run(paths: Iterable[Path]) -> CheckResult:
    errors: list[ValidationError] = []
    warnings: list[ValidationError] = []
    manifest_paths = iter_fleet_manifest_paths(paths)
    if not manifest_paths:
        return CheckResult(name=CHECK_NAME)

    try:
        denylist = _runtime_identity_denylist()
    except IdentityDenylistUnavailable as exc:
        denylist = None
        warnings.append(
            make_error(
                CODE_IDENTITY_DENYLIST_UNAVAILABLE,
                Path("validators/creator_engine_validator/data/identity_denylist.generated.yaml"),
                "",
                f"{exc}; CE-internal identity token scan skipped. Generate it from ce-ops with scripts/gen_identity_denylist.py --write when registry access is available.",
                CONTRACT,
            )
        )
    except IdentityDenylistError as exc:
        return CheckResult(
            name=CHECK_NAME,
            errors=(
                make_error(
                    CODE_IDENTITY_DENYLIST_INVALID,
                    Path("validators/creator_engine_validator/data/identity_denylist.generated.yaml"),
                    "",
                    f"runtime identity denylist artifact is invalid: {exc}",
                    CONTRACT,
                ),
            ),
        )

    if denylist is None and not warnings:
        warnings.append(
            make_error(
                CODE_IDENTITY_DENYLIST_UNAVAILABLE,
                Path("validators/creator_engine_validator/data/identity_denylist.generated.yaml"),
                "",
                "runtime identity denylist artifact is absent; CE-internal identity token scan skipped. Generate it from ce-ops with scripts/gen_identity_denylist.py --write when registry access is available.",
                CONTRACT,
            )
        )

    for path in manifest_paths:
        try:
            manifest = load_fleet_manifest(path)
        except FleetManifestValidationError as exc:
            errors.extend(exc.errors)
            continue
        errors.extend(_internal_identifier_errors(manifest.path, manifest.data, denylist))
    return CheckResult(name=CHECK_NAME, errors=tuple(errors), warnings=tuple(warnings))
