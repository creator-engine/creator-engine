---
name: ce-knowledge-ssot
description: CE learnings must live in one deterministic SSOT every controller checks independently — not probabilistic per-agent memory; capabilities probed not remembered
metadata: 
  node_type: memory
  type: project
  originSessionId: cb9529a3-0334-40ee-9ca9-b0f0434abc87
---

Operator principle 2026-06-21: CE's durable learnings (capabilities, conventions, decisions, gotchas) must live in **one authoritative source every controller checks INDEPENDENTLY + DETERMINISTICALLY** — not in probabilistic per-agent memories that are fallible, unshared, and force re-learning. This is CE's whole thesis (safety/persistence/predictability) applied to knowledge itself: re-learning the same facts = the opposite of advancing. Ticket: **ce-ops#166** (parent of [[ce-single-source-of-truth-ops-docs]] #162).

**Honest meta — this supersedes ME for shared facts.** CE's current auto-memory (this MEMORY.md system) IS the anti-pattern for *shared* facts: per-agent, free-text, skimmed by a probabilistic reader, no independent verification, no fleet-wide correction. It just held a WRONG fact ("codex lacks fan-out") that no peer controller could see/correct ([[ce-controller-spawns-many-workers]]). Boundary going forward: **per-agent/scratch context → agent memory; shared + verifiable facts → the SSOT (canonical).**

**Key requirements:** facts as machine-checkable assertions (not prose); loaded/validated at controller bootstrap (born-knowing, via [[ce-controller-spawns-many-workers]]'s #163 injection); **capabilities PROBED against reality, not remembered** (e.g. "does this harness have multi_agent_v1?" = a probe, never a stored claim — reproduce-don't-transcribe [[ce-verifier-hash-false-positive]]); drift-proof CI; corrected-once → fleet-wide. Sibling of the bounded-work-units tenet [[ce-bounded-workunits-tenet]] in the "deterministic > probabilistic" family.
