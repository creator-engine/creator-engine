---
name: ce-code-as-harness-paper-learnings
description: "The \"Code as Agent Harness\" survey (arXiv 2605.18747) → CE learnings/gaps/features report; the paper names CE's differentiators as open problems."
metadata: 
  node_type: memory
  type: reference
  originSessionId: 6ca73a06-2bec-4f3d-8882-8937ee7428be
---

**Reference report (2026-06-09):** `~/Documents/ce-code-as-harness-paper-learnings-20260609.md` — research seat's analysis of the UIUC/Meta/Stanford survey *"Code as Agent Harness"* (arXiv **2605.18747v1**) vs the real CE codebase.

**The durable findings (verify file:line before acting — point-in-time):**
- The paper = the academic articulation of CE's grader-outside thesis. E/V/S triad (Executable/Verifiable/Stateful) maps ~1:1 to CE substrate; the spine's `verify_chain()` is *more* than the paper asks (tamper-evident).
- **CE genuinely LEADS** on §5.2.5 **safety-as-harness-state** — SHIPPED (envelopes + `hook_check` + hash-chained spine + ratification records). This is the **NVIDIA-pitch headline** + the live demo (real `verify_chain`/envelope/push-deny). [[ce-push-deploy-authority-model]]
- **Honest seam:** the orchestrator's hypothesis was ~70% right. §5.2.3 (regression-free evo) + §5.2.4 (transactional shared state) rest on **DESIGN-ONLY** artifacts (`loop_governor`, coordination quorum in `.ce/state/research/`, NOT in `validators/`). Shipped answers are narrower: `version_boundary` static ratchet + PCO pessimistic leases. PCO *isolates* concurrent writes, does NOT *resolve* semantic conflicts (§5.2.4 gap). §5.2.2 semantic verification is delegated to humans (a position, not a solution).
- **Philosophical divergence to OWN in the pitch:** CE ships §3.5.3 Governed Harness Mutation but **deliberately rejects** §3.5.2 the autonomous "Evolution Agent" — grader stays outside, mutation is human-ratified.
- **Top feature candidate (F1):** a read-only **harness-health/Deep-Telemetry surface** over the spine (`runner/harness_telemetry.py`, pure projection) = the next Cockpit-B slice — "governance made visible." Highest leverage, substrate already shipped. F2 = ship the already-designed `loop_governor` via the strangeLoop track.
- **Vocabulary to ADOPT:** "governed agent harness," "safety-as-harness-state," "Deterministic Sensors," "Governed Harness Mutation." **AVOID claiming solved:** semantic verification (§5.2.2), harness-mechanism oracle adequacy (§5.2.1 deep), multimodal (§5.2.6). Don't conflate CE's "Scope" with the paper's "Scope boundary."

Feeds: [[ce-nvidia-v35-strategy]], [[ce-competitive-cockpit-b-inputs]], [[ce-v35c-strangeloop-coordination-design]]. Design-only; Operator ratifies before any feature gate. Sibling of [[ce-learning-reference-reports]].
