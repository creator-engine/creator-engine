---
name: ce-contained-seat-completed-but-unpushed-not-stalled
description: "A contained seat idle-on-main with no PR is often DONE-but-unpushed (no container auth), not stalled — check its worktree + harvest before re-dispatching."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a4e6df48-9f2a-4e66-b578-3690b46e4421
---

A contained dev seat showing "idle on main, no PR" after a dispatch does NOT mean the work stalled or failed. Contained seats have **no GitHub push auth** (GH_TOKEN unset; `git push` fails "could not read Username"), so a seat can fully COMPLETE + commit work in its worktree and still look idle-on-main to recon — because recon reports the *main checkout* branch, not the active worktree.

**Real case (2026-06-30):** The 1450Z resume flagged dev-3 #374 as "STALLED — idle on Main, no PR, re-verify + re-dispatch." It had actually finished: 4 commits in container worktree `/var/tmp/wt-ce-374-prepitch-docs-slice`, preflight GREEN, clean. It just couldn't push. Re-dispatching would have duplicated done work. Correct move was **harvest** (git-bundle out of container → push from controller → PR #689).

**Why:** contained-seat design = isolation substrate with fetch egress but no push creds; pushing is a controller-gate act. So "no PR from a contained seat" is the *expected* end-state of completed work, awaiting harvest.

**How to apply:** before concluding a contained seat stalled / re-dispatching, probe its **worktrees** (not just the main checkout): `git -C <worktree> log --oneline origin/main..HEAD` + `git status`. Committed commits above origin/main + clean status = DONE → harvest, don't re-dispatch. Pairs with [[ce-harvest-contained-seat-stale-origin]] (reconcile vs authoritative main, container origin is stale), [[ce-dispatch-territory-map-before-dispatch]] (recon misses worktrees), and the inverse [[ce-seat-done-not-committed]] (done-report w/o commit SHA ≠ done).

## Detail (moved from index 2026-07-05)
- probe the worktree + harvest.
- usually COMPLETED work (no push auth in container).
