---
name: ce-client-zero-brownfield
description: "CLIENT-ZERO lane (first external client, confidential): brownfield no-git Claude-Code app on Hetzner; ramp design RATIFIED 2026-06-12 w/ forks F1-F3; gates + tickets"
metadata:
  type: project
---

**First external CE client (confidential — ce-ops only, label `client-zero`).** Profile:
brownfield app built + still developed by Claude Code, deployed on a Hetzner VPS, NO
git/GitHub, agent mutating the live system, costly mistakes containing badly. Discovery call
2026-06-11.

**Two Operator gates before ANY client action:** ① CE v3 production-ready = OUR retirement
run lands (ce-ops#14) · ② the Brownfield Onboarding Ramp — designed, and **RATIFIED
2026-06-12 with forks: F1 capture IN-PLACE · F2 Phase 1 = manual-with-runbook under
per-step ratification · F3 shared App for client-zero** (per-client own Apps later).
Design: `ce-ops/designs/ce-brownfield-onboarding-ramp-design-20260611.md` (phases:
Stabilize→Capture→Govern→Migrate dev loop→Deploy gate).

**Tickets:** ce-ops#22 (design, RESOLVED) · **#23 v3.6-BF capture wave** (gaps G-A
onboard --brownfield / G-B secrets-scrub tree preflight / G-C baseline attestation —
BLOCKED BY #14) · **#24 Phase-0 intake pack + executable Phase-1 runbook** (composing).

**Strategic:** the secrets-scrub-before-first-commit step is LOAD-BEARING (no-git agent
codebases carry inline credentials — naive `git init && git add .` is dangerous). No
competitor has a no-git capture story (white space). Replit/SaaStr freeze-bypass incident =
public proof that policy freezes fail without a runtime gate — pitch material.
[[ce-pilot-env-hetzner-vps]] [[ce-team-mode-host-architecture]]

## Detail (moved from index 2026-07-05)
- #14+#23/#24.
- no-git Claude-Code app on Hetzner.
