---
name: ce-public-docs-playbooks-repos
description: Two NEW public repos created 2026-06-25 — creator-engine/docs (Astro Starlight human docs → docs.creator-engine.dev) + creator-engine/ce-playbooks (dual-use playbooks); the human-facing docs initiative
metadata: 
  node_type: memory
  type: project
  originSessionId: 9c67b023-0ac9-402b-9806-fa1c581c5303
---

Operator directive 2026-06-25: build human-facing docs (ref docs.openclaw.ai) + CE playbooks (ref github.com/overcut-ai/overcut-playbooks) — the agent-native `.md` is the machine SSOT; humans need real docs + runnable recipes. APPROVED decisions: **Astro Starlight** (open-source, not Mintlify) + **extend** `playbook.schema.yaml` (don't fork) + **public** repos.

- **`creator-engine/docs`** (public) — Astro Starlight site → **`docs.creator-engine.dev`**. Scaffolded: full CE IA (Get Started/Concepts/Guides/Playbooks/Reference/Operations), 4 `docs/guide/*` ported, deploy workflow + CNAME committed but **Pages NOT enabled**. **HELD for controller: build the Factory-Floor brand theme (Opus-only web design + a visual checkpoint to Operator) BEFORE enabling Pages.** Default theme currently; `THEME-TODO.md` in repo. (Host node too old for Astro 7 → CI uses node22.)
- **`creator-engine/ce-playbooks`** (public, Apache-2.0) — `FORMAT.md` = human-primary `PLAYBOOK.md` with YAML frontmatter (the machine contract: id/goal/prerequisites/steps/gates/mode/work_class) + prose; **dual-use = a human reads it AND hands it to their CE controller.** Exemplars: `author/first-governed-pr`, `review/governed-code-review`. Organized by CE spine (plan/author/review/merge/operate/ceo-mode).
- **`ce playbook run` CLI** (ce-ops#248) built by dev-1 (PR #467) — makes the dual-use playbooks executable (`list/show/run --dry-run`, projects PLAYBOOK.md → internal descriptor).

Ecosystem-page model (openclaw): card-grid + tier badges (Engine/Add-on/Internal); vocab Engine/Backend/Adapter/Service. [[ce-shipped-product-terminal-first]] [[ce-website-versioning-policy]] [[ce-website-design-claude-only]]
