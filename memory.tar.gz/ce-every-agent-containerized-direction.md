---
name: ce-every-agent-containerized-direction
description: "CTO/CEO direction — CE ships toward \"every agent is contained\" incl. the Controller under OpenShell (NEAR future, after pressing Ring-1/§8 work)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9856ffdc-c843-4966-a075-107dc335e56a
---

Operator (CE CTO/CEO) directive 2026-06-17: CE will move toward an **"every agent in CE is secured and contained"** architecture — including running the **Controller itself under OpenShell** (a containerized controller). **UPDATE 2026-06-17 — now PRE-PITCH CRITICAL PATH:** the NVIDIA pitch moved from 01-Jul to ~September (RTX/OpenShell launch; meeting was movable), so the containerized CE is to be **shipped before the pitch** ([[ce-nvidia-v35-strategy]]), not "near-future after pressing issues." This REOPENS the Env-4 disposition: the sandboxed-controller "no" is *now-only*, not permanent — and the Env-4 research's preconditions (S2/S3/§8b/§8c, OpenShell A.2b live-execute #82, credential broker, operator-witness bridge) are the **BUILD PATH to it**, not reasons for a permanent no. Operator decides timing. [[ce-operator-decides-relitigation]]

**Evidence / why (industry direction 2026):** Operator visited Microsoft (~2026-06-16), saw their "Secure agentic AI end-to-end" architecture. **MS Agent 365** = enterprise control plane for agents (observe/secure/govern: registry, publish-with-security-template, agent-map, management-rules, agent-tools, BYO-MCP governance) — i.e. Microsoft is productizing CE's category. **MS Scout** (separate intel) = OpenClaw running inside **Microsoft Execution Containers (MXC) + OpenShell** at the bottom layer (policy-driven shell-command restriction). **DECISIVE finding in the guide (p17 "View Shadow AI"):** Agent 365 detects + Intune-**BLOCKS** self-hosted agents — **OpenClaw detected now; Claude Code CLI, Codex CLI, Cursor, Ollama Desktop, Poe Desktop "coming soon."** → in M365-managed enterprises, an uncontained agent becomes blockable "Shadow AI"; **containment + registration is the path to being a *sanctioned* agent.** Aligns with NVIDIA NemoClaw (wrap any OS agent in a contained env). Containerization = the 2026 secure-agent norm.

**Implication for CE:** strengthens the OpenShell-as-substrate thesis ([[openshell-nemoclaw-stack]], [[ce-isolation-substrate-strategy]]) and the NVIDIA pitch ([[ce-nvidia-v35-strategy]]) — CE = the *governed-SDLC* layer over contained agents. Guide saved `~/Documents/MicrosoftAgent365GetStartedGuide.pdf` (src: adoption.microsoft.com/files/agents/MicrosoftAgent365GetStartedGuideMAC.pdf). Accuracy note: THIS guide shows control-plane + Shadow-AI blocking; the OpenShell/MXC/Scout linkage is from the Operator's separate Scout intel, not named in the guide.
