---
name: ce-openai-account-email-mapping
description: "The two GPT Pro accounts by EMAIL (neckar@ / amitaicoco1@) + the hard rule: verify the auth.json id_token email claim before/after every switch — never trust A/B labels or .bak filenames"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 61b01e4e-f0fa-453a-90f8-03a849b5c415
---

The codex fleet's two GPT Pro subscriptions, by the only label that matters — the account EMAIL:
- **neckar@gmail.com** (the Operator's primary; was historically called "acct A")
- **amitaicoco1@gmail.com** (the 2nd sub; was historically called "acct B")

**The trap (cost real churn 2026-06-26):** the "acct A / acct B" labels and the `auth.json.bak.B.<ts>` / `.bak.acctA.<ts>` filenames are NOT reliable — they drift as you switch back and forth, and `switch-openai-account.sh swap` prints a HARDCODED "swapped acct B auth.json" message regardless of which account it actually copied. I "switched back to acct-B" by restoring `.bak.B` (= amitaicoco1@) while the Operator had reset **neckar@** — putting dev-4 on the wrong, still-limited account, then misreading its live rate-limit as a stale pane.

**Hard rule — VERIFY BY EMAIL, never by label:** before and after any account switch, decode the `auth.json` id_token email claim and confirm it's the intended account. No tokens printed — email claim only:
```
python3 -c "import json,base64; d=json.load(open('<codex-home>/auth.json')); t=d['tokens']['id_token']; p=t.split('.')[1]; p+='='*(-len(p)%4); print(json.loads(base64.urlsafe_b64decode(p)).get('email'))"
```
Sizes happen to differ (neckar@ ~4847B, amitaicoco1@ ~4428B) but confirm by email, not size. When the Operator says "I reset X account," map X to the email and ensure the seat's live `auth.json` is that email — a seat showing "usage limit / try again at HH:MM" is almost always on the OTHER account, not a stale pane.

dev-4 contained codex home = host `/home/cedev4/.codex-contained` (NOT `.codex`); relaunch needs `CE_DGX_CODEX_HOME=/home/cedev4/.codex-contained` + clear `~/.ce/logs/seats/<seat>/xdg/config/herdr/session.json` first (ce-ops#250 — stale session.json shunts codex off w1:p1). See [[ce-openai-account-switch-playbook]] [[ce-seat-relaunch-canonical-launch-only]].
