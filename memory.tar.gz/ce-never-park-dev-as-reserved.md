---
name: ce-never-park-dev-as-reserved
description: "Never idle a dev as \"reserved\" (e.g. reviewer); every controller is a foreman — give it a lane to drive"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 66ba17c2-15bc-4894-a232-cbc995c57d15
---

I have repeatedly drifted into parking dev-1 as a "reserved reviewer" when it's idle (and rationalized it via thin context). Operator correction (2026-06-24): **no dev sits idle "reserved."** Every controller is a FOREMAN capable of driving multiple lanes, each with its own worker doing separate work.

**Why:** reviewing is an on-demand event, not a full-time occupation; a controller parked "as reviewer" is wasted capacity. Thin context is NOT a reason to park — foreman mode FANS OUT to workers, so the foreman's own context isn't the binding constraint (inlining is the anti-pattern, not delegating).

**How to apply:** when any dev (dev-1/3/4) goes idle, immediately give it a LANE to drive (a ticket or cluster), instructing it to operate as a foreman — launch/fan-out workers for the heavy build/research, keep its own context for coordination + the local gate. Reviewing happens alongside, not instead of, driving a lane. See [[ce-seats-foremen-self-managed-fanout]], [[ce-controllers-proactive-pickup]], [[ce-controller-spawns-many-workers]], [[ce-codex-foreman-directive-durable]] (re-assert foreman directive post-compaction).
