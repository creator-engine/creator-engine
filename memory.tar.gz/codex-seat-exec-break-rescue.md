---
name: codex-seat-exec-break-rescue
description: How to rescue a codex seat whose exec subsystem wedges mid-task without losing uncommitted work
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f43c293c-4148-40a5-874e-4ee7e4372de0
---

A codex seat's internal exec ("Failed to create unified exec process: No such file or directory (os error 2)") can wedge mid-task — it can no longer spawn ANY tool process (even `pwd`), often after heavy load (e.g. a docker build + gVisor container churn). Observed 2026-06-23 on dev-4 (DGX) during the #395 U-LAUNCHER dry-run.

**Why:** the codex harness's exec wrapper corrupts, NOT the box or the user shell. Verify: the host is healthy (`free -h`, no OOM in dmesg), the codex PID is alive with a valid cwd, and a **plain `ssh <seat>` shell still works fine** — only codex's exec is dead.

**How to apply:**
1. Don't panic-restart. The uncommitted work is intact in the seat's working tree (often a /tmp checkout the seat reported).
2. Rescue via the seat's PLAIN ssh shell (works even when codex is wedged): `cd` the tree, review the diff, verify a clean fast-forward (`git merge-base --is-ancestor origin/<branch> HEAD`), commit (preserves the seat's git authorship), and `git push <local>:<pr-branch>`. The work is now safe on the PR.
3. Do NOT C-c/kill dev-4's pane (standing rule [[ce-dev4-strongest-route-hardest-work]]). Recover the seat via canonical relaunch ([[ce-seat-relaunch-canonical-launch-only]]) — or, if the seat is pending containment conversion, let the contained relaunch BE its recovery (recovery = conversion).
4. Any further fixes while the seat is down: drive them through the same plain shell, or a controller worker lane.

The controller-as-rescue-operator is legitimate incident response here, not the usual inline-drift ([[ce-controller-inlines-execution-drift]]) — only the controller is positioned to reach the seat's tree.
