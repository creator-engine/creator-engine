---
name: ce-post-tmux-direction
description: "Operator directive (2026-06-12) — CE will move away from tmux as execution substrate; next-phase shape = deliberate post-pitch design decision (ce-ops#35); don't deepen tmux coupling without flagging it"
metadata: 
  node_type: memory
  type: project
  originSessionId: bfd80365-c499-4779-a81e-19909ae7ac19
---

**Operator directive (2026-06-12, ce-ops#35):** CE started tmux-based and **will move away from it** — tmux isn't the right shape for the all-encompassing dark-software-factory / full-SDLC solution. Next-phase execution shape = a deliberate design decision (post-pitch research+architect dispatch → ratifiable direction paper), not drift.

**Why:** the 2026-06-12 retirement run produced two live tmux-shape defects (venue pane cwd; env inherited from the tmux server, not the launching shell) — 4 venue-chain gotchas to date, all substrate-induced; and the #34 forge-side conveyor is headless by nature. **Preserve the tmux virtues portably:** witnessability (attach/replay), explicit governance seams (per-seat env/hook/envelope injection — never inherited ambience), evidence capture, laptop-first-class.

**How to apply:** until #35 is decided, flag any design that deepens tmux coupling (new pane choreography, env tricks) with its coupling cost; candidate shapes (containers-per-seat / headless SDK seats / cloud runners / hybrid) slot into the existing `RunnerBackend` seam — don't reopen [[ce-substrate-acp-decision]]. n8n-fork hypothesis about Overcut REFUTED 2026-06-12 (bespoke flow DSL — edge-list + steps, verified from their playbooks repo). [[ce-three-layer-pitch-thesis]] [[overcut-competitive-reference]]
