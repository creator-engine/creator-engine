---
name: ce-controller-verified-bootstrap
description: "Every CE controller must bootstrap on startup from a verified SSOT (identity + CE + playbooks), enforced by the outer layer — not re-learn/re-derive from drifting memory each context-clear."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 04cb5ced-a042-44e0-86cd-4bf66a556066
---

A CE controller re-learns and un-learns on every context-clearance / restart. That is the root cause of re-deriving operational procedures and getting them wrong — the 2026-06-24 session alone: relaunch churn, missing `--dangerously-bypass-approvals-and-sandbox`, the VPS trust-write loop, the `herdr send-text` dispatch not landing, the merge-queue-vs-`autoMergeRequest` confusion, and a fallback-logic misfire. Today my startup knowledge comes from hand-curated MEMORY.md + a resume-state file + a stale handoff doc — all of which drift and none of which I verify.

**The fix = a VERIFIED CONTROLLER BOOTSTRAP.** On startup every controller runs a setup sequence that loads the basics from a deterministic SSOT: (1) **what am I** — identity/role/host/creds; (2) **what is CE**; (3) **where is the SSOT** from which I draw playbooks; (4) the **playbooks** themselves = codified, self-verifying, agent-invokable actions (launch/relaunch a contained seat, dispatch a task to a seat, fire a reviewer venue, push Model-B, probe containment, retire a seat, merge a PR via the queue, …). And the controller **VERIFIES what it loads** — probe identity, creds, live fleet state, playbook validity — it never just trusts received information (probe-don't-assert, lifted to the knowledge/bootstrap layer). **CE's OUTER LAYER (harness/launcher) enforces the bootstrap** so it cannot be skipped.

This is the organizing purpose behind the SSOT + playbooks + OpenBao morning-arc items, which are ONE coherent thing, not three: **SSOT** = where identity + playbooks live (code-synced, not hand-curated memory); **playbooks** = the executable self-verifying actions; **OpenBao/SecretIdentityBackend** = where the controller's startup creds/identity are sourced + verified (not scattered loose in `~/.ce-keys`); **bootstrap** = the enforced, verifying startup that wires them in.

**Why:** Operator 2026-06-24 — "controllers don't relearn and unlearn on every context-clearance event; there has to be an SSOT and playbooks so every CE controller coming to life does a quick startup setup to get the basics into memory (what am I, what is CE, where is the SSOT for my playbooks), and a controller doesn't just rely on information he receives, he verifies it; and CE's outer layer makes sure he does this."

**How to apply:** treat startup as *load + verify from SSOT*, not recall from context. When the SSOT/playbook for a procedure doesn't exist, *building it IS the work* — do not hand-roll the incantation. Never trust a remembered procedure — verify it against the SSOT and live state. Supersedes the ad-hoc MEMORY.md/handoff bootstrap. Links [[ce-codified-actions-not-rediscovery]] [[ce-knowledge-ssot]] [[ce-single-source-of-truth-ops-docs]] [[ce-resume-state-seat-header-protocol]] [[ce-three-deputy-governance-model]].
