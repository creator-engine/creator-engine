---
name: ce-a2seq-singleton-cutover-ratified
description: A2-SEQ Option A RATIFIED 2026-07-04 — merge-gate queue-daemon is a policy singleton; containerized form replaces host daemon via cutover; review-pickup decoupled
metadata: 
  node_type: memory
  type: project
  originSessionId: 632322c0-1844-443f-a8f3-3f89ea2e7f9c
---

Operator ratified 2026-07-04 (~17:55Z, in-session form-echo): **live merge-gate authority
(queue-daemon + approval-wall) is a policy SINGLETON**. The containerized queue-daemon REPLACES
the DGX host daemon via stop-old→start-new cutover; host launcher `~/ce-wall-daemon-launch.sh`
stays as kill-switch until ≥3 arc-days green soak. review-pickup (routing-only authority class)
may go live on dev-1's containerized form INDEPENDENTLY once its OpenBao identity wiring lands.
Fail-closed startup lease for queue-daemon commissioned as fast-follow = **ce-ops#444**. Any ownership move to another host = separate cutover under the same singleton rule.
Active-active (distributed lease) explicitly REJECTED as premature.

Memo SSOT: `.ce/state/research/A2_DOUBLE_DRIVE_SEQUENCING_DECISION_20260704.md` (marked RATIFIED).
Evidence basis: queue-daemon has no mutual-exclusion seam; marker mint = unguarded read-modify-write
of PR body; settle windows are per-instance state. Related: [[ce-l2-automerge-golive-decision]]
[[ce-wall-daemon-token-expiry-restart]] [[ce-approval-wall-stale-marker-head-mismatch]]

## Detail (moved from index 2026-07-05)
- containerized replaces host daemon via cutover (host launcher = kill-switch, ≥3 arc-days soak); review-pickup decoupled; startup-lease fast-follow filed.
- -gate queue-daemon = policy singleton.
