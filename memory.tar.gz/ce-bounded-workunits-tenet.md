---
name: ce-bounded-workunits-tenet
description: Bounded work-units (small batches) is one core CE tenet behind BOTH the rebase-hell fix and the seat-bottleneck fix
metadata: 
  node_type: memory
  type: project
  originSessionId: cb9529a3-0334-40ee-9ca9-b0f0434abc87
---

Operator synthesis 2026-06-21: **keep every work-unit small enough to stay efficient** is ONE principle (DORA's "small batches" — a value-stream tenet, not a PR-specific rule), and it is the shared lever behind **two distinct CE structural problems**:

- **"Endless rebase-hell"** → a **controlled merge system between developers and `main`** (merge queue/train + auto-rebase + green-trunk; prior art: GitHub merge queue, Bors, Zuul, Google submit-queue). Small merge-units make it tractable; the queue enforces small + serialized + reviewed-before-main. Instance: [[ce-... ]] ce-ops#164 (small-PR/change-size + the wheel-serialization fix).
- **"Endless seats bottleneck"** → **foreman delegation** ([[ce-controller-spawns-many-workers]]): keep direct work small, decompose the rest into small worker-tasks you manage; scale by delegation depth, not seat count. Instance: ce-ops#163.

**They govern different units and want different numbers, but the principle + the reason (efficiency, prevent-by-design) are identical.** Do NOT reduce this to "two different line-budgets" (the mistake I made first) — it's one tenet, two applications. The size limit is the shared *knob*; for the merge-unit the metric is ~lines (grounded ~200/400, [[ce-... ]] research on #164); for the foreman budget the metric is **action-type × irreversibility**, NOT lines.

Parent ticket = **ce-ops#165** (likely graduates to an ADR). Connects existing doctrine: [[ce-energy-efficiency-ceo-mode-gravity]] (delegation gravity), [[ce-no-mvp-quality-from-day-1]] (prevent-by-design), [[ce-product-north-star]] (grader-outside-the-agent). Bounded work-units is the operational expression of all three.

## Detail (moved from index 2026-07-05)
- Related: [[ce-dispatch-ordering-discipline]] [[batch-strict-mode-gate-workflow]]
