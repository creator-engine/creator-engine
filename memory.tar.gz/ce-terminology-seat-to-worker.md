---
name: ce-terminology-seat-to-worker
description: "2026-06-18 terminology amendment — \"seat\" → \"worker\"; \"controller\"→\"foreman\" candidate only"
metadata: 
  node_type: memory
  type: project
  originSessionId: 3d84878f-7476-4bab-8598-c35b8c1edce1
---

**Operator terminology amendment 2026-06-18 (ce-ops#116):**
- **DECIDED:** "**seat(s)" → "worker(s)**" across CE vocabulary/canon. Factory metaphor: CE = the factory/platform; coding agents = the robots; the **workers** are the agents CE manages.
- **CANDIDATE only (undecided — do NOT assert):** "controller" → "foreman". 'foreman' pairs coherently with 'worker', but Operator finds 'controller' more intuitive. Track as open.

**Concept unchanged** — two robot roles: the **managing** agent (controller; the one the user talks to / drives from cockpit) + the **worker** agents it dispatches. Only the worker-role noun changes.

**Apply:** in new writing prefer "worker" over "seat" for the worker role; keep "controller" (not "foreman") until decided. Code/schemas/docs still say "seat" until the migration ticket lands — a vocabulary migration (code `seat_lifecycle`/`seat_reaper`/`seat_env_file`/schemas, docs, cockpit labels), sequenced w/ compat window, like the stage-vocabulary canon precedent. Coordinate with the docs portal (#37) so public docs ship in the new vocabulary.

**Worker ROLES — refinement 2026-06-18 (Operator directive, sibling of #116):** every CE worker carries a defined named **role** — e.g. **implementer, researcher, designer, reviewer** (consider also architect/planner; controller/foreman is the managing role). Workers are referred to by role in CE (e.g. "codex researcher", "implementer worker") → operations become better-defined and more structured (role-routed dispatch, like Superpowers' one-subagent-per-task / Spec Kit's per-phase roles). Canonical taxonomy proposed + **ce-ops#118 FILED 2026-06-18** to ratify it (maps roles to existing v1/v2 authority categories; no agent gains ratification). Bake the role concept into the #116 terminology work. Full findings + execution-contract rulings: [[ce-speckit-superpowers-whathow]]. See [[ce-controller-steers-seats-execute]].
