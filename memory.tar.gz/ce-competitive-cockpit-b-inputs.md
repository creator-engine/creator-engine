---
name: ce-competitive-cockpit-b-inputs
description: Two competitive analyses (memo + overcut) CONVERGE on 4 CE priorities → a durable synthesis artifact to CITE in the v3.5-B Cockpit architect handoff
metadata: 
  node_type: memory
  type: project
  originSessionId: 4161bee6-8595-4cc1-933c-1c7068380752
---

**READ when composing the v3.5-B (Cockpit) architect handoff** (and the product-surface work). Two independent, adversarial competitive scans — **gitpod-io/memo** (open-source app-build process) and **overcut.ai** (closed-source enterprise agentic-SDLC control plane), each researched by a separate Codex gpt-5.5 seat — **CONVERGE on the same four CE gaps.** Convergence from independent sources = a strong design steer.

**Durable synthesis (the citable doc):** `~/Documents/ce-competitive-synthesis-cockpit-b-inputs-20260609.md` — distills both reports into Cockpit-B design inputs + guardrails. Source reports: `~/Documents/ce-vs-memo-analysis-20260608.md` + `~/Documents/ce-vs-overcut-analysis-20260608.md` ([[ce-learning-reference-reports]]).

**The 4 converged priorities (each re-expressed through grader-outside — NOT imported as agent-trusted state):**
1. **Playbook / Scope-template catalog** (as ratifiable Scopes w/ manifest+mutation-class+spend defaults, not prompt-files-as-contract).
2. **Cockpit = governed fleet *operations* board** w/ real execution control — **locks (repo/branch/PR/issue/Scope-family), priorities, dedup, queues, concurrency, On-Hold/escalation** + post-Ship ops loops (memo: "operations needed more automations than build"). Locks/queues = EXTERNAL scheduler state, never agent claims.
3. **Evidence-backed memory/retrospectives** (the deferred durable Skill axis) — tentative→active→policy-affecting; policy/budget/mutation-class memory NEVER agent-promoted; ratified-before-it-binds.
4. **Product-grade evidence-projected metrics surface** (both reports' "Rec 5") — governed runs / tokens-hr+spend (fed by D.0.1+D.0.2) / cap events / escalations / manifest-failures / OpenShell denials. Same surface as the **D.0.3 compute-demand artifact.** Projections from the hash-chained evidence, not transcripts.

**Cross-cutting reads:** make governance VISIBLE ("logged ≠ externally replayable + policy-bound" — CE's gates are readable code, overcut's core is closed); perceived-readiness THREAT/urgency (rivals are deployable-this-quarter; don't let them define the category first); segment = overcut enterprise/platform-first (Azure, NO OpenShell/RTX) vs CE solo/small-team self-run → benchmarks not substitutes; the NVIDIA wedge is uncontested. **Do-not-import list** (self-merge, closed-claims-as-evidence, visual-builder-as-Scope, execution-pricing, hosted-default) in the synthesis doc.

Twin of [[ce-nvidia-v35-strategy]] (the v3.5 arc these feed) + [[ce-codex-controller-budget-offload]] (both probes were Codex graded trials, both PASSED).
