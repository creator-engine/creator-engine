---
name: ce-seat-probe-docker-exec-not-run
description: "Probe contained seats via `docker exec` into the live container, never a throwaway `docker run` (orphans accumulate)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 23673196-2290-4824-886a-497beda4df7e
---

When a worker needs to inspect a contained seat's container (socket paths, uid, env, image contents), use `sudo docker exec <live-named-container> ...` — NEVER `docker run` a fresh throwaway container.

**Why:** the herdr harness entrypoint backgrounds `herdr server` then `wait`s on it, so a one-shot `docker run` (even with `--rm`, even under gVisor runsc) never exits — the user command finishes but the container runs indefinitely and orphans accumulate. Found 2026-06-27: 2 orphaned probe containers (`id`, socket-`ls`) on the VPS, both spawned by my own seat prep/dispatch worker probes. The canonical relaunch (`run-vps-runsc.sh`, `docker run -d --name ce-vps-codex`) can't accumulate duplicates — only ad-hoc probes do.

**How to apply:** bake "probe via `docker exec` into the named live container; never `docker run` a throwaway; if you must `docker run`, override the entrypoint and ensure it exits" into every seat prep / dispatch / recon brief. Durable infra fix ticketed (run-vps-runsc.sh explicit `rm -f` + VPS `docker container prune` cron). Relates to [[ce-seat-relaunch-canonical-launch-only]].

## Detail (moved from index 2026-07-05)
- throwaway `docker run` orphans.
- via `docker exec` into the live container.
