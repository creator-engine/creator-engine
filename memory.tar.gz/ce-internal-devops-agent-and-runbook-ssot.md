---
name: ce-internal-devops-agent-and-runbook-ssot
description: "Fleet-infra ops should route to a dedicated internal CE DevOps agent per codified runbooks, not ad-hoc orchestrator sudo. Tracked in ce-ops#384. Orchestrator HAS passwordless sudo on the VPS."
metadata: 
  node_type: memory
  type: project
  originSessionId: d0a9fc77-23a0-480d-a261-1a7d96e0d811
---

Operator directive (2026-07-02): internal infrastructure ops (host guards, OpenBao/token lifecycle, daemon/seat health + recovery, image rebuilds) must be owned by a **dedicated governed CE DevOps agent** — an internal "IT department" — acting per **codified devops playbooks/runbooks**, so the build orchestrator ROUTES infra tasks to it rather than improvising sudo. Coupled with a **DevOps/runbook section in the infra SSOT** (extends infra/identity-registry.yaml / ce-ops#137) documenting each CE machine (DGX Spark, Hetzner VPS, laptop peer, seat containers), users/uids, credential POINTERS (OpenBao-ref, zero secrets), reach methods, and standard procedures. Filed as **ce-ops#384** (distinct from #33 = user-facing DevOps product persona, and #137 = the data registry).

Operational fact confirmed: **the CE-DEV-2 orchestrator HAS passwordless sudo on the VPS** (`ssh dev1 'sudo …'`) — used to durably fix ce-ops#184 (/tmp tmpfs guard) live.

**Why:** reconstructing an ops procedure from memory each time IS the bug (the 2026-07-02 OpenBao multi-hour recovery + the #184 ad-hoc fix are the evidence). **How to apply:** until #384 ships, the orchestrator still handles infra directly (has the access), but capture each procedure as a runbook so it's routable later; don't treat these as build work. Related: [[ce-codified-actions-not-rediscovery]] [[ce-approval-wall-daemon-token-durable-recovery]].

## Detail (moved from index 2026-07-05)
- orchestrator HAS passwordless VPS sudo.
- persona per codified runbooks (ce-ops#384).
