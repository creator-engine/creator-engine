---
name: ce-agile-shape-open-question
description: "RESOLVED 2026-06-05 — CE coordination-hierarchy shape settled (XP+Kanban+Shape-Up appetite; PRD→epic→story→task PRESERVED as OPTIONAL crosswalk traceability; ratified-Scope atom + durable Skill 2nd axis; two-end gate risk-tiered by mutation-class). Grounded in current-dated research."
metadata: 
  node_type: memory
  type: project
  originSessionId: b851d6f0-6527-4abc-91a1-158eac33141c
---

**✅ RESOLVED 2026-06-05** — the coordination-hierarchy SHAPE is locked, grounded in a current-dated research pass (frontier agentic-team practice + the spec-driven frameworks + the Agile-evolution discourse). **The settled position:**
- **KEEP (validated):** XP engineering discipline (TDD/CI/small-batches as hard inner gates) + **Kanban continuous flow**, WIP-limited on the *real* bottleneck — **human review**, not agent concurrency.
- **SHED (validated):** sprints, velocity, estimation, standups, sprint-commitment.
- **PLAN BY appetite** — anchor to **Shape Up's "fixed time, variable scope / appetite / betting table"** (real lineage + AI-era renaissance). **Drop the coined "scope-box"** — it has no industry traction; Shape Up's vocabulary is the attested one. The betting table = CE's constrained-BDFL ratification.
- **ATOM = the ratified *Scope*:** a scope-boxed task with verifiable acceptance criteria, isolated per-agent execution, its own PR (Devin's published "session" ≈ 4–8 junior-eng-hours = the concrete sizing datapoint). The agent-native backlog item.
- **SECOND AXIS = durable *Skill*** (reusable capability module, OpenClaw pattern), distinct from the ephemeral Scope. CE models BOTH axes — the genuinely new structural element.
- **Decomposition tree PRESERVED as OPTIONAL traceability** (= `crosswalk_register`, collapsible), NOT a mandated estimation/iteration hierarchy. Frontier practice *flattens* PRD→epic→story→task to PRD/spec→vertical-slice-Issue→isolated-run; **CE deliberately keeps the optional tree for audit/traceability (its north-star) — a justified divergence, owned as a choice.**
- **GATE = two ends + risk-tiered by mutation-class:** front = DoR (spec + acceptance criteria + appetite + mutation-class) + ratification; middle = CI + the runtime action gate (automated); back = ratified PR-merge with per-`mutation_class` `human_ratification_required` thresholds. The "humans → Operators except critical parts" trajectory = that per-class threshold dial.
- **STATE = committed artifacts** (issues-as-files / crosswalk + evidence chain), not a Jira FSM; state is a projection over (ratified? + DoR? + CI? + merged?).

**Evidence caveat:** direction well-grounded but the evidence base is THIN (only RCT = METR's 19% *slowdown* on stale tooling; DORA = gains conditioned on mature practice + a stability cost; Fowler: "too early" for a new manifesto) — treat as informed design, not proven. **Attribution corrections:** the `grill-me→to-prd→to-issues→tdd` pipeline is **Matt Pocock's** (`mattpocock/skills`), NOT OpenClaw; the "minimize-trunk/push-to-skills" slogan is inferred, not an OpenClaw quote.

Full synthesis + the Scope/Skill/crosswalk/gate-chain mapping onto CE primitives lives in the live design thread ([[ce-coordination-design-resume]]). Builds toward the coordination-hierarchy artifact.

---

**ORIGINAL FRAMING (now resolved — kept for provenance):**

**Operator-flagged prerequisite (2026-06-05):** before CE introduces ANY Agile construct into the coordination layer — specifically the `PRD → epic → story → task → PR → merge` auditable graph, the sub-issue hierarchy, and the backlog lanes (see [[ce-learning-reference-reports]] #5, the coordination-layer design) — **hold a thorough discussion on which *shape* of Agile is actually relevant in the era of agentic coding.**

**Stance:** CE **augments** Agile, does NOT discard it. There is an active industry debate about Agile's relevancy under agentic coding; CE's position is to keep the value layer and shed the human-pace machinery.

**Why this matters / how to apply:** the risk is importing Agile's *vocabulary* (epic/story/task, backlog, sprints) while silently smuggling in its *human-pace assumptions*. Grounding from the earlier learning arc to bring into that discussion:
- Agile = philosophy/values (iteration, feedback, respond-to-change); Scrum/Kanban = the structured implementations.
- Scrum's **time-boxed ceremonies are pace-bound** (sprints/standups/velocity assume human coding speed) and dissolve in the agentic era; the value-bound parts (review/feedback, retro) survive, re-formed as continuous.
- CE's move: **time-box → scope-box** (the ratified closed-manifest gate replaces the sprint); coordination becomes **continuous-flow / Kanban-shaped** + SDD as the inner production technique.
- The agent-native artifact redesign (machine-readable backlog item with its own acceptance oracle; the deferred machine-readable OKR / objective layer) is the forward edge.

**Gate:** treat this as a DECISION to make before building the coordination hierarchy artifacts, not after. Relates to [[ce-product-north-star]] and [[openclaw-steipete-prior-art]].
