---
name: ce-context-observability-issue-157
description: "Design input + pointer — GH issue #157 (Controller/co-pilot context-window observability: status bar + threshold checkpoint/clear nudges), deferred to G-6/G-7. The SIBLING of the G-5 spend meter → unify into ONE session resource/health surface. Must live PROJECT-level/CE-native (governed seats exclude user ~/.claude). Shapes G-6/G-7 prompts."
metadata:
  node_type: memory
  type: project
  originSessionId: b6a2d418-c215-4a71-ad2d-313d4465738c
---

**Tracked as [creator-engine/creator-engine#157](https://github.com/creator-engine/creator-engine/issues/157)** — "CE UX: Controller context-window observability (status bar + threshold nudges)", `enhancement`. Filed 2026-06-07 as **design input for G-6 (coordination) / G-7 (product surface)**, NOT a v1 change (v1 frozen → deferred). Operator-endorsed 2026-06-07.

**Root finding:** governed CE seats launch `claude --setting-sources project` → loads ONLY repo `.claude/settings.json`, EXCLUDES user `~/.claude/` → a user-level `statusLine`/`UserPromptSubmit` hook never reaches a governed Controller, so governed seats show no context bar + no threshold nudge. The authoritative context % comes from the HARNESS, delivered ONLY to the statusLine command (agents self-estimate unreliably — guess high).

**Synthesis (how it fits the v3 design):**
- **Context usage = the SIBLING of SPEND (G-5).** Don't design a one-off bar — fold into ONE "session resource/health" surface: the pilot-uiux status line already shows stage+counts → add spend% (G-5) + context% (#157). The context threshold-knob belongs in the SAME config + Default/Custom installer profile as the G-5 cost knobs ([[ce-g5-cost-enforcement-optout]]).
- **CE already practices it manually** ([[report-context-each-turn]] + the RESUME_STATE checkpoint discipline) → productize.
- **DIFFERENTIATOR (state-as-artifacts):** CE checkpoints to a structured durable resume artifact + resumes cleanly in a fresh window at the context cliff; bare agents only lossy-compact. "Your agent under CE never falls off the context cliff" — fits pilot-uiux "CE must FEEL like CE."
- **Transport-agnostic CONTRACT** ([[ce-substrate-acp-decision]] pattern): a `context_budget` observation; CC fills it via a PROJECT-LEVEL statusLine+hook (survives `--setting-sources project`); ACP = typed field; plain subprocess = estimate/unavailable. Best-effort by tier.
- **Architectural requirement (the issue's core):** lives at PROJECT-level `.claude/` OR a CE-native channel — NOT user settings (governed seats exclude them by design; keep seats hermetic; don't change the Ring0 `--setting-sources project` posture).
- **Nuances:** use the HARNESS authoritative number (not the agent's self-estimate); the nudge must be BOUNDARY-AWARE (suggest checkpoint+`/clear` at SAFE boundaries — between Scopes / after a Completion Report — never mid-run); "save state" = CE's structured checkpoint, not a raw dump; targets the LONG-LIVED co-pilot/Controller seat (boxed workers are ephemeral).
- **Lands:** a G-7 status-line element + a G-6/G-7 session-policy knob, unified with the G-5 resource surface. **Apply:** cite #157 + this synthesis in the G-6 + G-7 planning prompts.

**Instance-local technical appendix (gitignored under `.hermes/`, this machine only; [[ce-hermes-vs-ce-state-roots]]):** `.ce/state/research/ce-governed-statusline-monitor-proposal-20260607T124111Z/PROMPT_ce_governed_statusline_monitor.md` (SUPERSEDED gate proposal, DO-NOT-EXECUTE — retains the vendored scripts, warn-45/urgent-60 thresholds, `--setting-sources project` analysis) + `…/ISSUE_ce_controller_context_observability.md` (posted issue body). Off-machine, only the GitHub issue is visible. Cross-refs: [[ce-v3-roadmap-to-pilot]], [[ce-product-north-star]].
