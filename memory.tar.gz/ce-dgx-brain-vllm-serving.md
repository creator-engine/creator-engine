---
name: ce-dgx-brain-vllm-serving
description: DGX company-brain embedding stack — vLLM Qwen3-Embedding-8B serving + recall index + durability (SSOT pointer)
metadata: 
  node_type: memory
  type: reference
  originSessionId: 456001b1-fbac-429f-acc1-b74f71b05b5a
---

> ⚠️ **PARKED as of 2026-06-29 ~23:53 (local) — GPU contention.** A deliberate **Qwen3-Coder generation serving stack** was stood up ~20:39 (docker containers `vllm` serving `/models/coder` gpu-util 0.85 ~98 GiB, + `open-webui`/`gateway`(litellm)/`grafana`/`prometheus`/`litellm-db`). On the GB10's 121 GiB UNIFIED memory the embeddings brain (needs ~85 GiB at util 0.7) no longer fits → it crash-looped (systemd `Restart=on-failure`, counter hit ~468, `ValueError: Free memory cuda:0 10/121 GiB < desired 85 GiB`). I **stopped** `vllm-qwen3-embed.service` (futile loop) + stopped the auto-restart watcher. **The two services cannot coexist on one GB10 — Operator capacity decision pending** (which wins / partition util / move one off-box). To restore the brain: free GPU (stop/shrink the coder stack) then `systemctl --user start vllm-qwen3-embed`, OR lower BOTH services' gpu-memory-utilization to fit (8B-embed needs ~16 GiB min). Embeddings/recall are OFFLINE until then (NOT on the support-pilot path — pilot uses OpenRouter).

The company brain's embedding stack runs **host-local on the DGX (spark-b824)**:

- **Serving:** vLLM serves **Qwen3-Embedding-8B** (Apache-2.0) at `http://127.0.0.1:8989/v1/embeddings` — OpenAI-compatible, **dim 4096**, `--runner pooling`, GPU/SM121 (~80 GB resident, `VLLM::EngineCore`), ~111 ms warm. Loopback-bound (any local user can curl it; not egress).
- **Process/durability:** venv `/home/cedev2/vllm-qwen-venv`; start `/home/cedev2/vllm-qwen3-embed-start.sh`; log `/home/cedev2/vllm-qwen3-embed.log`; systemd **user** service `vllm-qwen3-embed.service` (ENABLED + `loginctl enable-linger cedev2` → survives reboot).
- **Recall index:** `.ce/state/brain/recall-qwen3-8b.sqlite` (Qwen3-8B, dim 4096). Keyword baseline still at `.ce/state/brain/recall.sqlite`. Query: `ce brain recall "<q>" --embedder vllm-openai --db .ce/state/brain/recall-qwen3-8b.sqlite` (endpoint/model/dim defaults already point here).
- **Adapter:** `brain_embedding_openai_endpoint.py` (`vllm-openai` backend; localhost = `requires_egress=False`) — merged in **PR #619**. Embedder choice rationale: `.ce/state/research/EMBEDDER_DECISION_THREAD_20260628.md`.

**Authority:** the infra SSOT is **`ce-ops : infra/identity-registry.yaml`** — this service must be added there (a `host_services`/`services` section; currently absent), tracked under [[ce-knowledge-ssot]] / ce-ops#137+#269. This memory is a recall pointer, NOT the source of truth — the registry wins on conflict. Consumed by the DevOps-agent persona (ce-ops#33). Related: [[ce-dev2-dgx-py314-venv]].

## Detail (moved from index 2026-07-05)
- SSOT=ce-ops identity-registry.yaml (#137, services-section gap).
- durable via systemd-user+linger.
- 8989 (dim 4096) + recall-qwen3-8b.sqlite.
