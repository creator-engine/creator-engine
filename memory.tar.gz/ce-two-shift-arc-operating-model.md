---
name: ce-two-shift-arc-operating-model
description: "CE runs two shifts/day (morning+night); each shift's arc is PRE-DRAWN + batch-ratified in advance, then the controller drives autonomously."
metadata: 
  node_type: memory
  type: project
  originSessionId: bd40e3b4-6d32-4603-a038-013c53cd022e
---

CE operates in **two shifts every day — morning and night**. The doctrine: for each shift, **draw the arc in advance** (theme + gates + dependencies + ordered wave), **collect ONE batch of Operator ratifications** ([[batch-strict-mode-gate]] + [[ce-precondition-frontloading]]), THEN the controller drives the shift **autonomously** (escalate only on ⏸️).

**Arc = a ce-ops issue** (`[arc] <shift>-Shift Arc — <date> — <theme>`), modeled on the night-arc #129 pattern: mandate + grants + gate table (with per-gate ratification anchors) + a live log the controller appends SHAs to. Deferred items roll to the next shift's arc.

**Live arcs (2026-06-21):**
- **Morning = ce-ops#169** — theme "deterministic-substrate / CE-dev-pace unblockers." Gates G-A…H (brain #167/#298, foreman #163/#297, work-sizing #168/#296, egress #292, ADR-0010 wheel F-wheel-1/2, ADR-0006 reloc). Was formalized MID-shift (emergent → manifest) — a doctrine deviation; going forward arcs are pre-drawn.
- **Night = ce-ops#170** — 🟡 PRE-DRAW shell (candidate gates N-1…6: work-sizing F2, foreman live-arming, wheel Phase-B Gate2/3, company-brain Phase-2 recall, morning carryover). Must be finalized + batch-ratified at the morning→night handoff BEFORE driving.

**Why:** Operator 2026-06-21 — running a shift off point-by-point inline ratifications (what the morning shift actually did) only works while the Operator is present; the doctrine is pre-draw + batch-ratify so the controller can run unattended. **How to apply:** at each shift handoff, reconcile the prior arc (strike merged, fold carryover), finalize the next arc's gate list, present the batch checklist as ONE SHA-pinned prompt, drive only after ratification.
