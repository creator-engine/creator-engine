---
name: ce-idle-seat-is-controller-failure
description: "Operator doctrine 2026-07-08 — an idle seat while backlog exists = controller-side failure (intake/conveyor/arc), never a normal state; seats carry stocked queues, zero idle seconds"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f99580bf-11af-4c3c-9cba-aa07611522b9
---

Operator doctrine (2026-07-08, on finding 3/3 seats idle against 157 open ce-ops tickets and a
two-week roadmap backlog): **any second the fleet is not at full steam means something is wrong
at the roadmap/arc/conveyor/controller level — never at the seat level.** Every seat is born a
foreman able to drive multiple tickets concurrently; "idle by design between units" is NOT a
thing while backlog exists.

**Why:** the factory's throughput ceiling is intake, not seats. The 2026-07-08 recovery session
ran serial single-unit dispatches (dev-1 waiting on a merge, dev-3 "awaiting relaunch", dev-4
free with nothing routed) — exactly the controller-as-bottleneck pattern the dark-factory
program exists to kill.

**How to apply:**
1. Every seat carries a STOCKED QUEUE ([[ce-multi-ticket-batch-dispatch]]: file-disjoint batch
   packets, per-ticket worktrees + subagent-threads) sized so it never waits on the controller
   between units. Legitimate serialization is rare and narrow (e.g. the brain-ledger tail).
2. Treat an idle-seat detection as a DISPATCH TRIGGER (fault alarm), not a status line to relay.
3. The durable fix is the conveyor intake queue (seats PULL ticket-units from an arc-fed queue);
   until it lands, restocking idle seats is the controller's standing highest-priority chore.
4. At session start / recon: if any seat is idle and the backlog is non-empty, restock BEFORE
   other controller work. [[ce-seats-foremen-self-managed-fanout]] [[ce-controller-conveyor-intake-directive]]

**⏫ Operator reinforcement (2026-07-09, STRANGELOOP-1 convergence):** "idle by right" does NOT
exist while ce-ops has open tickets (159 at the time). An arc's ratified pool being exhausted is
NOT an idle license — the backlog is the WHOLE tracker; the arc pool only sets ordering, not the
ceiling. Analogy given: idle seats = idle GPUs in a datacenter = the company mismanaging resource
allocation. When an arc pool drains, the controller's job is to pull the next well-specified
triage:ready tickets into new units (territory-mapped, file-disjoint batches) — not to declare
convergence. A seat too context-exhausted to dispatch into gets the pre-authorized canonical
relaunch, then restocked.
