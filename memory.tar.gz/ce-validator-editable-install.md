---
name: ce-validator-editable-install
description: The canonical .venv runs the Ring-1 validator EDITABLE-from-source (not the stale wheel) — do not rebuild the venv from validators/wheelhouse or the hard-deny bug returns
metadata: 
  node_type: memory
  type: project
  originSessionId: 6b29107e-2c6b-43ea-a171-285dfeca1298
---

**Durable host-state change (2026-06-09):** the canonical `.venv` now runs `creator-engine-validator` **editable from source** (`uv pip install -e validators/`), NOT the prebuilt `validators/wheelhouse/creator_engine_validator-0.1.0-py3-none-any.whl`. So the live Ring-1 hook always tracks current `validators/` source.

**Why this was needed:** the installed wheel was a stale `0.1.0` that **hard-denied** out-of-manifest author-time writes, while current source treats them as **advisory** (the G-i change moved binding containment to CI's `verify-path-manifest --base`). That skew hard-blocked a `ce lane launch --role implementer` seat. Verified post-reinstall (governed posture): out-of-manifest write = advisory-allow (correct); **`git push`/deploy still HARD-DENY** (the sacred no-self-deploy invariant preserved — the reinstall did NOT weaken it).

**How to apply:** (1) do NOT rebuild the venv from the stale `wheelhouse/` wheel — that reintroduces the hard-deny bug; reinstall editable (`uv pip install --python .venv/bin/python -e validators/`). The venv has no `pip`/`uv` of its own — use the system `uv` (`~/.local/bin/uv`). (2) The DURABLE productized fix is **Gate A v2 / PR #184**: a wheel↔source fidelity guard + `pyproject.toml` switched to setuptools auto-discovery (the stale wheel also structurally omitted `forge`/`runner` subpackages). Twin of [[ce-provisioning-hardening-architect-findings]] + [[ce-push-deploy-authority-model]].
