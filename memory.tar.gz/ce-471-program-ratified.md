---
name: ce-471-program-ratified
description: "Operator ratified the ce-ops#471 controller-power/continuity program recommendations AS A BLOCK on 2026-07-06 — all 10 report recommendations stand; P0 lands in current arc"
metadata: 
  node_type: memory
  type: project
  originSessionId: 29dd98b5-49df-420a-bb46-8a29aafdd959
---

2026-07-06 (~14:5xZ): Operator ratified the **ce-ops#471 controller power/continuity program** — the full 10-item recommendation list in `.ce/state/research/CONTROLLER_POWER_CONTINUITY_RESEARCH_20260706.md` §"Operator decision list" — **as a block**, verbatim ("I ratify the #471 program recommendations as a block, file the tickets").

Ratified highlights (now settled policy, not open questions):
- Continuity verb IS `ce takeover`; raw `role=controller` launch without takeover evidence = **read-only, no exceptions** (READ_ONLY_UNTIL_GOVERNED_LAUNCH_CONFIRMED refusal-that-teaches).
- Operator co-sign artifact for release signing: detached signed JSON bound to content_sha256, single-use, short-TTL, minted on Operator-controlled device — applies to the CURRENT un-contained controller immediately.
- Signing deputy must be SSHSIG-native (generic vault Transit insufficient); OpenBao custody behind deputy.
- Host-ops broker verb list v1 ratified (9 convergent verbs); raw container sockets excluded permanently.
- Remote-control: disabled for governed authoring controllers; allowed for read-only supervisory sessions.
- Codex Ring-1 promotion may precede containment acceptance if evidence packet + smoke live-proven.
- Continuity drill weekly until 2 consecutive clean runs; bottom-out = 3 same-failure repair attempts → AWAITING-OPERATOR circuit breaker.
- Rent/fork: rent Witness/OneCLI/OpenBao/GitHub App tokens; BUILD takeover, approval wall, SSHSIG deputy, host-ops broker (CE authority semantics).

Tiering: P0 (ce takeover + posture banner) lands in the current arc — the weekly quota cliff recurs every Sunday, making takeover-before-Sunday the concrete payoff. P1 = promotion gates/parity matrix. P2 = deputies + ephemeral seam. Eight tickets filed in ce-ops (see #471 comment thread for numbers).

**Why:** closes the 2026-07-06 continuity incident loop (controller quota halt with no discoverable takeover path) with a ratified program instead of ad-hoc fixes.
**How to apply:** treat all 10 recommendations as settled — do not relitigate ([[ce-operator-decides-relitigation]]); route P0 build early; the co-sign gap applies to today's controller, so surface it in any release-signing act until the deputy ships. [[ce-ephemeral-controllers-nanoclaws-direction]] [[ce-whole-fleet-to-containment-ratified]] [[ce-containment-not-authority]]
