---
name: ce-reviewer-triage-ratified
description: "2026-06-18 Operator ratified dynamic reviewer-triage (ce-ops#120) replacing static host pairing; first build SCOPED to Phases 1-2 (contracts + plan-only), Phases 5-6 deferred behind a 'second human / real reviewer load' trigger."
metadata: 
  node_type: memory
  type: project
  originSessionId: 42268e2e-bc78-436e-92f2-f34bd5c9a8ca
---

**ce-ops#120 RATIFIED 2026-06-18** (Operator). Dynamic reviewer triage **replaces** static dev-host pairing. Research: `.ce/state/research/RESEARCH_reviewer_triage_team_mode_20260618.md` (read commit `e211ce13`).

**Invariant adopted (research §D):** every PR needing review → CE computes the reviewer from required ownership + mutation class + risk tier + author identity + forge-enforcement facts + eligibility + availability; records an auditable triage decision; when agentic, materializes a distinct reviewer venue bound to one PR/head-SHA.

**SCOPE = Phases 1–2 only.**
- Phase 0 (rides first, blocking, cheap): reify `ADR-0003` distinct-controller-review pointer (sub-ticket #14; rule currently lives in ADR-V2-008/009/010) + fix now-stale static-pairing doc (#13).
- Phase 1: `reviewer-registry` + `reviewer-triage-decision` schemas + examples (no live mutation).
- Phase 2: plan-only `ce reviewer-triage plan --pr <n> --json` (candidate→eligibility→deterministic rank, NO source-host mutation).

**DEFERRED — Phases 5–6** (availability automation/SLA + expertise/load recommender + backtesting) parked behind **trigger: a second real human OR genuine multi-reviewer load.** Rationale: at N=1 with an agentic reviewer fleet there's nothing to load-balance; live value = the eligibility/independence filter + escalation, not ranking.

**Load-bearing OQ defaults (encoded; reversible in review):**
- OQ1 assignable unit = per-dev reviewer **identity** (assignment key); CE-managed GitHub reviewer **team** = forge-enforcement wrapper triage resolves to a concrete eligible identity.
- OQ4 storage split: tracked registry = durable declared status (`governance`/`identity`, ratified); ephemeral `.ce/state` read-model = transient (busy/OOTO+expiry/last_seen/load). Registry ≠ live scratchpad.
- OQ8 ADR-0003 reified first (Phase 0).
- OQ9 (keystone) N=1: agentic reviewer evidence = **useful-but-non-counting** for merge; Operator stays reviewer/ratifier boundary; engine still built — routes to best venue **for evidence**, escalates merge-gating approval to Operator. Composes w/ peer-authority auto-expiring N=1 carve-out.
- OQ10 concrete eligible reviewer chosen **before** any source-host request; broad-team request = documented degraded fallback.

**Parked OQs** (resolve when phase unlocks): OQ2 SLA (both first-response+evidence, two timers), OQ3 >1-reviewer tiers, OQ5 auto-spawn (default = ask-Operator-first), OQ6 ownership-only first (history→Phase6), OQ7 declared capability list (ratified-not-certified).

Supersedes static pairing in [[ce-team-mode-host-architecture]] (already isolation-domain-bound per ADR-0003). Related: [[independent-reviewer-venue-rule]] [[ce-speckit-superpowers-whathow]] [[codex-first-routing-directive]].
