---
name: ce-install-dependency-model
description: "CE install detects deps for the user's chosen config + prompts (with explanation) to install missing ones; mode-scaled — dev=BYO, ceo=prompted-install, strangeLoop=proactive-after-auth"
metadata: 
  node_type: memory
  type: project
  originSessionId: 7520a031-5b7e-497e-b56f-0427b09ba70a
---

CE's install/onboard must **DETECT dependencies for the USER'S CHOSEN config** (e.g. the isolation tier they picked), and for any MISSING dep, **PROMPT the user — with an explanation of what it is + why it's necessary — for authorization to install it.** This is the iOS/Android/Windows/modern-Linux-installer standard. The PRIMARY target audience = **NON-DEVS turning ideas into apps**; they must NOT be expected to do "host prep" or "bring-your-own isolation substrate."

Mode-scaled (CE serves BOTH power user and novice):
- **dev-mode (power user):** bring-your-own / manual substrate is fine (the host-prereq model — detect + use what's present).
- **ceo-mode (novice = default audience):** CE detects missing deps → explains → prompts → installs on authorization.
- **strangeLoop:** CE is proactive — if the default isolation substrate is absent, CE offers + installs it after prompting + authorization (takes initiative).

**Why:** non-devs are the primary market ([[ce-product-north-star]] · [[ce-positioning-ease-not-governance]] · [[ce-energy-efficiency-ceo-mode-gravity]]); "BYO substrate" is a dev-only answer that would lose them. Authorization-gated auto-install = the modern-OS norm. NOTE 2026-06-14: my initial "substrate = BYO host prereq" framing was corrected by the Operator to this mode-scaled detect→explain→prompt→install model.

**How to apply:** `sudo_grant` (scoped allowlist) is the authorization primitive. Correct the install PROCESS to: detect-per-config → explain → prompt → install-on-grant → degrade to governance-only only if declined. dev=manual; ceo/strangeLoop=prompted/proactive. Supersedes the implied "user-level install provisions nothing / BYO substrate" assumption. Pairs with the pluggable `RunnerBackend` ([[openshell-nemoclaw-stack]]).
