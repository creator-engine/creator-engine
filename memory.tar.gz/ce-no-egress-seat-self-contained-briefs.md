---
name: ce-no-egress-seat-self-contained-briefs
description: "Briefs to no-egress/contained seats must EMBED all content; never reference a private ce-ops ticket they can't read."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bd40e3b4-6d32-4603-a038-013c53cd022e
---

A dispatch brief sent to a **no-egress contained seat** (e.g. dev-4 on the DGX container) must be **fully self-contained** — embed every design table/spec inline. NEVER point it at "design posted on ce-ops#NN": the private ce-ops repo is unreachable from the container, so the seat blocks hunting for content it can't fetch.

**Why:** 2026-06-21, dev-4 created `ce168-work-sizing` but went F1-BLOCKED — it couldn't find the A.4 emission table because its brief said "design posted on #45" (private). Fix was to courier the design doc into the container (`tmp/...`, sha-verified) and re-seed.

**How to apply:** before dispatching to a contained seat, verify the brief has no unreachable refs; courier any private-repo content as a sha-pinned file into the container's mapped `tmp/`. This is also a candidate CE product gap — the dispatch tooling should enforce/auto-embed self-containment for no-egress targets (cf. [[ce-bake-gaps-into-ce-not-conventions]], [[ce-seat-dispatch-prompt-pointer-sha]]). Pairs with [[ce-team-mode-host-architecture]] courier mechanics.

## Detail (moved from index 2026-07-05)
- never ref a private ticket they can't read.
- ined seats must EMBED content.
