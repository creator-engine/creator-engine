---
name: ce-dev-process-stays-on-v1
description: "RETIRED 2026-06-12 on evidence — the #14 retirement run met the named trigger (PR #204 Scope→merge entirely through v3 on CE-DEV-1); v3 toolchain now self-hosts CE dev. Historical decision (2026-06-07) below; the v1-EOL-path guard SURVIVES"
metadata: 
  node_type: memory
  type: project
  originSessionId: bfad4f55-cd9e-4e98-9c51-eab66260a4be
---

**🏁 RETIRED 2026-06-12 — the named trigger fired on evidence:** the ce-ops#14 retirement run took PR #204 (B.7 fleet cost meter) Scope→ratify→drive→seat→pr→review(spawn)→collect→merge→◆report **entirely through cev3 on CE-DEV-1** (merge `570b20cf`; all three chains green; three distinct identities; declared deviations Operator-ratified; outside-witness attestation by CE-DEV-2 on ce-ops#14). **New posture: CE development self-hosts on the v3 toolchain.** v1 remains code-alive per [[ce-v1-v3-coexistence-not-deletion]], and the anti-ossification guard below (condition-based v1 deprecation/EOL path) SURVIVES the retirement — it now becomes the active question. Punch-list residue = the 7-finding live-drive ledger on ce-ops#14 → #16/G2-followups.

---
*Historical decision, superseded as above:*

**Decision (2026-06-07):** continue developing CE v3.1 **using the v1.0 dev toolchain** (batch-strict-mode + `ce` launcher / `lane_runtime` / hook-pack / distinct review venue). Do **NOT** "upgrade" the dev process to v3.0 mid-flight. Self-hosting / dogfooding (building CE *with* v3.x) is a **deferred milestone**, not a near-term migration. This **reverses** an earlier in-conversation idea ("from G-3.8 onward, develop CE using v3.0").

**Why:**
- **Resources are limited and prioritized for development** (the Operator's explicit allocation). Switching the toolchain to our own immature product would spend scarce effort *rebuilding dev-process capability we already have in v1.0* — pure opportunity cost against shipping v3.1.
- **v3.0 MVP only covers the inner loop** (governed open→merge). It lacks the backlog/Scope (G-6), automated review (`review_submitted` is reserved/producer-less in MVP), cost-safety (G-5), and the product CLI/install (G-7) the dev process actually leans on. A clean self-host is really a **v3.1** capability, not v3.0.
- **Validation is not lost by deferring — it relocates.** The external greenfield-OSS pilot (v3.1) is the hard-user signal; self-hosting's only forfeited benefit is the *credibility* proof point ("we build CE with CE"), a later marketing milestone, not a near-term need.

**How to apply:**
- Keep building v3.1 gate-by-gate on v1.0 (batch-strict-mode). Do **not** stage a "trial self-host" now (supersedes my earlier "(B) supervised trial after coexistence lands" suggestion).
- v1.0 = the **dev substrate** (frozen-operational, retained); v3.x = the **product**. Different lifecycles. This is the dev-process counterpart of the CODE-coexistence directive [[ce-v1-v3-coexistence-not-deletion]] — that one keeps v1 *code* alive; this one keeps v1 the *dev process*.
- **Self-hosting trigger — NAMED + falsifiable (Operator-confirmed 2026-06-10, supersedes the vaguer parity wording; recorded ce-ops#9):** v3 self-hosts when **one real gate goes Scope→ratify→drive→PR→merge entirely through v3, no v1 assist, on CE-DEV-1**. Mechanism = the **Track-2 phase-2 SHADOW TRIAL**: the team-mode wave's workload also runs through v3's `ce scope/ratify/drive` in parallel; the diff (expected: live-spawn seam, App-JWT mint leg, live taps) = the measured v3.1 self-hosting punch-list. Clean shadow ⇒ directive retires on evidence; gaps ⇒ filed, directive stands until closed.
- **Guard against ossification:** "coexistence" must carry a v1 **deprecation/EOL path** (condition-based), so we don't end up maintaining two coordination systems forever. Avoids over-correcting from "delete v1 too eagerly" (the withdrawn D1–D6) to "keep v1 forever."

**Industry framing (for docs/decisions):** this is textbook **dogfooding-when-mature** + **side-by-side versioning** + an **architectural fitness function** (the `version_boundary` import-isolation CI check). Cross-refs: [[ce-v3-roadmap-to-pilot]], [[ce-v3-product-vision]], [[ce-product-north-star]], [[user-ce-team-member]].
