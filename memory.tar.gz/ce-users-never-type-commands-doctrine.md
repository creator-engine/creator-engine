---
name: ce-users-never-type-commands-doctrine
description: "RATIFIED 20260708: users NEVER type ce/bash commands — the user supplies intent and natural-language authorization; the governed AGENT invokes ce verbs and records the authorization. Applies to CEO mode absolutely and even to skilled devs."
metadata: 
  node_type: memory
  type: project
  originSessionId: 695aa14d-c79d-4e91-b1ae-53e0a0689b2d
---

**RATIFIED by Operator 2026-07-08 (T5 review):** CE users are never expected to type `ce`
or bash commands — not the CEO-mode user (can't), and not the skilled dev (shouldn't).
The interaction model is the one the Operator and controller already practice: the agent
brings the ratifiable item with an explanation and a recommendation; the user reviews and
authorizes in NATURAL LANGUAGE; the agent records the authorization and executes the
verbs under the governance layer.

**Why:** (1) Users typing commands contradicts the agentic-SDLC thesis CE promotes — the
user gives intent and authorization, the machine does the mechanics. (2) The agent is
MORE reliable at command mechanics than the user and is the one actually checked by CE's
governance seam (hooks, gates) plus superior tools/memory. (3) The current human-typed
`ce ratify --approver-ref $(openssl rand -hex 32)` proves nothing about humanity — a
random hex typed by whoever holds the keyboard — so agent-mediated NL ratification is no
weaker; the REAL human-gate primitive is the reviewed-and-recorded authorization
([[ce-guided-journey-ui-vision]] inbox; [[ce-one-face-doctrine]]).

**How to apply:** All user-facing docs/packs teach intent-and-authorization interaction,
never command typing (any doc instructing a user to run ce/bash verbs = defect). Product
design: ratification/authority flows must accept agent-invoked verbs carrying a recorded
user authorization; the human-proof burden moves to the attestation/inbox layer, not
keyboard possession. Investigation 2026-07-08 determines whether current CEO mode
mechanically REQUIRES human-typed verbs (product gap, P0-class) or only documents it
(docs drift). [[ce-dual-format-emission-doctrine]] [[ce-user-facing-vocab-no-bet-no-budget-frontload]]
