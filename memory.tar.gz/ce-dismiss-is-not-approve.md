---
name: ce-dismiss-is-not-approve
description: "A dismissed changes-requested review ≠ an approval; gate must verify reviewDecision==APPROVED, and re-review briefs must say \"submit --approve, not dismiss\""
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2b67ead0-9d4c-41c1-974e-43b059ac1239
---

2026-06-23: #366/#368 kept landing on `reviewDecision=REVIEW_REQUIRED` after fixes. **CORRECTED ROOT CAUSE:** it was NOT reviewers dismissing-instead-of-approving — an automation App, **`ce-forge-dev-2[bot]`, dismisses standing approvals on every push** (confirmed in the issue timeline: it dismissed dev-3's #368 approvals at 05:38 and 06:20, each correlated with a rebase force-push). This **silently overrides branch-protection `dismiss_stale_reviews=false`** — no repo workflow does it, the bot does it via API. Net effect: every push (incl. a pure mechanical rebase) invalidates the approval, so a PR that gets rebased after approval needs a FRESH approval on the new head; a PR that is approved-then-merged-with-no-further-push keeps its approval (why #366/#367 merged but #368 didn't). A cleared/absent approval also *looks* merge-ready, which briefly fooled both me and the Operator.

**ROOT CAUSE (resolved 2026-06-23):** NOT App code / not a workflow / not `re_review.py`. It was the **repository ruleset `ce-reference-protection-floor` (id 17946690)** carrying `dismiss_stale_reviews_on_push: true` — rulesets layer over classic branch protection (most-restrictive wins), so it overrode the classic `dismiss_stale_reviews=false`. Dismissals attributed to the ruleset-owning App (`ce-forge-dev-2[bot]`), `dismissal_message: null` = native-ruleset signature. Source: hardcoded default `RulesetPolicy.dismiss_stale_reviews_on_push=True` (`forge/ruleset.py:73`). GitHub's flag is **binary (non-diff-aware)** — fires on pure rebases too — so diff-awareness must live in CE code, not the ruleset.

**FIX:** (a) **live ruleset PUT → `false`** applied 2026-06-23 (Operator-blessed; GET→flip-one-field→PUT clean payload; other protections preserved: 1-approval, last-push-approval, thread-resolution, squash). Approvals now survive rebases. (b) **PR #372** flips the source default False so installers don't re-emit the blunt flag (opt-in `True` preserved). **Trade-off blessed:** content-change pushes no longer auto-dismissed until CE's diff-aware re-review lane (`forge.re_review`, ce-ops#151 / unmerged #337) is wired — mitigated by mandatory independent review per PR. ce-ops#151 is on the [[ce-integrator-merge-mechanics-agent]] critical path. To re-apply via governed path: `ce ... ruleset --apply` once #372 lands.

**How to apply (gate discipline):**
- Merge-readiness check = verify `reviewDecision == APPROVED` (and CI green), NEVER infer approval from "changes-requested cleared" or `mergeStateStatus`. A `DISMISSED` review in the timeline with no later `APPROVED` = still unapproved.
- Re-review briefs to seats must say explicitly: *"submit `gh pr review <n> --approve` — a dismiss alone does not approve."* (Codex seats tended to dismiss-to-unblock rather than approve.)
- After a rebase/force-push, re-confirm a fresh `APPROVED` exists on the CURRENT head before enqueuing.

Related: [[ce-merge-queue-offloads-mechanics]], [[ce-reviewer-token-and-merge-mechanics]].

## Detail (moved from index 2026-07-05)
- verify reviewDecision==APPROVED on current head before enqueue.
- clears the block but isn't approval.
