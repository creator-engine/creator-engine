---
name: ce-compose-claim-lock-rule
description: "STANDING RULE (Operator, 2026-06-12): 🔒 compose-claim — before dispatching ANY composer/seat against a ce-ops ticket, CHECK for an unreleased lock then post '🔒 in-compose <host>' on the ticket; release = the 📦 deliverable comment. Feature = ce-ops#38."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a478804b-5c2d-4e77-8543-962deff93534
---

**Standing rule (Operator-approved 2026-06-12): the 🔒 compose-claim.** Before dispatching
any composer or seat against a ce-ops ticket:
1. CHECK the ticket for an existing UNRELEASED `🔒 in-compose <host>` lock comment — if one
   exists, do NOT dispatch (coordinate instead).
2. Post the one-line lock comment `🔒 in-compose <host>` on the ticket at dispatch time.
3. RELEASE by posting the `📦` deliverable comment (the deliverable IS the release).

**Why:** the 2026-06-12 near-miss — CE-DEV-1's proposed "G-B venue-trio" composer would have
duplicated the #16 spec already composed and banked on CE-DEV-2. Two authoring hosts make
work-claim races real; this extends the pco claim discipline from worktrees to WORK ITEMS.
Feature version (work-claim locks + velocity-tranche queue) = **ce-ops#38**.

**How to apply:** from the next dispatch onward (the 2026-06-12 in-flight tracks on #16/#21
are grandfathered by their ratification trails). Applies to compose seats AND build seats —
any dispatch "against a ticket". Queue history (2026-06-12): #25's rev-1 spec failed
cross-vendor verification, rev-2 (sha `244810b1…`) re-verified PASS + RATIFIED on the issue
and DISPATCHED from CE-DEV-1 same day — the hands-off is LIFTED. Lasting lesson from that
trial: **cross-vendor verify is now the MANDATORY leg for cross-vendor-composed specs**
(e.g. the codex-bridge spec holds its ratification ask until dev-2's verdict posts).
Twin of [[ce-check-parallel-tracks]].
