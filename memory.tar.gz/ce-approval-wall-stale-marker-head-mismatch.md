---
name: ce-approval-wall-stale-marker-head-mismatch
description: Push-after-approval strands a stale approval-capability marker → daemon skips on head_mismatch forever; recovery = strip the marker line from the PR body so the daemon re-mints
metadata: 
  node_type: memory
  type: project
  originSessionId: f1d48ae1-f6dd-445b-b907-acca81aaedda
---

Verified 2026-07-02 (creator-engine#737/#738, filed as ce-ops#404): when a PR head
changes after ce-dev-2 approval (e.g. controller pushes a merge-group reconcile fix
and re-approves), the signed `ce-approval-capability:` marker line in the PR BODY
stays bound to the OLD head. The queue-daemon verifies it, gets `head_mismatch`,
and skips with `approval_capability_invalid` — permanently and silently. It only
mints when the marker is MISSING (`_approval_marker_mint_needed` in
`forge/integrator_belt.py`).

**Why:** fail-closed wall design; a present-but-wrong marker is treated as an
anomaly, not a re-mint trigger.

**How to apply (recovery):** delete the `ce-approval-capability:` line from the PR
body (preserve the Declared-work-class line), keep the fresh ce-dev-2 approval on
the current head; the next daemon pass runs approval_settle_pending → mint →
enqueue. Also expect the mint's own body-edit to re-trigger the required
governance check (+1 ~6-min cycle on every wall-gated merge; also on ce-ops#404).
Sibling failure signature: daemon logs `stderr=already queued to merge` while
`mergeQueueEntry=null` = the queue silently dequeued a failing PR — check
merge_group run logs, not the daemon's claim. [[ce-dev2-approval-is-the-merge-trigger]]
[[ce-wall-daemon-token-expiry-restart]]

## Detail (moved from index 2026-07-05)
- fix=strip `ce-approval-capability:` line from PR body → daemon re-mints. `already queued` stderr + null mergeQueueEntry = silent dequeue, read merge_group logs.
- never re-mints (ce-ops#404).
- daemon skips silently.
