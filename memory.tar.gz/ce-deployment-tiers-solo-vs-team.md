---
name: ce-deployment-tiers-solo-vs-team
description: CE has deployment tiers — solo devs run ONE controller agent (no governed daemons); the broker/gate/integrator daemons are Team/skynet-tier only
metadata: 
  node_type: memory
  type: project
  originSessionId: 169d3cef-709b-4bce-82ab-bc9d1d64a305
---

> ⚠️ TERMINOLOGY CORRECTED 2026-06-30 — see [[ce-mode-axes-canon]]. This note's "Solo vs Team/skynet" framing conflated two orthogonal axes. Correct canon: **Tier** (Solo / Autonomous Fleet) is what determines whether you run the governed daemons; **Collaboration** (Individual / Team) is just whether a repo is shared. The daemons below are **Autonomous-Fleet-TIER** machinery — a Solo×Team setup (multiple solo installs on a shared repo) runs NONE of them. Read "Team/skynet tier" below as "**Autonomous Fleet tier**"; "solo-dev tier" as "**Solo tier**". The OS-portability conclusion still holds (solo installs don't run daemons).

**CE ships in deployment tiers (Operator, 2026-06-29; tier-vs-collaboration split 2026-06-30):**
- **Solo-dev tier (the common case):** a SINGLE coding-agent "ce controller" running os-native (or contained) in **CEO/strangeLoop** mode. Most solo devs use THIS. They do **NOT** run the advanced governed daemons (egress broker, merge-queue/gate daemon, integrator daemon, review-pickup) — those are the multi-seat fleet machinery they don't need.
- **Team / "skynet" tier:** the full fleet — multiple seats + the governed daemons (broker, gate, integrator, etc.). This is CE's own dogfood deployment and the offering for teams.

**Implications:**
- The governed daemons run on CE-hosted infra or the Team deployment (Linux hosts we control) → their systemd/Linux supervision is fine; OS-portable-supervision (launchd/Windows) is LOW urgency because solo users don't run those daemons. [[ce-no-anthropic-sdk-per-token-billing]] note: model-backend portability still matters for the support agent.
- For a solo dev, "what ships to their machine" = the `ce` CLI + ONE contained/os-native controller agent + the sandbox — NOT the daemon fleet. So macOS/portability work focuses on the seat runtime + sandbox, not daemon supervision. [[ce-mac-onboarding-via-linux-container]]
- Maps to the CEO-mode/strangeLoop gravity ([[ce-energy-efficiency-ceo-mode-gravity]]) and terminal-first product ([[ce-shipped-product-terminal-first]]).

## Detail (moved from index 2026-07-05)
- Solo×Team (multi-install shared repo) runs none; daemon OS-portability low urgency. CORRECTED 2026-06-30.
- (broker/gate/integrator) = Autonomous-Fleet-TIER only.
