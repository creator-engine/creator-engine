---
name: ce-mainhead-install-option-a-ratified
description: "Main-HEAD install (ce clean-main-install / ce update --track main) RATIFIED under Option A (SHA-pin + reproducible build + fail-closed verify), retroactively, 2026-07-02. Conveyor arming held pending ce-ops#388."
metadata: 
  node_type: memory
  type: project
  originSessionId: d0a9fc77-23a0-480d-a261-1a7d96e0d811
---

Operator decisions 2026-07-02 (approved a batch of controller recommendations as written):

1. **Main-HEAD install trust model — RATIFIED Option A retroactively.** `ce clean-main-install` + `ce update --track main` shipped LIVE (merged 2026-06-30) ahead of the ce-ops#366 ADR that was to ratify them; Operator accepts them as-is under Option A (commit-SHA pinning + local reproducible build + fail-closed hash verification). No ratification gate added to the existing commands (trust model sound; gap was procedural). ADR-0003 (PR #725) marked Accepted. Unblocks L1.a clean-main-install + L1.b `ce update --track main`. Future-surface guard = **ce-ops#389** (a ratification-gate PATTERN so the next trust-model-adjacent surface can't ship live before ratification).

2. **Conveyor arming (G-N3) HELD** pending the security design review **ce-ops#388** (payload-as-data-only + daemon-owned working dirs + seat-authored-bundle content-trust). #718 daemon merged DISARMED after 5 adversarial rounds closed all code-level RCEs. Do NOT arm on patched rounds; arm only after the redesign + independent review. [[ce-internal-devops-agent-and-runbook-ssot]]

3. **#720 onboarding guide** — publish when the fixes re-review green (first-contributor front door); don't publish before the canonical-vocabulary + false-banner fixes land.

**Why:** captures binding Operator ratifications so they aren't re-litigated and the follow-ups (#388, #389) are tracked. **How to apply:** treat Option A as the accepted main-HEAD trust model; route any new trust-model-adjacent surface through ratification BEFORE it's user-reachable (#389). Related: [[persist-decisions-at-confirmation]] [[ce-release-cut-off-current-main-not-feature-mergebase]].

## Detail (moved from index 2026-07-05)
- #720 publish-when-green; guard=#389.
- conveyor arming held pending #388.
- ratify main-HEAD install retroactively (Option A).
