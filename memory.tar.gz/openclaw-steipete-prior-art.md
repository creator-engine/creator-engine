---
name: openclaw-steipete-prior-art
description: "The OpenClaw/steipete (Peter Steinberger) ecosystem is the PRIME prior-art corpus for CE's agentic coordination/outer-loop layer — repo-by-repo relevance map"
metadata: 
  node_type: memory
  type: reference
  originSessionId: b851d6f0-6527-4abc-91a1-158eac33141c
---

Investigated 2026-06-05 (10-agent workflow, current-dated). **Peter Steinberger (GitHub `steipete`) + the `openclaw` org have independently built nearly CE's entire idea→triage→review→merge→evidence outer loop, decomposed into shippable, mostly-MIT parts** — and clownfish/clawbench/clawsweeper/gitcrawl *independently arrived at CE's own "grader lives outside the agent" principle.* Treat this corpus as CE's primary prior-art + competitive landmark. (Note: most projects live under the `openclaw` org, NOT `steipete/`; several named repos were renamed — e.g. Crabyard → **crabfleet**.)

**HIGH relevance (study targets):**
- **openclaw/clawsweeper** (MIT, forkable, ~1.7k★) — THE flagship. Production fleet of Codex agents doing GitHub issue/PR triage/review/repair/automerge on a shared repo with a strict **propose → deterministic-executor** split (LLM never holds a write token; creds minted only after agent exits; `codexEnv()` strips App env because issue/PR text is attacker-controlled). 4 lanes: Review(proposal-only)/Apply(guarded-mutation, live re-fetch + discard-on-snapshot-drift)/Repair(autofix/automerge)/Commit-review. Durable per-item markdown report w/ decision+evidence+snapshot HASH. Closed enum of 6 close reasons; 0.1% false-negative-biased close rate. = CE's "grader outside the agent" as a real impl.
- **openclaw/crabfleet** (formerly Crabyard; MIT) — "Mission control for agent runs": Kanban board (Todo/Running/**Human-Review**/Done) wiring GitHub issues/PRs to supervised agent runs; **named merge-policy enum** `repo_default|open_pr|merge_when_green|fix_until_green_and_merge`; per-repo `CRABBOX.md` config (parse-now/enforce-later); RBAC/allowlists/run-caps. Closest WHOLE-thesis analog to CE — BUT autonomous execution/merge are "adapter targets, not faked" → **that stub is CE's differentiator.**
- **openclaw/clownfish** — bulk cluster-resolution triage harness (read-only sandbox classify → safety checks → gated mutation w/ fresh-state validation); consumes gitcrawl clusters.
- **openclaw/lobster** (~1.2k★) — thin JSON-first workflow engine; **first-class approval gates encode separation-of-duties** (`require_different_approver`, `initiated_by`/`approved_by`) + durable resume tokens + a `github.pr.monitor` step. Near-1:1 analogue to CE's G-2.0 thin orchestrator + approved-plan ratification + independent-reviewer rule. "Lobster must not own OAuth/tokens."
- **openclaw/acpx** — headless Agent Client Protocol (ACP) client: drive coding agents over a STRUCTURED protocol (typed messages, durable sessions) instead of PTY scraping. The durable alternative to CE's current tmux-seed launch.
- **Octopus Orchestrator** (`src/octo` inside openclaw/openclaw, issue #64435; NOT a standalone repo) — "one head plans/supervises, many arms execute"; drives agents via PTY/tmux + structured CLI; chaos-tested, 1,436 tests. Reference architecture for CE's head-arms orchestrator.
- **openclaw/clawpatch** (~700★) — provider-agnostic review CLI: maps repo into semantic feature slices, READ-ONLY review → schema-validated **finding schema** (category/severity/confidence/evidence/recommendation) → explicit per-finding fix → open PR. Mirrors CE's RunnerBackend + classify/audit split.
- **openclaw/clawbench** — full-stack agent benchmark scoring harness+config+model via **deterministic verifiers an LLM judge CANNOT override** (Completion 40%/Trajectory 30%/Behavior 20%); 13 failure modes. = "grader outside the agent" as a scorer for CE's own agents.
- **steipete/deepsec** — agent security harness with `process --diff` PR-mode → a security reviewer lane for CE's reviewer stack.
- **openclaw/octopool** — shared org-authed GitHub READ relay (Cloudflare Worker + D1) pooling PATs/App identities for rate-limit headroom; clean **read/write split** (reads via relay, mutations via local gh). Solves the infra problem CE WILL hit with many governed seats on one shared repo.

**MEDIUM:** openclaw/gitcrawl (local-first SQLite issue/PR mirror + deterministic-cross-ref-required clustering heuristic — a triage FEEDER); openclaw/crabbox (remote exec control plane = RunnerBackend sibling + broker spend/lease caps + evidence-stays-with-broker); openclaw/releases (credential-free evidence LEDGER pattern); openclaw/agent-skills (autoreview/agent-transcript/handoff ≈ CE reviewer-venue + pointer-only handoff); steipete/agent-scripts (pointer-style cross-repo rule sync); steipete/oracle (multi-model advisory panel for review escalation); steipete/claude-code-mcp (nested-agent-via-MCP).

**LOW/none:** openclaw/clickclack (agent+human chat transport; only the scoped/revocable bot-credential model + cursor-replayable event log are referenceable), openclaw/crabpot (adapter-seam contract-testing meta-pattern), openclaw/clawhub (skill/plugin registry), steipete/ReleaseBar (dropped — monitoring UI).

**Cross-cutting:** (1) "grader outside the agent / deterministic gates dominate the model" is CONVERGENT across the ecosystem — validates CE's thesis. (2) The canonical agent-triage/review SHAPE: read-only classify in a sandbox WITHOUT write creds → schema-validated structured findings → deterministic safety gates → fresh-state recheck → guarded mutation by a non-LLM executor. (3) Two competing agent-control substrates: Octopus (PTY/tmux) vs acpx (structured ACP) — the key G-2.0 decision. (4) NONE of the corpus touches the INCEPTION layer (idea→PRD→spec) — consistent with CE deferring CEO mode; look to [[bmad-method-reference]] there. Relates to [[ce-product-north-star]] and [[ce-learning-reference-reports]].

## Detail (moved from index 2026-07-05)
- Related: [[ce-code-as-harness-paper-learnings]]
- coordination outer loop in MIT parts; PRIME prior-art.
