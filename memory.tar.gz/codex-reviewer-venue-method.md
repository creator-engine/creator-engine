---
name: codex-reviewer-venue-method
description: "How to run a governed-equivalent PR review/verify on a codex seat (external-gate, Env-2)"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 3d84878f-7476-4bab-8598-c35b8c1edce1
---

Under [[codex-first-routing-directive]] all review/verify/build runs on **codex**, which lacks the claude-code Ring-1 reviewer-authority hook ([[ce-governed-reviewer-venue-method]] is claude-only). Codex runs under **external-gate posture (Env-2)**: independent analysis + distinct-actor submission; the **controller holds the merge gate**.

**Launch:** `ce launch --harness codex --session <n> --json` → parse `pane_id` → tmux-seed. Helper that launches+waits+seeds from a text file: `.ce/state/dispatches/codex-seed.sh <session> <seed-file>` (proven 2026-06-17 night-shift). Codex is gpt-5.5 xhigh, bypass-mode, cwd=canonical.

**Review submission as the distinct reviewer actor** (`ubuntuaws745-cmyk`, dev-2 reviewer): seed the seat to submit ONLY for the gh call, token never global:
`GH_TOKEN="$(source ~/.ce-keys/ce-reviewer-seat-env; echo "$GITHUB_REVIEWR_TOKEN")" gh pr review <PR> --repo creator-engine/creator-engine {--approve|--request-changes --body ...}`
Reads (incl. ce-ops private spec) use DEFAULT gh (reviewer token has no ce-ops access) — don't export it globally.

**Pattern:** write a BRIEF + per-round SEED in `.ce/state/dispatches/ce<PR>-rev/`; seat writes a verdict file (e.g. `CODEX_REVERIFY.md`) + submits the gh review; arm a watcher on the verdict file OR the PR `reviewDecision`. Pair a full review with a focused-verify seat for risk-bearing PRs (Operator-ratifiable). Retire seat after submit (`tmux kill-pane`). Merge-on-gates = review APPROVED + CI green + verify-path-manifest + full suite, merged by the CONTROLLER (chmod735, distinct from reviewer).
