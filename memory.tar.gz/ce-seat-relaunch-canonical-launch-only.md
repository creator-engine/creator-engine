---
name: ce-seat-relaunch-canonical-launch-only
description: "Never relaunch a contained codex seat via raw `codex`; use the canonical ce launch / root — raw launch breaks the bwrap sandbox"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 87adf545-0606-41c1-a287-c1d201274e70
---

2026-06-21: I relaunched the dev-4 codex seat myself via raw `codex -m gpt-5.5 -c model_reasoning_effort=xhigh` (over `tmux send-keys` from an ssh-as-cedev4 session) to pick up a new credential config. This BROKE its sandbox: `bwrap: setting up uid map: Permission denied` on every command, because Ubuntu 24.04 has `kernel.apparmor_restrict_unprivileged_userns=1` and `/usr/bin/bwrap` is not setuid. The original codex (launched via the canonical method) worked under the same sysctl — and I had killed it.

**Why it matters:** a raw `codex` relaunch bypasses whatever the canonical launch (`ce launch` / the original setup) does to make bubblewrap's user-namespace sandbox work, and silently produces an agent that either can't run anything OR is tempted to run OUTSIDE the sandbox (a [[ce-mandatory-containment-decision]] violation).

**How to apply:**
- Relaunching a contained seat = a **root/Operator action via the canonical launch method**, NOT raw `codex` and NOT from an ssh-driven tmux context. Surface it to the Operator; don't do it inline.
- To make a running seat pick up a config change (e.g. an injected `GH_TOKEN` via `shell_environment_policy.set`), the relaunch still must go through the canonical path.
- Quick root fixes for the bwrap error if a raw relaunch is unavoidable: `chmod u+s /usr/bin/bwrap`, or `sysctl kernel.apparmor_restrict_unprivileged_userns=0` — but prefer the canonical launch.
- `/compact` (not C-c, not kill) is still the way to manage a seat's context without restarting. Related: [[ce-dev4-dgx-spark-access]] [[ce-seats-foremen-self-managed-fanout]].

## Detail (moved from index 2026-07-05)
- Related: [[ce-codex-seat-launch-method]] [[ce-controller-launch-method]]
- relaunch via `ce launch`.
- contained codex seat via raw codex/ssh-tmux (breaks bwrap).
