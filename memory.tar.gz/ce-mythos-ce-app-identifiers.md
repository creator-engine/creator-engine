---
name: ce-mythos-ce-app-identifiers
description: mythos-ce GitHub App identifiers (non-secret) + the account-wide installation-ID lesson; registry is SSOT
metadata: 
  node_type: memory
  type: reference
  originSessionId: 2b41093b-d5a3-4e35-82f8-71ed2b77412f
---

**mythos-ce GitHub App (non-secret identifiers):** App ID `4103119` · Client ID `Iv23liuJp6OxfCWvwfSl` (= App-JWT `iss`) · slug `mythos-ce` · owner `chmod735-dor` · installation `141552951`. PEM (secret): `~/.ce-keys/mythos-ce.2026-06-20.private-key.pem` (stage to /dev/shm for runs, shred after). Env mirror: `~/.ce-keys/mythos-ce-app.env`. SSOT = `ce-ops:infra/identity-registry.yaml` — registry WINS over this memory.

**Installation-ID lesson (2026-07-06, canary C2):** GitHub App installations are PER-ACCOUNT, not per-repo. The chmod735-dor installation has `repository_selection: all`, so **141552951 covers ce-canary-sandbox too** — the "NOT 141552951 for the sandbox" caveat in the 20260706 resume state was wrong (assumed a per-repo installation that doesn't exist). Authoritative resolution: App-JWT `GET /repos/<owner>/<repo>/installation`.

**How to apply:** need an installation token for any chmod735-dor repo → iss=4103119 (or client id), same installation 141552951. Related: [[ce-mythos-tenant-live]] [[ce-github-identity-model]] [[ce-gh-cli-cannot-app-jwt-auth]]
