---
name: ce-contained-seat-codex-update-prompt-blocks-pane
description: "On relaunch, contained codex seats show an update notification that BLOCKS the pane until dismissed — dismiss it (never approve), durable fix is image-pinning"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 7ed7fba2-2c2b-4884-b503-f02c682d85b0
---

When a contained codex seat is (re)launched, codex shows a "codex update available / npm install -g @openai/codex" notification in its TUI pane. **It BLOCKS the pane — the seat won't accept dispatched work until the prompt is dismissed.** Hit twice by the Operator during the GATE β dev-3 bring-up (2026-06-26).

**How to handle:**
- DISMISS it as part of every contained-seat bring-up — send a herdr keypress (Esc, or the decline key) to the pane (e.g. `herdr pane send-keys w1:p1 Escape` inside the container). Bake this into the relaunch/dispatch worker flow; don't leave the seat stuck.
- NEVER approve the update. ce-ops#271 (MERGED) already blocks contained-seat toolchain self-update (`npm -g`/pip/apt/curl|sh) and the codex binary is read-only mounted, so the install can't proceed anyway — the prompt is cosmetic-but-blocking.
- DURABLE fix: suppress the update-check / pin the codex version in the canonical image and update it only via the governed image-rebuild → canonical relaunch path. [[ce-govern-rented-surface-updates]] (rented-surface arc #272–#280). Codex bumps are a fleet-wide governed change, never per-seat.

Relates: [[ce-seat-relaunch-canonical-launch-only]], [[ce-contained-codex-needs-yolo-gvisor-is-sandbox]]. The relaunch must also clear the stale herdr session (ce-ops#250) — both are post-relaunch hygiene steps.
