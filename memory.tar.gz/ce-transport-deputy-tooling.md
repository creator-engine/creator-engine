---
name: ce-transport-deputy-tooling
description: "For the Three-Deputy Transport layer, use onecli (cred-injection gateway) + Microsoft ACS (policy schema) on CE's own gVisor+herdr runtime; OpenShell/NemoClaw = pattern+pitch, not runtime."
metadata: 
  node_type: memory
  type: project
  originSessionId: 2fe171be-e2b8-479e-b208-4b0153b128cf
---

Tooling decision for the **Transport deputy** of [[ce-three-deputy-governance-model]] (eval spike 2026-06-24, Operator-endorsed). Full eval: ce-ops `designs/RESEARCH_credmediation_eval_20260624.md`.

**It's a COMPOSITION across layers, not one tool:**
- **Sandbox runtime** = CE's OWN gVisor + herdr + `runsc` launchers (keep it — proven; do NOT adopt OpenShell/NemoClaw runtime, which would replace it and is alpha).
- **Egress confinement** = CE's OWN `gvisor_proxy_backend.py` (`EgressProxyConfig(deny_by_default=True)`, already declares the concrete proxy as an unfilled "deployment overlay").
- **Credential injection** = **onecli** (github.com/onecli/onecli) — Apache-2.0 HTTP gateway, inject-out/strip-back (placeholder→real token on the outbound request, stripped on the reply; agent never holds the secret), transparent git-over-HTTPS + GitHub-API. **It drops straight into CE's existing overlay slot.** Operator endorses it; **corroborated by production use — NanoClaw uses onecli** (that's how the Operator knows it). This is the layer OpenShell/NemoClaw do NOT provide (they do network/egress, not token injection — per third-party analysis, ~high confidence).
- **Policy schema** = **Microsoft ACS** (Agent Control Spec, MIT, vendor-neutral) — one manifest (`pre_tool_call` allow/deny/transform) driving BOTH PEPs: CE's in-box `hook_check.py` (mechanic-class-only today; the L7 method/path gap) AND the proxy.
- **Rejected:** MXC runtime (Windows/WSL-coupled, identity-binding not injection).

**OpenShell/NemoClaw's actual role:** pattern reference (validates deny-by-default egress, which we already implement) + **NVIDIA pitch alignment** (build the NemoClaw containment *model* on a herdr-native runtime → speaks NVIDIA's language) — NOT components we run.

**⚠️ Gates W5:** `run-controller-runsc.sh:180` + `run-vps-runsc.sh:218` forward `CLAUDE_CODE_OAUTH_TOKEN` INTO the sandbox (live cred-in-box). Converting THIS controller naively leaks it → W5 needs the Transport deputy (or a token-strip) FIRST.

**Open unknowns (config spike before commit):** (1) is onecli default-deny for ALL traffic + native L7 method/path, or inject-only? (2) onecli↔OpenBao — it ships Bitwarden not Vault; does CE's `EgressProxyConfig` rule-shape drive it as-is or need a shim? Formal build-ratification still pending ([[ce-autonomous-authority-doctrine]] — endorsed ≠ ratified-to-build).
