---
name: ce-controller-inlines-execution-drift
description: Operator correction — I drift into inlining substantive multi-step execution (recon/audits/git-ops/probes) under hands-on momentum; delegate it to workers and keep controller context for coordination + the gate
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a5799e45-b562-4e65-b393-dc6c0c4d2251
---

**Operator correction (2026-06-22):** during long hands-on threads I drift into *inlining* substantive multi-step execution — multi-host recon/audits, repeated ssh probes, git surgery, release mechanics — instead of delegating to workers. Flagged on a VPS dev-1/dev-3 transition audit I ran inline (should have been a worker returning a structured summary).

**Why it matters:** controller context is the scarce resource. Inlining heavy execution defeats the [[ce-controller-spawns-many-workers]] fan-out model and burns the context I need for coordination + the merge gate. The pull is strongest exactly when I'm "in flow" on a hands-on task — that's the trap.

**How to apply:** before running a multi-step probe/exec inline, ask "is this a worker task?" — default **YES** for recon, audits, multi-host probes, build/transition mechanics, git archaeology. A worker runs it in an isolated worktree and returns a tight structured report; I review the conclusion + hold the gate. Reserve inline action for: single decisive commands, the merge button, signing, and coordination. Reinforces [[ce-controller-steers-seats-execute]] + [[ce-delegate-merge-conflict-triage]].

**Operator RE-FLAGGED 2026-06-26** (second time) — I inlined ~15 gh/bash calls diagnosing #541/#543/#537 CI failures, patching PR bodies, and scanning #544 confidentiality before being corrected. Sharper division of labor:
- **WORKER work (dispatch — Sonnet/Haiku, NOT Opus where Sonnet suffices):** CI-failure diagnosis, PR-body/metadata fixes, doc/confidentiality scrubs, recon, retrospective/arc-data assembly, branch updates, seat harvest, dispatch-envelope prep. Claude Code = sub-agents/forks; codex seats = threads+worktrees (every seat born-a-foreman). Use the CE harvest/dispatch playbooks (`playbooks/controller/briefs/dispatch.md`), don't reconstruct inline.
- **CONTROLLER-retained only:** review JUDGMENT, approve-as-ce-dev-2 identity act, enqueue/merge gate decision, Operator interface, arc synthesis/ratification.
- Model routing per [[ce-model-effort-routing-policy]]; default workers to Sonnet, justify any Opus.
