---
name: ce-rent-or-fork-before-reinvent
description: "Operator principle (2026-06-23): don't reinvent where you can RENT (use as-is) or FORK (customize). Before building, evaluate existing solutions; build only the irreducibly-CE differentiator. Layer the decision."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a3bac9be-36f9-4b41-a61c-0f86c4d754cc
---

**Operator principle (2026-06-23):** "We don't invent where we could rent. If [tool] is a good-enough solution we can fork it and customize to CE's needs." Standing principle, not a one-off — applies to every build decision.

**Why:** build-throughput is no longer the constraint ([[ce-agent-paced-estimation]]), but engineering attention + maintenance surface still are; reinventing commodity layers wastes both and ships worse than a battle-tested upstream. CE's edge is its *governance/evidence* differentiator, not re-implementing substrate.

**How to apply — LAYER the rent/fork/build decision:**
1. **Framework / commodity substrate → RENT or FORK.** TUI frameworks, multiplexers, transport, vector DBs, CI. (We already rent Textual + watchfiles for the cockpit view; "rent coordination to the forge" [[ce-v3-product-vision]].)
2. **CE's differentiator → BUILD (irreducibly-CE).** The hash-chained evidence spine, the refusal feed + ratifier attribution, the capability-envelope matrix, the read-model projection of CE's OWN governance records (`runtime_agent_action`, `reviewer-authority-envelope`, `runtime_spend_ledger`). No upstream has CE's data model — not rentable.
3. **Before launching a build worker, state the rent/fork check explicitly** (what upstream exists, why fork-vs-build) — don't default to greenfield.

**Worked example (this session):** Cockpit-B. L2 read-model = BUILD (projects CE's own spine — nothing to rent). L3 view = RENT the framework (Textual, per design-of-record). **herdr** (agent-aware tmux-for-agents: Rust ratatui, local-first/SSH-native, agent-status sidebar, harness hooks incl. Hermes/Codex/Claude Code, socket API) is NOT a governance cockpit — it's a strong **rent/fork candidate for the post-tmux ATTACHABLE-SESSION SUBSTRATE** ([[ce-post-tmux-direction]], M2 #207/#208, the PTY backend #368 we just built CE-native) and the cockpit's "live-attach to a seat" affordance — and it's local-first/headless (fits CE's posture, unlike cloud-hosted crabfleet). Decision pattern echoes [[ce-acpx-fork-vs-learn-decided]] (learn-not-fork) + [[ce-substrate-acp-decision]].

**Decision (2026-06-23):** Operator researched herdr and **leans FORK** it for CE's post-tmux substrate; **eval ticket = ce-ops#217** (fork-vs-extend-#368, license, containment fit, witnessability, what-stays-CE). Decision gate to Operator before any fork lands.

**Watch-out:** rent/fork only where the upstream's architecture fits CE's constitution (daemonless, headless-native, local-first, never-a-new-authority). crabfleet/FABRO were REJECTED as forks despite being "mission control for agents" because they are web-first/cloud-hosted — the opposite posture. herdr passes that test where they failed.

## Detail (moved from index 2026-07-05)
- check our own repo first.
- BUILD only CE's differentiator (spine/refusal/envelope).
