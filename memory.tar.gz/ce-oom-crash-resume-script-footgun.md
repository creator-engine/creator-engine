---
name: ce-oom-crash-resume-script-footgun
description: "2026-06-10 OOM crash post-mortem — a 9.1GB claude seat triggered the kernel OOM-killer + oomd killed GNOME Shell; resume-ce.sh's kill-session line nukes still-alive seats; resume right after an OOM dies in the thrash window"
metadata: 
  node_type: memory
  type: project
  originSessionId: 071505c2-cc58-4822-b191-75dcf4d1f870
---

**2026-06-10 05:56 IDT crash post-mortem (14GB HP laptop):** one claude 2.1.170 seat in the `ce-hermes-controller` tmux session grew to **9.1GB anon RSS** → kernel OOM-killed that pane AND systemd-oomd killed GNOME Shell (whole desktop UI vanished — looks like "everything crashed" but the tmux server + other seats survived).

**Why:** the OOM victim's transcript was `374220e7` (froze 05:56); gov-controller/site-lane/E.3 seats stayed alive until 05:59.

**Footgun (the original bug):** `~/resume-ce.sh` did `tmux kill-session` UNCONDITIONALLY before resuming — running it after a *partial* crash KILLED the still-alive seats, escalating a partial crash to a total one.

**✅ FIXED 2026-06-10 — the script is now HARDENED** (don't re-apply the old manual workaround): (1) **survivor-safe** — never kills a session that has live seats; if the orchestrator window is dead it `respawn-pane`s IN PLACE, else adds a window, survivors untouched; (2) **OOM-guarded** — refuses to resume when `free -m` available <2GB and surfaces recent `journalctl -k` OOM events (kills the silent-death-in-thrash-window failure); (3) **idempotent** — if the orchestrator pane is already running `claude`, does NOTHING (two processes on one session id corrupts the transcript). `RESUME_FORCE_FRESH=1` opts into the old kill+recreate. Model default also corrected to `claude-fable-5`/`high`. Verified by a live idempotence self-test.

**Diagnostic discipline still applies:** on any "session crashed" report → `journalctl -k | grep -i oom` + `free -h` FIRST. Crash is far less destructive than it feels — **git commits + saved `~/Documents/` files are durable**; reconcile via `git -C ce-worktrees/<wt> log` (the 2026-06-10 crash lost ZERO committed work — 4/5 Cockpit gates + the E.1/E.2 site PR + the E.3 design all survived). Orchestrator session id = `3d6c61d0-…`. Watch long-lived seats for RSS creep (**9GB = leak/runaway territory**); recycle periodically.

**WHY THIS MANDATES THE SECOND VPS (Operator point, 2026-06-10):** the CE fleet sharing this 14GB desktop means one runaway seat's OOM takes down GNOME Shell + the whole dev environment at once. A dedicated **headless Hetzner VPS for the v3.1 pilot** ([[ce-pilot-env-hetzner-vps]]) ISOLATES the agent fleet from the operator's desktop — a runaway seat there kills only itself, never the human's UI — and is exactly the durability proof needed before upgrading this dev machine off v1.0 ([[ce-dev-process-stays-on-v1]], [[ce-v35e-onboarding-docs-lane]] E.4 install-drive). [[ce-controller-launch-method]] [[ce-venue-seat-retirement-procedure]]

**→ SPAWNED v3.5-F (Fleet Resource Hardening), Operator-RATIFIED 2026-06-10.** The OOM proved CE's containerization (gVisor/OpenShell) sandboxes the TASK runtime, NOT the agent-harness process that leaked — so CE has no defense against a seat's own resource runaway. v3.5-F design DELIVERED + reviewed **EXCELLENT** (`~/Documents/ce-v35f-fleet-resource-hardening-design-20260610.md`) — **empirically PROVEN on the crash host** (probes O1–O10: `systemd-run --user --scope` MemoryMax bounding works WITHOUT root; a 256M-capped runaway OOM-killed in isolation in 442ms, host+siblings untouched; O8 high-stall-zombie shapes the ladder). **Q1 = per-seat `systemd-run --scope` bound (F.0 policy + F.1 wrap on the Ring-0-output command, V1 launch-mechanic, no v1→v3 import); Q2 = `runner.resource_tap` MEASURED RSS tile + `runner.resource_gate` memory-breaker (mirrors spend_gate, freeze-and-summon via `cgroup.freeze`) = 4th strangeLoop hard-stop.** **✅ DAY-0 STOPGAP APPLIED + working (no repo change): `systemctl --user set-property --runtime tmux-spawn-*.scope MemoryMax=4G MemoryHigh=3500M MemorySwapMax=256M TasksMax=512` — bound every live seat; re-run after each new launch.** **Q1 FAST-TRACK gate (F.0+F.1) COMPOSED** at `.ce/state/research/v35f-Q1-fasttrack-GATE-MANDATE.md` — awaiting Operator ratification; lands BEFORE the A-cluster wave. VPS pilot needs F.0+F.1 FIRST (8GB box, no systemd-oomd). Framed as safety-as-harness-state over the harness's OWN footprint ([[ce-code-as-harness-paper-learnings]] §5.2.5).

## Detail (moved from index 2026-07-05)
- on crash `journalctl -k|grep oom`+`free -h`; git durable.
