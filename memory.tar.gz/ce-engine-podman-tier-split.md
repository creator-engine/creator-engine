---
name: ce-engine-podman-tier-split
description: Container-engine direction RATIFIED 20260704 + same-day DGX spike — rootless Podman for validation/PCO workers; Docker+gVisor stays for agent seats; OCI image engine-agnostic
metadata: 
  node_type: memory
  type: project
  originSessionId: ff7c6aad-2efc-4c15-b974-baf109538a8e
---

Operator ratified 2026-07-04 (on ce-ops#437): CE's OCI image + compose stay **engine-agnostic**; solo users bring any engine (Podman = recommended default); fleet proves one engine per tier.

Same-day DGX spike (report: `.ce/state/research/CE_PODMAN_SPIKE_DGX_20260704.md`): **rootless Podman 4.9.3 PASSES on aarch64** — native overlay, cgroups v2, and the exact CE-410 verification profile (ro worktree, `--network=none`, tmpfs) works with zero config. **gVisor under rootless podman FAILS out of the box** (3 modes documented; needs a gvproxy-style port → ce-ops#439).

**Resulting tier split**: validation sandbox + PCO worker containers = **rootless podman/crun, socketless** (schema enum `podman-rootless` fits as-is); agent seats = **Docker + runsc-gvproxy-ptrace** (proven live) until #439 lands. Podman is installed on the DGX host now.

**How to apply:** CE-410 slice 8a/8b briefs bind to rootless podman; don't attempt runsc under podman until #439; scale rationale (rootless/socketless posture, `podman kube play` k8s on-ramp, Docker Desktop licensing) is banked on #437. [[ce-two-plane-os-architecture-ratified]]
