---
name: headroom-eval-no-go
description: 2026-06-17 evaluated chopratejas/headroom token-saver — NO-GO for CE Claude Max seats
metadata: 
  node_type: memory
  type: project
  originSessionId: 3d84878f-7476-4bab-8598-c35b8c1edce1
---

Evaluated `github.com/chopratejas/headroom` (context-compression token-saver) on 2026-06-17 as a candidate night-shift lever for the Claude Max token burn (29%/day). Codex+gpt-5.5 xhigh research report: `.ce/state/research/RESEARCH_headroom_token_saving_20260617.md`.

**Verdict: NO-GO** for CE Claude Code / Claude MAX **subscription** seats now.
- It is NOT API-key-only — it CAN route Claude Code OAuth via a local proxy (`ANTHROPIC_BASE_URL`, classifies `sk-ant-oat-*`). But subscription mode is deliberately conservative, has critical open bugs (cache-busting → net-NEGATIVE while reporting savings #1042; CCR retrieval data-loss #1006), telemetry on-by-default, sits in the auth/token path seeing bearer material, and mutates `.claude`/`.codex`/hooks/MCP.
- Anthropic policy risk: routing Max OAuth creds through a 3rd-party proxy is near the prohibited boundary.
- Savings are workload-dependent (median ~4.8% broad telemetry; 60-95% only on bulky tool output); no CE-specific proof.

**Pivot (the actual lever):** CE-native token discipline instead — `/clear` hygiene, transcript pruning + task-state reports, model/effort + Codex-offload routing [[ce-model-effort-routing-policy]], a small CE-native shell/log summarizer with deterministic raw-artifact retention. Possible future headroom test only quarantined: disposable repo + API-key (not Max OAuth) + telemetry off. Operator decides if reopened [[ce-operator-decides-relitigation]].
