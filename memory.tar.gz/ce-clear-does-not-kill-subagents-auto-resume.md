---
name: ce-clear-does-not-kill-subagents-auto-resume
description: "After /clear, prior-session background subagents auto-resume from transcript and complete — they are NOT killed; re-dispatching their work creates duplicates."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 260724fc-e8c5-4c0e-98f6-94726041d899
---

After a `/clear` (or context summarization handoff), the previous session's **background subagents are NOT terminated** — the harness **auto-resumes them from transcript** and they run to completion in the new context. On 2026-06-30 resume this caused two failures: (1) a stale prior-session #674 reviewer auto-resumed and returned **APPROVE**, I approved #674 as ce-dev-2 on it, but a fresh reviewer I'd dispatched then returned **REQUEST_CHANGES** catching 3 real blocking defects the stale one missed (premature approval); (2) a stale Phase-4 constitution implementer auto-resumed, finished, and pushed the branch, while a fresh dup I'd dispatched was about to push the **same branch** — near force-overwrite collision (caught + killed the dup just before its push).

**Why:** I assumed `/clear` killed in-flight background agents, so I re-dispatched the "lost" work. The assumption was wrong — they were alive and resuming.

**Counter-example (2026-07-02):** auto-resume is NOT guaranteed either — two fix-workers dispatched minutes before a /clear were simply GONE in the fresh session (TaskList empty, no fix worktrees on disk, PR branches still at the pre-fix commits). Waiting for them would have stalled the lanes. So neither "they died" nor "they'll auto-resume" is safe to assume.

**Third occurrence (2026-07-04):** TaskList in the fresh session showed **empty** — yet the prior session's ce-440 fix-forward worker AND all four watchers auto-resumed and delivered later anyway. An empty TaskList right after resume is NOT evidence the old agents are dead; they can rehydrate minutes later. The re-dispatched duplicate worked the SAME staging worktree concurrently (converged by luck: identical commit chain + one empty retrigger commit; duplicate killed on sight when the original's completion fired). Strongest tell that an original is alive: its task-output file exists and its named artifact (PR/branch/worktree commits) is advancing.

**How to apply:** On every resume, VERIFY before acting either way — TaskList + task-output dir + `git log` on the branches the prior agents owned + worktree existence. Evidence of progress → wait/adopt it; zero evidence (no task, no worktree, branch unmoved) → re-dispatch is correct. BEFORE re-dispatching anything a prior agent owned: (a) check the leftover task-output dir (`/tmp/claude-*/<session>/tasks/*.output`, newest by mtime) — symlinked `.jsonl` = a real subagent that may still be live; (b) check origin for the branch the prior agent was authoring (it may have already pushed); (c) prefer waiting for the in-flight agent's completion notification over re-spawning. If you must re-dispatch, kill the original first (TaskStop). When two agents return conflicting verdicts on the same PR, the evidence-backed REQUEST_CHANGES wins over a bare APPROVE ([[ce-verify-not-already-landed-gotcha]], [[ce-seat-done-not-committed]]).

## Detail (moved from index 2026-07-05)
- re-dispatching dups them (caused a premature approval + near branch-collision). Check task-outputs/origin before re-spawning; kill original first; evidence-backed REQUEST_CHANGES beats bare APPROVE.
- background agents auto-resume+finish.
