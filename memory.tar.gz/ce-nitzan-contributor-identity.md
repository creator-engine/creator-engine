---
name: ce-nitzan-contributor-identity
description: "First external CE contributor Nitzan — GitHub handle Nitzan94, already a creator-engine collaborator (push), onboards from-source on latest main via Claude Code"
metadata: 
  node_type: memory
  type: reference
  originSessionId: dd146cd2-c96c-49bc-a20b-797098491dc6
---

**Nitzan** = CE's first external **contributor** (human dev, **Claude Code** harness, on her **own Claude Code subscription**; works on her own machine). **Mode (canon [[ce-mode-axes-canon]]):** Tier=**Solo** × Collaboration=**Team** (shared `creator-engine` repo with our fleet). Not yet onboarded; when she is, she gets her **own `ce-forge-Nitzan` App** for her governed agent (like every fleet agent — NOT the shared `creator-engine` onboarding App). (Lifecycle Dev-vs-CEO unsettled across notes — don't assert without Operator confirm.)
- GitHub handle: **`Nitzan94`** (user id **219014518**); email **nitzanbarness1@gmail.com**.
- **Already a creator-engine COLLABORATOR** with `pull/push/triage` (invite accepted 2026-06-27) — so R4 "grant contributor access" is ALREADY EXERCISED; no provisioning needed.
- Onboard path (decided 2026-06-27 plan `creator-engine/.ce/state/research/CONTRIBUTOR_ONBOARDING_PLAN_20260627.md`): **from-source editable install on latest `main`** (NOT the 0.2.0/release wheel), via **fork (default) or her collaborator access**; Mac → Linux container (Docker Desktop) [[ce-mac-onboarding-via-linux-container]]. Welcome package finalized at `~/creator-engine/tmp/nitzan-welcome-package.zip`.
- Her PRs are gated like any seat's: author≠approver, CE-DEV-2 reviews/merges; she opens issues as observer-tier. The clean-main-install path she'll eventually use is gated on **ce-ops#366** (main-HEAD artifact resolver, RATIFIED 2026-06-30, build pending).

GAP (brain-lane signal): her handle/identity is NOT in the SSOT `ce-ops:infra/identity-registry.yaml` — only scattered in 06-27 resume-state files. Add her to the registry for reliable recall. Distinct from test-user **Arad** (gets the signed RELEASE 0.3.0, not main). [[ce-github-identity-model]]

## Detail (moved from index 2026-07-05)
- R4 already-done; not in SSOT registry.
- already creator-engine collaborator(push); from-source on main.
