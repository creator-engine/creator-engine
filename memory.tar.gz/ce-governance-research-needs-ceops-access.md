---
name: ce-governance-research-needs-ceops-access
description: "Any CE governance/architecture research MUST have ce-ops (private repo) FILE-TREE read access, not just gh-issue search; else the 'CE baseline facts' are structurally incomplete. Make access-verification the dispatched task's first step."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 42268e2e-bc78-436e-92f2-f34bd5c9a8ca
---

2026-06-18: the ce-ops#120 reviewer-triage research read **only the public `creator-engine` repo** (+ `gh issue search`) and concluded ADR-0003 was "missing" — it actually exists at ce-ops `decision-records/ADR-0003-reviewer-independence-isolation-domain.md`. Per ADR-0001 public/private split, **ADRs, `decision-records/`, designs, and the governance arc live in PRIVATE `ce-ops`**. A research seat without ce-ops file-tree access can't see them.

**Why it matters:** Operator (2026-06-18) ruled this is NOT a one-line patch — a blind-spot like this **structurally taints the entire "CE baseline facts" section and every "searched / did not find" claim**, so the foundation under any ratified design built on it must be re-validated, not patched. I initially under-scoped it as an OQ8 footnote; that was wrong.

**How to apply:**
- Every governance/architecture research mandate must (a) grant ce-ops file-tree read access, and (b) make **"verify ce-ops `decision-records/` is readable; HALT+report if not"** the seat's FIRST step — don't let it produce a report from issues alone.
- When a delivered research artifact shows a private-repo blind-spot, **re-run the research (delta pass)** + downgrade any ratification built on it to provisional until reconciled; don't just fix the one finding.
- Mechanics note: cross-host relay to a codex seat through ssh+sudo — pass the message **base64-encoded and decode remotely**; a bare `$MSG` in remote-side quotes expands empty and silently sends nothing. Always capture the pane to confirm pickup. See [[ce-codex-seed-large-paste-stall]].

Related: [[ce-reviewer-triage-ratified]] [[ce-public-private-ops-architecture]] [[agent-research-discipline]] [[audit-findings-against-operator-directives]].
