---
name: ce-authority-attaches-to-form
description: "Operator principle (2026-06-12) — Operator authority attaches to the canonical CONTENT FORM of a binding act, not the input modality/transducer; voice = just another rendering for text"
metadata: 
  node_type: memory
  type: project
  originSessionId: bfd80365-c499-4779-a81e-19909ae7ac19
---

**Operator adjudication 2026-06-12 (on ce-ops#27, but a GENERAL principle):** a spoken utterance DOES carry Operator authority **provided the content adheres to CE-recognized form**. Meta-level = the L3→L2→L1 analogy applied to authority: **L1 = the standardized form of ratification** (canonical vocabulary, SHA pins, explicit scope); L2/L3 = mechanical definition + rendering layers. Voice is just another rendering for text; keyboard and microphone are both noisy transducers.

**Why:** the gate is the **form-match**, modality-independent — a garbled STT transcription fails closed on form-validation exactly as a typo'd SHA fails on the typed path. No typed-path-only fallback for binding acts.

**How to apply:** when designing any new input surface (voice, GUI, chat-app bridge, future modalities), never gate authority on the modality — gate on validation against the canonical ratification form, with a **form-echo before binding** (fidelity affordance, not an authority gate). Recorded on ce-ops#27; shapes G-7. [[ce-shaping-ux-design]] [[ce-cockpit-frontend-agnostic-core]]

## Detail (moved from index 2026-07-05)
- Related: [[ce-installation-grant-is-mint-ceiling]]
- form-echo before binding.
- ratification FORM not modality.
