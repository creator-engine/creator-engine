---
name: ce-verifier-hash-false-positive
description: "The Claude verify leg can HALLUCINATE computed values (manifest hashes); never transcribe a verifier's hash — independently reproduce it"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 71cdf93e-202b-4810-8953-7dfa4c47203d
---

**Process guard (2026-06-13, ce-ops#46):** in the GPT-compose→Claude-verify cycle, the **verifier can false-positive on COMPUTED values**. On #46 the Claude verifier issued its *sole BLOCKING* item claiming `ALLOWED_PATHS_SHA256` should be `0cb42dc6…` vs the draft's `9b7b3c4f…`. The draft was CORRECT — dev-1 (controller) reproduced the house rule (sorted newline-joined path list + trailing newline) → `9b7b3c4f…`, cross-validated the *method* against the already-RATIFIED ce-43 manifest's published `e710b83a…` (exact match), and **rejected the amendment with proof**. dev-2 independently reproduced `9b7b3c4f…` a third time.

**Why it matters:** blindly transcribing the verifier's "fix" would have CORRUPTED a correct manifest and broken CI. A composer error and a verifier error are symmetric risks.

**How to apply:** NEVER transcribe any agent's computed value (hash/count/digest) on assertion — **independently recompute it**, and when in doubt cross-validate the method against a known-good published value. The manifest-hash discipline ([[ce-pr-path-manifest-carrier-required]], [[batch-strict-mode-gate-workflow]]) already demands the count+hash be reproducible; this extends it: the *verifier's* hash claims get the same reproduce-don't-trust treatment. Strengthens [[audit-findings-against-operator-directives]] (test a finding before acting) — here the finding came from the verifier, not the composer.

## Detail (moved from index 2026-07-05)
- Related: [[rehearsal-preflight-deployed-capability]]
- reproduce never transcribe (#46).
