---
name: ce-operator-decides-relitigation
description: Only the Operator decides what is settled / not to be re-litigated — never frame a recommendation as foreclosing future discussion
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9856ffdc-c843-4966-a075-107dc335e56a
---

Operator correction 2026-06-17: I proposed recording the sandboxed-controller verdict so it "isn't re-litigated." Pushback: **"only I (the Operator) will decide what isn't re-litigated; if I bring an issue back, it means I had a good reason."**

**Why:** authority over what is open vs settled belongs to the Operator (CE insider/decision-maker), not the Controller. Research verdicts are inputs/recommendations, not foreclosures.

**How to apply:** dispose a research/design conclusion as a *recommendation* and leave the door open. NEVER write "do not re-litigate" / "closed, don't revisit" into a ticket or memory on the Operator's behalf. If the Operator re-raises a previously-"decided" topic, assume a good reason and engage fresh — don't reply "we already decided this." Pairs with [[offer-recommendation-on-options]] and [[ce-user-choice-architecture]].

## Detail (moved from index 2026-07-05)
- if they re-raise, engage fresh.
- never frame "don't re-litigate".
