---
name: verify-hash-independently-before-fold
description: "Always re-reproduce any manifest/path-set hash a verify seat claims is wrong before transcribing it — verify seats can hallucinate a hash \"fix\""
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 699b284d-b9d4-44b5-826e-a249478cd2ee
---

When folding a verify verdict, NEVER transcribe a machine-checkable digest (closed-manifest `ALLOWED_PATHS_SHA256`, path-set hash) on the verifier's say-so. Independently re-reproduce it yourself with the house rule, and prove your method by reproducing a KNOWN-GOOD ratified manifest's published digest (e.g. the ce-43 reaper spec's `e710b83a…`).

**Why:** 2026-06-13 day-shift, the #46 verify seat raised its SOLE blocking finding as "the manifest hash is wrong" and supplied a confident "correct" value (`0cb42dc6…`). It was the verifier that was wrong — the draft's `9b7b3c4f…` reproduced exactly under the house rule, and my method reproduced ce-43's published digest exactly, proving the draft was right. Blindly transcribing the verifier's value would have CORRUPTED a correct closed manifest (introducing the very defect the verifier hallucinated). Same shift, the #54/#56/#57/#58 verifiers all got their hashes right — so it is not systematic, which is exactly why you must check each one rather than trust or distrust wholesale.

**How to apply:** for each verdict, `awk` the 15-ish manifest paths (exclude the `COUNT=`/`SHA256=` lines), `LC_ALL=C sort | sha256sum` (house rule = newline-joined sorted list, single trailing newline; watch the locale footgun — `_versions.py` sorts before `ce_cli.py` only in C locale), and compare to BOTH the draft's claim and the verdict's claim. Cross-check the method against a ratified manifest in the same pass. Generalises [[audit-findings-against-operator-directives]]; pairs with [[ce-pr-path-manifest-carrier-required]] and the re-verify-on-core-redesign / controller-validate-on-additive-narrow rule.
