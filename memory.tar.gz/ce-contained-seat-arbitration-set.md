---
name: ce-contained-seat-arbitration-set
description: "Contained-seat briefs must name the FULL host-arbitrates failure set (not just ssh-keygen) + pass --declared-work-class, else seats emit false BLOCKED"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8055e914-85fe-4a69-9377-bf58ca77c226
---

Contained-seat preflight briefs must allowlist the FULL known in-container failure set as
"READY-FOR-HARVEST with named caveats — host arbitrates", not a single guard. The set (as of
2026-07-05, dev-3 ce-vps-codex + dev-4 ce-dgx-codex):
- install-spec signature guard (ssh-keygen absent in container)
- portability guard (/run/secrets)
- check-examples aggregate + well-formed examples (env/policy class)
- `ce` not on PATH → module-equivalent invocation
- full-suite pytest env failures that reproduce identically on origin/main baseline
  (zero-NEW-failures is the seat-side bar, not zero failures)
Also: seats must run `ce validate-pr --profile contained-seat --declared-work-class <class>` —
omitting the flag fails the work-sizing gate locally ("missing declared work class").

**Why:** On 2026-07-05 a dev-3 brief allowlisted only the install-spec guard; the seat hit the
other env classes, correctly emitted BLOCKED per the literal rule, and cost a probe+harvest
round-trip on two completed units. Same session, the identically-shaped dev-4 brief carrying
the full set produced clean READY-with-caveats behavior.

**How to apply:** Paste the full arbitration set + the --declared-work-class flag into every
contained-seat brief's preflight section. Host harvest remains the arbiter (zero new failures
vs fresh origin/main). Durable product fix tracked in ce-ops#453 Part A / ce-ops#400 (image
deps). [[ce-run-full-preflight-before-push]] [[ce-harvest-contained-seat-stale-origin]]

## Detail (moved from index 2026-07-05)
- (ssh-keygen/portability/check-examples/env-pytest w/ zero-NEW bar) + pass --declared-work-class; narrow rules → false BLOCKED.
- the FULL host-arbitrates failure set.
