---
name: ce-openai-account-switch-playbook
description: How to switch the codex fleet between OpenAI Pro subscriptions (done often) — drain→swap-auth→canonical-relaunch→resume
metadata: 
  node_type: memory
  type: reference
  originSessionId: 6c51a018-83e5-45dc-8943-a61fef8b0fc7
---

We switch the codex fleet (dev-1/3/4) between two OpenAI Pro subscriptions OFTEN (quota). **No zero-restart switch exists** — codex reads auth once + holds the token in memory; a seat adopts the new account only on RESTART. Two enablers: swapping `auth.json` on disk does NOT disturb a running seat (pre-stage anytime); codex sessions persist on disk (host bind-mount for contained seats) → `codex resume <SESSION_ID>` rehydrates (imperfect on long/auto-compacted contexts → keep a handoff brief). Limits are PER-ACCOUNT → switching = fresh pool.

**Pre-stage (once, non-disruptive):** per host, `CODEX_HOME=~/.codex-acctB codex login --device-auth` into acct B → ready auth.json. **On headless hosts (VPS) `--device-auth` is REQUIRED** — bare `codex login` tries a browser/localhost callback and fails; `--device-auth` prints a URL+code to complete elsewhere (confirmed working on the VPS 2026-06-25). VPS codex bin = `~/.npm-global/bin/codex` (not on non-login-shell PATH; set `CODEX_BIN` for the helper, which may need `--device-auth` added).

**Switch per seat (drain-to-boundary):** 1) `/status` → record SESSION_ID + 1-line handoff; 2) drain to a task boundary; 3) clean-stop codex; 4) swap host `auth.json` to acct B (contained seats' auth.json is on the HOST bind-mount → host-side copy, don't enter the container); 5) relaunch — dev-1 in-pane; **dev-3/dev-4 via canonical `ce launch`/`run-*-runsc.sh` ONLY (raw codex restart breaks bwrap — [[ce-seat-relaunch-canonical-launch-only]])**; 6) `codex resume <SESSION_ID>`; 7) `/status` to confirm new account + fresh quota.

**Order:** dev-1 (canary) → dev-3 → dev-4; stagger (never two restarting at once).

CODEX_HOME paths: contained seats bind-mount the host codex home rw (DGX `/home/cedev4/.codex`; VPS container-user `~/.codex`); the launcher also overlays a generated read-only `config.toml` (so config goes in the launcher, not the host file — see statusline). Verify on a throwaway login that acct B shows an independent pool in `/usage` before relying on it.

**Codified SSOT:** LIVE in **ce-ops** main: `docs/operations/SWITCH_OPENAI_ACCOUNT.md` + `scripts/switch-openai-account.sh` (landed via creator-engine PR #454, relocated to ce-ops by the public/private doc split PR #494 — that's why creator-engine git log shows them deleted; verified 2026-07-07, ce-ops#245). This memory is the gist/pointer. [[ce-codex-shared-account-subscription]] [[ce-codex-seats-cannot-self-compact]] [[ce-codified-actions-not-rediscovery]]

**⏫ 2026-07-06 night switch — verified account map + state:** account_id `2dc1bc68` =
**neckar@gmail.com** (x20); account_id `5bf52cef` = **amitaicoco1@gmail.com**. JWT-decode the
auth.json (`tokens.id_token` payload email claim) to identify — file dates/names mislead.
Found ALL hosts' live codex homes (dev-1 ~/.codex, dev-3 ~/.codex-contained on dev1, dev-4
/home/cedev4/.codex, cedev2 ~/.codex) already PRE-STAGED with neckar from Jun 25-30 while the
running seats held amitaicoco1 in memory — i.e. a prior pre-stage never got its restart. So a
"switch" can be pure drain→canonical-relaunch→resume with ZERO login. Neckar refresh token
still valid after ~8 days (verified via `codex exec` on cedev2). dev1 `~/.codex-acctB` holds
the amitaicoco1 fallback auth. (Correction 2026-07-07: the codified SSOT DID land — it lives in ce-ops, not
creator-engine; see the SSOT paragraph above. ce-ops#245 updated.)
