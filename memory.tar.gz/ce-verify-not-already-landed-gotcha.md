---
name: ce-verify-not-already-landed-gotcha
description: "GOTCHA — before dispatching/acting/re-deciding, verify the work or decision hasn't ALREADY landed in a prior session"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 7ed7fba2-2c2b-4884-b503-f02c682d85b0
---

**GOTCHA (Operator-flagged 2026-06-26, after it happened MULTIPLE times):** I repeatedly act on work that already landed — dispatch tickets already implemented, re-surface decisions the Operator already ratified in a prior session, or prepare to "relocate/build" something that's already done. Example: ce-ops#91 was dispatched to dev-4 and produced PR #544, and the Operator had ALREADY approved the relocate decision in a prior session — so the work and the decision may already exist.

**Why it matters:** burns tokens and Operator attention; the fleet has limited weekly quota; re-litigating a settled decision wastes the Operator's time and erodes trust in the gate.

**How to apply — verify BEFORE acting, every time:**
- Before DISPATCHING a ticket: confirm it's genuinely undone — read the target files / recent merges / the issue's close history (was it closed then reopened? is there a prior PR?). Bake "VERIFY-UNDONE with evidence" into every dispatch brief (already standard; enforce it). [[ce-dispatch-territory-map-before-dispatch]]
- Before ACTING on a decision (relocate, build, scrub, file): check whether it was already executed — does the target location already contain it? Was the ticket already resolved? grep the destination repo/path.
- Before RE-SURFACING a decision to the Operator: check resume states + ce-ops + memory for a prior ratification. If the Operator says "I already approved this," treat that as a hard signal to STOP and verify the landed-state, not to re-execute.
- When verification is non-trivial (cross-repo, multi-file), DISPATCH a cheap (Sonnet) verify worker rather than inlining — and rather than trusting one planner's say-so. [[ce-controller-inlines-execution-drift]]

**COMMIT-ANCESTRY + RENAMED-FILE traps (lived 2026-07-03, ce-369 redo near-dup):** `git merge-base --is-ancestor <branch-tip> origin/main` FALSE-NEGATIVES for already-landed work — the merge queue rewrites commits, so a merged branch's tip is often NOT an ancestor of main even when its TREE landed byte-identical (ce-369 redo landed as PR #751 while the ancestor check said "not on main"). Second trap the same day: grepping main for the work's OLD filename misses a rename (fleet_identity_denylist_snapshot.py → identity_denylist.py). FIX: already-landed = **content check** — `git fetch origin main && git diff origin/main...<branch>` (empty or carrier-only ⇒ LANDED), plus `gh pr list --state merged --search "head:<branch-slug>"` for a prior merged PR by branch name. Never ancestry, never historical filenames. (Caught by the harvest worker's layered verify-undone — keep it IN worker briefs; the redundancy is what saved it.)

**STALE-LOCAL-CHECKOUT trap (lived 2026-06-26):** verify/finder WORKERS grep the LOCAL working tree, which LAGS `origin/main` — a ticket that merged this session reads as "undone" (a finder re-proposed ce-ops#273 right after it merged as PR #551, because the local checkout lacked the merged file). FIX: every verify-undone check must `git fetch origin main` FIRST and verify against `git show origin/main:<path>` / `git ls-tree -r origin/main` + `gh` PR/issue state — NEVER local file absence. Bake "verify against origin/main, not local" into every finder/verify brief. The controller must re-verify a finder's "undone" claim against origin/main before dispatching.

**SAME-TICKET-PARALLEL-DISPATCH trap (lived 2026-07-02):** ce-ops#382 was dispatched to dev-1 (branch `ce-382-brain-drift-falsered`, merged 2026-07-01) and AGAIN to dev-4 the next morning (branch `ce-382-brain-drift-local-reconcile` → PR #730) — the second fix was redundant for the symptom (verification worker proved the false-RED was already unreproducible at base). Root cause: the not-already-landed probe greps for open PRs/branches but the first fix had ALREADY MERGED under a non-obvious branch name. FIX (cheap + mechanical): before dispatching ticket N, run `git ls-tree origin/main .ce/changelog/ | grep -i <ticket-number>` — every merged PR leaves a changelog fragment slugged by branch, and branch slugs carry the ticket number by convention. Also grep `git log origin/main --grep="<ticket>#N\|ce-N-"`. One line, catches merged same-ticket work regardless of branch naming.

This is the standalone, prominent form of the "already-done trap" that kept recurring. Default suspicion: assume it might already be done until evidence shows otherwise.

## Detail (moved from index 2026-07-05)
- VERIFY the work/Operator-decision hasn't already landed in a prior session.
