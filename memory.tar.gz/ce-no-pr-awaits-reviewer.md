---
name: ce-no-pr-awaits-reviewer
description: No PR should sit awaiting a reviewer; any non-author seat picks it up and drives the review via a fan-out worker
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5183bef7-5a7b-413f-9619-d7da7f7c58c8
---

Operator directive (2026-06-21): **no PR should ever sit "awaiting a reviewer."** Every seat that did NOT author a PR can and should pick up its review and drive it via a worker — concurrently with its own current work.

**Why:** seats are foreman-controllers with native fan-out ([[ce-seats-foremen-self-managed-fanout]], [[ce-controller-spawns-many-workers]]). A code review is just another fan-out worker task, not a blocking single-threaded duty. Treating "independent reviewers" as a scarce resource (e.g. "both candidate seats are busy, I'll assign review next tick") is a FALSE constraint that stalls the merge pipeline — it was my error.

**How to apply:** in every watch/route tick, immediately assign each open PR that is awaiting review to ANY non-author seat as a worker task ("fan out a worker to drive the review of #N"), in parallel with whatever that seat is building. Never report a PR as "held for a free reviewer" and never defer review assignment to a later tick for lack of capacity. Still respect author≠reviewer ([[independent-reviewer-venue-rule]]) — that's the only constraint on WHICH seat, not WHETHER to assign now.