---
name: ce-gbrain-research-findings
description: "Research (2026-06-30) comparing garrytan/gbrain to CE's company brain: CE's storage invariant validated; real bottleneck is dim-32 placeholder + unwired launch-hydration; gbrain's transferable win is zero-LLM markdown-link graph"
metadata: 
  node_type: memory
  type: project
  originSessionId: dd146cd2-c96c-49bc-a20b-797098491dc6
---

architect_research (Opus) compared **garrytan/gbrain** (MIT, ~24.6k★, TS/Bun) to CE's company brain on 2026-06-30. Full report: `creator-engine/.ce/state/research/reports/gbrain-vs-ce-brain-20260630.md`.

**Validations:** gbrain independently uses CE's exact invariant — markdown+frontmatter = system-of-record, vector/graph DB = derived rebuildable cache (CI-guarded byte-identical rebuild). CE's storage layer is its strongest; SSOT structural precedence + pointer-only recall + privacy fail-closed are things gbrain lacks.

**CE's real bottleneck (internal, not gbrain):** production `recall.sqlite` runs on the **deterministic dim-32 placeholder embedder** → semantic recall is non-functional in prod today. And launch-hydration (injecting recall into controller decision context) is **design-only** (`docs/design/ce-brain-memory-augmentation.md`, no impl authorized). The MEMORY.md auto-memory recall failure (subagent-launch convention) is exactly what wired+real-embedded recall would fix. Two memory systems (repo brain vs controller auto-memory) are unintegrated — open Q: route auto-memory through the brain recall surface.

**Prioritized follow-ups (NOT yet filed):** P0 back prod recall with a real self-hosted embedder (GPU-gated — see [[ce-brain-on-fake-embeddings]]); P1 land launch-hydration slice; P1 **zero-LLM typed-graph edge layer** over existing `[[wikilinks]]` (gbrain's highest-ROI idea, +31 P@5, invariant-safe — CE already wikilinks heavily); P2 deterministic intent-classify + source/tier boosts + per-page max-pool; P3 replay/qrels eval + advisory contradiction/staleness detection.

**Do NOT adopt:** external per-token rerankers/embedders (ZeroEntropy/Voyage/OpenAI) for CE surfaces (violates no-per-token-billing); Postgres/pgvector (Team-tier; keep sqlite-vec for solo contained); auto-write into the assertion ledger SoT (must stay deliberate/ratifiable). [[ce-no-anthropic-sdk-per-token-billing]] [[ce-knowledge-ssot]]

## Detail (moved from index 2026-07-05)
- adopt zero-LLM wikilink graph; P0-P3 follow-ups unfiled.
- CE bottleneck=dim-32 placeholder+unwired launch-hydration.
- s CE's SSOT-derived invariant.
