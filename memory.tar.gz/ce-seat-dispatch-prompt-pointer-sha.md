---
name: ce-seat-dispatch-prompt-pointer-sha
description: "Always dispatch seats via a saved prompt FILE + pointer + SHA, never a long inline prompt"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5f2b5f45-8ec4-4ec3-9b6e-1196f3b2bc05
---

When dispatching/seeding a governed seat, **always save the prompt to a file first, then send the seat a short pointer + the file's SHA256** — never paste a long prompt inline.

**Why:** (1) inline prompts paste-collapse in codex/claude TUIs (the `[Pasted Content]` + second-Enter dance, content loss risk); (2) no durable record of exactly what was dispatched; (3) no integrity/ratification anchor. A file+SHA fixes all three and is the same shape as the SHA-bound `do_not_replan` ratified-tasks→worker handoff contract ([[ce-speckit-superpowers-whathow]], ce-ops#119) — the dispatch IS the ratified task, pinned.

**How to apply:**
1. Write the prompt/brief to a file (e.g. `~/ce-briefs/<task>.md`).
2. `sha256sum` it.
3. Seed the seat with a one-liner: `Read <path> (sha256 <hash>) and execute it. Verify the hash matches before acting.` — short line, no paste-collapse.
4. The seat reads the exact ratified prompt; drift is detectable via the SHA.

**Contained seats (dev-4):** its container only bind-mounts the repo worktree + `.codex`, so write the brief under the bind-mounted worktree at a gitignored path (e.g. `/home/cedev4/ce-workspaces/creator-engine/tmp/<task>.md` → readable inside as `/workspace/creator-engine/tmp/<task>.md`), then send the pointer+SHA. For VPS seats, write under the seat user's `~/ce-briefs/` (already the pattern for the bigger briefs). Operator directive 2026-06-20: do this for ALL seeds, not just the large briefs.

**⚠️ RE-BRIEFS / CORRECTIONS ARE SEEDS TOO — Operator catch 2026-06-28:** I followed file+pointer for INITIAL briefs but regressed on W3 *corrections*, sending ~1018-char re-briefs INLINE via `herdr agent send`. Result: a `[Pasted Content 1018 chars]` blob sat UNSUBMITTED in dev-4's input box (paste-collapse + the second-Enter never fired). EVERY injection — initial, re-brief, or fix-correction — goes via file+pointer+SHA. Transfer with `cat brief | <docker exec -i> tee /tmp/<task>.md` (content via stdin, never argv), then send the SHORT pointer line.

**herdr drive mechanics (verified 2026-06-28):** transport for contained/herdr seats:
- Inject text: `herdr agent send <pane> "<short pointer>"` then SUBMIT with `herdr pane send-keys <pane> Enter`. Verify it landed via the `Working`/`esc to interrupt` indicator (the input box clears on submit; an idle box shows a greyed suggestion).
- **Clear a stuck/unsubmitted box:** `herdr pane send-keys <pane> Escape` (or `ctrl+u`). Key token format is `ctrl+X` / named keys (`Enter`, `Escape`) — `C-u`/`ctrl-u` are REJECTED (`unsupported key`).
- Don't re-send to a busy seat ("Messages to be submitted after next tool call" = queued; re-sending dupes). [[ce-herdr-dispatch-landing-misread]]

## Detail (moved from index 2026-07-05)
- transfer via stdin→tee not argv.
- NEVER inline paste (incl re-briefs/corrections).
- to file → send short pointer + sha256.

**⏫ Base-pin nuance (2026-07-10):** a hard `STOP if origin/main != <sha>` precondition
false-blocks seats whenever the merge queue is actively landing (main legitimately moves
between compose and fetch). During active-landing periods, phrase the pin as
"<sha> OR LATER — use the current origin/main you fetch; re-block only on FORCE-PUSH/rewind"
(the old restock briefs had this right). Keep the hard pin only for release-cut bases.
