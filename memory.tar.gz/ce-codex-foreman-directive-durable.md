---
name: ce-codex-foreman-directive-durable
description: "Codex seats revert to doing work INLINE after compaction unless the foreman/fan-out directive lives in ~/.codex/AGENTS.md (durable, re-injected); seed-only is NOT durable."
metadata: 
  node_type: memory
  type: project
  originSessionId: bd40e3b4-6d32-4603-a038-013c53cd022e
---

**Failure mode (verified 2026-06-21):** the codex fleet's "drive via worker fan-out, don't do work inline" pattern was **prompt/seed-propagated** (interim, per [[ce-controller-spawns-many-workers]]) — so it is **lost on context compaction**. Caught dev-1 (reviewing #299) AND dev-3 (building #23) both working INLINE in their own lanes post-compaction, no explorer/worker sub-agents. Root cause: the repo `AGENTS.md` is a bare SpecKit stub with zero fan-out directive.

**Durable fix:** codex auto-loads `~/.codex/AGENTS.md` (global, per-seat) and **re-injects it every turn → survives compaction**. NOT the public repo `AGENTS.md` (would leak internal dev-process to external contributors). Placed a concise **FOREMAN operating directive** (`/tmp/ce-foreman-directive.md`, sha `0610b86c8456…`, 21 lines) at `~/.codex/AGENTS.md` on dev-1 + dev-3 (VPS, via `sudo -n -u <user>`) and dev-4 (DGX container, couriered + self-installed). Directive: delegate substantive build/review to workers; inline only for plan/read/git-status/dispatch/monitor/trivial-coordination-edits; explicit post-compaction self-check.

**Caveat:** a running session caches AGENTS.md at session start — the directive takes effect at each seat's **next compaction/resume** (which is exactly when the regression fires, so timing is right). dev-4's container `~/.codex` may reset if the container is recreated → re-install on container rebuild.

**Permanent fix = ce-ops#163** (born-a-foreman `seat_class`, deterministic + governed) — this directive is the interim until #163 ships. **Verify the fix empirically:** watch a seat's next post-compaction substantive task — it should spawn workers, not edit source inline. Pairs with the lost-queue-on-rotation finding (queues + behavior both die on rotation unless made durable).

**STANDING DISPATCH RULE (Operator, 2026-06-23) — applies to ME (the controller), every push:** EVERY brief/nudge I send a fleet dev (dev-1/3/4) MUST embed a foreman directive — *"You are a CE controller/foreman: drive this via governed CE workers (fan out the decomposable sub-tasks, reserve your context for plan/dispatch/verify); inline ONLY trivial/atomic steps."* This is the interim enforcement until #163 self-enforces; do NOT omit it even on small briefs. (Use a standard preamble.) Caveat per the doctrine: a genuinely atomic single-file change IS correctly done inline — the directive is "delegate the decomposable, inline the trivial," not "spawn a worker for everything."

**STATUS 2026-06-23 (Operator re-emphasized — dogfooding gap is LIVE).** Operator watched dev-1/3/4 panes doing fixes/reviews INLINE again and ruled this MUST be baked-in, not left to controller judgment. Ground truth: **#163 is already DESIGNED + Operator-RATIFIED** (defaults ratified 2026-06-21, sha `6567380f…`): boundary behavior = **hard-deny / force-delegation modeled on the §7 push-block**; primary trigger = **action-type × irreversibility** (line-count only a tertiary backstop — no orchestration-economics literature exists, so don't invent a LOC number); worker isolation = **worktree + cred-scrub now**, container-per-worker staged; **foreman-of-foreman recursion allowed, depth-bounded**. So the gap is **BUILD/DEPLOY, not design and not a missing ticket** — the deterministic gate that would refuse a foreman's direct impl-work hasn't shipped, so seats still inline. **Mechanical prerequisite = #148** (controllers couldn't `ce launch` a worker from an un-provisioned env → fan-out was partly *unavailable*, not just un-chosen). Recommended next program: BUILD #163 (req-1 born-a-foreman launcher inject + req-2 harness-agnostic worker-spawn primitive + req-3 §7-style hard-deny refusal). It's meta-leverage — see [[ce-orchestration-replaces-model-upgrade-pitch]] (our own throughput ~2x'd this week via orchestration, no model change). Pairs with [[ce-controller-inlines-execution-drift]], [[ce-seats-foremen-self-managed-fanout]], parent tenet ce-ops#165.

## Detail (moved from index 2026-07-05)
- verify post-compaction.
- unless fan-out directive in `~/.codex/AGENTS.md`.
- ert to inline after compaction.
