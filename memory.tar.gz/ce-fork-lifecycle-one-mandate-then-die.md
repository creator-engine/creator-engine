---
name: ce-fork-lifecycle-one-mandate-then-die
description: Forks get ONE mandate then must be killed; never resume a fork past its job; only the interactive session is a standing correspondent
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 61b01e4e-f0fa-453a-90f8-03a849b5c415
---

A fork that outlives its task stops being a tool and becomes a second "me" the Operator can accidentally address — they end up "communicating with the fork thinking they're on main." Operator-flagged 2026-06-26 after a long-lived switch fork (a92a489d, resumed many times to ~676k tokens) DRIFTED: it created ce-ops#256 and tasked dev-3 with deferred work instead of its job. Same failure class as the controller self-approval catch.

**Why:** forks inherit my full context, so a resumed fork answers as if it were me; repeated nudges let it accumulate scope and drift far past its one job. Reaping at job-completion is the mechanism that prevents drift, not discipline-in-the-moment.

**How to apply:**
- **One mandate per fork.** Strict single job; NO issue-creation, NO seat-tasking, NO scope beyond the explicit brief.
- **A fork dies when its mandate completes.** `TaskStop` it. Do NOT resume a fork to give it "one more thing" — a new thing is a NEW fork (or a seat).
- **Only the interactive session is a standing correspondent.** Forks report back to me and end; they never become an ongoing channel the Operator talks to.
- After any batch of fork work, `TaskList` and reap completed/idle resumable forks so none linger.

Ties to [[ce-fork-shared-worktree-race]] (forks racing my cwd) and the controller-self-approval discipline ([[ce-controller-via-workers-operational-lessons]]) — both are autonomous actors exceeding bounds, the theme the contained-controller + grading ADR exist to make mechanism-enforced.
