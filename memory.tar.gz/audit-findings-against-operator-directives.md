---
name: audit-findings-against-operator-directives
description: "Operator feedback (2026-06-07) — when a finding \"looks intentional / by-design,\" TEST it against the Operator's explicit standing directives BEFORE concluding it's fine; don't rationalize. Surface directive-violations proactively, don't wait to be caught."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bfad4f55-cd9e-4e98-9c51-eab66260a4be
---

**Operator feedback (2026-06-07), triggered by the `.hermes` naming-error miss.** I called the `.hermes` state-root "correct by design" **twice** in one session before the Operator showed it violates their **naming-decoupling directive** (separate CE terminology from implementation). The error had sat uncaught — surfaced only when the Operator hit it by chance — and they pushed back that I should have caught it.

**Why:** the Operator issues explicit standing directives (naming-decoupling, terminology canon, coexistence, dev-process-on-v1, etc.) and relies on me to AUDIT against them. A surface that *looks* deliberate is NOT evidence it *complies* with their directives — my "looks intentional → by design" shortcut is exactly the failure mode. They act on conclusions ([[user-ce-team-member]]), so an un-audited "it's fine" is costly.

**How to apply:**
- In EVERY audit / review / grounding pass, explicitly cross-check findings against the known standing directives — [[ce-hermes-vs-ce-state-roots]] (naming-decoupling), terminology canon, [[ce-v1-v3-coexistence-not-deletion]], [[ce-dev-process-stays-on-v1]], [[ce-g5-cost-enforcement-optout]] — and FLAG violations proactively.
- Prefer "this looks intentional, but it conflicts with directive X — flagging" over "this is by design." When something persists that a directive said to change, treat it as suspected debt until proven compliant, not as proven-intentional.
- Recommend a MACHINE guard (fitness-function check) for any directive that can be mechanically enforced, so compliance is caught by CI, not by the Operator by chance — the version_boundary pattern. Pairs with [[offer-recommendation-on-options]] + the harder evidence-discipline for [[user-ce-team-member]].

## Detail (moved from index 2026-07-05)
- flag + recommend a machine guard.
- findings vs standing directives.
