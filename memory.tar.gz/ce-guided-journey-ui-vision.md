---
name: ce-guided-journey-ui-vision
description: "Operator vision 2026-07-08 RATIFIED direction: UI/UX = the human-side harness, co-equal with the engine; guided all-inclusive journey (expedition-agency metaphor); webui→mobile riding the cockpit emission model"
metadata: 
  node_type: memory
  type: project
  originSessionId: 610efb0b-4c03-43ec-a265-97e9f566f502
---

**Operator vision (2026-07-08, pre-research alignment — controller onboard):** CE serves TWO
probabilistic engines — the LLM and the HUMAN. Determinism lives in the governance layer for
both: hooks/harness = the model's guardrails; the **guided journey UI = the human's guardrails**.
UI/UX is architecturally co-equal with the engine, not a skin. "Trusting the user to drive the
controller like the Operator" fails the same way "trusting the model to self-grade" fails.

**The product shape (expedition-agency metaphor):** all-inclusive guided journey — user's idea →
working software with every logistic handled; the user still makes inputs, but ONLY their
decisions, at the right moment, with recommended defaults pre-staged (= user-choice-architecture
+ AWAITING-OPERATOR queue as the core UI primitive / user inbox). The vacation test: return
after weeks → click project → see journey position → click resume. Natural language remains the
interaction; the journey is guided along a path the user doesn't need to know exists.

**Architecture anchors (all pre-ratified, this vision unifies them):**
- Read-model emission: webui renders the SSOT (forge + state roots), NEVER holds state
  [[ce-cockpit-pivot-herdr-base]] / visibility=channel-emission.
- Hermes-style per-turn completion reports become durable rendered emission events (what was
  done / how / what's next), accreting into the journey view — not ephemeral chat.
- Controller RESUME_STATE files = the controller's own vacation-test solution; users get the
  auto-generated visual equivalent.
- Sequencing, NOT overturning [[ce-shipped-product-terminal-first]]: TUI ships now to technical
  early adopters; webui = the surface that makes CE sellable to non-machine-thinking humans;
  mobile = the awaiting-operator inbox in your pocket (approve/answer, not full control).
- OpenClaw webui = prior-art reference [[openclaw-steipete-prior-art]].

**Status:** vision ratified as direction; HEAVY research+design task to follow (research lane
ticket filed in ce-ops). Related: [[ce-user-choice-architecture]]
[[ce-positioning-ease-not-governance]] [[ce-product-north-star]] [[ce-awaiting-operator-queue-rule]]
