---
name: ce-method-memories-host-portability
description: "CE-DEV-2 review recommendation (2026-06-11, Operator-endorsed) — \"proven method\" memories carry their birth-host's assumptions; diff every concrete parameter against the current host before reuse"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2bae9844-7348-4cd1-9a89-54226b622914
---

**From the CE-DEV-2 controller's review of the PR #200 lane (persisted on Operator instruction,
2026-06-11):** the `.hermes` ledger-root repeat happened DESPITE two standing warnings, because
I reused the laptop-era venue method verbatim — method memories encode their birth-host's
assumptions.

**Why:** "PROVEN" means proven *on the host where it was proven*. Paths, state roots, env-var
names, identities, push mechanics all vary by host (CE-DEV-1 vs CE-DEV-2 differ on every one).

**How to apply:** before reusing any proven-method memory on a different host, explicitly diff
each concrete parameter against the current host's standing directives — state/ledger root
(`.ce/state/...` on CE-DEV-1, [[ce-hermes-vs-ce-state-roots]]) · reviewer identity + env-var
name ([[ce-team-mode-host-architecture]]) · push path · tool availability/PATH. When a
parameter gets host-corrected, bake the correction back into the method memory (as done for
the ledger root) so the memory becomes host-aware rather than host-blind. Family: "look before
executing", with [[ce-preflight-merge-path]] + [[ce-controller-steers-seats-execute]].
