---
name: ce-user-choice-architecture
description: "CE design doctrine — give options with our recommendation encoded as the default; solve real problems, don't invent them; anchor on direction, hold implementation swappable."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 246cec36-0c18-4fea-aba8-efebb75868e0
---

**Operator architecture doctrine (2026-06-13, deliberately taught) — three interlocking principles for ALL CE design:**

1. **User-choice via defaults.** Give the user real options; encode CE's recommendation *implicitly* as the **DEFAULT** (not by removing the alternatives). Recurs everywhere: Dev(default)/CEO/strangeLoop modes; interactive/non-interactive install; sandbox user-level(default)/gVisor-hardened opt-in; inference native/NemoClaw-routed; runtime backend standalone/OpenShell. The user's needs + desires dictate the final pick. **Never bet the farm on one path** — NemoClaw is ONE option, not THE path, just like Dev is one mode.
2. **Problem-first.** Design the solution to solve a real problem; do NOT invent a problem to fit a solution you came up with. (This is the discipline that keeps the NemoClaw/Claude/Codex integration *implicit* — it serves users already on that stack; it's not a trophy. CE's SDLC automation is the main event.)
3. **Direction over details.** Anchor on architectural **DIRECTION** (durable); hold the implementation **MECHANISM swappable** (CE will often substitute its own specifics — e.g. our own sandbox impl rather than literal srt/Seatbelt/bubblewrap). The #71 recommendation was *right on direction* even though the mechanism details will be swapped.

**Why:** "Authority through structure & defaults, not coercion" is the SAME philosophy as CE's grader-outside moat, one layer down — the gate *evaluates*, it doesn't dictate; the installer *recommends-via-default*, it doesn't force. **Product principle == governance principle.**

**How to apply:** Every design I bring = a **menu of profiles behind a clean abstraction** (e.g. `RunnerBackend`), with a smart **default that signals our recommendation**, both interactive + non-interactive paths, and the mechanism explicitly flagged swappable. Lead with direction, not implementation. Links: [[ce-v3-product-vision]] (Dev/CEO modes), [[ce-g5-cost-enforcement-optout]] (Default-vs-Custom installer), [[ce-shaping-ux-design]], [[openshell-nemoclaw-stack]], [[ce-product-north-star]].

## Detail (moved from index 2026-07-05)
- Related: [[offer-recommendation-on-options]]
- authority via defaults not coercion.
- problem-first.
