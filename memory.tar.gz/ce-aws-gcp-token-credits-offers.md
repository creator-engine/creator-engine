---
name: ce-aws-gcp-token-credits-offers
description: "CONFIDENTIAL (2026-06-10): AWS offered $10,000 USD in API tokens for CE dev on AWS infra; Google approached for counter-offer. Under consideration — reshapes the token-economics constraint."
metadata: 
  node_type: memory
  type: project
  originSessionId: ab38584e-06c5-40cb-aba2-ec5d3f4a84bd
---

**CONFIDENTIAL — private-ops only, never public.** On **2026-06-10** CE received an **AWS offer: $10,000 USD in API tokens** to continue CE development using AWS infrastructure. **Status: under consideration**; the Operator has also approached **Google for a counter-offer**. No decision yet — do not act on either, do not mention in public artifacts.

**Why it reshapes things (analysis, 2026-06-10):**
- **Relieves the binding fleet constraint.** The Track-2 assessment ("token rate, not compute, binds fleet size" — [[ce-pilot-env-hetzner-vps]]) was subscription-shaped. $10k of API credits (AWS = Bedrock serves `us.anthropic.*` Claude models; GCP = Vertex equivalently) converts the fleet from subscription-rate-bound to credit-budget-bound → real multi-seat scaling on CE-DEV-1/Track-2.
- **Upgrades metering honesty tier.** API usage is **MEASURED**, not ESTIMATED ([[ce-cockpit-resource-envelope-routing]]) — a credits-funded fleet gives the G-lane (ce-ops#4) and Cockpit B.4 meters real numbers, and makes the v3.5-D compute-demand figure for the NVIDIA deck directly measurable.
- **Transport implications.** API-key auth is NOT subject to Anthropic's ACP-over-OAuth ban ([[ce-substrate-acp-decision]]) — credits would open the Tier-A ACP path that subscription auth forecloses. Claude Code supports Bedrock/Vertex backends natively (env-switched).
- **Strategy watch-item.** Infra-provider courtship (AWS vs GCP) is adjacent to but distinct from the NVIDIA play ([[ce-nvidia-v35-strategy]]) — CE's substrate is transport/provider-agnostic by ratified decision; accepting cloud credits does not couple CE to a provider, but optics/terms should be checked against the partnership posture before the 01-Jul meeting.

**Open:** Operator decision AWS vs GCP (or both/neither); terms unknown to me; revisit fleet-sizing + G-lane scoping when decided. Recorded ce-ops#4 comment 2026-06-10.

## Detail (moved from index 2026-07-05)
- Related: [[headroom-eval-no-go]]
- converts fleet to credit-budget.
