---
name: ce-one-face-doctrine
description: "RATIFIED 20260708: ONE authority-holding operator-facing controller per human (the 'face'); every other surface is emission/proposal-only; face = POLICY singleton (IaC-redeployable), scoped per-human AND per-deployment."
metadata: 
  node_type: memory
  type: project
  originSessionId: 695aa14d-c79d-4e91-b1ae-53e0a0689b2d
---

**RATIFIED by Operator 2026-07-08** (Operator's hub-and-spoke insight + controller
refinements, all confirmed):

1. **One face, not one agent.** Each human has exactly ONE authority-holding,
   operator-facing controller. Behind the face, fleet fan-out is unbounded (seats,
   workers, daemons). Every other surface the human touches — webui, awaiting-operator
   inbox, mobile, support agent — is an emission or proposal-only view of the face's
   state, NEVER a second authority. Rationale: the awaiting-operator queue only works
   as THE inbox if there is exactly one; two probabilistic controllers holding divergent
   world-models of one project is the same failure as the UI becoming a second brain.

2. **Policy singleton, not process singleton.** The face must be killable and
   respawnable from IaC + forge SSOT ([[ce-controller-parity-iac-ssot-doctrine]],
   [[ce-singleton-plus-iac-redeploy-rule]], ce takeover per [[ce-471-program-ratified]]).
   One face is SAFE precisely because the face is replaceable while its state lives in
   the substrate. A non-redeployable face is the snowflake-controller SPOF.

3. **Scope: per human AND per deployment.** Team tier: each human has their own face;
   the deployment still has ONE gate. Conflicts between humans resolve at the
   gate/governance layer, not by negotiation between their controllers. A team must NOT
   share one face (recreates the attention bottleneck at team scale).

4. **Era-bound observation, permanent architecture.** "The human is the bottleneck even
   with one agent" is a current-era observation, not a law — the guided-journey UI
   ([[ce-guided-journey-ui-vision]]) exists to raise how much delegation one human can
   supervise. The one-face ARCHITECTURE is permanent; the bottleneck claim is revisable
   without touching the doctrine.

**How to apply:** design reviews of any new user-touching surface must classify it as
emission/proposal-only or reject it; multi-controller proposals for one human are
refused by default; CE's distributed patterns (multiple controllers) attach controllers
to ROLES/deployments, never a second face to the same human. Companion ratified same
day: [[ce-dual-format-emission-doctrine]] (the two-probabilistic-engines frame both
doctrines share). [[ce-dev2-orchestrator-role]]
