---
name: ce-validate-pr-brain-drift-false-red
description: ce validate-pr false-RED on stale instance-local .ce/state/brain/assertions.yaml that CI never hits
metadata: 
  node_type: memory
  type: reference
  originSessionId: 1b7bb9dc-d71c-4ac0-8dac-d3ed8c769a21
---

`ce validate-pr` can FAIL locally on `ce brain verify --drift` while CI is green, because `.ce/state/brain/assertions.yaml` is **instance-local, gitignored, rebuildable state** (`.ce/state/` = "never tracked"). CI runs `brain verify --drift --state-root .ce/state` in a FRESH checkout where that file is absent → passes. A PERSISTENT checkout (long-lived seat, or any contributor across sessions) accumulates a stale copy that diverges from the tracked canonical `.ce/brain/assertions.yaml` (e.g. after #686 XS/S/M/L rename updated canonical assertions) → false drift FAIL on a file OUTSIDE the PR's allowed paths.

**Fix (reconcile local state to canonical):** `git show origin/main:.ce/brain/assertions.yaml > .ce/state/brain/assertions.yaml` then re-run `ce validate-pr` → drift=0 → green. Do NOT commit the state file (gitignored).

**Gotcha:** hit dev-1 live 2026-07-01 on the contributing-guide PR — the seat correctly refused to push a non-green PR, but the RED was a local artifact, not a repo blocker. Diagnose before assuming a repo-wide breakage: check whether the failing gate touches tracked files or gitignored instance-local state. Product-gap ticket filed in ce-ops (validate-pr should mirror CI's fresh-checkout condition / provide a reconcile command). Will recur on any persistent checkout — including a new contributor's. [[ce-bake-gaps-into-ce-not-conventions]] [[ce-run-full-preflight-before-push]]

## Detail (moved from index 2026-07-05)
- reconcile from canonical, don't assume repo breakage.
- fails local drift gate but NOT CI (fresh checkout).
