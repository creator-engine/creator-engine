---
name: ce-dev2-dgx-py314-venv
description: "CE-DEV-2 DGX controller host — local py3.14/uv venv for running CE's validator suite, plus the aarch64 dev-wheelhouse gap"
metadata: 
  node_type: memory
  type: project
  originSessionId: f7be5efa-fbab-480f-9569-a78cd97fcc3d
---

The CE-DEV-2 controller host (DGX `spark-b824`, **aarch64**, Ubuntu 24.04) ships with only system **python3.12**, but CI pins **py3.14** and the wheelhouses are **cp314**. To run CE's validator suite locally, a standalone 3.14 venv was set up via **uv** (2026-06-19):

- `curl -LsSf https://astral.sh/uv/install.sh | sh` → `~/.local/bin/uv` (no system changes)
- `uv python install 3.14` → `uv venv ~/creator-engine/.venv --python 3.14`
- runtime deps OFFLINE: `uv pip install --python ~/creator-engine/.venv --no-index --find-links validators/wheelhouse -r validators/requirements.txt`
- test deps ONLINE from PyPI: `uv pip install --python ~/creator-engine/.venv --find-links validators/wheelhouse -r validators/requirements-dev.txt`
- run: `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=validators ~/creator-engine/.venv/bin/python -m pytest -p no:cacheprovider validators/tests/ -q -n auto --dist loadgroup`

**Why test deps come from PyPI (not offline):** `validators/wheelhouse` (runtime) is dual-arch (cp314 x86_64+aarch64), but `validators/wheelhouse-dev` (test deps: aiohttp, frozenlist, markupsafe, multidict, propcache, watchfiles, yarl) is **x86_64-only**, so a pure-offline suite install fails on aarch64. Fix tracked in **ce-ops#134** (vendor aarch64 cp314 dev wheels). See [[ce-derived-artifact-trust-path-fix]].

This venv **reproduces CI exactly** — it caught the v8 PR #271 packaging-contract wheel-drift (re-pinned `v3_cockpit.py` ships inside the app wheel → wheel must be rebuilt). **Verify green here before pushing.** The app wheel is `py3-none-any` (buildable on any python); only the *test run* needs 3.14.

## Detail (moved from index 2026-07-05)
- Related: [[ce-validator-editable-install]] [[ce-validator-suite-slow-not-hung]]
- verify green before push.
- 14 runs CE suite (reproduces CI).
