---
name: ce-nd-pickup-openbao-prereqs-done
description: "N-D pickup-token OpenBao prereqs EXECUTED 2026-07-05 — PAT in vault, orphan+periodic token at ~/.ce-keys/ce-pickup-token, policy sha ab476942…"
metadata: 
  node_type: memory
  type: project
  originSessionId: d9bfe94b-1dfa-43f4-960c-a14a67aa550b
---

All four N-D Operator prereqs executed 2026-07-05 by CE-DEV-2 (Operator authorized the controller
to run the ceremony; passphrase custody verified first). Full artifact record:
`.ce/state/research/ND_REVIEW_PICKUP_OPENBAO_WIRING_DESIGN_20260704.md` §✅ (mirrored to dev-1).

- PAT: `ce-kv/forge/ce-dev-2/gh-token` field `token`. Disk copy `~/.ce-keys/ce-dev-2.pat` stays
  until D1/D2 deployment verifies, then delete.
- Daemon token: ORPHAN+PERIODIC (720h), policy `ce-pickup-token-read`, least-priv proven
  (wall-path DENIED). Custody `~/.ce-keys/ce-pickup-token` (0600, DGX).
- POLICY_SHA=`ab4769424e205eb53ee31d61da0c386ae9a418682e9bc0a6636f82de708c8982`; canonical HCL =
  `.ce/state/research/ND_PICKUP_TOKEN_POLICY_20260705.hcl`. ALLOWED_REFS entry string staged in
  the design doc.
- Ceremony script pattern reusable: adapted [[ce-approval-wall-daemon-token-durable-recovery]]
  recipe; two-line stdin (passphrase, secret) via ssh; trap-reverted; CEREMONY_OK.

D1/D2 fully unblocked (D1 still serialized behind ce-ops#444 PR merge — v3_cli.py territory).

## Detail (moved from index 2026-07-05)
- D1/D2 unblocked.
- POLICY_SHA ab476942….
- ce-keys/ce-pickup-token.
