---
name: ce-orchestration-replaces-model-upgrade-pitch
description: "PITCH POINT + MOAT (Operator, 2026-06-23): CE reproduced/exceeded a FRONTIER-MODEL-UPGRADE-level throughput jump via orchestration alone (same model), proven by our own GitHub metrics. The field (Sakana Fugu et al.) is racing to do this; CE has demonstrated it."
metadata: 
  node_type: memory
  type: project
  originSessionId: a3bac9be-36f9-4b41-a61c-0f86c4d754cc
---

**The claim (Operator, 2026-06-23):** CE has reached, through *orchestration + deterministic-layer automation* (controller→worker fan-out, merge-queue offload, belt pickup, conflict-prevention dispatch), the development-throughput jump that was previously obtainable only from a **model upgrade** — and has done so on the SAME model tier (Opus 4.8 + Codex gpt-5.5), no upgrade. This is the three-layer thesis proven empirically and is a direct **moat** demonstration.

**The natural experiment — our own GitHub history (Operator-authoritative; weeks are SUNDAY-start):**
- **Week of 7 Jun 2026 — "Fable week":** Claude **Fable 5** released 9 Jun, **banned 12 Jun** (available <72h, for its high reasoning). **68 commits · 67,705 additions · 5,472 deletions.** An incredible jump — *solely* a model upgrade (Opus 4.8 → Fable 5).
- **Week of 14 Jun 2026:** **65 commits · 43,349 additions.** The drop (esp. additions) once Fable was gone *proves* the spike was the model, not anything else that changed.
- **Week of 21 Jun 2026 (current):** has **already surpassed the best (Fable) week in commits**, and is on track to surpass it in additions too — achieved by **orchestration, same model, no upgrade.**

**Why it's a moat / pitch headline:** right now the whole field is trying to extract more from the **non-model factors** — orchestration is the frontier (e.g. Sakana **Fugu**, https://github.com/SakanaAI/fugu — small learned orchestrator; see [[sakana-fugu-orchestration-research]]). CE has *already demonstrated*, on its own measured GitHub history, that the deterministic orchestration/governance layer can reproduce **and exceed** a frontier-model-upgrade-level jump. A vendor ships and controls that layer — it's durable and not hostage to one model's availability (Fable proved model access is fragile). Headline for [[ce-three-layer-pitch-thesis]] / [[ce-nvidia-v35-strategy]].

**Metric-source discipline:** cite **GitHub Insights** (contributor commits + Code frequency on the default branch), NOT a local `git log` on origin/main — main is squash-merged (under-counts commits) and additions are polluted by vendored/generated files. The 2x-this-week leverage argument is the prioritization case for building #163 (deterministic foreman fan-out) — orchestration leverage compounds ([[ce-codex-foreman-directive-durable]], [[ce-agent-paced-estimation]]).

## Detail (moved from index 2026-07-05)
- Related: [[sakana-fugu-orchestration-research]] [[ce-three-layer-pitch-thesis]]
- field racing this (Sakana Fugu).
- surpassed our Fable-upgrade peak.
