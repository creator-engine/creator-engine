---
name: ce-three-deputy-governance-model
description: "CE containment+governance reference architecture — three confused-deputy defenses: rent transport (cred-injection proxy), model authorization on Entra, build correctness spine (the moat)."
metadata: 
  node_type: memory
  type: project
  originSessionId: 2fe171be-e2b8-479e-b208-4b0153b128cf
---

The reference architecture for CE's contained-fleet governance (Operator+controller session 2026-06-24). Full doc: **ce-ops `designs/DESIGN_THREE_DEPUTY_GOVERNANCE_20260624.md`**.

A credential-injection proxy (onecli-style: inject the real token into the outbound request, strip it from the reply; agent never sees it) stops key exfiltration but creates a **confused-deputy / proxy-oracle** problem — a compromised agent drives the proxy as a remote tool. Defeat it at **three layers**:
1. **Transport deputy** (RENT — NemoClaw/onecli/OpenShell/MXC): the cred-injection egress proxy; ALSO the egress-confinement primitive (cred-injection + W6 egress = one layer). Evolves Model-B from commit-only → full mediated capability ([[ce-contained-controller-push-model]]). Unblocks [[ce-contained-seats-cannot-submit-reviews]] + dev-1 conversion.
2. **Authorization deputy** (MODEL on Microsoft Entra): PDP/PEP split; per-seat JIT *ephemeral* identity ([[ce-per-dev-identity-secret-storage]]); endpoint allowlist; L7 per-op policy; attribution; **CAE** mid-session revocation on risk → upgrades [[ce-autonomous-authority-doctrine]] from static to dynamic gating. Key invariant = **durable-decision-before-act** (= the #399 ledger-before-push fix = Entra's commit-to-2-datacenters-before-ack). One policy source (the `claims` artifacts) drives BOTH the in-box hook AND the proxy.
3. **Correctness deputy** (BUILD — CE's moat): the 4 authz tiers bound blast radius but NOT *intent* — a scoped/allowlisted/attributed seat can still APPROVE bad code (semantically-valid malicious act). Entra governs *access* and assumes the human's judgment is sound; agents void that, and correctness-verification has NO enterprise-IAM analog. So grader-on-work / quorum / refusal spine ([[ce-product-north-star]]) is the irreducible core. Approval-that-gates-merge = privileged op → JIT-elevated independent approver (quorum/human), never blindly proxied.

**Stack:** rent transport, model authorization on Entra, build correctness. Pitch line: *"Conditional Access + PIM for agent fleets, plus the correctness layer Entra was never built to have"* ([[ce-nvidia-v35-strategy]]).

## Detail (moved from index 2026-07-05)
- Related: [[ce-transport-deputy-tooling]]
- authz on Entra · BUILD correctness spine (the moat).
- (cred-injection proxy) · MODEL.
