---
name: ce-merge-mechanics-off-frontier-model
description: Merge/conveyor MECHANICS must never run on a frontier model (Opus); reserve Opus for genuine/security/architecture review + Operator interface. Routine review → cheap governed reviewer role. The cheap contained tender is blocked on the contained-controller egress chain; do NOT rebuild an ambient-cred shortcut.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 72817e73-31ba-4def-afac-1749f7c332b8
---

**Operator directive 2026-06-26 (sharp, right):** watching the controller hand-drive the merge conveyor (harvest→rebase→update-branch→enqueue→queue-watch) in Opus 4.8-high, the Operator asked "is this really a task for our most expensive tokens?" It is not. Chosen model = **B**.

**The split (apply every session):**
- **Mechanics** (harvest extract→rebase→full-suite-baseline→carrier→push→open-PR; enqueue; update-branch; queue-watch) → **NOT Opus.** Harvests → general-purpose workers with `model: sonnet`. Enqueue of APPROVED+green+CLEAN PRs → the deterministic `:30` cron `ce-conveyor-tend.sh` stranded-sweep (modelless). The expensive thing was Opus *reasoning over* mechanics, not the git commands — so the fix is determinism + cheap models, not a cheaper model on the same reasoning loop.
- **Routine review** → the cheap governed **`reviewer` role on `model: sonnet`** (returns a verdict; controller submits as ce-dev-2). Validated: a Sonnet reviewer did a thorough hash-chain/write-once review of #515. The CE governed agent types (`architect_research`/`implementer`/`reviewer`/`verification`) are available as Agent subagent_types — use them.
- **Opus reserved for:** genuine/security/architecture review (e.g. #514 cred-seam, #517 worker-run) + Operator interface. Not routine harvest reviews.

**Why it's not just "use Sonnet for the conveyor":** the mechanics should ultimately be **modelless** — a deterministic Integrator (#216) running INSIDE the contained controller with per-call injected creds. That's the end state that retires even the cheap-model spend.

**Hard "don't" (learned the hard way this session):** do NOT stand up a cheap conveyor-tender as a raw **tmux + host codex + ambient overwatch creds**. That VIOLATES mandatory containment ([[ce-mandatory-containment-decision]]/[[ce-whole-fleet-to-containment-ratified]]) and re-creates the exact ambient-credential authority-leak the contained-controller arc exists to close. The correct cheap tender is the CONTAINED Integrator — and it's **blocked on the contained-controller egress chain**: #514/#240 (fail-closed gh seam, MERGED) → #239 (OpenBao supplier that fills the seam) → #242 (contained self-push via injected cred). A contained seat is tokenless ([[ce-governed-seat-cannot-push]]/#228) so it literally can't push until that lands. Until then: mechanics on cron/sonnet, review-split as above, NO ambient-cred shortcuts. Related: [[ce-codex-controller-budget-offload]], [[ce-integrator-merge-mechanics-agent]], [[ce-model-effort-routing-policy]].
