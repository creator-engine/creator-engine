---
name: offer-recommendation-on-options
description: Operator rule — ALWAYS lead with my own recommended option + reasoning whenever presenting design forks/options/choices; never a neutral menu they pick cold
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 91752b76-678c-4425-a88a-f39af4c6764e
---

When presenting choices, design forks, or option menus to the Operator, **ALWAYS state my own recommended option and the reasoning explicitly, up front.** Never present a neutral/balanced menu and ask them to pick cold.

**Why:** the Operator is a product-decision-maker who acts on conclusions ([[user-ce-team-member]]); they want my synthesized judgment as a thought-partner, not a survey. Demonstrated 2026-06-05 — they repeatedly asked "what is your recommendation?" and intercepted option-modals to get my pick first, then issued the standing instruction "offer your recommendation every time from now on."

**How to apply:** lead with the recommendation + the why; then give the alternatives with tradeoffs; then ask to lock or push back. Prose-first (recommendation stated in text) works better for this than a cold `AskUserQuestion` modal. Related: [[report-context-each-turn]], [[agent-research-discipline]].
