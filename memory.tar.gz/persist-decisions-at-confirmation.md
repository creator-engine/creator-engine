---
name: persist-decisions-at-confirmation
description: "Operator feedback — persist EVERY confirmed decision AT confirmation-time (memory/artifact + strike-from-open-lists); a checkpoint RECONCILES open/parked-thread lists, never copy-forwards one as \"unchanged\""
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 080d99e1-0600-42db-a6f5-66f72e1682bd
---

**Failure that triggered this (2026-06-06):** the fork-vs-learn-on-acpx decision was Operator-confirmed in-session ("learn-not-fork") but was never persisted — it kept resurfacing as an "open/parked" thread after a `/clear` because (a) it lived ONLY as a list item in the resume's "parked threads" line, and (b) at checkpoint I copy-forwarded that list verbatim, even labeling it "(unchanged)", instead of reconciling it against the session's decisions. The marquee decisions (substrate/contract/tokenomics/hierarchy) survived because each got a dedicated memory + artifact AT decision-time; the sub-decision that only existed as a list item fell through. "Save state before /clear" got executed as "update the headline + next-action pointer," not "verify every open item against what got decided."

**Why:** the Operator acts on conclusions and treats "decision locked" as durable. An unpersisted decision = re-litigated work + lost trust + a stale corpus that mis-onboards other agents. Telling contrast: the gate-EXECUTION program does NOT have this failure mode because its prompts MANDATE re-grounding ("verify, don't trust") — which is precisely why the Controller caught the stale "no-schemas" claim in its own handoff. The design-DISCUSSION checkpoint had no equivalent reconciliation step.

**How to apply:**
1. **Persist at the moment of confirmation, not at checkpoint.** When the Operator says confirmed/locked/agreed/"that lands" on ANY decision (marquee OR sub-decision), immediately (a) write/update its durable record (a memory file and/or the design artifact) and (b) strike it from every open/parked/next list. Do NOT defer to a later batch "save state."
2. **A checkpoint is a reconciliation, not a copy-forward.** Before saving resume state, diff every open/parked-thread item against the decisions made that session. Never carry a list forward as "unchanged" without re-checking each item. Treat "save state" as a verification step with a checklist.
3. **Build the verification into the artifact** (mirror the gate program's re-grounding mandate) — the discipline that survives `/clear` is the one written into the process, not the one I have to remember.

Related: [[ce-acpx-fork-vs-learn-decided]] (the dropped decision), [[report-context-each-turn]], [[batch-strict-mode-gate-workflow]], [[user-ce-team-member]].

## Detail (moved from index 2026-07-05)
- checkpoints RECONCILE.
- decision at confirm-time + strike from open lists.
