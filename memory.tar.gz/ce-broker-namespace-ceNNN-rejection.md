---
name: ce-broker-namespace-cennn-rejection
description: "Egress broker rejects `ceNNN-` branches (403); broker-self-push seats need `ce-NNN-` naming until fixed"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 23673196-2290-4824-886a-497beda4df7e
---

The egress broker's namespace allowlist accepts `ce-`, `ce-ops-`, `feat/`, `fix/`, `chore/` — so a branch named `ce296-closebot-...` is **403'd** (no dash after `ce` → not `ce-`). The self-push fails **silently**: the contained seat commits, but the PR never appears → stranded work (hit on dev-3 ce-ops#296 2026-06-27; recovered via courier as PR #564).

**Why:** Only **dev-3** (broker self-push) is affected. dev-1 (direct push) and dev-4 (commit-only → courier) are not. dev-3's earlier successful pushes happened to use `ce-NNN-` (with dash).

**How to apply:** until the broker policy is fixed (ce-ops ticket filed — broaden allowlist to `ce[0-9]`/`ce*-` + surface the 403 non-silently), name **dev-3 dispatch branches `ce-NNN-...` (with the dash)**. And after any dev-3 self-push, VERIFY the PR actually landed before re-feeding (a silent broker 403 looks like "done"). Relates to [[ce-herdr-dispatch-landing-misread]] and the verify-PR-exists-before-refeed discipline.
