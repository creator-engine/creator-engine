---
name: ce-nightarc-20260701-batch-ratified-authority
description: Night-arc 20260701 standing authority — full batch ratification (G-N1..G-N7 + quorum/auto-gate decisions)
metadata: 
  node_type: memory
  type: project
  originSessionId: 1b7bb9dc-d71c-4ac0-8dac-d3ed8c769a21
---

🌙 **LIVE ARC = NIGHT-shift 2026-07-01.** Mandate: `.ce/state/research/NIGHTARC_MANDATE_CE_DEV2_20260701.md`. Thesis: **close the autonomy loop** — mechanize harvest→review→gate→re-dispatch into a self-driving governed conveyor; kill validator friction; harden infra for unattended running.

**Operator batch-ratified FULL (2026-07-01), so I drive to completion without per-item asks:**
- **G-N1** standing merge authority (approve as ce-dev-2 + merge ONLY after independent review + full CI green; envelope = docs + code ≤ work-class M).
- **G-N2** #351 live daemon DGX→VPS cutover · **G-N3** conveyor daemon arming · **G-N4** Surface-B strangeLoop as standing capability · **G-N5** autonomous saturation-dispatch (PROBE not-already-landed FIRST — the #347 miss) · **G-N6** triage-driven dispatch · **G-N7** #337 dev-3 self-push fix (live containment).
- **D-N1** code ≤ M needs **TWO** independent governed reviews (quorum, author≠approver); docs XS/S single-review.
- **D-N2** conveyor **full auto-gate** on independent-APPROVE + green within envelope.

**RESERVED (fresh nod required):** external release/publish, install.sh/signed artifacts, Arad/Nitzan comms, branch-protection/constitution, identity-registry reals, net-new scope. Auto-halt→Operator on any of these or a safety trip.

**Why:** Operator wants an ambitious self-driving night. **How to apply:** drive lanes N0-N5 across the 3 seats + conveyor; independent review before every gate; signing stays my non-delegable act; checkpoint+dual-write each block; NO seat idle. [[ce-dayshift-arc-autonomous-authority]] [[ce-autonomous-authority-doctrine]] [[ce-verify-not-already-landed-gotcha]]
