---
name: ce-controllers-proactive-pickup
description: "Dev controllers must self-pick work from the forge when idle (never idle-and-wait); controller stocks the queue, doesn't hand-feed one task per tick"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5183bef7-5a7b-413f-9619-d7da7f7c58c8
---

Operator directive 2026-06-21 (unhappy that dev controllers sat idle reporting status with abundant open forge tickets): **a CE dev controller (dev-1/2/3/4) must PROACTIVELY pick up work and drive it — never idle-and-wait for assignment.**

**Two-sided root cause:**
1. The seats' AGENTS.md foreman directive covered HOW to work (delegate to workers) but not WHAT to do when idle → they finished → reported "idle, awaiting assignment" → waited.
2. **I (controller) was hand-feeding one task per seat per tick** — which trains passivity. That violates [[ce-seats-foremen-self-managed-fanout]] ("don't single-task-assign; stock the queue; seats self-pick").

**Fix applied 2026-06-21:** appended a **"PROACTIVE WORK PICKUP"** section to each seat's `~/.codex/AGENTS.md` (dev-1/3/4) — survives compaction per [[ce-codex-foreman-directive-durable]]. On idle, the seat runs a self-pickup loop: scan forge → priority (own PRs needing action → reviews awaiting it as non-author → next unclaimed UNBLOCKED arc/brain ticket) → check 🔒 lock → claim 🔒 (gh CLI) → drive via workers → report → repeat. Guards: dependency order, author≠reviewer, never self-merge.

**My behavior shift:** controller = **queue-stocker + sequencer + merge-gate**, NOT task-router. Stock/order the ready queue; let seats self-pick. And I carry my OWN build lane (ce-dev-2 is a peer controller — [[ce-controller-spawns-many-workers]]), not just route.

**⚠️ The AGENTS.md directive is a PROBABILISTIC STOPGAP, not the solution (Operator 2026-06-21).** Putting "when idle, pick up next" *inside the agent* is the same class as the old Hermes-era "completion report → recommended-next-action" — it holds only while the agent obeys, and "works until it doesn't" (compaction/drift silently stops the loop). CE's founding thesis: **the loop-guarantee (complete → pick up next) MUST live in a DETERMINISTIC layer outside the agent** — the harness/supervisor or the CE/Forge layer — never the prompt. The deterministic home = the **#55 pickup belt** (timer-driven `ce pickup`, blocked on #182 feed + deploy); a harness-layer completion-trigger is the alternative. The agent does the WORK (probabilistic, fine); the deterministic layer owns the SCHEDULING. Treat the AGENTS.md directive as a thin labeled bridge until the belt deploys — do NOT mistake it for the fix. Recorded on #55.

**⚠️ Operator correction 2026-06-25 — NO seat held in reserve.** I said "hold dev-3 until the review PRs need rework" — exactly the attitude to root out. Reserving a born-foreman controller against hypothetical future work is waste; an idle seat is an **immediate dispatch obligation**. Never gate a seat's next lane on another seat's PR landing, on a future rework that may not materialize, or on "quota maybe." Stock a real backlog lane now (seat self-picks if truly out of obvious work). Controller = queue-stocker, never capacity-rationer.