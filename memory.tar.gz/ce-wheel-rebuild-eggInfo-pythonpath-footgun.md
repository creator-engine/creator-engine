---
name: ce-wheel-rebuild-egginfo-pythonpath-footgun
description: Source-changing CE PRs must rebuild validators/wheelhouse wheel + re-pin SHA256SUMS; the local pip-wheel build leaves a gitignored egg-info that breaks test_install_bootstrap via PYTHONPATH=validators — rm it before the suite.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d14ea5b1-747b-4b05-89fa-fa01ddf62e3f
---

Any PR that edits `validators/creator_engine_validator/*.py` MUST rebuild the
committed app wheel `validators/wheelhouse/creator_engine_validator-<ver>-py3-none-any.whl`
and re-pin the app-wheel line in `validators/wheelhouse/SHA256SUMS`, else
`test_packaging_contract.py` (`verify_wheel_matches_source` compares wheel `.py`
bytes to source; `verify_packaging_contract` checks SHA256SUMS) fails. List BOTH
in the per-PR carrier. `_version.py` does NOT need re-baking — `verify_generated_version`
only requires `BUILD_GIT_SHA` to be an ANCESTOR of HEAD, which the base's baked sha
already is. (See [[ce-batch-pr-merge-tax]].)

Build offline: `cd validators && python -m pip wheel . --no-deps --no-build-isolation -w /tmp/out`
(no `build` module in the venv), copy into wheelhouse, recompute sha256 → SHA256SUMS line.

**Why / footgun:** `pip wheel .` leaves a gitignored `validators/creator_engine_validator.egg-info/`
(version metadata) in the worktree. The sanctioned test invocation runs with
`PYTHONPATH=validators`, which the `test_install_bootstrap.py` install.sh subprocess
inherits (it runs `cwd=repo_root`). That egg-info makes the inner `pip install
creator-engine-validator==<ver>` think it's ALREADY installed → it skips creating the
`cev3` console script in the fresh venv → install.sh fails `entrypoint_missing: cev3
absent`. Deterministic, source-independent, does NOT happen in CI (fresh checkout).

**How to apply:** after `pip wheel`, `rm -rf validators/creator_engine_validator.egg-info
validators/build` before running the suite. Symptom is a *different* unrelated
integration test failing only under the parallel `-n auto` full run. Also note the
OOM/fleet-cap launch test (`test_launch_runtime_resource_bound`) is flaky under
`-n auto` but green in isolation — verify suspected regressions in isolation first.
The seat rebuilds the in-repo wheelhouse wheel; `docs/downloads/**` + `docs/llms-install.md`
re-sign is a SEPARATE Controller-side release act (seat can't sign). [[ce-release-spec-signing-procedure]]
