---
name: ce-singleton-plus-iac-redeploy-rule
description: "RATIFIED GENERAL RULE 2026-07-08: prefer efficient SINGLETON designs over multi-instance/HA — PROVIDED a one-click IaC redeploy path exists (e.g. from the VPS, redeploy a dead DGX daemon); IaC redeploy = precondition for arming new singleton authority"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 46fbbf10-9bed-41a5-a4fd-040713bc0bcb
---

Operator ruling 2026-07-08 (answering the Option A materializer topology question,
generalized on the spot): "we can go with the more efficient singleton design,
provided we have an IaC mechanism to one-click deploy said singleton. i.e. if one
goes down on the dgx, it's possible to run a script from the vps and for example
terraform deploy another one."

**Why:** availability is bought with REDEPLOYABILITY, not with concurrent instances —
multi-instance-under-external-lock multiplies holders of sensitive authority and adds
distributed-lock infrastructure for a failure mode (bounded downtime) that CE's
fail-closed designs already make benign. This composes with
[[ce-controller-parity-iac-ssot-doctrine]] (everything IaC-deployable, SSOT-fed) and
the merge-gate/A2-SEQ singleton doctrine.

**How to apply:** (1) when a design asks singleton-vs-HA, answer singleton + name the
redeploy path; (2) treat the IaC redeploy script/terraform as a PRECONDITION for
arming any new singleton authority (Option A materializer explicitly); (3) redeploy
must be runnable from a DIFFERENT host than the one that died (VPS↔DGX cross-cover).
Recorded: DECISIONS_20260708.md items 1-2. First applications: Option A materializer
(Q4=singleton), ce-queue-daemon (promoted C5, needs the same redeploy unit).
