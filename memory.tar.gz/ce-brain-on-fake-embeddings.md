---
name: ce-brain-on-fake-embeddings
description: "Company-brain recall.sqlite is built with the DETERMINISTIC FAKE embedder (dim 32), not the real Qwen3-8B — never re-ingested through the GPU embedder"
metadata: 
  node_type: memory
  type: project
  originSessionId: dd146cd2-c96c-49bc-a20b-797098491dc6
---

As of 2026-06-30, the company-brain recall DB at `creator-engine/.ce/state/brain/recall.sqlite` (1556 entries) was vectorized with the **deterministic CI placeholder embedder**, NOT the real embedding model:
- `recall_metadata`: `vector_model_id = ce-deterministic-fake-embedding-v1`, `vector_dim = 32`, `vector_backend = python-cosine-json`, `sqlite_vec_available = false`.
- The real embedder is `Qwen/Qwen3-Embedding-8B` (dim **4096**) served on :8989 by the `vllm-qwen3-embed` systemd-user unit ([[ce-dgx-brain-vllm-serving]]).

So semantic recall is currently FTS keyword + fake 32-dim vectors — not real embeddings. To get real semantic recall, re-ingest the corpus through the Qwen3-8B embedder (`ce brain ingest --embedder <real>`), which **requires the GB10 GPU**.

The GB10 is held by a self-hosted **Qwen3-Coder** vLLM server (`/models/coder`, :8000, served-name `coder`, gpu-util 0.85, launched by the Operator 2026-06-29 20:39Z). **DECIDED 2026-06-30:** the coder belongs to ANOTHER (non-CE) project — Operator will verify ~2026-06-30 ~10:00Z (in office). **Interim policy: keep the coder; CE runs on the DETERMINISTIC company-brain layer** (no real-embedding ingest until the GPU is freed). The embedder (:8989) and coder can't coexist on one GB10. So the deterministic dim-32 recall is a deliberate interim, not a bug to fix now. [[ce-dgx-brain-vllm-serving]]

## Detail (moved from index 2026-07-05)
- re-ingest needs GPU (held by coder=other project, DECIDED keep+deterministic interim).
- deterministic dim-32 placeholder, NOT real Qwen3-8B.
