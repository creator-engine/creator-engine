---
name: ce-multi-controller-operator-pattern
description: "RATIFIED 2026-07-10 — an Operator may run several controllers at once; exactly ONE holds write/main authority (one-face), others are read-only supervision/diagnosis/design interfacing via durable artifacts"
metadata: 
  node_type: memory
  type: project
  originSessionId: c2ab6f1e-56de-4553-a526-de2839a2a739
---

**Ratified by the Operator 2026-07-10** during the post-migration supervision session (DGX
session read-only, VPS ce-dev-2 controller = the one main write-authorized face).

The pattern: a dev/devops-qualified Operator with capacity to interface multiple controllers
may do so, provided exactly ONE controller is the main write-authorized (operator-facing,
arc-driving) controller per [[ce-one-face-doctrine]]. All others operate read-only:
supervision, deep diagnosis, fix DESIGN — and hand work to the main face through durable
artifacts (design docs, ratified supplements in `.ce/state/research/`), never through shared
authority or direct mutation of the machinery the face drives.

Live proof (2026-07-10): supervising session diagnosed the VPS disk-100%/gate-outage incident,
authored `VPS_STORAGE_GATE_INCIDENT_DESIGN_20260710.md` + the Operator-ratified
`ARC_STRANGELOOP2_SUPPLEMENT_RATIFIED_20260710.md` (N-11..N-13, R-1/R-2, S-1, P-1); the main
face executed. Two interference rules learned: (1) check the face's tmux composer is empty
before send-keys (grayed text = Claude autosuggestion, safe); (2) config read at spawn-time
(agent role files) is safe to install mid-run; live state is not.

**Why:** preview of the team-mode product — multiple humans/controllers collaborating across
a trust boundary with a single binding authority. **How to apply:** when supervising, do
diagnosis/design freely, deliver via files + one pointer message to the face; never approve,
merge, dispatch seats, or touch the face's in-flight state. [[ce-dev2-vps-migration-bundle]]
