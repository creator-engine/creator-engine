---
name: ce-speckit-sync-plan
description: "Governed plan to sync CE's vendored spec-kit 0.8.7→0.12.0 preserving CE's 3 forks; 6-PR breakdown; full report in agent a00a8272"
metadata: 
  node_type: memory
  type: project
  originSessionId: dd146cd2-c96c-49bc-a20b-797098491dc6
---

spec-kit upstream = **0.12.0**; CE pinned **0.8.7** (`.specify/init-options.json`). Operator wants sync ASAP (2026-06-30). Governed rented-surface update — preserve forks, no naive clobber. Full research: agent output a00a8272b440335aa.

## ⚖️ RESEARCH OUTCOME — "speckit under the hood?" — ✅ 4 DECISIONS LOCKED (Operator, 2026-06-30). Report: `.ce/briefs/speckit-under-the-hood-REPORT-20260630.md`
1. **DON'T-ADOPT the speckit RUNTIME pipeline** (specify→clarify→plan→tasks→implement→analyze) under the hood. CE's `cev3` outer-loop (Scope: Goal/Done-when/Budget/ratify) + orchestration inner-loop (dispatch→implementer-worktree→harvest→independent-review→merge-gate) already subsumes SDD and is STRONGER (isolation, author≠approver, grader-OUTSIDE-the-agent = the moat). speckit analyze/clarify are in-agent self-checks → would DILUTE the moat. Sync burden severe (25 releases/7wk, ≥4 breaking) + upstream growing its OWN orchestration → drifting toward competing w/ CE.
2. **#114 = TEMPLATE-LAYER sync ONLY** (not runtime). Re-base forked spec/plan/tasks templates onto 0.12.0, PRESERVE governance forks, **STRIP the MVP-first framing** (spec-template.md:16 "viable MVP", tasks-template.md:218 "MVP First") — contradicts [[ce-no-mvp-quality-from-day-1]]. Add the MVP-strip to the C/D/E template-refresh PRs.
3. **Build a CE-NATIVE test-coupling gate** in `validate-pr` (the ONE real gap; speckit leaves tests OPTIONAL so wouldn't close it) — code-class diff w/ zero test delta → gate finding, tunable by mutation_class. Ticket filed via ops_triage.
4. **Reword mode-axes canon:** "agent invokes the speckit pipeline under the hood" → "invokes CE's cev3 SDD loop + governed orchestration." (Pending edit to [[ce-mode-axes-canon]].)
Pilot SKIPPED (Operator). **✅ DECIDED 2026-06-30: PLAN FULL RETIREMENT of spec-kit (Operator).** Not deprecate-in-place — full retire. Consequences: (a) **#114 → RETIRE, not sync** (dev-3 PR-A sync work ABANDONED, do NOT harvest/gate it); (b) **#367 scaffold gap → CLOSE as superseded** (not building `ce speckit init`); (c) **#674** CEO guide=keeper but Solo+Dev banners point at speckit → HOLD, fold into retirement docs rewrite; (d) Solo+Dev persona (Nitzan) needs a NEW **cev3 hands-on** onboarding path (replaces the speckit pipeline) — URGENT for today's pilot; (e) constitution **Principle X (Spec Kit Compatibility)** → update/remove (governance act = ratification); (f) strip ~10 speckit public docs + `.specify/` + `.claude/skills/speckit-*` + validate.yml speckit wiring; KEEP `specs/00X-*` historical bootstrapped artifacts. **Pilot-safety (R/mandate): retirement must be SEQUENCED so it does NOT break the live install/docs/demo before the 01-Jul NVIDIA pitch (#74).** Retirement-plan architect dispatched. Test-coupling-gate native ticket = ce-ops#368. [[ce-mode-axes-canon]] reword: NO "Solo+Dev types speckit" cell → Solo+Dev = hands-on cev3.

**CE's forks (the ONLY files with CE content — re-apply these on the 0.12.0 base):**
1. `.specify/memory/constitution.md` — ENTIRE ratified CE doc (12 principles, v1.1.0). ⚠️ HIGHEST RISK: `specify init --force` overwrites it → governance hole. Guard it.
2. `.specify/templates/plan-template.md` — the 12-gate Constitution Check section (Forks I–XII); rest tracks upstream.
3. `.specify/templates/tasks-template.md` — 2 CE sentences (the `tasks.creator-engine.yml` sidecar note + the attestation-task note).
Plus KEEP-AS-IS: `.specify/extensions.yml` (CE hook chain), `git-config.yml`, `.registry`, `integration.json`, the 3 `*.manifest.json` (regen SHAs after skill/template updates).

**FR-009 — ✅ RATIFIED 2026-06-30: add the MECHANICAL guard (= a new Fork 4).** Add an envelope-binding preamble to `speckit-implement/SKILL.md` that hard-halts a human-typed call outside a governed envelope (prevent-by-design > trust-the-agent). Today it's PROCEDURAL — lives in `docs/architecture/agentic-sdlc-operating-model.md §d.5` + `agent-interaction-model.md §g`, NOT the skill file; skills otherwise update wholesale.
⚠️ **Operator correction (2026-06-30): DE-HERMES the framing.** "Must run inside a *Hermes* envelope" is a remnant from when Hermes was THE controller; **CE is agent-agnostic now.** The guard + all FR-009 wording must say generic **"governed envelope"**, not "Hermes envelope." Sub-task: audit/scrub residual "Hermes envelope" framing in the operating-model + agent-interaction docs while landing Fork 4. (Note `.hermes/` kernel-state namespace is separate and stays.)

**Upstream delta 0.8.7→0.12.0:** new `/speckit.converge` command (v0.11.2, append-only); extensions schema gained list+`priority` (backward-compat, CE already list-form); git extension became opt-in (CE already has it); CLI flags `--ai/--ai-skills` removed; `branch_numbering`→`feature_numbering` deprecation (CE uses branch_numbering — may warn).

**6-PR breakdown (bounded work-units):** A=fork-overrides doc + version pin 0.12.0 + constitution guardrail (tiny, do FIRST, de-risks everything). B=new converge skill (.claude+.agents, tiny additive). C=18 core skill files refresh + manifest regen (story; reviewer confirms no CE content). D=scripts+git-ext refresh (story). E=templates refresh w/ CE re-apply (HIGH risk — re-apply forks 2+3). F=governed repeatable sync-mechanism playbook (tiny). A+B startable now/parallel; C→D→E sequential (share manifests); F parallel.

Recommend making this a REPEATABLE governed mechanism (PR F), not one-time. [[ce-govern-rented-surface-updates]] [[ce-rent-or-fork-before-reinvent]]
