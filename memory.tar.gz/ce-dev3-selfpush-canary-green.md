---
name: ce-dev3-selfpush-canary-green
description: dev-3 contained self-push spine GREEN 2026-07-02 — broker-socket push proven end-to-end; canary procedure + broker gotchas; unblocks dev-1 containment
metadata: 
  node_type: memory
  type: project
  originSessionId: cae4382b-381a-490e-962a-afb1d5769495
---

2026-07-02: dev-3's contained self-push spine passed its green canary end-to-end (recorded ce-ops#408 — the dev-1 migration ticket; NOTE ce-ops#378 = work-management SSOT, NOT FleetIaC — old #377/#378 mapping in MEMORY header is stale): `tools/egress-broker/ce_self_push_canary.py --branch <ce-branch> --repo . --seat dev-3` from inside ce-vps-codex → broker socket `/run/ce-egress/dev-3.sock` (env `CE_EGRESS_BROKER_SOCKET`) → push applied + PR auto-opened by the seat's GitHub App identity (`app/ce-forge-dev-3`).

**Why:** last precondition for migrating dev-1 to containment (whole-fleet→containment M2); Operator directed the canary + migration 2026-07-02.

**RE-PROVEN 2026-07-08 on the rebuilt x86_64 image** (PR #903, closed unmerged per hygiene). Working controller-driven recipe when a seat fumbles the push: (1) verify branch+commit visible in HOST repo (`/home/ce-dev-3/creator-engine`); (2) write carrier `.ce/pr-manifests/<branch-slug>.md` with a `- **Declared work class:**` line into the HOST working tree via ssh+sudo tee; (3) `ssh dev1 'sudo docker exec ce-vps-codex python3 /workspace/creator-engine/tools/egress-broker/ce_self_push_canary.py --branch <br> --repo /var/tmp/<wt> --seat dev-3'`; (4) hygiene: close PR `--delete-branch`, remove worktree+local branch in-container, rm carrier. GOTCHAS 20260708: live policy `/etc/ce-egress/broker-dev3.json` has `require_signed_commits=false` (gate-beta) so unsigned passes TODAY, but the rebuilt image lost `~/.ssh`+`~/.gitconfig` (seat can't sign — restore before tightening policy; in followups ledger); per-seat daemon units are `ce-egress-broker-dev3.service`/`ce-egress-self-review-dev3.service` — the unsuffixed `ce-egress-broker.service` shows inactive and is a red herring; a seat-side raw `git push` failing "could not read Username" is the DESIGNED refusal, not broken credentials.

**How to apply:**
- Contained seats must NOT `git push` — remote is credential-less https by design; broker-socket is the only push path.
- Broker gates: author allow-list, `ce-` branch namespace, rate cap, and a GOVERNANCE CARRIER — it fail-closes without `.ce/pr-manifests/<slug>.md` carrying a declared work class.
- GOTCHA: the broker reads the carrier from the HOST repo working tree (`/home/ce-dev-3/creator-engine/.ce/pr-manifests/`), not from the branch — the file must exist there (bind-mounted /workspace in the container).
- Canary hygiene: empty commit + carrier, close PR unmerged with --delete-branch, rm artifact copies + worktree + local branch in the seat.
[[ce-dev3-relaunched-selfpush-live]] [[ce-contained-seats-have-git-egress]] [[ce-whole-fleet-to-containment-ratified]]

## Detail (moved from index 2026-07-05)
- broker needs carrier IN HOST WORKING TREE; seats never git-push directly; unblocks dev-1 containment.
- 26-07-02 (ce_self_push_canary.py → broker socket → PR by app/ce-forge-dev-3).
