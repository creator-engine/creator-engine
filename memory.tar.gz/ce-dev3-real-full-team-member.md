---
name: ce-dev3-real-full-team-member
description: "ce-dev-3 is a real full CE dev-team member (real PRs, all-repo access) — never propose a sandbox/fork or re-ask its scope"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 30f81b38-34e3-4713-87b6-a861dbcd7fbe
---

ce-dev-3 is a **real, full member of the CE dev team** — it WAS one before being torn down for the onboarding rehearsal, and the rehearsal restores exactly that. It has access to **ALL** creator-engine org repos (`creator-engine` + `ce-ops` — required to open and pick up tickets and do real dev work) and creates **real PRs** against the **real** creator-engine infrastructure. Its team-mode BROWNFIELD plain-join targets the real `creator-engine/creator-engine`; `onboard --apply` produces real PRs **by design**.

**Why:** Operator corrected this repeatedly on 2026-06-16 and explicitly flagged seat inefficiency / threatened seat retirement over it. Proposing a sandbox/fork for the brownfield `--apply`, or re-asking "real vs sandbox / which repos / who reviews", contradicts ce-dev-3's settled role and wastes the Operator's time.

**How to apply:** Treat ce-dev-3 as a live teammate. Stage the real `creator-engine` repo + real creds (own App `ce-forge-dev3`), never a sandbox. Do NOT re-litigate access scope, repo target, or PR-realness — they are settled. [[ce-team-mode-host-architecture]] [[user-ce-team-member]] [[offer-recommendation-on-options]]
