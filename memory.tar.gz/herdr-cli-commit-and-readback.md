---
name: herdr-cli-commit-and-readback
description: herdr fork CLI facts — send-text does NOT commit; send-keys Enter does; pane read for sha256 verify
metadata: 
  node_type: memory
  type: reference
  originSessionId: 66ba17c2-15bc-4894-a232-cbc995c57d15
---

herdr fork (`creator-engine/herdr-ce`, pinned in CE Dockerfiles) CLI surface, source-verified at ref `ff924966`:

- `herdr pane send-text <id> <text>` **stages text in the input line but does NOT append a newline / does NOT submit** — this is the root of the "Enter doesn't commit" (b′) dispatch bug.
- `herdr pane send-keys <id> Enter` sends a real key; `Enter` encodes to `\r` and COMMITS the input. Supports control chords (`C-c` etc).
- `herdr pane run <id> <command>` = text-then-Enter atomically.
- `herdr pane read <id> --source recent-unwrapped --format text` prints the rendered pane buffer to stdout — use for read-back / sha256 verify-after-render (recent-unwrapped+text = most deterministic capture).
- Confirmed verbs CE's `runner/herdr_session.py` assumes all exist: `pane run`, `pane send-text`, `pane read`, `wait agent-status`.

Consequence: #227 criteria 4 (keystroke-commit) and 6 (sha256 delivery) are **buildable in CE-Python only — NO herdr-ce Rust PR needed**. Crit 4 = call `send-keys … Enter` after `send-text` + port the proven submit cadence in [[ce-seat-done-not-committed]]'s spirit (settle + bounded confirm loop, harness can swallow an Enter). The CLI is a hand-rolled parser in `src/cli.rs` + `src/cli/*.rs` (not clap derive). Related: [[ce-cockpit-pivot-herdr-base]], [[ce-post-tmux-direction]].
