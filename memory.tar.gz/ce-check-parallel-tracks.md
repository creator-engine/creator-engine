---
name: ce-check-parallel-tracks
description: "Operator co-drives seats directly — before driving a governed PR, check for parallel/duplicate tracks to avoid wasted work"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 0dd6e0d5-5231-47c3-ba50-45bcdf86f9d1
---

**Trigger (2026-06-08):** I drove a full governed site-update build via seat %609 → PR #175, but the Operator had **in parallel** built + merged the *identical* design as **#174** on a different branch. #175 was redundant (wasted %609 effort; surfaced only as a merge-conflict after #174 landed). The Operator flagged "too many mistakes this session."

**Why:** the Operator frequently **co-drives tmux seats directly** (typing into %609/%431/etc.) at the same time as delegating to the orchestrator — so two tracks can build the same artifact concurrently. I treated my orchestrated track as the only one.

**How to apply:**
- Before launching a governed build (esp. site/`docs/index.html`, or anything the Operator might be doing themselves): run `gh pr list` + check for open branches/PRs touching the same files; if found, reconcile rather than build a parallel track.
- When `origin/main` **drifts unexpectedly** mid-flow, immediately check `git log` for what merged — it may be the Operator's parallel track, not just a carrier-collision rebase.
- When the Operator is clearly hands-on in a seat for a task, confirm who owns the execution before spinning up a duplicate. One track per artifact.
- Relates to the multi-actor coordination seen all session (Operator queuing instructions in seats); pairs with [[ce-site-v5-followup-tidy]].
