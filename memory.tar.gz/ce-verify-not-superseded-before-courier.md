---
name: ce-verify-not-superseded-before-courier
description: "Before couriering a parked/stale seat branch, verify the work hasn't already merged via another path"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5bc52056-d810-41c3-bacc-32bca88f5d2d
---

Before pushing + opening a PR for a **parked or stale seat branch** (work the controller is couriering because the seat couldn't self-push), FIRST verify the work hasn't already landed on `main` via another path. Diff the branch's key artifacts against **current** `origin/main`: target file paths present? ADR numbers already taken? `git diff --stat origin/main <branch>` dominated by deletions (= branch is behind, would regress)?

**Why:** 2026-06-22 I couriered 5 branches parked ~2 days (egress #324, cockpit #325, webui #328, website #326, mint-broker #330). ALL were superseded — the egress impl (`tools/egress-broker/`), mint-broker (`tools/mint-broker/` via #300), webui `ADR-0008`, and the website "FULL AUTOMATION" hero had already merged via other paths; cockpit was 33.7k-deletions stale. The courier created duplicate PRs + ADR-number collisions (branches claimed ADR-0007/0008 already on main) and burned cycles to reconcile + close.

**How to apply:** a parked branch ≠ unmerged work. Staleness compounds: the older the parked branch, the more likely its content shipped elsewhere. Cheap pre-courier check (ls-tree the target paths on `origin/main`, scan ADR numbers, diff-stat for net deletions) before push. Also: assign ADR numbers from current `main`'s max, not the number that was free when the branch was cut. Related: [[ce-base-only-refresh-microauth]] (drift handling), [[ce-delegate-merge-conflict-triage]].
