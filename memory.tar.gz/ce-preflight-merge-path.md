---
name: ce-preflight-merge-path
description: "CE-DEV-2 review recommendation (2026-06-11, Operator-endorsed) — pre-flight the WHOLE merge path before dispatching a reviewer venue; the PR"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2bae9844-7348-4cd1-9a89-54226b622914
---

**From the CE-DEV-2 controller's review of the PR #200 lane (persisted on Operator instruction,
2026-06-11):** the CODEOWNERS blocker was knowable BEFORE the reviewer venue ran — instead a
completed hook-validated review hit an unsatisfiable gate and cost an Operator round-trip.

**Why:** a venue review is expensive (seat + tokens + wall-clock) and approval-consuming steps
are wasted if a later gate can't be satisfied by the planned identity.

**How to apply — before dispatching ANY reviewer venue (or other approval-consuming step),
pre-flight branch protection end-to-end against the PLANNED reviewer identity:**
`gh api repos/<o>/<r>/branches/main/protection` + read `.github/CODEOWNERS`, and check:
required approving count · `require_code_owner_reviews` (is the planned identity a CODE OWNER,
not just write-collaborator?) · `require_last_push_approval` (vs who last pushed) ·
`dismiss_stale_reviews` (vs any planned rebase — see the shared-carrier serialization in
[[ce-batch-pr-merge-tax]]) · up-to-date requirement (vs other in-flight PRs touching the same
files). Only then compose the envelope/venue. Family: "look before executing", with
[[ce-method-memories-host-portability]] + [[ce-controller-steers-seats-execute]].
