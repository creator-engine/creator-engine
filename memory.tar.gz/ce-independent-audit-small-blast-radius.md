---
name: ce-independent-audit-small-blast-radius
description: "Operator design principles (2026-06-11): independent audit layers have intrinsic merit (CE's spine ≠ substitute for forge-side attribution); minimize shared credential surfaces (failures come unforeseen) — drove per-dev-GitHub-App team-mode lean"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2457e0af-87f4-4a24-9180-884b72b2db0d
---

Operator, 2026-06-11 (raised over the shared GitHub App during the strict E.4 re-run):

1. **Independent audit layers have intrinsic merit.** "CE's spine attributes internally" is never a reason to forgo forge-side (GitHub) attribution — two ledgers with different owners/failure modes = grader-outside applied to CE itself. Don't design as if our ledger suffices.
2. **Minimize shared credential surfaces.** A team sharing one App concentrates exactly the risk you can't enumerate: "things go wrong in ways we haven't foreseen." Prefer structural smallness (per-actor credentials, per-dev revocation) over predictive confidence.

3. **(Refined 2026-06-12)** Forge-side isn't replaceable by the spine — **but CE designs, sets up, deploys, and interfaces with it.** Independence of the auditor ≠ hands-off its lifecycle: CE owns provisioning/operating the forge-side machinery (CI gates, branch protection, Apps, cloud triage/CI-CD agents — the "Overcut layer" of [[ce-three-layer-pitch-thesis]]) as a product surface, exactly as #33 does for infrastructure. The independence property lives in WHERE it runs and WHO can mutate it, not in CE pretending it isn't there. Solo-devs won't configure branch protection/CI gates themselves — CE doing it FOR them is part of one-stop-shop.

**Why:** both are standing lenses for ANY identity/credential/audit design call, not just the App question.
**How to apply:** when a design centralizes credentials or treats CE-internal evidence as the sole audit source, flag it against these principles proactively ([[audit-findings-against-operator-directives]]). Concrete instance: team-mode lean = per-dev `own` GitHub Apps default, `shared` = solo/onboarding door (ce-ops#6, C-cluster decides mechanics). [[ce-v35c-strangeloop-coordination-design]]
