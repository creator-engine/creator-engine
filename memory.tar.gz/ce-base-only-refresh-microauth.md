---
name: ce-base-only-refresh-microauth
description: "Standing Operator micro-authorization — on benign main-drift (base SHA only), rebase+re-pin+proceed WITHOUT a fresh per-refresh ratification; any content change still needs full ratification"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 521e4ee7-d627-4b71-8e76-25cbd2e3b51e
---

**Operator grant (2026-06-08, relayed by orchestrator):** I hold a STANDING base-only-refresh micro-authorization for the governed site/PR flow.

**When it applies (ALL must hold):** a ratified change is blocked only because `origin/main` advanced (main drift), AND the baseline being replaced (e.g. live `docs/index.html`) is unchanged, AND every content artifact pin is unchanged, AND the ratified path-set (manifest `AUTHORIZED_PATHS_COUNT` + `AUTHORIZED_PATHS_SHA256`) is unchanged.

**What I may do without a fresh ratification:** rebase the branch onto the new `origin/main`, re-pin the base SHA (the manifest's documented `base:` line + the prompt's base preconditions/`verify-path-manifest --base`), re-run the gates (must stay green), and proceed to push/PR.

**What still requires FULL ratification:** ANY content change — docs/index.html bytes, a path-set change, a new/edited artifact, scope expansion. Never fold content into a "base-only" refresh.

**Why:** main drifted ~4× during the site work; each benign drift forced a re-ratify round-trip that changed only the base SHA (the path-set hash is base-independent). This removes that friction while keeping full rigor on every content change.

**How to apply:** on drift, first prove the four conditions above hold (diff the pins). If yes → rebase, re-pin base, gates-green, proceed; tell the Operator it was a base-only refresh. If ANY content differs → halt and seek full ratification. Pairs with [[batch-strict-mode-gate-workflow]] and the website flow in [[ce-website-versioning-policy]].
