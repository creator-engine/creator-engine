---
name: ce-memory-migrated-to-vps
description: 2026-06-11 the entire auto-memory + Documents CE corpus + resume states were MIGRATED to CE-DEV-1 (team-mode); laptop copy = secondary pending Operator cutover
metadata: 
  node_type: memory
  type: project
  originSessionId: fc4bf9c0-20a8-413b-881d-753baa0dc700
---

**Track-2 team-mode milestone (2026-06-11):** the entire local memory was migrated to
CE-DEV-1 — the VPS is becoming the CE dev execution host (Operator day-outline item A).

- Auto-memory (79 files incl. MEMORY.md) → `ce-dev-1:~/.claude/projects/-home-ce-creator-engine/memory/`
  with `vps-host-context.md` as the READ-FIRST marker: it carries the **laptop→VPS PATH MAP**,
  the deliberately-ABSENT list (keys, reviewer token, workflow-push scope), and the root rule.
- `~/Documents` CE reference corpus (55 items incl. pitch-evidence pack, v7 site deliverables,
  `AgentSmithPillsCalm.png`, seat transcripts) → `ce-dev-1:~/Documents/`.
- Resume states → `ce-dev-1:~/creator-engine/.ce/state/research/` — **the `.ce/state` root, NOT
  `.hermes`** (Operator-audited 2026-06-11: `.hermes` is superseded v1/controller-instance
  naming; it was removed from the VPS checkout; laptop v1 canonical keeps its frozen `.hermes`
  per [[ce-hermes-vs-ce-state-roots]]). `sync-ops.sh` is now host-portable across this split.
- `ce-ops` CLONED on the VPS at `~/projects/ce-ops` (gh = chmod735, repo scope, verified access).

**The laptop copy remains live-secondary** — dual-write until the Operator confirms cutover;
after any significant laptop-side memory write, re-sync (one rsync line; see session
3d6c61d0). Keys did NOT move: ce-root-v1 + ce-forge-app PEM stay on the laptop
([[ce-github-app-created]] if written, else ce-ops#9).

**Why:** how to apply — when resuming on the VPS, memory + corpus are local; when resuming
on the laptop, check whether VPS-side sessions wrote memories that need syncing BACK.
