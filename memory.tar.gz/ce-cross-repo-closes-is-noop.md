---
name: ce-cross-repo-closes-is-noop
description: "GitHub \"Closes\" keyword does NOT auto-close issues across repos; ce-ops needs an API close-bot"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 14a7ac79-079e-4234-95cc-a669e2f773b9
---

GitHub closing keywords (`Closes #N`, `Closes owner/repo#N`) auto-close issues only in the **same repository**. A cross-repo reference produces a `CrossReferencedEvent` (mention) but **never** a `ConnectedEvent` (close). Proven 2026-06-26: ce-ops#260, referenced by `Closes creator-engine/ce-ops#260` in path-to-main PR #525, stayed OPEN; timeline showed mention-only. CE code PRs live in `creator-engine/creator-engine`; issues in `creator-engine/ce-ops` — so `Closes creator-engine/ce-ops#N` in a code PR is a **NO-OP**. This is *the* cause of ce-ops tracker drift (59 stale-open issues with merged PRs found 2026-06-26).

**Fix (ce-ops#262):** a merge-triggered GitHub Actions bot in creator-engine that parses `ce-ops#N` from the merged PR **title** (`feat(ce-ops#N): ...`) and closes the issue via the API using a cross-repo token secret (`CE_CROSS_REPO_TOKEN`, ce-ops issues:write). Never rely on the keyword for cross-repo. Until the bot is live, close ce-ops issues manually when their PR merges. Related: [[ce-run-full-preflight-before-push]] (harvest/dispatch workers should run `ce validate-pr` before opening PRs — the missing work-class line + carrier failures this session would've been caught pre-push).

## Detail (moved from index 2026-07-05)
- fix = merge-triggered close-bot (#262).
- code-PR→ce-ops#N is mention-only.
