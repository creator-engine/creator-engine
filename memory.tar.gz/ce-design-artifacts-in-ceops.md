---
name: ce-design-artifacts-in-ceops
description: "Design/research artifacts go in the PRIVATE ce-ops repo (designs/ + mandates/), never the public creator-engine repo"
metadata: 
  node_type: memory
  type: project
  originSessionId: 2b67ead0-9d4c-41c1-974e-43b059ac1239
---

Operator directive (2026-06-23): **design artifacts must be repo-durable for seat access — but in the PRIVATE `creator-engine/ce-ops` repo only, NEVER the public `creator-engine/creator-engine` repo.** Internal planning ≠ public product. Aligns with [[ce-public-private-ops-architecture]] (ADR-0001, default PRIVATE).

**Where:** ce-ops already has the homes — `designs/` (DESIGN_*/RESEARCH_*), `mandates/` (BUILD_MANDATE_*/GATE_*), `resume-states/`, `decision-records/`, `roadmaps/`.

**Mechanism:** `ce-ops/sync-ops.sh` mirrors from `~/creator-engine/.ce/state/research/` (the resume root). **Gap fixed 2026-06-23:** the script originally synced only `*MANDATE*.md` + `RESUME_STATE_*.md` from that dir (DESIGN_*/RESEARCH_* fell through because they sat in `.ce/state/research/`, not `~/Documents`). Extended to also copy `DESIGN_*.md` + `RESEARCH_*.md` → `designs/`.

**Why it matters:** the gitignored `.ce/state/research/` is DGX-local — fleet seats on other hosts/users can't read design docs via the repo, so briefs had to embed full specs. Durable ce-ops home + a seat-side ce-ops checkout lets future briefs point to a ce-ops path instead of embedding. [[ce-no-egress-seat-self-contained-briefs]] still applies until seat-side ce-ops read access is wired.
