---
name: ce-stage-vocabulary-canon
description: CE v3 user-facing stage vocabulary is CANON (Frame→Shape→Build→Review→Ship) over the conserved mechanical machine; landed PR
metadata: 
  node_type: memory
  type: reference
  originSessionId: fb01930d-8197-4165-a823-9f134d36e4f1
---

**LANDED 2026-06-07 — PR #161 @ `main 02caa51`** (the CE-Design-Controller's first governed workflow; compose→ratify→execute→independent-review→head-pinned-squash-merge, no-drift verified). The v3 **user-facing stage vocabulary is CANON** (peer to Operator/Controller), authored in `docs/architecture/stage-vocabulary.md`:

> **Frame → Shape → Build → Review → Ship**

- It is a **skin** over the **conserved mechanical state machine** (renames/removes **zero** enums): spec-lifecycle `draft→ready→in_progress→verified→ratified→done` (`schemas/spec-wrapper-sidecar.schema.yaml:35`); container `provision→run→collect→teardown`; run-outcome `pr_opened|pr_merged|review_submitted|research_delivered|no_change` (`runtime-evidence.schema.yaml:247`); mutation-class. The doc holds the **dual-mapping table** (cognitive ↔ board `BACKLOG/SHAPE/READY/RUN/REVIEW/MERGE` ↔ spec-lifecycle ↔ gate ↔ BMAD) + the **fractal/altitude** framing (default = Scope altitude; `Frame` collapses into `Shape` at small grain; `Ship` is plural — covers research_delivered/no_change too).
- Operator-locked the two contested words 2026-06-07: **Frame** (over "Understand") and **Ship** (over "Deliver"). Maps to BMAD: Frame≈Analysis · Shape≈Planning+Solutioning · Build≈Implementation · **Review/Ship = CE's first-class governed tail** (external grading + governed merge = differentiator).
- **✅ DONE 2026-06-08 — shipped in G-6 (PR #162 @ `main dee9c9b`).** The G-6 coordination layer authored the Scope state/phase vocabulary in this canon: `schemas/scope.schema.yaml`'s `state` = the conserved spec-lifecycle; `coordination.py`'s `project_scope_state`/`cognitive_phase` derive the Frame→Shape→Build→Review→Ship skin per the dual-mapping; `ce_scope` FORCES a stored `phase` to equal the derivation (no third vocabulary, no drift). **NEXT — G-7 surfaces the canon in the product** (the `ce session` status line / ◆ CE Completion Report / board); fold into the G-7 prompt alongside [[ce-context-observability-issue-157]] (one session resource/health surface) + the G-5 spend meter. See [[ce-docs-terminology-canon]] (docs-canon = manual hygiene) and [[bmad-method-reference]].
- Surfacing the canon in the status line / ◆ CE Completion Report / board = **G-7** (deferred). A docs-scoped CI terminology guard for it = named deferred follow-on. Pairs with [[ce-context-observability-issue-157]] + the G-5 spend meter (one session status-line surface).

## Detail (moved from index 2026-07-05)
- Related: [[ce-shaping-ux-design]]
- skin over the machine.
