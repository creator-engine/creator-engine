---
name: ce-tenant-launch-gate-remote-diagnosis
description: "Remote-diagnose/verify a tenant's `ce launch` refusal without spawning — dry-run skips the gates; invoke the gate function via the installed venv python"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 8204b18d-a84c-4233-9490-8c9eb78e3e8f
---

`ce launch --dry-run` returns BEFORE the Ring-0 pre-spawn gates (tmux ~668, seat-surface sentinel
~681, brain bootstrap ~714 in launch_runtime.py) — it CANNOT preflight the gates that actually
refuse launches (ticket = ce-ops#431; incidents = ce-ops#430, Arad 2026-07-03 ×2).

**Why:** Operator expects fix verification before "rerun ce launch" relay; running real `ce launch`
over ssh is wrong (refuses non-visible; writes launched sentinel → re-brick risk = the #430 class).

**How to apply (verified on Arad/mythos):**
1. Gate ORDER matters: the tenant's own failed run proves every gate BEFORE the one that fired.
   Only verify the failing gate + note untested downstream legs.
2. Tenant `ce` is a /bin/sh wrapper — real interpreter is in line 2:
   `~/.local/share/creator-engine/bootstrap/venv-<ver>-<hash>/bin/python`.
3. Run the exact gate function read-only from the tenant repo root via ssh stdin heredoc, e.g.
   brain gate: `from creator_engine_validator import brain_bootstrap;
   brain_bootstrap.build_bootstrap_payload(repo_root=".")` (pure — payload write happens later).
4. Legacy-brain fix itself: archive stale `.ce/state/brain/assertions.yaml` (never delete) →
   `ce brain init` (refuses to overwrite invalid — archive first is mandatory) → `ce brain verify`.

Related: [[ce-reviewer-cyber-safeguard-workaround]] pattern of proving a workaround in-session
before relaying; [[ce-verify-not-already-landed-gotcha]].

## Detail (moved from index 2026-07-05)
- archive→brain-init for legacy ledgers.
- verify the exact failing gate fn via tenant venv python over ssh.
