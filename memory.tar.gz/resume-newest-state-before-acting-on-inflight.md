---
name: resume-newest-state-before-acting-on-inflight
description: "Before acting on any in-flight/parked PR or decision, re-read the NEWEST resume state — context summarization can silently drop a prior REJECTION"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f302e45f-21e6-4286-809c-20b2e6622b34
---

Context summarization can silently drop a prior **decision** (especially a REJECTION or a park-for-ratification), leaving an older instruction as the only surviving signal — which leads me to re-do work my better-informed earlier self had deliberately rejected.

**Concrete failure (2026-06-24 night, #429 dispatch_worktree / ce-ops#200):** Earlier in the session I deep-analyzed #429, concluded the `version_boundary` ratchet *correctly* blocked it (new `shared→v1` import edge must force an architectural decision), REJECTED dev-3's allowlist+`__import__` fix as ratchet-subversion, and parked it for Operator ratification in **V15 (`AWAITING-OPERATOR / ce-ops#231`)**. After context summarized, I read only V14 ("push dev-3's fix"), and pushed + rebased + carriered + **approved** the exact rejected fix — nearly auto-merging a governance-subverting change. Caught it only by reading the existing V15 on disk before overwriting it; re-blocked via CHANGES_REQUESTED + draft.

**Why:** resume states are versioned (V13→V14→V15); the NEWEST supersedes older ones. The summary in my live context is lossy and may carry a stale older instruction instead of the latest decision.

**How to apply:** Before acting on ANY in-flight PR, parked item, or "just do X" integration instruction — `ls -t .ce/state/research/RESUME_STATE_CE_DEV2_*` and read the NEWEST one's **AWAITING-OPERATOR** + **IN-FLIGHT** sections FIRST. If the newest state rejected/parked the very thing an older note tells me to do, the rejection wins. Never let a summarized older instruction override a more-analyzed newer decision. Related: [[persist-decisions-at-confirmation]], [[audit-findings-against-operator-directives]], [[ce-controller-verified-bootstrap]]. Governance ratchets (version_boundary V1_RUNTIME allowlist "only shrinks") must not be subverted by allowlisting — that needs ratification.
