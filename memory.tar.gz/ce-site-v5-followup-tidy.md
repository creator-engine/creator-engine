---
name: ce-site-v5-followup-tidy
description: NEXT TASK after the 2026-06-08 /clear — a small governed follow-up site PR tidying cosmetic items on the LIVE v5 design
metadata: 
  node_type: memory
  type: project
  originSessionId: 0dd6e0d5-5231-47c3-ba50-45bcdf86f9d1
---

**✅ DONE + MERGED 2026-06-08 — PR #176 squash-merged → `origin/main df85fe0`. TASK CLOSED.** (Approval cleared the non-author code-owner gate via the reviewer token `ubuntuaws745-cmyk` — Operator-ratified direct waiver of the independent-venue rule for this cosmetic docs PR; CI "Validate governance artifacts" PASS; orchestrator squash-merged + deleted branch.) Historical detail ↓**

**(pre-merge log) EXECUTED 2026-06-08 — PR #176.** Done in-session (orchestrator drive, Operator-ratified all 3 recs: match `og:title` phrasing · v5.x in-place patch, no new archive · in-session not a seat). Branch `feat/site-v5x-tidy` @ `0bcea2f`, base `af6ee9d`. 3-path carrier (`.ce/pr-path-manifest.md` + `docs/index.html` + `site-archive/README.md`); `verify-path-manifest`+`scan-path-manifest` PASS; pytest green modulo the known umask artifact (`ce-hook-common.sh` 0o775). Did 4 `docs/index.html` edits (the 2 title-metas, the `<h2>`→`<h3>` demote, **+ a scoped `.section-head h3` size rule** so the demote reads as a deliberate sub-head not a default-size h3) + reconciled the v5 ledger row (title quote **and** refreshed its SHA256 `9e799a47…` — slightly beyond "just the quote", flagged to Operator). `gh pr list` first = only stale #108 lingering, no parallel site track. **NEXT: Operator review-or-waive + merge head-pinned, then this task CLOSES.** Original task spec below ↓

**Context (2026-06-08 ~15:00Z):** the **v5 NVIDIA-ready consumer redesign is LIVE** on creator-engine.dev — PR #174 merged (`origin/main af6ee9d2`), `docs/index.html` sha256 `f39afa2f` (the Operator-chosen, hand-corrected Claude bake-off winner), v4 archived, ledger shows v5 "current — live". Codex alternative preserved for revert at `~/Documents/ce-website-redesign-round2-20260608/codex-v2-CORRECTED.html`.

**NEXT TASK (Operator-directed): one small GOVERNED follow-up site PR** on the live v5 `docs/index.html`, batching these cosmetic tidies + the session's eye-flags:
1. **`<title>` sync** — the browser-tab `<title>` still reads *"Creator Engine — Turn your computer into a software factory you can trust"* (stale from before the H1 correction). The H1 is now *"Turn your home computer into a software factory."* and `og:title` was updated to match, but `<title>` (and check `twitter:title`/any other title meta) was missed. Unify them to the corrected H1's phrasing.
2. **"Why governance / safety" double-headline** — that section now has TWO big headlines: its intro *"The safety gap is not theoretical."* AND the fear-map headline *"Every consumer fear maps to a mechanism you can read in the repo."* (added per the Operator's round-2 correction). Confirm it reads right or demote/restructure one.
3. **(optional) v5 ledger-note prose** — the `site-archive/README.md` v5 row (written by #174) quotes the title as *"Turn your computer into a software factory you can trust"*, slightly misquoting the actual H1; sync if tidying.

**How:** governed site flow (ratify → branch → write → gates green → push → review/waive → merge), single track. Versioning per [[ce-website-versioning-policy]] (snapshot the outgoing v5 if the policy treats any `docs/index.html` change as a new version; the site seat decides v5.x vs v6). Carry `.ce/pr-path-manifest.md`. Executor = the site seat **%609** (its `ce-site-lane-resume` memory has the lane context) or a fresh site seat.

**Do NOT repeat the #175 mistake** ([[ce-check-parallel-tracks]]): before building, check `gh pr list` for any open/parallel site PR on `docs/index.html` so this isn't a duplicate. Gotchas: shared-carrier collision → benign rebase ([[ce-base-only-refresh-microauth]]); code-owner gate (`ubuntuaws745-cmyk`) → Operator waiver → reviewer-token re-stamp (`GITHUB_REVIEWR_TOKEN` in `~/.hermes/.env`) → merge promptly.
