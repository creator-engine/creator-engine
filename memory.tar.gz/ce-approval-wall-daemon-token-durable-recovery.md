---
name: ce-approval-wall-daemon-token-durable-recovery
description: Merge-gate down = expired approval-wall OpenBao token; durable fix = orphan+periodic token + policy with sys/audit; full recovery ceremony
metadata: 
  node_type: memory
  type: reference
  originSessionId: 1b7bb9dc-d71c-4ac0-8dac-d3ed8c769a21
---

**Symptom:** queue-daemon logs `approval_capability_mint_failed` / `error=approval capability secret unavailable`, OR on restart refuses `approval wall misconfigured: armed_state_without_secret`. → **merge gate DOWN** (no auto-merge). Daemon = pid running `.venv/bin/python -m creator_engine_validator.v3_cli queue-daemon` on DGX; launcher `~/ce-wall-daemon-launch.sh` reads a STATIC token file `~/.ce-keys/ce-approval-wall-token` (no auto-refresh → expires → fail-closed).

**Two root causes hit 2026-07-02 (both now fixed):**
1. The static daemon token EXPIRED. A running daemon may limp on a renewed in-memory token, but ANY restart/reboot re-reads the dead file → hard fail. 
2. On restart the backend `validate_config` does `GET /v1/sys/audit` (root-protected, needs **read+sudo**). A token whose policy only grants the secret read gets 403 → `AuditUnavailable: no enabled audit device` (misleading — audit IS enabled: `ce_audit/` file → /var/log/openbao/audit.log). The daemon needs sys/audit + sys/health caps for the preflight.

**DURABLE FIX (done):** minted an **ORPHAN + PERIODIC** token (`bao token create -orphan -period=720h -renewable`) — orphan so root-revocation doesn't cascade-kill it; periodic so it auto-renews forever. Wrote to `~/.ce-keys/ce-approval-wall-token`. Updated policy **`ce-approval-wall-read`** to: `read` on `ce-kv/data/forge/approval-capability/wall` + `read` on `sys/health` + `read,sudo` on `sys/audit`. Restart via canonical launcher → validate_config passes → materialize writes `/dev/shm/ce-wall-daemon/secret` → armed. Now restart-safe (survives reboot → unblocks #351 cutover too).

**Recovery ceremony (need OpenBao root; standing OpenBao-arm authorization holds):** OpenBao is on the VPS (`https://100.72.252.20:8200`, CA `/usr/local/share/ca-certificates/ce-openbao-ca.crt`, config `/etc/openbao/openbao.hcl`, bin `/usr/local/bin/bao`). Bundle `/home/ce/open_bao.json.gpg` decrypts with `~/.ce-keys/openbao-init-bundle.pass` → 5 unseal shares (threshold 3); the bundle's root_token is REVOKED (must generate-root). Run script as root: `cat ~/.ce-keys/openbao-init-bundle.pass | ssh dev1 'sudo bash /root/x.sh'` (passphrase via stdin head -1). Steps: add `disable_unauthed_generate_root_endpoints = false` INSIDE the `listener "tcp" {` stanza → `systemctl restart openbao` → unseal 3 → generate-root (`-generate-otp` → `-init -otp` → feed 3 keys → parse **plain** "Encoded Token" line, NOT -format=json which can be warning-prefixed → `-decode -otp`) → use root → `bao token create -orphan ...` / `bao policy write` → `token revoke -self` → **trap on EXIT reverts flag + restart + unseal 3** (fail-safe). Working script saved: `scratchpad/bao_mint_wall_token.sh` + `bao_fix_wall_policy.sh`.

**GOTCHAS that cost hours 2026-07-02:** (a) token MUST be `-orphan` (else revoking transient root cascade-revokes it → invalid); (b) generate-root encoded-token parse: use plain output + grep "Encoded Token", not json; (c) don't reuse var name `OUT` for both output-file path AND generate-root capture; (d) the env-fallback (`CE_APPROVAL_CAPABILITY_SECRET`) is NEVER used when `--approval-wall-secret-backend openbao` is set (primary-then-env returns primary() directly) AND minting REQUIRES the backend — so you MUST fix the backend/token, env-secret can't bridge it; (e) DON'T restart the working daemon unnecessarily — the token-FILE fix alone gives restart-safety; I restarted needlessly and turned a self-healed gate into a full outage. [[ce-openbao-admin-recovery-blocked]] [[ce-wall-daemon-token-expiry-restart]]

## Detail (moved from index 2026-07-05)
- durable fix = ORPHAN+PERIODIC token + policy w/ sys/audit(read,sudo); full generate-root ceremony via init-bundle passphrase. Don't needlessly restart a self-healed daemon.
- = expired OpenBao approval-wall token.
- (mint_failed / armed_state_without_secret).
