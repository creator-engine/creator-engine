---
name: ce-contained-seats-have-git-egress
description: "Contained seats DO have (brokered) git egress to GitHub — don't assume 'no-egress / needs ref-injection'; probe per-seat before labeling a seat broken."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9cc9934a-6a57-49e0-b6fd-bf167a20994b
---

**Verified 2026-06-30:** dev-3 (`ce-vps-codex`, a CONTAINED seat) has `origin = github.com/creator-engine/...` and **working git egress** (live `git ls-remote origin` succeeded; FETCH_HEAD timestamped hours-fresh). Containment = filesystem/landlock/bwrap isolation + brokered network — NOT zero network. Self-pushing seats NEED git egress (they author their own PRs). So "contained == no-egress == can't fetch" is a **misnomer**.

**Why:** I labeled dev-3 "no-egress, ancient refs, needs ref-injection" and called a 9k-line `git diff (old-merged-HEAD)..(current main)` a "stale base" — both WRONG. dev-3 was a healthy seat parked on an old merged commit (#650); it just needed a normal dispatch (`git fetch && git checkout -b <new> origin/main`). The phantom "ref-inject" task didn't exist.

**How to apply:** Before declaring a contained seat broken / needing injection, PROBE: `git remote -v`, a live `git ls-remote origin HEAD` egress test, and `git rev-parse HEAD` (is it just parked on an old branch?). A two-dot `diff main..HEAD` showing huge churn is usually a direction artifact (HEAD on an old branch), not damage. Don't inherit a "no-egress" assumption from older notes — verify. Tempers [[ce-harvest-contained-seat-stale-origin]] (which applies to GENUINELY air-gapped seats like dev-4-style setups, not all contained seats). [[ce-verify-not-already-landed-gotcha]]

## Detail (moved from index 2026-07-05)
- Don't label a seat broken/needs-inject from an inherited assumption — probe `git remote -v`+`ls-remote`+`rev-parse HEAD` (two-dot diff churn = old-branch artifact, not damage).
- "contained≠no-egress".
- real github origin + working fetch.
