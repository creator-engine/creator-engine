---
name: ce-v1-v3-coexistence-not-deletion
description: Operator directive (2026-06-07) — do NOT delete CE v1.0; v1 and v3 must COEXIST (we use v1 to build v3); supersedes the spec §6 D1–D6 deletion plan and pauses G-3.9-as-deletion
metadata: 
  node_type: memory
  type: project
  originSessionId: a2a431aa-13ed-471d-98a8-2f89c63a42d1
---

**Operator directive (2026-06-07, mid-G-3.9):** CE v1.0 must **not be deleted**; CE v1.0 and v3.x must **coexist** as different versions in the repo. The reason: **we operate as Controllers using the CE v1.0 machinery (`ce lane`/`lane_runtime`, the hook pack, PCO/leases/panes, tmux) to develop CE v3.1** — deleting v1.0 cuts our own dev substrate, and v1.0 is a working shipped system worth keeping as a coexisting version (continuity + fallback + comparison baseline).

This **supersedes the `docs/architecture/v3-spec.md §6` D0–D6 "deletion plan"** and the `docs/architecture/pilot-roadmap.md §G-3.9` "cleanup by deletion" framing. The deletion plan was SUBTRACTIVE (excise ~9% of v1/v2 coordination/posture/lane/reviewer machinery to reveal v3). The directive reframes the goal as ADDITIVE/coexistence.

**Key insight that makes this coherent:** G-1…G-3.8 were already ADDITIVE — they built the v3 surface (runtime spine, forge adapters, thin orchestrator, `run_assembly`) **alongside** v1 without deleting it. G-3.9 was the FIRST subtractive gate, and that is exactly where the bootstrap dependency bit (the launcher-coupling hazard: the retained v1 launcher `lane_runtime` module-level-imports the doomed D1/D3 modules — see [[ce-v3-g3-program-resume]]). So the right move is to **keep going additively** and formalize coexistence, not delete v1.

**How to apply:**
- **PAUSE G-3.9 as a deletion gate** (the v2 plan + the G-3.9.1/D4 strip are withdrawn pending a reframe). D4 itself strips v1 reviewer-authority/posture behavior from `hook_check` — also wrong under coexistence (keep v1's hook behavior).
- **Reframe "cleanup"** to a **version-coexistence / separation** design: keep v1.0 intact + operational; establish explicit v1↔v3 boundaries (versioned namespacing/packaging, distinct entry points — `ce` v1 launcher vs the v3 CLI, shared durable checks as common substrate); re-scope any actual removal to ONLY genuinely-orphaned code proven unused by BOTH v1 and v3.
- **Amend the design docs** (`v3-spec.md §6`, `pilot-roadmap.md §G-3.9` + the deferred "lane/launch teardown" framing) to coexistence-not-deletion when re-planning.
- Compose a coexistence design/research artifact (pre-authorized) before re-planning the gate. Then resume the v3.1 arc (G-4 → G-7) additively.

Cross-refs: [[ce-v3-roadmap-to-pilot]] (the MVP→pilot roadmap — its cleanup gate is what changes), [[ce-v3-product-vision]], [[ce-v3-g3-program-resume]] (live gate state), [[batch-strict-mode-gate-workflow]].

## Detail (moved from index 2026-07-05)
- Related: [[ce-v4-runtime-language-research]]
