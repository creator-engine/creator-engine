---
name: ce-installation-grant-is-mint-ceiling
description: "Per-run least-privilege (scoped tokens) ≠ narrowing the standing App installation grant — you can't mint above the installation ceiling."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 10663450-528d-4232-812b-ce40bad5e9ab
---

A GitHub App installation access token can only be scoped *down* to a subset of what the installation already holds (`POST /app/installations/{id}/access_tokens`); there is **no JIT-elevation of the installation grant itself**. So an **escalation-gated JIT minter can only mint a permission if the standing App installation HOLDS it.** The standing grant is the **capability ceiling**; the minter + bound policy is the **exercise gate**.

**Why:** On ce-ops#87 I recommended narrowing `ce-forge-dev3` from `administration:write` → `read` for least-privilege — but that would have **broken the Phase-2 escalation path just ratified in the ceiling-driven minter** (ce-ops#88), since you can't mint `administration:write` from a read-only installation. The Operator caught the contradiction.

**How to apply:** For CE credential least-privilege, the lever is the **minter + bound-policy gate** (per-run scoped tokens, escalation-gated, time-boxed, revoked), NOT trimming the standing installation grant. KEEP the write ceiling on onboarding-capable Apps; the blast-radius control is "the minter is the sole sanctioned mint path + PEM-on-tmpfs/Signer + short-TTL + audit." The real crown jewel is the **App PEM** (a leak lets an attacker self-sign JWTs and mint the ceiling directly), not the grant level. Legitimate standing-grant narrowing = repo *scope* (all→selected) and unused scopes (e.g. `actions:write`→read), never the *level* the minter must escalate to. Ceiling-driven minter lives in `ce-ops designs/ce-applydriver-live-forge-gate-spec-RATIFIED-20260615.md`. Related: [[ce-push-deploy-authority-model]] [[ce-independent-audit-small-blast-radius]] [[ce-governed-seat-cannot-push]].
