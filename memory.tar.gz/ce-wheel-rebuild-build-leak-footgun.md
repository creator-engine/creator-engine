---
name: ce-wheel-rebuild-build-leak-footgun
description: pip wheel leaks validators/build/lib/ artifacts that silently bloat a gate diff — clean before commit
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 191f4aca-7093-4ea1-af83-1705595fa567
---

When rebuilding the Ring-1 validator wheel (the F6 "wheel-IN" step recurring in many CE gates),
`pip wheel --no-deps --no-build-isolation .` (run in `validators/`) leaves a setuptools
build tree at `validators/build/lib/creator_engine_validator/**` (~118 .py files). It is
NOT gitignored, so `git add -A` sweeps it into the commit and blows the closed path-manifest
(caught on ce-ops#21: 131 staged paths instead of 13).

**Why:** the per-PR/closed-manifest gate fails (`path_manifest_diff_outside_manifest`) if these
leak through — or worse, they merge as dead artifacts.

**How to apply:** after building, copy ONLY the `.whl` into `validators/wheelhouse/`, then
`rm -rf validators/build` (and `git rm -r --cached validators/build` if already staged) BEFORE
committing. Verify the staged diff == the ratified path-set exactly. Reproducible build that
matched the prior wheel's generator: setuptools 78.1.1 + wheel 0.45.1 from the canonical
`.venv` (no `build` module needed). Validate the result with
`packaging_runtime.verify_wheel_matches_source` (every bundled .py must byte-match source —
this, NOT just `test_wheelhouse_built_surface.py`'s ce_cli.py check, is what forces a rebuild
when any package module changes). Pairs with [[ce-pr-path-manifest-carrier-required]].

**WHEELHOUSE-ONLY rule (Operator correction, 2026-06-13, near-miss on ce-ops#34 RS lane):** rebuild
**ONLY `validators/wheelhouse/`** (the wheel + `validators/wheelhouse/SHA256SUMS`). `verify_wheel_matches_source`
checks `validators/wheelhouse/` EXCLUSIVELY (`packaging_runtime.py:261`); **no test couples
`docs/downloads/<ver>/` to source.** `docs/downloads/0.2.0/` is the **SIGNED-RELEASE install wheel**
pinned in the signed spec — rebuilding it **breaks the live install chain** (e.g. a pilot/VPS rehearsal)
and requires **Operator-only re-signing**. So in a code lane that changes validator source: rebuild the
wheelhouse wheel, add ONLY `validators/wheelhouse/{whl,SHA256SUMS}` to the carrier (e.g. 7→9 paths, not
+docs/downloads), and **never touch `docs/downloads/`**. The #54/#56/#58 batch uses this same wheelhouse-only rule.
