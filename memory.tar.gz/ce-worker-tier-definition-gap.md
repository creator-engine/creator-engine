---
name: ce-worker-tier-definition-gap
description: CE defines worker ROLES + role-shaped credential policy for CONTAINED workers (spec 005 §d.2); the gap is the in-process sub-agent modality
metadata: 
  node_type: memory
  type: project
  originSessionId: 6c51a018-83e5-45dc-8943-a61fef8b0fc7
---

CE's hierarchy is Operator → Controller/Foreman → **Worker**. The Worker tier IS substantially defined — for **contained** workers:
- **Role taxonomy** is normative across ~12 schemas: `operator/controller/architect/implementer/reviewer/verification/agent_reviewer` (authority-matrix: source/ratifier/architect/implementer/verifier/observer).
- **spec 005** `worker-isolation-runtime.md` §d.2 ratifies three worker-container roles with DISTINCT role-shaped credential/egress/mount policy: `architect_research` (read-only mount, model+web egress, NO write tokens/SSH/controller-key), `implementer` (rw on ONE worktree, per-task scoped PAT claim-lifetime TTL), `verification` (read-only, no egress). Plus `schemas/implementer-evidence.schema.yaml` + `docs/contracts/implementer-evidence.md`.
- §d.1: a worker container sits **below a visible pane** — CE's worker model is **entirely container-based**.

**THE GAP (Operator 2026-06-25, ce-ops#244):** there is NO sanctioned **in-process sub-agent** modality for those same roles — the Agent/Task primitive a Controller actually reaches for (faster/cheaper) for research/review/mechanical fan-out. It's currently raw/ungoverned: inherits the Controller's creds (root of the [[ce-fork-credential-drift-approval-leak]] authority-leak) and sits outside [[ce-mandatory-containment-decision]] (#115).

**Direction:** admit a governed in-process modality reusing the EXISTING role names (don't invent — I wrongly improvised "researcher" when CE has `architect_research`); in-process workers MUST carry the same §d.2 role-shaped credential boundaries (an in-process `architect_research` = no write tokens — exactly what prevents the leak); reconcile with mandatory containment.

**ROOT CAUSE — framework not injected harness-uniformly (evidenced 2026-06-25):** two CE controllers diverged on "I need a helper" — codex dev-3 used CE role `implementer`; Claude-Code dev-2 improvised `researcher`. Why: codex controllers are grounded by `~/.codex/AGENTS.md` (rich re-read-every-session FOREMAN directive naming explorer/implementer/reviewer roles, launcher-injected); the Claude-Code controller loads only a bare SpecKit `CLAUDE.md` stub + empty `.claude/agents/` + no injected charter → falls back to raw harness primitives. So CE's worker framework is wired for codex controllers, ABSENT for Claude-Code controllers = determinism breach at the harness boundary (adherence depends on harness). Concrete form of [[ce-controller-verified-bootstrap]]. Secondary: codex directive is interim (perm form=#163); role names drift (codex explorer/implementer/reviewer vs spec005 architect_research/implementer/verification) = not single-SSOT.

**FIX:** one canonical worker framework (roles + selection policy + §d.2 cred boundaries) from a SINGLE SSOT, injected IDENTICALLY into every controller harness (Claude-Code: CLAUDE.md + `.claude/agents/` + launcher charter; codex: AGENTS.md) so no controller boots ungrounded.

**Why:** completes the Operator→Controller→Worker framework (product differentiator) + closes the authority-leak at the architecture level + makes all CE controllers behave identically by construction. **How to apply:** when spawning sub-agents, map them to CE roles (architect_research/implementer/reviewer/verification) with role-scoped creds; NEVER credentialed-fork for gate-adjacent work. [[ce-terminology-seat-to-worker]] [[ce-controller-spawns-many-workers]] [[ce-codex-foreman-directive-durable]] [[ce-controller-verified-bootstrap]]

## Detail (moved from index 2026-07-05)
- don't improvise. Related: [[ce-reviewer-triage-ratified]] [[ce-speckit-superpowers-whathow]]
- map sub-agents to CE roles.
- ROLES+creds for CONTAINED workers (spec005 §d.2).
