---
name: ce-mode-axes-canon
description: "Operator-ratified (2026-06-30) decomposition of CE's mode vocabulary into FOUR orthogonal axes: Lifecycle×Autonomy (run mode) + Tier + Collaboration; resolves the Solo-overload + speckit-persona gaps"
metadata: 
  node_type: memory
  type: project
  originSessionId: dd146cd2-c96c-49bc-a20b-797098491dc6
---

Operator ratified 2026-06-30 (matrix research by architect_research). Supersedes the loose single "Dev/CEO/strangeLoop run-mode" framing. Full report in agent output a65c191ef1cea6e6f.

**The "run mode" axis is really TWO sub-axes (RATIFIED — decompose for canon):**
- **1a. Lifecycle ownership** = `Dev` (human owns Frame+Shape; CE owns Build→Ship — the v3 MVP) / `CEO` (CE owns inception→execution; human Frames+Shapes+ratifies).
- **1b. Per-action autonomy** = `strict / auto / transcendence` (the WIRED enum in `operating-mode-policy.schema.yaml`). **`strangeLoop ≡ transcendence`** (highest band, self-running loop behind a consent gate; privileged floor still human-gated).
- "Dev→CEO→strangeLoop" = a named DIAGONAL gradient across BOTH sub-axes (pin the 80/15/5 figure to the gradient, not a single enum).
- Three unreconciled autonomy vocabularies exist in-tree (product prose; schema strict/auto/transcendence; automerge `run_mode dev/ceo`) — FOLLOW-UP: re-key automerge off `operating_mode` not the lifecycle label "ceo" (caller audit first).

**Axis 2 + Axis 3 — the old "Scale tier" was a flattened 2×2 (Operator-CORRECTED 2026-06-30, supersedes the Solo/Team/Fleet single-axis):** the prior list conflated TWO orthogonal questions, which is why "Solo" felt overloaded. Split them:
- **Axis 2 — Tier (install/runtime topology = how many coordinated governed agents under one orchestration domain):** **Solo** (ONE governed agent) / **Autonomous Fleet** (many, orchestrated — our dogfood). "Autonomous Fleet" = PUBLIC-safe name; **"Skynet" stays INTERNAL codename only** (confidentiality validator scrubs it; zero public leaks confirmed 2026-06-30).
- **Axis 3 — Collaboration (repo sharing = how many human principals share the work):** **Individual** (one principal, own repo) / **Team** (multiple CE principals on a shared repo).
- **The fix keeps the words, reassigns the axes:** Solo→a Tier value, Team→a Collaboration value, Fleet→the other Tier value. The OLD "Team deployment" decodes as **{Tier: Solo} × {Collaboration: Team}** — several single-agent installs on a shared repo; it was never a third tier. ⚠️ The governed daemons (egress broker / merge-queue-gate / integrator / review-pickup) are **Autonomous-Fleet-TIER** machinery, NOT "Team" — a Solo×Team setup (e.g. Nitzan + Operator on a shared repo) runs NO daemons; each is a solo install. [[ce-deployment-tiers-solo-vs-team]]

**Live principals (Tier × Collaboration × Lifecycle):**
- **Arad** (Mythos pilot) = **Solo × Team × CEO** — Operator (chmod735) co-owns `chmod735-dor/mythos` and collaborates with her there → Team, not Individual. Own Claude Code subscription.
- **Nitzan** (future CE contributor) = **Solo × Team** — shared `creator-engine` repo; own `ce-forge-Nitzan` App for her governed agent (not the shared onboarding App); own Claude Code subscription.
- **Our internal fleet** = **Autonomous Fleet × Team × CEO/strangeLoop** = the dogfood. (Autonomous-Fleet + Dev = degenerate — can't hands-on-drive a multi-fleet at typing speed.)
- External principals BYO their own model subscription (Claude Code); the shared weekly codex pool is internal-fleet-only. [[ce-codex-shared-account-subscription]]

**Speckit-persona resolution (the onboarding fix):** a human types `/speckit-*` slash commands in EXACTLY ONE cell — **Solo+Dev** (and per-seat Team+Dev). In every CEO/strangeLoop/Fleet cell the AGENT invokes the speckit pipeline under the hood; `/speckit-implement` is ALWAYS agent/envelope-invoked (FR-009 halts a human-typed call outside an envelope). Our fleet = Autonomous-Fleet+CEO/strangeLoop → never types slash commands. Onboarding docs were written for Solo+Dev but UN-SCOPED → Arad (Solo+CEO) is told to type commands his mode never uses. FIX (ratified, BOTH): add a "You are in: <cell>" banner to existing guides + AUTHOR the missing Solo+CEO (Arad) onboarding path (cev3 scope/ratify + decision-inbox). Confirmed by my speckit dogfood: the flow is agent-driven (human types 1 line, agent generates name/branch/spec + self-validates; human RATIFIES).

Related: [[ce-deployment-tiers-solo-vs-team]] [[ce-energy-efficiency-ceo-mode-gravity]] [[ce-stage-vocabulary-canon]] [[ce-nitzan-contributor-identity]]. spec-kit also needs upstream sync 0.8.7→0.12.0 (separate; governed rented-surface update).

## Detail (moved from index 2026-07-05)
- **Tier**(Solo/Autonomous Fleet=how many coordinated agents; Skynet internal) is ORTHOGONAL to **Collaboration**(Individual/Team=shared repo). Old "Solo/Team/Fleet" was a flattened 2×2. Arad=Solo×Team×CEO; Nitzan=Solo×Team; fleet=AutonomousFleet×Team×CEO. Related: [[ce-deployment-tiers-solo-vs-team]]
- +Autonomy(strict/auto/transcendence≡strangeLoop).
