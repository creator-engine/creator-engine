---
name: ce-batch-pr-merge-tax
description: Landing a BATCH of CE gate-PRs serializes painfully; collapse into one combined branch. The shared path-manifest + strict branch protection is the cause.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: eeb561ab-ea57-48c7-aec6-3cb849952a98
---

**LESSON (2026-06-09, cost ~hours this session).** Landing a batch of >1 CE gate-PR from a common base hits an N-1 serial **rebase→re-review→merge tax**, because:
1. **Every gate-PR rewrites the single shared `.ce/pr-path-manifest.md`** ([[ce-pr-path-manifest-carrier-required]]) → after the FIRST merges, all the others CONFLICT on that one file (even ones with disjoint code).
2. **`main` branch protection** = `strict` (must be up-to-date) + `dismiss_stale` (push dismisses approval) + `require_code_owner` (only `ubuntuaws745-cmyk` approval counts) + **`enforce_admins: true`** (admins CANNOT bypass — `gh pr merge --admin` is useless here). So each rebase to resolve the carrier dismisses the approval → needs a fresh code-owner approval + a fresh ~8-min CI run, serially.

**Why:** verified via `gh api repos/.../branches/main/protection`. The author seat can reach green+commit; the **orchestrator** pushes/merges ([[ce-push-deploy-authority-model]]) but still can't bypass `enforce_admins`.

**THE FIX THAT WORKS (Operator-approved):** collapse the batch into ONE combined branch — cherry-pick each PR's CODE commit onto current `main` (resolve overlaps once), `git checkout <branch> -- <files>` for disjoint PRs, author ONE combined carrier (path-set = union of all changed files + carrier), ONE CI, ONE independent review (focused on: the cross-PR conflict resolution + scope=union + anything rebuilt), ONE merge. Close the originals as superseded. Proven on PR #185 (landed A.2b-i+D.0.3+GateA+GateB after Gate C #182 merged).
- **Gotcha:** if any PR ships a built artifact (e.g. Gate A's wheel), REBUILD it from the COMBINED source (the combined tree has more `.py` than the original PR's source) and re-pin its checksum, else the fidelity guard fails. The canonical `.venv` has no pip/setuptools → rebuild a pure-`py3-none-any` wheel with stdlib `zipfile` (overwrite the package `.py` from source + regenerate RECORD).

**DESIGN FIXES to stop the tax recurring (good §3 / gate fodder):** (a) per-PR carrier filename `.ce/pr-path-manifest-<slug>.md` (gate resolves by glob) so batched PRs don't collide; (b) or have the diff-gate EXCLUDE the carrier file itself; (c) or make the carrier transient (not retained on `main`). Root tension: this friction is amplified by developing with **CE v1.0 tooling while source advanced past it** ([[ce-v1-v3-coexistence-not-deletion]]). Also a stray `/tmp/.git` breaks the fan-in `_detect_repo_root` heuristic → mass `PacketRootNotIgnored` false-failures locally (`rmdir /tmp/.git`); the detector should verify a real repo, not just a `.git` dir's existence.

**Designed fix (2026-06-11, ce-ops#21):** per-PR carrier files `.ce/pr-manifests/<branch-slug>.md` + "exactly one carrier in the diff" CI rule — kills the guaranteed cross-PR conflict, keeps evidence in-tree, leaves only a trivial conflict-free strict-mode rebase. **RATIFIED (Operator 2026-06-11):** first post-freeze gate (after 01-Jul), W2-pain escape hatch. Until then: single-lane merges per the ratified roadmap.
