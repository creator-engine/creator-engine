---
name: ce-bake-gaps-into-ce-not-conventions
description: "When I catch a CE-product gap, TICKET it (bake into CE itself) — don't band-aid it as a personal convention/memory that only steers me"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: fdf1f630-c8da-4de0-86e1-9d24db177a6a
---

When a gap surfaces in how CE *should* behave (review craft, governance, automation, UX), the fix belongs **in CE itself as a ticketed product capability**, NOT as a note in my personal memory/conventions that only changes how *I* operate around it.

**Why:** Operator 2026-06-19 — a convention in my head is a band-aid that doesn't scale, isn't dogfooded, and disappears when I'm not the one acting. Baking it into CE (a ticket → real feature) is the prevent-by-design posture; it makes the product better for all users, not just a workaround I personally remember. Reinforces [[ce-no-mvp-quality-from-day-1]] ("prevent-by-design not observe-and-react").

**How to apply:** the moment I'm tempted to "bake X into the convention/memory" to cover a CE capability gap → open a ce-ops ticket in the right workstream instead, and let my memory only POINT to the ticket (operating doctrine about *my* behavior is fine in memory; *product behavior* is not). Triggered #138 (first-class peer review) after I wrongly tried to memo the inline-comment review craft. Distinguish: my-operating-behavior → memory; CE-product-behavior → ticket.

## Detail (moved from index 2026-07-05)
- product-behavior→ticket.
