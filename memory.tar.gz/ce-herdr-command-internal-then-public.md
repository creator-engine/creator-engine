---
name: ce-herdr-command-internal-then-public
description: "Operator decision 2026-06-25: `ce herdr` (herdr-substrate reach, e.g. remote-attach) ships as an INTERNAL/dev-gated command first, graduating to a public product command only in a later release after internal testing proves functionality"
metadata:
  node_type: memory
  type: project
  originSessionId: 9c67b023-0ac9-402b-9806-fa1c581c5303
---

**Operator decision 2026-06-25 (on PR #444 / ce-ops#237 "herdr authenticated reach-plan"):** the `ce herdr` command group (e.g. `ce herdr remote-attach` — authenticated controller→contained-seat reach over the herdr agent-PTY substrate) ships **INTERNAL first, public later**.

- **Now:** keep the capability but take it OFF the public product surface — internal/dev-gated namespace, classified internal in the command-inventory guard, NOT documented in the public README. This satisfies `test_as_built_ce_inventory_matches_expected` + `test_readme_documents_every_ce_command_group` WITHOUT advertising internal fleet machinery (consistent with the product-lens doctrine we enforced all day in #473/#477).
- **Later:** graduate `ce herdr` to a public product command in a future release once internal testing proves functionality. Leave a code/ticket marker recording the promotion path.

**Why:** herdr is our internal agent-PTY containment substrate; `remote-attach` is controller-to-seat fleet ops, not something a solo dev installing CE would run. Presenting it as a public product command now = leaking internal machinery as product (the exact thing the [[ce-public-docs-product-lens-doctrine]] forbids). But herdr-PTY IS shipped containment substrate per [[ce-shipped-product-terminal-first]], so it's a legitimate *future* product surface — hence staged promotion, not permanent hiding.

**How to apply:** any new `ce herdr` (or herdr-substrate) command defaults to the INTERNAL inventory category until an explicit Operator-ratified promotion; the public README documents only product-surface commands. This is the pattern for any internal-machinery CLI that may later graduate. [[ce-bake-gaps-into-ce-not-conventions]]

## Detail (moved from index 2026-07-05)
- graduates to public later (#444/ce-ops#237).
- CLI ships INTERNAL/dev-gated first.
