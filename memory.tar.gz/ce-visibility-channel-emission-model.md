---
name: ce-visibility-channel-emission-model
description: "CE visibility = emit canonical read-model to user-chosen renderers/channels (TUI/WebUI/App + Discord/Slack/NanoClaw), OpenClaw-like headless gateway; watching is opt-in, ratify+retrospective-audit is the default. 80/15/5 strangeLoop/CEO/Dev."
metadata: 
  node_type: memory
  type: project
  originSessionId: 6bbff8e6-70c6-4729-b4d2-2376e936be75
---

Operator directive 2026-06-23 reshaping CE's visibility/witnessability + interaction architecture (feeds #207/#208 + cockpit; supersedes "controllers must stay on tmux").

**Core:** CE is OpenClaw-shaped — the gateway/controller runs **HEADLESS**, and the **user chooses the UI/channel** to interact with it: CE TUI, WebUI, App, OR a comms channel (Discord/Slack/NanoClaw). CE must know how to **EMIT** its reports/status/"what's going on" into whichever channels/UIs it supports. The visibility layer's product = **read-model emission**, not pane-hosting.

**"Headless" ≠ dark.** Visibility contract = controller EMITS to the canonical **read-model (L2)**; tmux/cockpit/channel are interchangeable RENDERERS of the L1→L2 spine. The harness_seat_contract C4 gate should refuse **dark** headless (Claude `--print`, no archivable surface) but ALLOW control-UI/channel-visible headless — **including controllers**.

**Limitless-fleet-on-Discord proof (Operator's own experience):**
- (A) Live work-watching is **OPT-IN** — peek by emitting an ascii/event stream to any channel (NanoClaw-connectable); not the default.
- (B) **Ratification = Authority** — agent asks + receives authorization BEFORE a task; the implementation is audited **retrospectively** via forge artifacts + emitted completion reports (occasional live monitoring only).
- (C) Most users **don't want to watch** — they want a heavily-guided design phase (they have an idea but lack technical skill/vocabulary) and to be **CONTACTED only when input/action is needed**.

**Market research (solo-dev):** **80% strangeLoop by default · 15% CEO Mode · 5% Dev Mode.** Optimize visibility/UI for the 95% who delegate, not the 5% who watch.

**Implication for #207/#208:** the headless backend's real job is read-model emission; a sibling **channel-emission + contact-on-need layer** (completion reports + "I need your input" to the user's chosen channel; opt-in live stream on request) is first-class — the strangeLoop/CEO-mode surface.

**herdr reference (RESEARCH_HERDR_AGENT_MULTIPLEXER.md):** a Rust agent-multiplexer (server-owns-processes/thin-client/NDJSON event-stream/Agent-as-first-class-object) — independently validates CE's headless-core + read-model bet; reference only (AGPL+Rust). **GUARDRAIL it confirms:** CE read-model state MUST come from authoritative governance/lifecycle events, NOT screen-scraping (herdr's brittle default). Adopt: one socket for human-TUI + agent-RPC; unseen/reviewed (done/idle) axis; blocked/AWAITING-OPERATOR as scannable; self-report > scrape.

**ATTACH requirement (Operator 2026-06-23, from herdr) — design MUST accommodate from the start:** CE must ALWAYS offer the option to SEE + INTERACT with the live agent/controller, **read+write, exactly as if the user had launched it standalone** (Claude Code / Codex in a terminal/app) — surfaced through the CE TUI/WebUI/App. **Dev-Mode = this is the DEFAULT** (see all controllers, drive any). So the agent runtime = a **CE-OWNED ATTACHABLE SESSION per agent** (PTY-backed multiplexer, herdr-shaped, **replaces tmux's role**), supporting BOTH (a) read-model emission (structured/multi-seat/contact-on-need — the 95%) AND (b) full interactive ATTACH (read+write, on demand — Dev-Mode default, always available). Read-model + attach = **complementary** surfaces, not either/or. **CE = herdr's function (own attachable agent sessions) on a governance spine.** Governance PRESERVED: the agent's ACTS go through Ring-1 gates regardless of who drives input — user attaches THROUGH CE's audited session, not around it (attach ≠ ungoverned bypass; Dev-Mode confirmation-relaxation is a separate policy knob). → corrects #207: backend = **attach-capable PTY substrate, NOT log-capture-only**.

Related: [[ce-cockpit-frontend-agnostic-core]] [[ce-journey-cockpit-vision]] [[ce-energy-efficiency-ceo-mode-gravity]] [[openshell-nemoclaw-stack]] [[ce-substrate-acp-decision]] [[ce-every-agent-containerized-direction]].

## Detail (moved from index 2026-07-05)
- ratify+audit=default; 80/15/5 strangeLoop/CEO/Dev. Related: [[ce-journey-cockpit-vision]] [[ce-mode-gated-operator-peek]]
- user-chosen TUI/WebUI/App+Discord/Slack; watch=opt-in.
