---
name: ce-shared-app-published
description: "The shared CE GitHub App for self-serve onboarding is published; slug, config, and PEM custody location."
metadata: 
  node_type: memory
  type: project
  originSessionId: f190d01e-2101-407f-aefa-f1b25ff3c3cb
---

2026-06-20: the **shared CE GitHub App is PUBLISHED + verified live** — this unblocks self-serve test-user onboarding (the installer's shared 1-click path no longer 404s).

- **Distinct from per-agent Apps:** this slug-`creator-engine` App is the self-serve ONBOARDING/install VEHICLE (`creator-engine[bot]`), NOT a governed agent's runtime identity. Each governed agent has its OWN `ce-forge-<name>` App ([[ce-github-identity-model]]). Neither Arad nor Nitzan was/will-be onboarded through this self-serve App (Arad = direct-mint on Mythos; Nitzan = her own `ce-forge-Nitzan` App). Don't conflate "the shared creator-engine App" (onboarding) with the per-agent forge Apps (identity).
- **Slug = `creator-engine`** (owner: creator-engine org). This is exactly what the installer expects: `SHARED_APP_SLUG = "creator-engine"` in `validators/creator_engine_validator/v3_installer.py:1574`; install URL `https://github.com/apps/creator-engine/installations/new`; bot identity `creator-engine[bot]`. If the slug ever changes, update that constant.
- **Perms:** contents / pull_requests / administration / workflows / actions = write; issues = write; metadata = read. Verified via App-JWT `GET /app`.
- **app_id + client_id** (non-secret) saved on CE-DEV-2/DGX: `~/.ce-keys/creator-engine-shared-app.env`.
- **PEM custody = INTERIM tmpfs:** `/dev/shm/ce-shared-app.pem` (mode 600, cedev2). ⚠️ tmpfs is **wiped on reboot** → after any DGX reboot the PEM must be re-placed (Operator has the original; future home = OpenBao [[ce-per-dev-identity-secret-storage]] #113).
- **Scope caveat:** publishing unblocks *install + onboarding* (onboarding repo-config rides the user's bootstrap PAT). **Runtime** App-token minting for EXTERNAL users still needs the egress-broker (ADR-0007 / ce-egress-broker / #153) wired — external users can't hold CE's private key. Fine for a pilot user we mint for directly; the broker is the self-serve-at-scale dependency.
- Determining an App's public/private state from outside is unreliable: `github.com/apps/<slug>` returns 200 for any existing app (public OR private) — NOT a public indicator. The owner's settings view is authoritative. (`ce-forge-dev4` is NOT public despite a 200 About page — verified false-positive 2026-06-20.)

## Detail (moved from index 2026-07-05)
- ce-keys/creator-engine-shared-app.env.
- PEM on /dev/shm (re-place after reboot); config ~/.
