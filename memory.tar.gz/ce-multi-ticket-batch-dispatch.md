---
name: ce-multi-ticket-batch-dispatch
description: "Codex seats are NOT single-ticketed — each runs SEVERAL file-disjoint tickets concurrently via codex worktrees + background subagent-threads. Controller routes safe (non-overlapping) BATCHES, not one ticket. Disjointness checked vs other seats AND in-flight PRs; probe main that a ticket isn't already resolved before dispatching."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 72817e73-31ba-4def-afac-1749f7c332b8
---

**Operator directive 2026-06-26:** "we're not using codex's built-in threads and worktrees — each codex seat/controller can tackle multiple tickets simultaneously. A controller shouldn't be tasked with just one ticket; it should drive several concurrently. Your job (until the relief work lands) is to divert the tickets for each controller that are safe to be worked on concurrently." Refs: developers.openai.com/codex/app/worktrees, /app/automations#thread-automations, /codex/prompting#threads.

**Codex CLI concurrency mechanics (for headless herdr-driven seats):**
- A *thread* = one session (prompt history + tool calls + outputs). Codex spins up background subagent threads ONLY when explicitly asked: e.g. "Create a separate background thread in a worktree to do ticket X."
- Each spawned subagent runs in its own **git worktree/branch** → concurrent threads can't corrupt shared files. Manage via `/agent` (inspect/switch), `/new` (fresh thread), `/ps` (view background), `/stop`. Subagent roles in `config.toml [agents]`.
- The hard constraint (from the prompting guide): **"avoid two threads modifying the same files."** Concurrency is safe ONLY across file-DISJOINT tickets.

**How to apply (controller dispatch):**
1. **Route a BATCH of file-disjoint tickets per seat**, not one. Packet = born-a-foreman header + N embedded ticket problem-statements + `git worktree add ../wt-ceN -b ceN-... origin/main` per ticket + "spawn a background subagent-thread in its own worktree per ticket; if two need a shared file, serialize them." Report PER-TICKET. (Validated live: dev-1 created 3 isolated worktrees + background terminals from one batch packet.)
2. **Partition for disjointness** — pick tickets in different files/subsystems. Check collisions BOTH across concurrent seats AND vs **in-flight open PRs** (lived miss: dispatched #177 drift-CI while its own #166 slice-2 (#515) was un-merged → both touched `.ce/brain/assertions.yaml`+`ce_brain_drift.py` → harvest conflict). The fix folds the rebase-resolution back to the authoring seat.
3. **PROBE current main before dispatching** — an OPEN ticket may already be RESOLVED by a merged PR (open ≠ unresolved; tickets don't always auto-close). Lived miss: dispatched #239 (wall→OpenBao supplier) but it was already done via merged #446 — wasted a dev-4 cycle. `git show origin/main:<file> | grep <deliverable>` before assigning. [[ce-knowledge-ssot]] (probe, don't remember).

Pairs with [[ce-merge-mechanics-off-frontier-model]] (mechanics off Opus) and [[ce-dispatch-ordering-discipline]] (manifest-intersection). Endgame still [[ce-integrator-merge-mechanics-agent]] (#216) running in the contained controller once the egress chain lands (#242).

## Detail (moved from index 2026-07-05)
- route disjoint BATCHES; PROBE main that a ticket isn't already resolved first.
- concurrently via worktrees+subagent-threads.
- SEVERAL file-disjoint tickets.
