---
name: ce-cockpit-resource-envelope-routing
description: Major Cockpit-B / metering design input — subscription-limit estimation + governed multi-provider routing (the 99.9% solo-dev case); read when composing Cockpit-B / the D-cluster meter / CEO-mode routing
metadata: 
  node_type: memory
  type: project
  originSessionId: 6b29107e-2c6b-43ea-a171-285dfeca1298
---

**Operator-shaped design input (2026-06-09)** — durable design-of-record at `~/Documents/ce-cockpit-b-resource-envelope-routing-design-20260609.md` (instance-local per the §3 storage policy). The headline product insight for Cockpit-B / metering:

- **~99.9% of solo devs / small teams use SUBSCRIPTIONS, not API keys** → their constraint is a *ceiling* (weekly/rate limits), not a bill. Subscription resource-management is CE's **primary** metering case; $-metering is the minority surface. Operator market call: the solo-dev segment explodes + overtakes traditional software-company market.
- **No standardized cross-provider subscription-usage API exists — BY DESIGN** (labs differentiate personal vs professional). So a CE capability here is a **durable moat**, not a stopgap. CE does the heavy lifting: **ESTIMATE** current + remaining usage vs limits.
- **Honesty discipline (two epistemic tiers):** API usage = MEASURED; subscription usage = ESTIMATED (very accurate but still estimates → labelled, advisory-enforced not hard-blocked).
- **Why CE can estimate accurately:** it owns the agent processes → measures its own throughput precisely (`usage_tap`), maps it onto each provider's known limit-structure model, calibrated by any ground-truth the harness surfaces (e.g. the Claude "78% weekly · resets 2am" status line).
- **Architecture:** generalize spend-gate → a **resource envelope** (pluggable units: `$` / `% of subscription limit` / `rate`); Cockpit meter = multi-provider headroom (not a $ ticker); **governed routing advisor** = risk-tiered + ratified policy (simple→cheaper/other-provider, complex→best; agents NEVER self-downgrade — grader-outside). Our [[ce-codex-controller-budget-offload]] decision is the manual prototype.
- **Pitch reframe:** product story leads with throughput + limit-headroom (the 99.9%); $-equivalent stays the NVIDIA inference-demand lens.

**Why:** this is as load-bearing for Cockpit-B as the competitive synthesis, and it's dogfood-proven (we shifted work Claude→GPT on hitting our weekly cap). **How to apply:** cite the design doc in the Cockpit-B architect mandate (alongside [[ce-competitive-cockpit-b-inputs]]); the §6 "cross-provider subscription-usage estimation" research is a scoped future delegated task in the dev arc. Twin of [[ce-codex-controller-budget-offload]]; feeds [[ce-nvidia-v35-strategy]].

## Detail (moved from index 2026-07-05)
- Related: [[ce-g5-cost-enforcement-optout]] [[ce-competitive-cockpit-b-inputs]]
- spend-gate→envelope.
- BSCRIPTIONS manage limits not $.
