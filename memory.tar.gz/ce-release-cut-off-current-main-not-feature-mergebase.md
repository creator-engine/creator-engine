---
name: ce-release-cut-off-current-main-not-feature-mergebase
description: Release branches must be cut off CURRENT origin/main; a feature-merge-base cut silently ships stale wheels — verify before signing.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9cc9934a-6a57-49e0-b6fd-bf167a20994b
---

A release branch (e.g. `ce-release-0.3.1`) MUST be cut off **current `origin/main` HEAD**, the same way 0.3.0 PR #603 was (`base=main`). Twice in one block a release worker cut off the *retirement merge-base* `dd629ec1a` (#674) instead — that tree predated #678 (test-coupling gate) and #680 (artifacts fix), so the built wheels and CHANGELOG silently OMITTED that merged code. A 3-way merge wouldn't textually revert the files, so the defect hides: the danger is the **signed release wheels are built from a stale source tree** missing merged PRs.

**Why:** the signed release channel (Arad/pilot) must reflect ALL merged work up to the cut. Stale-base = users install a release missing features that are "on main".

**How to apply:** Before signing ANY release, run `git merge-base --is-ancestor <latest-key-feature-sha> origin/<release-branch> && echo CONTAINS` — it must pass. Also `unzip -l` the built CE wheel and grep for the newest feature's source file (e.g. `checks/test_coupling.py`). Bake this into the release brief as a mandatory pre-report check ("CONTAINS-<sha>" gate). Don't trust a GREEN preflight — preflight passed on the stale branch because base..head was internally consistent. Related: [[ce-run-full-preflight-before-push]] two-strikes doctrine, [[ce-release-spec-signing-procedure]].

## Detail (moved from index 2026-07-05)
- verify `merge-base --is-ancestor <feat-sha> branch` + unzip-grep wheel before signing.
