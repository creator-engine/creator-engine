---
name: ce-contained-self-push-proven
description: Contained-seat self-push IS solved + proven (GATE β chain);
metadata: 
  node_type: memory
  type: project
  originSessionId: eefacbda-f105-407b-b54b-8b164d415263
---

Contained-seat self-push via the egress/cred-injection broker is **solved and proven from-seat** — NOT an open capability question. Stop re-deriving "#337 = self-push doesn't work."

**Proof chain (GATE β):** #266/#267/#268 (vault wiring) → #281/#282 (per-policy signature + socket reachability) → #287 (from-seat canary) → #290; **#548** proven from-seat push (vault-sourced, key-never-on-disk, containment intact, clean recovery after restart); **#567** a real dev-3 self-push PR (merged 2026-06-27 08:25Z, author `ce-forge-dev-3`). dev-3 is **on par**.

**Mechanism (ADR-0007 egress broker):** host-side Unix-socket daemon `tools/egress-broker/ce_egress_self_push_broker.py` at `/run/ce-egress-broker.sock`. Seat sends JSON `{seat_id,branch}` via `socket.connect(CE_EGRESS_BROKER_SOCKET)`; host mints a least-privilege App token, pushes, opens PR, revokes — **token never enters the container**.

**#337 is TWO separate things mislabeled as one "self-push gap" — neither is a dev-3 capability gap:**
1. **dev-4 (DGX `ce-dgx-codex`) has NO broker deployed** — verified 2026-06-28: no `/run/ce-egress*` socket, no broker env/service on DGX host or container. Broker `config.py` SUPPORTS dev-1/2/3/4 but was only DEPLOYED for dev-3 on the VPS (#265). So dev-4 genuinely cannot self-push yet → harvest is its ONLY path until the broker is deployed to the DGX.
2. **dev-3 (VPS) usage-reflex gap** — there is **no transparent git-credential-helper** (`credential.helper` unset, no `git-credential-ce-egress`, `.git/config` plain https). The proven path is an EXPLICIT broker-socket call; a seat that reflexively runs `git push` falls through to unauthenticated HTTPS → `gh auth: not logged in` (the #337 symptom). dev-3 CAN self-push; it falls back when not driving the broker.

**My night-arc process error (own it):** briefs `brief-ce336/ce327` said "self-push when green; if push FAILS → STOP + READY-FOR-HARVEST (#337)" — but did NOT embed the broker push command AND offered an easy harvest escape-hatch. Result: dev-3/#336 (broker up the whole time) was couriered AVOIDABLY; dev-4/#327 harvest was necessary (no broker); dev-1/#334 self-pushed fine (own creds). FIX: equip the proven broker as the seat's reflex; stop putting harvest escape-hatches in dev-3 briefs.

**Two real fixes:** (1) **seat push reflex = a `ce push` SUBCOMMAND** in `ce_cli.py` + thin socket client (`egress_push_client.py`) that sends `{seat_id,branch}` to `$CE_EGRESS_BROKER_SOCKET` + AGENTS.md doc — NOT a git-credential-helper (broker is deliberately CREDENTIAL-FREE — never returns a token to the container, so a credential helper is architecturally impossible). Work-class story, controller-dispatchable, NO live-deploy. Equips ALL contained seats (dev-3 AND dev-4) to drive the broker instead of naive `git push`. (2) **deploy broker to dev-4/DGX** — repo wiring ALREADY done (launcher socket-mount, service unit, dev-4 App identity app_id 4085526/install_id 141102698 in registry); only RUNTIME host state missing → Operator-ratified: R1 `/etc/docker/daemon.json` add `--host-uds=open`+reload (hard blocker, = VPS #286), R2 vault key `ce-kv/forge/dev-4` → PEM `/dev/shm/ce-dev4/` (registry TODO_VERIFY — the real unknown), R3 `~/.ce-egress/broker.json`+env+`systemctl enable` broker. ~same-day once ratified + key confirmed. dev-4 broker deploy is the real prerequisite for the "switch whole fleet to self-push" offer.

Self-push is **not** a blocker for onboarding. Relates to [[ce-fleet-deployment-surfaces]] (merged≠deployed), [[verify-vendor-capability-vs-our-wiring]] (capability ≠ our-wiring), [[ce-transport-deputy-tooling]], [[ce-three-deputy-governance-model]].
