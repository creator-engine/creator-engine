---
name: ce-dev2-vps-migration-bundle
description: EMERGENCY 2026-07-09 — full ce-dev-2 controller identity bundle shipped to VPS at ~/ce-dev2-controller-migration-20260709; hashes verified; secrets excluded
metadata: 
  node_type: memory
  type: project
  originSessionId: c2ab6f1e-56de-4553-a526-de2839a2a739
---

2026-07-09 ~17:40 UTC, after the SECOND DGX incident of the day (dev-4 exited(255) 17:28, /tmp launcher-toml wiped again), the Operator ordered immediate migration of the ce-dev-2 controller to the VPS.

**Bundle location (VPS/dev1, host ce-pilot-1): `~/ce-dev2-controller-migration-20260709/`** — extracted and hash-verified (MEMORY.md + STRANGELOOP1F checkpoint sha256 match DGX source; 343 memory files, 354 state files, denylist audit 0 hits).

Contents: full memory dir · .ce/{state,briefs,claims,envelopes} · .claude/agents (incl. uncommitted role edits) · `local-branches.bundle` (481 local branches not on origin, incl. killed workers' partial branches) · main-worktree patch/status · per-agent-worktree WIP patches · `BOOTSTRAP_README.md` (read order + first acts) · `RESUME_STATE_CE_DEV2_STRANGELOOP1F_EMERGENCY_20260709.md` (live board at cut).

**Why:** [[ce-controller-parity-iac-ssot-doctrine]] executing live — this is the manual v0 of what ce-497 (state-sync tool, unharvested at cut) will automate.

**How to apply:** A new controller on the VPS starts from BOOTSTRAP_README.md there. Secrets did NOT travel — Operator provisions creds on the new host. Session infra (cron/watchers) must be recreated. The four dead worker mandates re-dispatch fresh per STRANGELOOP1F. Keep this bundle until superseded by a landed ce-497 sync pipeline.
