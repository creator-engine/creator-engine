---
name: ce-dont-self-throttle-on-quota
description: "Don't preemptively hold work to avoid hitting codex/quota limits — push on and let the hard limit stop you"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: cb9529a3-0334-40ee-9ca9-b0f0434abc87
---

Operator directive 2026-06-21 (correcting night-shift arc ce-ops#161 behavior): when the shared codex pool runs low, **do NOT self-throttle / hold queued waves to conserve quota.** Keep dispatching and pushing the arc forward; if anything, push on and get *stopped by actually hitting the limit* — don't stop yourself in anticipation of it.

**Why:** preemptive metering left ~8 waves idle for hours with seats sitting at 4–8% weekly and nothing in flight — wasted throughput. The Operator would rather extract all available capacity (and upgrade x20 when the wall is truly hit) than have the controller bank quota. The limit is a real backstop; let it be the stopping point.

**How to apply:** at low quota, still dispatch the next waves to idle seats. Surface the quota state (notify once per [[ce-codex-shared-account-subscription]] wall) but keep working through it. A seat erroring on a hard limit = the correct stop signal, caught by monitoring — not a reason to hold beforehand. This narrows [[ce-model-effort-routing-policy]] token-efficiency: efficiency ≠ idling capacity. Distinct from real gates (binding-architecture nods, [[ce-awaiting-operator-queue-rule]]) which DO hold.

## Detail (moved from index 2026-07-05)
- Related: [[ce-codex-controller-budget-offload]]
- let the HARD limit stop a seat; surface once.
