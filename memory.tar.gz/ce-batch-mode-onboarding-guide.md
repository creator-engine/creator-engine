---
name: ce-batch-mode-onboarding-guide
description: Location of the canonical CE batch strict-mode onboarding guide for new Controllers
metadata: 
  node_type: memory
  type: reference
  originSessionId: 90312fe4-f8d6-4559-85de-2a95428731b8
---

The Operator-requested onboarding guide for the CE **batch strict-mode** cadence lives at
`/home/nefarious/Documents/cebatchmode.md` (outside the repo, so it survives across feature branches).

It is the single source new CE Claude Code Controllers read to execute a ratified gate end-to-end:
roles (Operator = sole ratifier; orchestrating Controller = ungoverned; seated peer; reviewer venue),
the SELECT→COMPOSE→RATIFY→EXECUTE→REVIEW→MERGE loop (three Operator ratifications), the canonical
ratification line + §0 SHA self-check, the §0–§13 prompt skeleton, PCO driver-worktree allocation +
manifest SHA canonicalization, the independent-reviewer-venue seam recipe, merge/audit/C-merge
closeout, real-green=pytest + wheel rules, and the HALT conditions.

Consolidates the operational substance of [[batch-strict-mode-gate-workflow]],
[[independent-reviewer-venue-rule]], [[ce-reviewer-token-and-merge-mechanics]],
[[v2-gate-validation-and-lane-execution]], and [[ce-controller-launch-method]]. Keep it in sync when
seam/ledger/branch-protection mechanics change.
