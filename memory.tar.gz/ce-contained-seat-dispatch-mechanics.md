---
name: ce-contained-seat-dispatch-mechanics
description: "Concrete env gotchas when dispatching/harvesting contained codex seats (ce-dgx-codex, ce-vps-codex): worktree path, venv invocation, brief delivery, branch base"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: dd146cd2-c96c-49bc-a20b-797098491dc6
---

When briefing contained codex seats (dev-4=`ce-dgx-codex` DGX-local, dev-3=`ce-vps-codex` VPS), bake these in — each bit me on 2026-06-30:

**Why:** my briefs assumed one seat's local conventions apply to all; they don't, and a wrong assumption silently stalls a seat for 40+ min.

**How to apply (put these IN every contained-seat brief):**
- **Worktree path:** create in a WRITABLE dir — `/var/tmp/wt-<slug>` (world-writable, sticky). NOT `/workspace/...` (root-owned, `Permission denied`) and NOT relying on the repo dir. dev-4's foreman auto-adapts to /var/tmp; dev-3's does not — so be explicit.
- **Branch base:** `git worktree add -b <branch> /var/tmp/wt-<slug> origin/main` — branch off `origin/main` (the REF), NOT local `main` (local main lags; e.g. dev-4 local main was #652 while origin/main was current). Tell the seat to STOP if `origin/main` ≠ the expected sha.
- **Preflight / venv:** the seat `.venv` is a **uv venv with NO `bin/activate` script**. Do NOT `source .venv/bin/activate`. Invoke the venv python directly: `TMPDIR=/var/tmp PYTHONPATH=./validators /workspace/creator-engine/.venv/bin/python -m pytest -p no:cacheprovider ./validators/tests/ -q`. (system python3=3.11.2 lacks pytest; the .venv python has it.)
- **aarch64 false-positives:** `test_install_sh_uv_*` (x86_64-hardcoded) + stale-checkout REPO_ROOT tests fail on these aarch64 seats — tell the seat to ignore ONLY those and confirm no NEW failures. [[ce-dev2-dgx-py314-venv]]
- **Brief delivery (host→container):** `cat brief | sudo docker exec -i <container> bash -lc 'cat > /var/tmp/<file>'` then verify sha both sides. `docker cp` to /tmp does NOT reach the codex view (mount mismatch); /workspace is not writable by the exec uid (1002). For VPS seat prefix with `ssh dev1 '…'`.
- **Origin refresh (no-egress seats):** if a seat's `origin/main` ref is stale, deliver a bundle (`git bundle create … refs/remotes/origin/main ^<old>`) → docker-exec into /var/tmp → `git fetch <bundle> 'refs/remotes/origin/main:refs/remotes/origin/main'` → verify rev-parse. [[ce-harvest-contained-seat-stale-origin]]
- **Dispatch landing:** herdr `agent send w1:p1 "<ptr>"` then `pane send-keys w1:p1 Enter`; confirm a `Working` indicator. [[ce-herdr-dispatch-landing-misread]]
- **⚠️ herdr transport (verified 2026-07-08):** `herdr` is NOT on the host PATH and there is NO tmux inside the containers. The ONLY drive/read primitive is herdr INSIDE the container image, with the socket env passed at exec time: `sudo docker exec -e HERDR_SOCKET_PATH=/run/creator-engine/herdr/herdr.sock <container> herdr agent send w1:p1 "<ptr>"` (VPS seat: prefix `ssh dev1 '…'`). Read: same wrapper + `herdr pane read w1:p1 --source recent --lines 30`. Bare `herdr …` on the host and `docker exec <container> tmux …` BOTH fail — a session-hook memory carried the bare form; this wrapper form is the correction.

## Detail (moved from index 2026-07-05)
- venv/bin/python -m pytest`; deliver via docker-exec tee to /var/tmp.
- venv has NO activate.

**⚠️ Shell-substitution mangling in pane messages (2026-07-10):** backticks or `$( )` inside a
message passed through `ssh "... herdr pane send-text w1:p1 \"$msg\""` get COMMAND-SUBSTITUTED by
the shell before delivery — the pane receives the message with that section replaced by the
command's output/empty (observed: a gate-check command silently vanished from a dev-4 nudge,
plus a stray `fatal: not a git repository` locally). Rule: never put backticks/$() in pane
messages; single-quote the message through every hop, or reference the brief file instead of
inlining commands. Signal-monitor corollary: pane text ECHOES brief content, so signal watchers
must anchor on the terminal-output bullet prefix (`^\s*• (READY|READY-FOR-HARVEST|BLOCKED) ce-`),
not bare READY/BLOCKED greps — brief echoes false-fire otherwise (3 false signals on 2026-07-10).

**⏫ Post-relaunch PATH gotcha (2026-07-10):** a recreated seat container loses whatever PATH
wiring made bare `ce` resolve — the repo venv survives (bind-mounted) but briefs must invoke it
ABSOLUTELY: `/workspace/creator-engine/.venv/bin/ce validate-pr --profile contained-seat`.
Bare `ce` in a brief = BLOCKED(env) round-trip after every relaunch. Durable fix belongs in the
launcher env (PATH additive), tracked with the seat-env-integrity scope.
