---
name: ce-dev4-rebuild-and-launch-canon
description: "How to rebuild + relaunch the dev-4 DGX contained codex seat (canonical launch command, per-arch base-digest gotcha, codex update path) — learned the hard way 2026-06-30."
metadata: 
  node_type: memory
  type: reference
  originSessionId: 9cc9934a-6a57-49e0-b6fd-bf167a20994b
---

**dev-4 = contained codex seat `ce-dgx-codex` on the DGX.** Rebuilding/relaunching it has several non-obvious requirements (each cost a failed attempt 2026-06-30):

**Canonical LAUNCH (from cedev4's own checkout, as cedev4 — NOT cedev2/root):**
```
sudo -u cedev4 -i bash -lc 'cd /home/cedev4/ce-workspaces/creator-engine && \
  CE_DGX_IMAGE=creator-engine/codex-runsc:<ver>-aarch64 \
  CE_DGX_CODEX_HOME=/home/cedev4/.codex-contained \
  CE_DGX_REPO=/home/cedev4/ce-workspaces/creator-engine \
  CE_DGX_CODEX_BIN=/home/cedev4/.codex/packages/standalone/current/bin/codex \
  ./deploy/dgx-runsc/run-codex-runsc.sh --detach tui --dangerously-bypass-approvals-and-sandbox -m gpt-5.5 -c model_reasoning_effort=high'
```
- **cedev4 = UID 1002** (not the Dockerfile default 1000, not cedev2's 1003). Container runs as 1002.
- **cedev4 has its OWN repo checkout** at `/home/cedev4/ce-workspaces/creator-engine`. The contained codex home is **`/home/cedev4/.codex-contained`** (NOT `.codex`).
- **MUST launch as cedev4**, not root/cedev2: as root the entrypoint can't chmod `/var/log/ce-seat` (Operation not permitted → container exits 1); as cedev2 the preflight can't read cedev4's home. (`ce launch` is the CLAUDE-controller launcher, NOT this seat's launcher.)
- ⚠️ **Always pass `CE_DGX_IMAGE` explicitly:** the launcher's default image is read from `run-codex-runsc.sh` in WHATEVER CHECKOUT BRANCH you launch from. On `origin/main` #687 already set it to `0.142.4-aarch64`, but stale branches (e.g. `ce-release-0.3.1-rc2`, which the DGX cedev2 checkout sits on) still have `0.141.0-aarch64` (broken: no ssh-keygen/PyNaCl) → relaunching from a stale checkout silently brings dev-4 up broken. Confirmed 2026-06-30 (first relaunch picked 0.141.0 from the rc2-branch script; re-did with explicit `CE_DGX_IMAGE=creator-engine/codex-runsc:0.142.4-aarch64`). Durable gap = the DGX launcher's `CE_DGX_IMAGE` has NO `surfaces_manifest` CI guard (the VPS `CE_VPS_IMAGE` does) → **ce-ops#380**. Safe rule: always set `CE_DGX_IMAGE` explicitly.
- Recover the exact command from `sudo grep run-codex-runsc /home/cedev4/.bash_history`.

**REBUILD the image:** `deploy/dgx-runsc/build-image.sh` (hermetic, pinned via `surfaces/render.py build-args`). Build with `CE_DGX_USER=cedev4 CE_DGX_UID=1002 CE_DGX_GID=1002`.
- ⚠️ **Per-arch base-digest gotcha:** `surfaces/manifest.yaml` pins ONE digest per base image, currently the **amd64** digests for debian/rust. The DGX is **aarch64** → `exec /bin/sh: exec format error`. Override `DEBIAN_COMMIT_OR_DIGEST` + `RUST_COMMIT_OR_DIGEST` to the **arm64** digests of the same tags (get via `docker buildx imagetools inspect <tag>`). Proper fix = ce-ops#377 (per-arch digests in the manifest). [[ce-govern-rented-surface-updates]]

**UPDATE codex version (rented surface):** the seat mounts the host standalone at `/home/cedev4/.codex/packages/standalone/current/bin/codex`. Bump it host-side: `sudo -u cedev4 -i codex update` (codex's own updater → latest → installs to `releases/<ver>-aarch64-unknown-linux-musl`, repoints `current`). This is HOST-side (governed), not a contained-seat self-update. Then RESTART the container to pick up the new mount. Image tag + `surfaces/manifest.yaml` codex version + deployed standalone must all match.

**The packages that were missing (fixed 2026-06-30):** the image lacked `openssh-client` (→ no `ssh-keygen`) and `PyNaCl` (→ `import nacl` failed). Both added to `deploy/dgx-runsc/Dockerfile`. [[ce-contained-seats-have-git-egress]]

## Detail (moved from index 2026-07-05)
- codex-contained`, via run-codex-runsc.sh (NOT root/cedev2, NOT `ce launch`). Rebuild needs arm64 base-digest override (manifest pins amd64 → exec-format-error on DGX; ce-ops#377). codex bump = host-side `sudo -u cedev4 codex update` + restart. After relaunch, codex needs RE-AUTH.
- never root/cedev2.
- as cedev4 (UID 1002) via own checkout.
- ⚠️ **Container re-creation WIPES /var/tmp worktrees** (confirmed 2026-07-07 relaunch: all
  worktrees + brief files gone despite a pre-stop "intact" check — they lived in the old
  container's writable layer). ALWAYS `git bundle` every unpushed branch and exec-cat the
  bundles to durable host storage BEFORE `docker rm`; restore by streaming bundles back in +
  `git fetch <bundle> <branch>:<branch>`.
