---
name: ce-govern-rented-surface-updates
description: Operator directive — CE must have ONE governed mechanism to update every external surface it rents/forks (codex, herdr, gVisor, OpenBao, image base, pip/npm deps); no band-aids, no per-seat ad-hoc updates. A contained seat must NEVER self-update its own toolchain.
metadata:
  node_type: memory
  type: project
  originSessionId: 14a7ac79-079e-4234-95cc-a669e2f773b9
---

**Operator directive 2026-06-26:** "we shouldn't band-aid this. we need a proper mechanism to update every external dependency / 'surface' we rent (e.g. herdr, codex) under CE."

**Trigger:** while monitoring the GATE β canary, a contained dev-3 codex seat surfaced a self-update prompt offering `npm install -g @openai/codex`. Approving that would: mutate the governed seat out-of-band, desync it from the pinned fleet image, risk breaking the herdr-harness wiring, and reach npm from inside containment. We declined.

**Why:** CE rents/forks a stack of external surfaces ([[ce-rent-or-fork-before-reinvent]]) — codex agent binary, herdr (tmux-for-agents fork), gVisor/runsc, OpenBao, the codex-runsc base image, Python (PyYAML/jsonschema/Textual) + npm deps. There is no unified governed update path, so ad-hoc per-seat updates are possible. That is the run-from-source patchwork the fleet-retirement program exists to kill ([[ce-fleet-retirement-clean-install-program]], [[ce-seat-relaunch-canonical-launch-only]]).

**Target capability (the proper mechanism):** one SSOT version manifest pinning EVERY rented surface (version + commit/digest, no floating tags) → update detection (poll upstream, surface to controller, never auto-apply) → evaluation gate (changelog + CVE/security + vendor-capability grounding [[verify-vendor-capability-vs-our-wiring]], ratified adoption) → staged canary test (apply bump in isolated build / one seat, run full gate) → CANONICAL fleet rollout (rebuild image + canonical relaunch, never per-seat npm/pip; reproducible/atomic) → rollback (manifest is the single lever). Plus the **refusal-spine rule: a contained seat must be UNABLE to self-update its toolchain** (block the npm/pip self-update path at Ring-1/hook; suppress/deny the update prompt in governed seats). Every surface update = a ratified, audited change.

**Status:** design + ticket breakdown dispatched 2026-06-26 (architect_research). Highest-leverage first step expected = the SSOT version manifest + a pinning CI guard (fail if anything unpinned or running-surface ≠ manifest). Reuse existing CE machinery (_versions SSOT, governance carriers, canonical launch) — do NOT build parallel infra. New ARC, parallel to GATE β / fleet-switch; bring to Operator for ratification before building.

## Detail (moved from index 2026-07-05)
- no band-aids.
- contained seats NEVER self-update toolchain.
- chanism to update every rented surface.
