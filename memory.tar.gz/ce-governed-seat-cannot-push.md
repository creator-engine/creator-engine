---
name: ce-governed-seat-cannot-push
description: "A governed CE Controller seat (§7 posture) is hard-blocked from `git push` — the deploy mechanic has no authority path; pushes/PR-opens need the Operator or a deploy-authorized venue"
metadata: 
  node_type: memory
  type: project
  originSessionId: 198ba48c-f0a2-44ed-a5e3-2ff932fd74d9
---

**Verified 2026-06-08 (v3.5-A.1 gate).** A CE-governed Controller seat running under the §7 governed posture **cannot `git push`** — the CC-G-C PreToolUse hook (`.claude/hooks/ce-pretooluse.sh` → `creator_engine_validator hook-check`) classifies `git push` as the restricted **`deploy`** mechanic (`hook_check.py:188-194`) and **hard-denies it with NO authority path** (posture hard-deny at `hook_check.py:388-408`). *(Line numbers re-verified 2026-06-09 against `ea1eea6`; behavior unchanged.)*

**Why no path:** `_authority_covers` (`hook_check.py:287-301`) returns `True` ONLY for `mechanic == "pr_review"` (with a matching PR number); for every other action — including `deploy` — it falls through to `return False`. The reviewer-authority-envelope system (`reviewer-authority-envelope.schema.yaml`, `REVIEWER_VENUE_AUTHORITY.md`) only ever authorizes **`pr_review`** on one PR. So `git push`, `gh pr merge`, `gh pr comment` are all fail-closed-denied under governed posture, by design — error: *"restricted mechanic (deploy) is denied without a matching ratified reviewer-venue side-effect-authority envelope (G2.007.2)."*

**How pushes/merges actually happen:** by the **Operator** (push/merge from a non-governed shell, or an Operator override — the `REVIEWER_VENUE_AUTHORITY.md` mentions PR #106 "landed once via an Operator override"), OR a distinct seat launched with the right posture/authority. The author Controller produces+verifies the commit and routes to **independent review** ([[independent-reviewer-venue-rule]]); the deploy/merge side effects are performed under separate authority. Do NOT bypass the hook (`--no-verify`, disabling hooks, evading the classifier) — that defeats CE's own dogfooded governance.

**Practical:** when a ratified gate cadence says "→ push → review → Operator merge", a governed author seat reaches green + commits locally, then HANDS the push to the Operator with the head SHA + exact command. Relates to [[ce-reviewer-token-and-merge-mechanics]], [[batch-strict-mode-gate-workflow]].
