---
name: ce-merge-queue-offloads-mechanics
description: "The GitHub merge queue exists to offload merge mechanics from the controller — hold the gate + enqueue; don't run merging as a manual campaign. Prevent content conflicts via dispatch discipline."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2b67ead0-9d4c-41c1-974e-43b059ac1239
---

Operator (2026-06-23): we set up the GitHub merge queue so the controller does NOT do merging mechanics — sequencing, testing against speculative main, and the merge commit are offloaded to GitHub (it merged #369/#364/#365 hands-free). My job = **hold the gate (approve-to-merge) + enqueue**; the queue does the rest.

**The ONE thing no merge queue can do is auto-resolve CONTENT conflicts** — two PRs editing the *same lines* (e.g. `_versions.py`, `docs/install.sh`). GitHub evicts the second with a "conflict" status; it needs a manual rebase before re-entering. That's a git-level reality, not a setup gap.

**Why this is feedback:** I treated a question-for-understanding ("why does #366 show conflicts?") as a work order and launched a multi-worker rebase campaign. Over-reach. The right posture: enqueue approved+green PRs and let the queue work; on a content-conflict eviction, delegate the rebase to the authoring seat / one worker (minimal) — never make merge-mechanics a recurring manual controller job.

**The durable fix is PREVENTION, not faster resolution:** intersect file-manifests before fanning out parallel PRs ([[ce-dispatch-ordering-discipline]], [[ce-check-parallel-tracks]]); serialize or coordinate PRs that touch shared registry/config files — `_versions.py` and `install.sh` are recurring collision points. A per-module registration pattern (vs one `_versions.py`) would let the queue merge new-module PRs in parallel — candidate ticket. Related: [[ce-delegate-merge-conflict-triage]].

## Detail (moved from index 2026-07-05)
- Related: [[ce-merge-queue-strict-antipattern]] [[ce-delegate-merge-conflict-triage]]
- PREVENT content conflicts (intersect manifests).
- let queue sequence/test/merge.
