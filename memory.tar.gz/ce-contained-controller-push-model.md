---
name: ce-contained-controller-push-model
description: "Ratified push/credential model for contained CE controllers — commit-only in sandbox, publish host-side"
metadata: 
  node_type: memory
  type: project
  originSessionId: f43c293c-4148-40a5-874e-4ee7e4372de0
---

RATIFIED (Operator, 2026-06-23, short AND long term): contained CE controllers — and all contained seats — use **model B: commit-only INSIDE the sandbox; push/publish happens host-side via the trusted substrate.** A contained agent NEVER holds push credentials.

**Why (Operator-endorsed framing):** B CENTRALIZES the push credential into ONE auditable chokepoint you can harden and watch; A DISTRIBUTES App keys across every contained controller — the opposite of least-privilege. Containment assumes a seat can be compromised (prompt injection / hostile code); a credential inside the sandbox is inside the blast radius. B keeps ZERO push creds in the box — a compromised contained seat physically cannot push (no cred + confined egress); worst case it writes commits to the bind-mounted repo, which the trusted layer inspects before publishing. Push becomes a gate point (only green/approved, attributed, no force) = grader-outside-the-agent + [[ce-push-deploy-authority]] + [[ce-independent-audit-small-blast-radius]].

**How to apply:**
- Clean-build contained seats with NO push cred in the box: strip the `[shell_environment_policy]` GH_TOKEN/GITHUB_TOKEN injection from the codex home; do NOT mount the git-credential App helper / gitconfig.
- Seats COMMIT into the bind-mounted repo (commits land host-side); the substrate/controller PUSHES.
- NEAR-term: the host-side controller pushes manually (as cedev2 did rescuing #395).
- LONG-term: a minimal, audited substrate PUBLISH-SERVICE backed by the secret/identity broker ([[ce-per-dev-identity-secret-storage]] — OpenBao/SecretIdentityBackend) mints just-in-time, short-lived, scoped, attributed push creds; never resident in a sandbox. Seats commit; substrate publishes AS their identity (preserves the peer-controller authorship model; only cred custody moves to the substrate).
- WATCH: B's real cost is friction + SPOF. If a contained controller feels hamstrung, invest in the publish-service's SPEED (make commit→publish fast + ambient so it FEELS like self-push) — do NOT hand creds back to the box.
