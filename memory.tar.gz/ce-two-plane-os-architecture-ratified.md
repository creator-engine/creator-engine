---
name: ce-two-plane-os-architecture-ratified
description: "RATIFIED 2026-07-04: two-plane OS strategy — portable Python control plane + ONE canonical Linux container runtime plane; container-first for ALL deployment forms; HIGH priority, touches nearly every dev plane"
metadata: 
  node_type: memory
  type: project
  originSessionId: 299ba4fc-879c-4829-b11e-c289c34bde5e
---

**Operator-RATIFIED 2026-07-04 (ce-ops#437, as written, HIGH priority).** CE's OS strategy is two
planes: (1) **control plane** = `ce` CLI/validators/onboarding/brain — portable Python, runs
natively on any host OS, CI-guarded against Linux-isms (no systemd/UDS//run literals); (2)
**runtime plane** = ONE canonical Linux container image (multi-arch, per-arch digest pins per
surfaces/manifest.yaml discipline) — Docker/Podman on Linux, Docker Desktop/Apple containers
(micro-VM tier) on macOS, WSL2 on Windows. Rationale: containment-grade isolation has NO portable
abstraction (kills per-OS builds and magic-stack options); reference class (NanoClaw et al.)
converged on containers-everywhere; Linux is CE's internal preferred env AND docker's native one.

**Why:** the "OS-agnostic Python" promise had de-facto broken exactly where it had to — the
enforcement layer (systemd, UDS, bwrap/Landlock/seccomp/gVisor). Ratification converts the Linux
tie from liability to spec: the tie is to an image CE ships, not to the host.

**How to apply:** container-first for ALL deployment forms — supersedes OQ-1's solo-pilot→
os-native mapping. CE-410 slice-8 production validation sandbox designs ON this runtime image.
[[ce-ops-436]] contained-solo/OneCLI lane rides the same image. **AMENDED 2026-07-04: NO fleet/solo differentiation — fleet daemons/brokers are containers on the
same image too; systemd exits CE architecture ENTIRELY (host bootstrap is outside CE's contract);
exactly ONE privileged launcher component may hold container-runtime API access; deploy/systemd/
= migration legacy.** Implementation slices queued in
ce-ops#437 comments (ADR doc → CI portability guard → containerize gate daemons+brokers w/ compose
topologies → published runtime image). [[ce-whole-fleet-to-containment-ratified]] [[ce-shipped-product-terminal-first]]

## Detail (moved from index 2026-07-05)
- container-first ALL forms; supersedes OQ-1 solo→os-native; systemd=adapter only.
