---
name: ce-dev-speed-priority-week
description: "Operator priority (2026-06-12, week of): CE DEV SPEED = top priority — rank tickets by dev-velocity acceleration (#21-class); NVIDIA-demo-value items deprioritized (meeting far enough off)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a478804b-5c2d-4e77-8543-962deff93534
---

**Operator priority directive (2026-06-12, governing the coming week):** CE development
SPEED is the top priority. Rank work by how much it accelerates dev velocity — #21
(per-PR carriers, killed the merge tax) is the archetype. The NVIDIA meeting (01-Jul) is
far enough off that demo-value items (live cockpit rail, hero art, demo runbook) rank
BELOW velocity items this week.

**Why:** throughput compounds — every velocity gate landed this week multiplies all
remaining pre-pitch work; demo polish doesn't.

**How to apply:** when proposing next work or adjudicating queues, score by
attention-minutes-saved-per-gate × gates-remaining. The standing velocity ledger (from
the #14/#21 live drives): merge head-pin vs concurrent PRs (THE serializer now that
carriers are per-PR) · venue-chain ergonomics trio (unattended mode + token propagation +
envelope materialization = per-review babysitting) · codex drive bridge (Claude-budget
ceiling on seat-hours — ties to [[ce-model-effort-routing-policy]]) · transcript stamping.
[[ce-retirement-run-14-complete]]
