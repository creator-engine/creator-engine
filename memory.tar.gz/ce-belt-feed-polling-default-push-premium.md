---
name: ce-belt-feed-polling-default-push-premium
description: "Belt work-feed = Search-API polling as durable default+fallback; webhook-relay push is an optional future PAID tier, never the baseline"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5183bef7-5a7b-413f-9619-d7da7f7c58c8
---

Operator-ratified 2026-06-21 (belt feed architecture, recorded on ce-ops#182, cross-ref #55):

- **Search-API polling = the DURABLE DEFAULT and universal fallback.** Outbound-only, fine-grained-PAT compatible, self-contained on the user's box. Works for every CE target user — solo/small-team devs with consistent *outbound* internet but no publicly-addressable *inbound* endpoint (laptops behind NAT/CGNAT/corp networks). The CE controller is outbound-only by design and never needs anything to dial in.
- **Real-time push (GitHub App webhooks) = an optional FUTURE premium/enterprise tier, NOT the default and NOT deterministic-wrapper code.** Push to a non-addressable machine is impossible without a CE-operated multi-tenant relay/control-plane (GitHub→relay→controller's outbound-initiated SSE/WebSocket). That central service has real op/security/centralization cost → fits a paid tier (OSS-free-core + premium model), never the baseline of a self-run local-first product.
- **Polling stays the live fallback even if the premium relay ships** — the relay can fail CE- or client-side, so push must degrade to polling. Layering: polling = always-on substrate (correctness/liveness); push = latency accelerator.

**Why it matters:** first articulation of a CE **premium/enterprise paid-tier** model (OSS-style). General principle: any "push"/real-time/centralized convenience that requires CE to operate central infra is a candidate paid tier layered on a self-contained free default — and must degrade to the free default on failure. Ties [[ce-no-pr-awaits-reviewer]]'s belt context, [[ce-positioning-ease-not-governance]] (self-run/local-first), [[ce-nvidia-v35-strategy]] (control-plane direction could justify the relay later).

**How to apply:** don't propose central-service designs as defaults; keep the self-contained outbound-only path as the baseline + fallback; surface central-service convenience as an explicit optional tier.
## Detail (moved from index 2026-07-05)
- webhook push = future premium, must degrade to polling.
- ing = durable default+fallback.
