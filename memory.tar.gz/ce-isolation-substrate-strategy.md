---
name: ce-isolation-substrate-strategy
description: "OpenShell A.2b is the PRIORITY isolation-execute gate (#82); gVisor/container RETAINED (not dropped) for Claude-subscription seats per Anthropic's ACP-over-OAuth ban (#83)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 7520a031-5b7e-497e-b56f-0427b09ba70a
---

CE's isolation backends (`RunnerBackend` keys: `noop` / `gvisor-proxy` / `openshell`) are **translate-only today** — the orchestrator runs the inert `LocalNoopBackend`; no execute path is wired (gVisor's `runsc_argv` is "illustrative"; "no proxy primitive"). OpenShell is furthest along: A.2a registered + wired a live `SandboxClient` + the `CreateSandbox→Exec→Watch→Delete` lifecycle; **A.2b (live run) is the PRIORITY execute gate = ce-ops#82.**

**Substrate strategy (verified 2026-06-14):** OpenShell ORCHESTRATES the agent (gateway/supervisor, ACP-style), so it serves **Codex-subscription + any-API-key + the NVIDIA arc** — but NOT **Claude-subscription** seats. Anthropic BANS Claude Free/Pro/Max subscription OAuth in third-party tools / the Agent SDK, **actively blocked since 2026-04-04 12:00 PT** (stops "spoofing the Claude Code harness"); the ONLY sanctioned Claude-subscription transport is the official Claude Code **subprocess + CC-hooks / stream-json** (never ACP / third-party harness). OpenAI/Codex has NO equivalent ban (codex login + sanctioned access tokens cover automation/CI).

**So gVisor is NOT superseded by OpenShell** — a non-OpenShell substrate (gVisor-proxy rootless, or a container engine à la NanoClaw) is RETAINED to sandbox the Claude-subscription CC-hooks subprocess WITHOUT mediating its LLM auth = **ce-ops#83** (lower priority than #82, but not dropped). This is the ToS-mandated path for a large slice of the non-dev mass market (anyone keeping a Claude Pro/Max sub). Note: gVisor/`runsc` is external (Google's) — CE never "builds gVisor"; it builds the execute ADAPTER + the egress-proxy primitive. Authoritative transport matrix: `docs/architecture/pilot-deployment-transport.md`. [[ce-substrate-acp-decision]] [[openshell-nemoclaw-stack]] [[ce-install-dependency-model]]

## Detail (moved from index 2026-07-05)
- Related: [[ce-contained-codex-needs-yolo-gvisor-is-sandbox]] [[ce-environment-separation-strangeloop-precondition]]
- gVisor/container for Claude-sub seats.
- 2b = priority gate (#82).
