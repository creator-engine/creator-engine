---
name: verify-vendor-capability-vs-our-wiring
description: "Verify external-tool capabilities against CURRENT vendor docs, not our codebase's wiring state — \"we didn't wire X\" ≠ \"vendor lacks X\""
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4d7ce6e3-ba6d-4f97-ae66-1f3e9598f80c
---

A research worker claimed Codex has no synchronous pre-exec hook, reading `codex_launch_spec.py` ("no Ring-1 parity claimed") + `~/.codex` config. The Operator knew Codex has a **GA (May 2026) deny-capable `PreToolUse` hook**; vendor-doc research (developers.openai.com/codex/hooks) confirmed the Operator. The worker conflated **CE's missing wiring** with the **vendor's missing capability** — nearly forcing a wrong architectural conclusion (containment-only) when native codex Ring-1 + managed (non-bypassable) hooks were available.

**Why:** capability ≠ our integration state. A CE-side comment like "no X parity claimed" is evidence of OUR choices, not the vendor's limits.

**How to apply:** any claim that an external tool "can't" do X → ground it in the tool's CURRENT official docs BEFORE concluding (esp. before architectural decisions). Reinforces [[agent-research-discipline]] + [[ce-knowledge-ssot]] (capabilities PROBED not remembered). Also: when a worker returns a strong negative capability verdict sourced from our own repo, treat it as suspect and re-verify against the vendor.

## Detail (moved from index 2026-07-05)
- ground capability claims in CURRENT vendor docs.
