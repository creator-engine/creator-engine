---
name: ce-sdd-feedback-loop-gap
description: "CE shipped the forward SDD loop but NOT spec-kit's reverse/living feedback loop; Operator ratified closing it the ratification-gated way (impact-flagging, no self-mutation)."
metadata: 
  node_type: memory
  type: project
  originSessionId: 9cc9934a-6a57-49e0-b6fd-bf167a20994b
---

**Finding (audit 2026-06-30, grounded in code):** CE implemented the FORWARD half of spec-driven development (spec→plan→envelope→graded build = 'grader outside the agent') but NOT the reverse/living feedback loop spec-kit's spec-driven.md calls the actual transformation. Of the 4 loop claims: production/incidents→specs, requirement-change→flag-affected-plans, change→regenerate = **ABSENT**; specs-stay-at-WHAT-level = **PARTIAL, not machine-enforced** (our own spec.md files contain HOW: Python version, package names). No code path from operational reality back into `specs/`; drift checks (schema/cli autogen-sync, scope state/skin) only FAIL the build and run code→docs; `specs/plan.md` is write-once; the only feedback register = `_traceability_matrix.md` as-built column, hand-authored. Never specced (unexamined omission, NOT a deliberate 'no'); only named seam = `v3_shaping` telemetry-tune loop (narrow, deferred, unmilestoned).

**The key distinction (why the gap is partly an over-reach):** CE rightly rejects spec SELF-MUTATION ([[ce-bake-gaps-into-ce-not-conventions]]; `docs/design/ce-forge-side-automation.md`: proposals = evidence + draft patches only, active only after human ratification). But that doctrine over-reached and ALSO dropped impact-FLAGGING (surfacing which plans/decisions/tests a spec change affects, as a draft for a human to ratify) — which is NOT self-mutation and IS the loop's high-value, ratification-compatible part. **Strategic sting:** this loop IS our own pitch ('grader outside the agent bridges present+future'); we shipped the grader and skipped the loop.

**Operator decision (2026-06-30):** treat as a GAP to close, the doctrine-compatible way — **impact-propagation + flagging, ratification-gated, NO auto-mutation.** Build on the traceability-matrix seam. Production→spec proposals = later phase. Tickets: **ce-ops#375** (design — architect pass dispatched 2026-06-30), plus the docs lane it surfaced (#374 pre-pitch slice, #37 un-deferred full portal, #376 process-hole sweep). [[ce-stage-vocabulary-canon]] [[ce-product-north-star]]

## Detail (moved from index 2026-07-05)
- Doctrine rejects self-MUTATION but over-reached, killing impact-FLAGGING (the ratification-compatible value). Operator: close it gap-style → ce-ops#375 design (architect dispatched). Docs lane: #374/#37/#376.
- but NOT spec-kit's reverse/living loop (audit: claims 1-3 ABSENT, 4 PARTIAL).
