---
name: ce-worker-roles-and-dispatch
description: "CE's 4 canonical worker roles + the governed dispatch runbook a controller must consult before spinning any worker"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 10ed6d19-ae37-4db2-8564-f31b3cf45718
---

CE defines **4 canonical worker roles** (`.claude/agents/`, governed by `specs/005-pco-parallel-controller-orchestration/worker-isolation-runtime.md` §d.2 + ce-ops#244). Controllers MUST NOT improvise roles or broaden boundaries at spawn:

- **architect_research** — read-only research; tools Read/Grep/Glob/WebFetch/WebSearch; model-provider key only, no write tokens.
- **implementer** — build one task in one allocated worktree; tools incl Bash/Edit/Write; per-task scoped PAT only; NO approval/merge authority.
- **verification** — read-only test execution; returns reproducible evidence; no creds by default.
- **reviewer** — read-only review; returns verdict only (APPROVE/REQUEST_CHANGES/COMMENT); no submission authority.

**Dispatch (the runbook to consult BEFORE spinning a worker):**
- `playbooks/controller/briefs/dispatch.md` — brief format (ticket, branch, role, allowed paths, expected evidence, stop line).
- `docs/operations/GOVERNED_LANE_LAUNCH_PROTOCOL.md` §d — full `ce lane launch` arg set (`--controller-id --lane-id --role --prompt --prompt-sha --worktree-path`) + refusal predicates.
- `docs/operations/WORKER_CONTAINER_PROTOCOL.md` — per-role mount/egress/secret defaults.

**Hard constraint:** the controller-key private key NEVER enters any worker container (PCO-045); only the controller signs leases. Contained seats can't read private ce-ops → briefs to them must EMBED ticket content [[ce-no-egress-seat-self-contained-briefs]]. Seats are foremen — stock a QUEUE, don't single-task-assign [[ce-seats-foremen-self-managed-fanout]]. See [[ce-controller-conveyor-intake-directive]].

## Detail (moved from index 2026-07-05)
- consult `playbooks/controller/briefs/dispatch.md` BEFORE spinning a worker; NEVER improvise a role; controller-key never in a worker. architect_research is READ-ONLY → returns brief CONTENT, controller writes the seed-brief file (ce-dispatch skill).
- (architect_research/implementer/verification/reviewer).
