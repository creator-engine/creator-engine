---
name: ce-outgrown-tmux-substrate-redesign
description: "Operator decision (2026-06-12): CE has OUTGROWN tmux — seat/venue substrate redesign happens early next week (by ~2026-06-15/16, ce-ops#35 thread); tonight's seed-Enter swallow = the archetype evidence"
metadata: 
  node_type: memory
  type: project
  originSessionId: a478804b-5c2d-4e77-8543-962deff93534
---

**Operator decision (2026-06-12): CE has outgrown tmux.** tmux was never meant to be the
infrastructure for what CE now does (governed agent-fleet seat/venue orchestration); CE pays
a growing MANAGEMENT-OVERHEAD price for it. The seat/venue substrate REDESIGN happens
**early next week at the latest (~2026-06-15/16)** — the ce-ops#35 thread is the design home
(its lens is already cited throughout the #16 spec).

**The evidence ledger to bring to that design (accumulated from the 2026-06-12 live drives):**
- The archetype: the **seed-Enter swallow** — `tmux send-keys` rc=0 means DELIVERED, not
  SUBMITTED; the TUI input box can drop the Enter, undetectable except by pane-content
  introspection (#16 S8 dogfood caught it; the D5 fix is bounded pane-polling choreography —
  overhead that exists ONLY because of the substrate).
- Pane env inherits from the tmux SERVER, not the launching shell (finding 4 → the D2
  exec-wrap exists to route AROUND tmux env semantics).
- tmux `-e` env injection transits client argv (ps-visible) — rejected D2-b for secrets.
- Readiness/cwd polling choreography (`pane_current_command`, `pane_current_path` settling)
  — D5 + the tmux_adapter cwd-poll both deepen coupling, flagged in-spec per the #35 lens.
- Viewport-vs-scrollback ambiguity (idle-looking prompt while deep in work), capture-pane
  scraping as the only observation channel, marker false-positives from seeded protocol text.
- Pane/session lifecycle races (sessions dying with processes, remain-on-exit autopsies).
- **2026-06-12 THIRD swallow instance (~10:45Z–12:07Z, pane %78):** the codex-BRIDGE gate
  seat's seed-Enter swallowed at dispatch; the 1145Z checkpoint recorded the seat as
  "building" and the orchestrator /cleared — the seat sat idle ~80 min, caught only because
  the resumed session re-inspected the pane instead of trusting the checkpoint. Lesson
  folded into [[ce-v3-g3-program-resume]]: checkpoint "seat live" claims need a liveness
  probe (working indicator / transcript mtime), not seed-delivery rc=0.
- **2026-06-12 second swallow instance, cross-harness:** the F6 codex composer (pane %35)
  sat IDLE ~40 min with the orchestrator's steer visible-but-unsubmitted in its input box
  ("[Pasted Content 1016 chars]") — swallowed Enter on a gpt-5.5/codex TUI, so the failure
  is substrate-level, not harness-specific. Caught only because the post-/clear session
  re-inspected the pane; a marker watcher alone reads a stalled composer as "still working."

**How to apply:** when the redesign fires, these become requirements: launch = submitted
job with ack (not keystrokes); env/credentials = explicit per-seat contract at exec (D2-a
already substrate-portable); observation = structured event stream (not pane scraping);
lifecycle = supervised processes with exit status. The #16 fixes were deliberately shaped
substrate-portable (exec-wrap, absolute refs, session-id stamping) or confined to the ONE
seed seam (`seed_brief`) so the post-tmux substrate replaces one function, not a scatter.
[[ce-compose-claim-lock-rule]] (#38 queue) and the F6/codex-bridge designs should both be
read against this timeline. Twin of [[ce-substrate-acp-decision]].
