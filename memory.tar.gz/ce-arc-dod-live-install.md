---
name: ce-arc-dod-live-install
description: "Operator-redefined arc DoD (2026-06-12) — NVIDIA demo AFTER real pilot users in prod; demo includes LIVE self-serve install by an NVIDIA employee's own coding agent"
metadata: 
  node_type: memory
  type: project
  originSessionId: 71cdf93e-202b-4810-8953-7dfa4c47203d
---

**Operator directive (2026-06-12), amends [[ce-nvidia-v35-strategy]]:** the v3.5 arc's **definition of done** is NOT "demo the self-hosted repo." It is:
1. CE **already in prod with real external test users before the 01-Jul meeting** — solo-devs/small teams (already waiting for access), BOTH greenfield and brownfield projects = proven commercial viability + actual consumer/enterprise use.
2. The NVIDIA demo **includes a live install**: an NVIDIA employee, on their machine, points their own coding agent at creator-engine.dev and performs full install + onboarding, unassisted.

**Why:** Operator clarified earlier ambiguity (took responsibility); "working in prod by us AND by users" is the pitch's proof spine.
**How to apply:** E-lane live-drive (real installer, onboard apply executor, brownfield adoption) = the arc's critical path, outranks B-wave/#45/v8 polish. DoR/DoD proposal: `~/Documents/ce-arc-dor-dod-PROPOSAL-20260612.md`. Multi-harness install rehearsals on clean machines are mandatory pre-demo (the NVIDIA employee's agent is unknown). Twin of [[ce-v35e-onboarding-docs-lane]] (whose "lane DONE" is now superseded — scoped-gates-done ≠ journey-done).

## Detail (moved from index 2026-07-05)
- Related: [[ce-pilot-env-hetzner-vps]] [[ce-vps-install-rehearsal]] [[ce-arad-pilot-onboarding]]
- demo = NVIDIA employee self-serve install via own agent.
