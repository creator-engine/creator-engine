---
name: ce-mandatory-containment-decision
description: 2026-06-18 Operator decision — containment is MANDATORY for every agent incl controller; NO sandbox opt-out
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3d84878f-7476-4bab-8598-c35b8c1edce1
---

**Operator decision 2026-06-18 (ce-ops#115, ADR pending):** CE makes a clear, non-negotiable security architecture choice — **every agent is contained, INCLUDING the controller. There is NO non-sandboxed opt-out.**

**Why:** you cannot deliver a security promise with a sandbox opt-out (an escape hatch makes the guarantee conditional = no guarantee). The opt-out also **wouldn't work in the new enterprise environments** — Microsoft Agent365/Intune block self-hosted/uncontained agents; containment is becoming the *sanctioning* condition. Matches NanoClaw, Microsoft, et al. refusing to compromise on security.

**How to apply / what it reverses:**
- Firms [[ce-every-agent-containerized-direction]] from "direction" → "DECIDED, no opt-out."
- The earlier design framing I gave (sandboxed default + non-sandboxed opt-out) is **WRONG/superseded** — do NOT offer a non-sandboxed option again.
- Supersedes: runtime-policy isolation `off`/`advisory` as a containment escape (containment always `enforce`); **#71** gVisor-backend "opt-IN" → mandatory; non-sandboxed-controller option removed.
- **Explicit carve-out from [[ce-user-choice-architecture]]:** options everywhere EXCEPT the security floor — containment is not a user choice.
- **Substrate still varies by harness** (OpenShell where permitted; gVisor+proxy container for Claude-subscription per ACP-ban ce-ops#83) — but containment itself is always-on, substrate-agnostic.
- **Target = post-tmux runtime** [[ce-post-tmux-direction]] (agent-in-container replaces agent-in-pane); NOT an immediate change to today's host/tmux controllers.
- **LANDED 2026-06-18:** ADR = `ce-ops/decision-records/ADR-0004-mandatory-containment.md` (Accepted). Code reconciliation committed on creator-engine branch `ce115-containment` (suite 3404 green) but **ENFORCEMENT SEQUENCED** — HELD from merge until the waitlist install reliably provisions a contained backend (gVisor/OpenShell) turnkey (tracks dev-4/A.2b + ce-ops#117). Decision in force now; code enforcement lands WITH the turnkey install.
