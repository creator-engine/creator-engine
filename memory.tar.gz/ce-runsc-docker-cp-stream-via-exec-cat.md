---
name: ce-runsc-docker-cp-stream-via-exec-cat
description: docker cp fails to extract files from gVisor/runsc containers (ce-dgx-codex) — stream via docker exec cat > file instead
metadata: 
  node_type: memory
  type: project
  originSessionId: cae4382b-381a-490e-962a-afb1d5769495
---

`sudo docker cp ce-dgx-codex:/var/tmp/<file> <dest>` fails on the gVisor/runsc-sandboxed `ce-dgx-codex` container (deploy/dgx-runsc/*): cp can't find a file that `docker exec ls` sees.

**Why:** runsc's filesystem view isn't exposed to the docker cp differ the way runc's is.

**How to apply:** extract files by streaming through exec stdout: `sudo docker exec ce-dgx-codex cat /var/tmp/<file> > /var/tmp/<file>`. For git bundles, also create a ref-range bundle (`<old>..<branch>`), not a full-history one (160MB vs 7KB on ce-388 round 3). Proven in the ce-388 round-3 harvest (2026-07-02). [[ce-contained-seat-dispatch-mechanics]] [[ce-seat-probe-docker-exec-not-run]]

## Detail (moved from index 2026-07-05)
- bundle as ref-range not full-history.
- (docker cp fails on runsc).
- via `docker exec … cat > file`.
