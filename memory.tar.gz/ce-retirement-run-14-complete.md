---
name: ce-retirement-run-14-complete
description: "2026-06-12: ce-ops#14 retirement run COMPLETE — B.7 merged (#204, 570b20cf) entirely through cev3; 7-finding live-drive ledger → #16; venue zone = linked worktree (standing posture)"
metadata: 
  node_type: memory
  type: project
  originSessionId: a478804b-5c2d-4e77-8543-962deff93534
---

**2026-06-12: the dev-stays-on-v1 RETIREMENT CONDITION is SATISFIED.** PR #204 (Cockpit B.7
fleet cost meter) merged at `570b20cf` with EVERY leg through `cev3` — Scope→ratify→drive→
seat→pr→review→collect→merge→◆report; three identities (App author / `cedev1vps-cmd` envelope
/ Operator ambient); three GREEN chains in `.ce/state/runs/`. PR #205 (G2b venue fixes:
lowercase `rev-` id mint + `--worktree-path`) landed first at `b0edeb73`. Week-1 of the
pitch arc = DONE except #15 (dev-2).

**Why it matters:** this is THE self-host proof + the pitch's centerpiece evidence
(`~/Documents/ce-pitch-evidence-governance-in-action/retirement-run/` — L1–L11 casts +
CE_DEMO both-tiers capture; the run surfaced 7 real defects/gaps, each caught fail-closed,
2 fixed same-day through the governed flow — full ledger in the 🏁 comment on ce-ops#14).

**How to apply:**
- #16 spawn hardening now carries the 7-finding ledger (venue unattended mode · token
  propagation · envelope-ref materialization · `merge --head-override` for amendment heads ·
  live-cockpit `load_chains` must read `<root>/runs/` — that last one blocks the LIVE rail
  demo capture and is a one-line fix).
- Standing host posture: `~/ce-review-venues` is a LINKED WORKTREE (pco requires the venue
  zone to be a non-root checkout) — never convert back to a plain dir.
- cev3 venues run INTERACTIVE — babysit modals; steer identity via the venue sourcing
  `~/.ce-keys/reviewer.env` + `GH_TOKEN`.
- Don't re-run the retirement question — it is CLOSED. [[ce-v3-g3-program-resume]]
  [[ce-cockpit-b-design-ratified]] [[ce-model-effort-routing-policy]]
