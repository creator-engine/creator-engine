---
name: ce-seat-done-not-committed
description: "A seat \"done\" report is NOT proof of a committed artifact — require + verify a commit SHA before trusting completion"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3f9a25b8-879d-4819-b9bd-3847f6b938a9
---

2026-06-24: dev-3 reported #221 "done — 6+23 tests passed, DONE_EXIT=0" but had **never committed**. Its branch sat at `origin/main` (0 commits ahead), the worktree was pruned, and the work was **unrecoverable** (no dangling commit). It validated in the worktree then finished without committing.

**Tell:** the done-report had **no commit SHA**. dev-1's #225 report gave `5f099a0` (real, verifiable); dev-3's #221 gave none. A done-report without a verifiable commit SHA = NOT done.

**Why:** seats run tests in a worktree then can hit DONE_EXIT=0 without ever committing; a pruned/ephemeral worktree then loses the work silently.

**How to apply:**
- Every seat brief MUST end with: `git add -A && git commit -m "…" && git rev-parse HEAD | tee /tmp/<slug>-sha.txt` — and "do NOT report done until that SHA is printed."
- On every "done", VERIFY the commit exists on a ref before trusting it: `git rev-parse --verify <branch>` + `git rev-list --count origin/main..<branch>` > 0 (the push-fork/controller does this; the watcher already polls commit-count for some lanes).
- Verify the ARTIFACT (commit + diff), never the narrative. Adjacent: [[ce-verifier-hash-false-positive]] (reproduce, never transcribe).

## Detail (moved from index 2026-07-05)
- controller verifies the ref.
- briefs must `commit && echo SHA`.
