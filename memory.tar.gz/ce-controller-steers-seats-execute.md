---
name: ce-controller-steers-seats-execute
description: "Operator correction 2026-06-11 — the main Controller session is the Operator↔Controller INTERFACE (plan/coordinate/monitor/dispatch); substantive work goes to launched governed CE seats, never inline"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2bae9844-7348-4cd1-9a89-54226b622914
---

**Operator correction (2026-06-11, after the v7 site arc):** I did the whole website
design/build inline in the main session. Wrong altitude. **The main CE Controller session
(the agent harness in the orchestrator tmux) is the Operator↔Controller interface — alongside
the CE cockpit. It steers and leads: planning, coordinating, monitoring, dispatching. The
actual WORK (design, build, docs, review) belongs in launched CE-governed seats.**

**Why:** governance + independent inspectability of the work itself (a seat runs under its own
envelope/hook with its own transcript), keeps the Controller's context lean for steering, and
makes the work product a first-class governed artifact rather than orchestrator output.

**How to apply:** when a work item arrives (even an "edit this draft" round), compose a mandate
+ launch a governed seat ([[ce-controller-launch-method]] / [[ce-codex-seat-launch-method]] /
[[ce-governed-reviewer-venue-method]]) and steer it; do inline only trivial coordination edits
(memory, resume states, queue/ops bookkeeping, seeding/monitoring seats). Model choice per
[[ce-model-effort-routing-policy]] + [[ce-website-design-claude-only]] for the site lane.
Refines [[ce-delegation-flavor-by-risk]]: the calm-setting "subagent OK" relaxation does not
extend to doing the work in the Controller's own context.
