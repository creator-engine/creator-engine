---
name: ce-codex-seed-large-paste-stall
description: Codex seat dispatch footgun — large multi-line seed paste via send-keys -l can fail to submit; use a short seed-file pointer instead
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9d73b5a5-8838-47f6-9513-e86697828b8b
---

**Footgun (bit twice on 2026-06-18):** `codex-seed-cwd.sh` / `codex-seed.sh` paste the FULL seed text into the codex composer via `tmux send-keys -l "$SEED"` then Enter. For LONG multi-line seeds the paste lands in the input buffer but Enter does NOT submit — it just scrolls through the buffered lines, so the seat sits idle showing the seed with no "• Working" indicator and edits nothing. Looks launched; isn't.

**Why:** large bracketed/multi-line pastes in the codex CLI composer aren't submitted by a trailing Enter the way a short line is.

**How to apply:** after launching a codex seat, VERIFY it shows "• Working / Explored / Read" — not just the echoed seed. If stalled: `C-u` (clear) then send a SHORT single-line pointer that submits cleanly: `Read the file <abs-path-to-seed> and execute its instructions exactly. It is your full task brief. Work only in <worktree>.` Keep the detailed brief in the seed FILE; never rely on the giant paste submitting. Prefer this short-pointer dispatch for all codex seats going forward. See [[ce-check-parallel-tracks]].
