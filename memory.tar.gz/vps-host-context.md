---
name: vps-host-context
description: READ FIRST on CE-DEV-1 — migrated memory corpus, the laptop→VPS path map, what is deliberately ABSENT here, and the .ce-not-.hermes root rule
metadata:
  type: project
---

This claude memory corpus was migrated from the Operator laptop to CE-DEV-1 (ce-pilot-1)
2026-06-11, completed+audited same day (Track-2 team-mode: the VPS is the CE dev execution
host). You are ON CE-DEV-1 when reading this.

**ROOT RULE (Operator directive, applied here):** local CE state root on this host = `.ce/state/`
(gitignored). `.hermes` is SUPERSEDED v1/controller-instance naming — it does NOT exist in this
checkout and must not be re-created; on the LAPTOP canonical it persists (frozen v1 venue).
Resume states live at `~/creator-engine/.ce/state/research/RESUME_STATE_*.md` (newest by mtime
= live program state). `sync-ops.sh` is host-aware of this split.

**PATH MAP (laptop → this host):**
- repo `/home/nefarious/projects/creator-engine-canonical` → `~/creator-engine` (venv `.venv` inside)
- resume states `<repo>/.ce/state/research/` → `~/creator-engine/.ce/state/research/`
- reference corpus `~/Documents/ce-*` → `~/Documents/` (synced, incl. v7 site mock+research+AgentSmithPillsCalm.png)
- ops repo `~/projects/ce-ops` → `~/projects/ce-ops` (cloned 2026-06-11; gh = chmod735, repo scope)
- seat venues: worktrees `~/ce-worktrees/`, launch dirs `~/ce-launch/`, casts `~/*.cast`

**DELIBERATELY ABSENT (laptop-only legs — do NOT improvise around):**
- KEYS: `ce-root-v1` signing key + `creator-engine-forge` App PEM (`~/.ce-keys/` on laptop). Spec re-signing (K3) + App-JWT minting = laptop legs.
- reviewer token `GITHUB_REVIEWR_TOKEN` (`~/.hermes/.env` on laptop, controller-instance file). Reviewer venues fire from the laptop unless the Operator provisions this host.
- This host pushes over its own gh auth ONLY for non-workflow files; `.github/workflows/**` pushes = laptop (token scope).

Host-state memories describing the LAPTOP: [[ce-github-push-https-not-ssh]] [[ce-oom-crash-resume-script-footgun]] [[ce-validator-editable-install]]. This host: gvisor installed (one env-dependent test fails by design, ce-ops#11), governed seats run born-bound via systemd-run scopes, tailnet-only SSH ([[ce-dev1-access-method]]).
**Dual-write is SYMMETRIC since 2026-06-11 (evening):** this host is PRIMARY; mirror back to the
laptop (CE-DEV-2, secondary) with `~/projects/ce-ops/bin/ce-sync-back` after significant memory/
resume-state writes. Transport = Tailscale SSH (ACL action=accept, src=this host only,
dst=ce-dev-2 100.106.203.52, user=nefarious — no identity keys, no public sshd; enabled by the
Operator). The script carries the host-path mapping (laptop keeps the frozen .hermes root).
