---
name: ce-estimate-in-arcs-not-days
description: "Operator calibration 2026-07-10 — all timeline estimates in ARCS at agentic dev pace, never calendar days/weeks; human-pace framing is a reporting defect"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: c2ab6f1e-56de-4553-a526-de2839a2a739
---

Operator correction (2026-07-10), after I gave dark-factory timeline answers in calendar days
("~Jul 12-13", "~2 weeks"): **"we calculate in arcs not days and we calculate in agentic dev
pace not humans."**

**Why:** calendar estimates smuggle in human-team assumptions. The factory's throughput unit is
the arc (one ratified mandate driven to Done-when); a day can hold multiple arcs (2026-07-09:
21 merges through one day spanning two arcs), and an arc's duration compresses as automation
lands — so day-denominated estimates go stale in a way arc-denominated ones don't.

**How to apply:** express every forecast as "N arcs" (optionally with what gates each arc),
e.g. "harvest retirement = 1 arc after dev-4 broker deploy; dispatch retirement = N-1 s2 + 1
arc for N-11". Calendar dates only where an external human milestone genuinely binds (NVIDIA
pitch, T1/T2 certification dates the Operator set). [[ce-agent-paced-estimation]]
