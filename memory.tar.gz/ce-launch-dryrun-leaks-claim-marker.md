---
name: ce-launch-dryrun-leaks-claim-marker
description: ce launch --claim-ticket --dry-run leaves an orphaned work-claim marker that self-blocks the real launch
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e2cf4ccf-fa9b-4239-ad01-0e065000d886
---

`ce launch --claim-ticket <ticket> --dry-run` **acquires and leaves an orphaned work-claim marker** (a `wclaim-…` comment on the ticket) instead of releasing it. The subsequent real `ce launch --claim-ticket` then races its own leftover, loses the re-read, and refuses with `claim:lost_after_reread` / `another claim won the re-read`. Hit 2026-06-16 launching the ce-ops#98 codex host seat.

**Why:** dry-run is "plan only" but the claim-acquire leg still mutates (posts a marker); it isn't rolled back on dry-run exit.

**How to apply:**
- Don't pass `--claim-ticket` on a `--dry-run` you'll immediately follow with a real claimed launch — dry-run the launch plan WITHOUT the claim, then add `--claim-ticket` on the real run.
- If already stuck: `ce claim status <owner/name#N>` to see the holder, then `ce claim release <ticket> --claim-id <wclaim-…> --reason "…"`.
- For a **host-local sysadmin seat** (e.g. CE-DEV-2 host work), the work-claim lock is unnecessary anyway — it exists to prevent parallel repo-gate/compose collisions [[ce-check-parallel-tracks]]; launch unclaimed and reference the ticket in the mandate. Worth filing as a ce launch bug (dry-run should be claim-neutral).
