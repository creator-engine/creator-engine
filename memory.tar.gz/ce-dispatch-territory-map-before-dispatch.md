---
name: ce-dispatch-territory-map-before-dispatch
description: Before dispatching ANY ticket, check its file-scope against the controller's live in-flight file-territory map; never filler-dispatch a seat that is about to be relaunched. A bad dispatch wastes seat tokens AND compounds (the seat foremans its own sub-worker on it).
metadata:
  node_type: memory
  type: feedback
  originSessionId: 14a7ac79-079e-4234-95cc-a669e2f773b9
---

**Operator correction 2026-06-26 (twice, sharp): "stop wasting tokens with dispatches that should never have been dispatched."**

What happened: I dispatched ce-ops#101 (migrate `validate.yml`→`ce-validate.yml`) to the dev-3 canary seat. It was a triple-bad dispatch: (1) it edited `.github/workflows/validate.yml` — the SAME file in-flight #137 was adding a lint step to → guaranteed merge conflict; (2) renaming the required "Validate governance artifacts" check while ~5 PRs drain the gate = high blast radius; (3) the brief used work class `refactor`, which is NOT in the valid set `{tiny|story|feature|epic}` → would fail the work-sizing gate. The dispatch worker checked disjointness only against the file list I gave it — and I had not listed `validate.yml` as #137's territory. Cost compounded: dev-3 (itself a controller) spun up its OWN sub-worker in `wt-ce101` before my stop landed.

**Why: the controller must hold a single LIVE in-flight file-territory map and check EVERY candidate against it BEFORE dispatch.** A planning/dispatch worker only knows the exclusions I hand it; if my exclusion spec is incomplete, the worker's "disjoint" verdict is worthless. Disjointness is the controller's call, grounded in the full map — not delegable on a partial spec.

**How to apply:**
1. Maintain an explicit map: for each in-flight PR/ticket, the exact paths/globs it touches (incl. shared/gate files: `.github/**`, `deploy/systemd/install-gate-daemons-systemd.sh`, `_versions.py`, `install.sh`, any CI workflow). Two PRs editing the SAME shared file = must-serialize even if "conceptually disjoint" (e.g. #267 + #268 both append to the systemd services array → sequence them).
1b. **Two standing OFF-LIMITS categories beyond in-flight collisions (a dispatcher missed both 2026-06-26):** (a) **live grounding files** — `AGENTS.md`, `~/.codex/AGENTS.md`, `.claude/agents/**`, `CLAUDE.md` — editing them can de-ground RUNNING seats and overlaps the parked #244 SSOT-injection scope; reserve them. (b) **signed artifacts** — `docs/llms-install.md` (detached SSHSIG) and anything carrying a signature — editing breaks the signature and a CONTAINED seat cannot re-sign (only the controller holds ce-root-v1); never put a signed-artifact edit in a contained seat's envelope. Always state BOTH categories in the dispatcher's exclusion list, and VET the dispatcher's picks against the map right after it reports (it may still violate an exclusion you handed it — caught #91→AGENTS.md and #81→llms-install.md only on post-dispatch review).
2. Before any dispatch, intersect the candidate's scope with the WHOLE map. Treat `.github/**` and the gate workflow as radioactive while the fleet is draining — those are quiet-window changes.
3. Verify-undone AND valid-work-class (`tiny|story|feature|epic`) are part of the pre-dispatch gate, every time. [[ce-dispatch-ordering-discipline]] [[ce-merge-queue-offloads-mechanics]]
4. **Do NOT filler-dispatch a seat that is about to be relaunched/torn down** (e.g. the GATE β canary seat). Marginal dev value, high coordination cost + thrash. Holding it idle beats a churned dispatch. "Don't idle the fleet" does not mean "dispatch at any cost."
5. A bad dispatch is expensive in a compounding way on contained dev-controllers: they foreman their OWN sub-workers on it, so the waste multiplies before a stop signal lands. Get the dispatch right the first time.

## Detail (moved from index 2026-07-05)
- ⚠️ Haiku recon reports MAIN-checkout branch, can MISS active worktrees (caused a dup-W1a near-miss 28 Jun) — verify the worktree.
- in-flight work (incl shared/gate files) before dispatch.
