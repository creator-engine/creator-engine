---
name: ce-subagent-model-efficiency-directive
description: "Operator directive 2026-07-07 — every subagent spawn must use the most token-efficient model adequate for the task; pick the right pinned agent role, never default heavyweight."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: edf19c2d-23e4-4021-942f-766a3d922458
---

Operator directive (2026-07-07, reinforced during the post-halt drive): **be very token
efficient — any subagent must use the most efficient model the given task needs.**

**Why:** controller sessions and the shared account pools are the factory's scarcest resource;
the halt that morning was a session-limit outage caused partly by heavy parallel agent load.

**How to apply:** compose with [[ce-model-effort-routing-policy]] (NEVER pass `model` on
pinned-role agents — frontmatter wins; Haiku = verification only): efficiency comes from
CHOOSING THE RIGHT PINNED ROLE (utility for mechanical chores, ops_triage for tickets,
fleet_recon for probes — not general/claude/fork), keeping prompts tight and prescriptive
(exact steps for mechanical work so the agent doesn't explore), throttling concurrent
heavy agents (max ~2 full preflights), reusing a completed agent via SendMessage instead of
respawning with fresh discovery, and doing trivial 1-2 command acts inline instead of
spawning at all.

**⏫ Operator correction (2026-07-10, second reminder — treat as standing):** the face was
inlining brief-composition, harvest mechanics, PR bodies, and multi-step forensics on Fable.
Routing table now binding:
- DETERMINISTIC mechanics (harvest: bundle→fetch→rebase→queue; push→PR-open; segment arming)
  → SCRIPT, not tokens at all (daemon-class per the rubric). One parameterized pipeline script.
- Brief/report DRAFTING from a scope statement → worker (sonnet-4.6-class general-purpose;
  Haiku for simple restock briefs); face verifies, hashes, sends.
- Forensics/sweeps/audits → Haiku/verification workers (already correct).
- Reviews/fixes/research → pinned roles (already correct).
- Face-only (never delegate): adjudication of verdicts, approvals, signing, dispatch send,
  memory/checkpoints, Operator comms.
Every inline act that isn't in the face-only list is a routing failure.

**⛔ Agent-tool alias trap (2026-07-10, Operator-caught VIOLATION):** the harness Agent tool's
`model: "sonnet"` alias resolves to the LATEST Sonnet = **Sonnet 5 = BANNED** (token-heavy).
Four unpinned general-purpose spawns ran on it today before the Operator caught it. RULE:
NEVER pass the bare `sonnet` alias. Compliant routes for unpinned work: (a) a PINNED role
agent (.claude/agents/* frontmatter carries claude-sonnet-4-6 explicitly) — preferred; the
architect_research read-only+return-content pattern covers drafting (controller writes the
file); (b) `model: "opus"` (= Opus 4.8, allowed at high) when no pinned role fits and the task
warrants it; (c) `model: "haiku"` for verify/sweep. Standing law: sonnet-4.6 where a sonnet
fits, else opus-4.8/high; Sonnet 5 never.
