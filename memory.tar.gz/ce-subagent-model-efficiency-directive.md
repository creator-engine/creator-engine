---
name: ce-subagent-model-efficiency-directive
description: "Operator directive 2026-07-07 — every subagent spawn must use the most token-efficient model adequate for the task; pick the right pinned agent role, never default heavyweight."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: edf19c2d-23e4-4021-942f-766a3d922458
---

Operator directive (2026-07-07, reinforced during the post-halt drive): **be very token
efficient — any subagent must use the most efficient model the given task needs.**

**Why:** controller sessions and the shared account pools are the factory's scarcest resource;
the halt that morning was a session-limit outage caused partly by heavy parallel agent load.

**How to apply:** compose with [[ce-model-effort-routing-policy]] (NEVER pass `model` on
pinned-role agents — frontmatter wins; Haiku = verification only): efficiency comes from
CHOOSING THE RIGHT PINNED ROLE (utility for mechanical chores, ops_triage for tickets,
fleet_recon for probes — not general/claude/fork), keeping prompts tight and prescriptive
(exact steps for mechanical work so the agent doesn't explore), throttling concurrent
heavy agents (max ~2 full preflights), reusing a completed agent via SendMessage instead of
respawning with fresh discovery, and doing trivial 1-2 command acts inline instead of
spawning at all.
