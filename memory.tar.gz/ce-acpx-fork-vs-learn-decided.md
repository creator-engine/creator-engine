---
name: ce-acpx-fork-vs-learn-decided
description: DECIDED 2026-06-06 — learn-not-fork on openclaw/acpx; acpx = reference for the POST-MVP Tier-A ACP adapter (CE builds its own behind RunnerBackend); ClawSweeper/Crabfleet credential-custody prior-art folded into G-3.7
metadata: 
  node_type: memory
  type: project
  originSessionId: 080d99e1-0600-42db-a6f5-66f72e1682bd
---

**Operator-confirmed 2026-06-06 (design session): LEARN, do NOT fork** on `openclaw/acpx` (MIT, "drive over ACP not PTY-scraping"). Routing locked:

- **acpx → the Tier-A ACP transport adapter, POST-MVP.** CE mines acpx as the *reference* for the structured-ACP transport but builds its OWN thin adapter behind the `RunnerBackend` seam — never a wholesale fork. Follows directly from [[ce-substrate-acp-decision]] ("build against the contract, never the transport; never bet the farm on ACP"); a hard fork would couple CE to one pre-1.0 SDK/transport. Tier-B (CC-hooks) is the cheaper first transport, so acpx is NOT on the MVP path.
- **The openclaw learning that IS load-bearing now = credential-custody / sandbox-isolation prior art** — ClawSweeper **late-credential-minting** (write creds created only after the agent exits; the LLM never holds a write token) + Crabfleet **per-agent isolation** — folded into **G-3.7** (the live spike), NOT acpx.

**Why this memory exists:** this resolution was made in-session 2026-06-06 but was NOT persisted — it kept resurfacing as an "open/parked" thread in the resume parked-threads `(1)`, the contract-design §5, and hierarchy-design §9 open lists, producing a post-`/clear` gap (the design corpus said "open" when it was decided). THIS file is the persistence; verify against it, not the stale open-thread lists.

Related: [[ce-substrate-acp-decision]], [[openclaw-steipete-prior-art]], [[ce-coordination-design-resume]], [[ce-agile-shape-open-question]].
