---
name: ce-support-pilot-live-validated
description: ce ask support pilot is LIVE + release-gate-validated against the real OpenRouter backend (2026-06-29 night arc)
metadata: 
  node_type: memory
  type: project
  originSessionId: 99085dc3-1b11-483f-9ea5-ca656b6f6db7
---

**2026-06-29 night arc:** the `ce ask` support agent pilot went from scaffold → working, validated end-to-end against a real model. All PRs merged to main this arc: Phase B model wiring (#656), zero-leak eval harness (#657), OpenRouter adapter (#659); P0 was #644.

**The wiring (controller-side, for the pilot):**
- Backend = OpenRouter via the committed adapter `tools/support-agent/openrouter_model_cmd.py` (JSON SupportRequest on stdin → answer on stdout, exit0; fail-closed; key never logged).
- Env: `CE_SUPPORT_AGENT_MODEL_CMD="python3 <repo>/tools/support-agent/openrouter_model_cmd.py"`, `CE_OPENROUTER_API_KEY` ← `OPENROUTER_API_KEY` in `~/.ce-keys/openrouter.env` (the env file names the var `OPENROUTER_API_KEY`, adapter expects `CE_OPENROUTER_API_KEY` — MAP it), `CE_OPENROUTER_MODEL=google/gemini-2.5-flash-lite` (default; cheap, non-Anthropic, on-doctrine).
- Invoke: `PYTHONPATH=validators .venv/bin/python -m creator_engine_validator.ce_cli ask "<q>" --json`.

**Validated live (controller smoke on DGX, key lives there):**
- Real product Q ("how do I install CE?") → `accepted:true`, real corpus citations (README/llms-install/pilot-runbook/quickstart), reason `cited-corpus-answer`.
- Out-of-scope Q → `model-refusal` ("I don't know").
- **Zero-leak eval (`support_eval.run_eval(load_cases(fixtures), model_command=adapter)`) vs live backend: RELEASE GATE PASSED — 8/8, 0 leak_violations; 4 answered-with-citation, 4 leak-probes REFUSED.**

**Remaining to truly ship to pilot users (Nitzan/Arad):** persist the env wiring into the pilot deployment config so `ce ask` works out-of-box (not just my ad-hoc test env); at VPS deploy move the key to OpenBao ce-kv. Hardening follow-up: ce-ops#362 (runtime leak filter is laxer than the eval — sync them). Phases next: C Discord adapter (built, PR harvesting), then Slack/web/NanoClaw-containment. See [[ce-no-anthropic-sdk-per-token-billing]].
