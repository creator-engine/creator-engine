---
name: ce-l2-automerge-golive-decision
description: Operator R1 decision (2026-06-30) — merging the L2 automerge live-data fix goes LIVE within the ratified ceo/docs envelope; kill-switch is rollback.
metadata: 
  node_type: memory
  type: project
  originSessionId: a4e6df48-9f2a-4e66-b578-3690b46e4421
---

**Operator decision 2026-06-30 (R1 go-live, Option A):** when the L2 automerge-canary live-data fix is built + verified + CI-green, the controller MERGES it, which flips **docs-class auto-merge LIVE** within the already-ratified envelope.

**Why:** the automerge canary is ~90% built (decision engine `forge/automerge_policy.py`, actuator `forge/automerge_actuator.py`, both CI workflows, kill-switch, audit-JSONL). The repo was ALREADY armed (`CE_AUTOMERGE_RUN_MODE=ceo`, `CE_AUTOMERGE_ENABLING_REF=ce-ops#356`, Operator-ratified 2026-06-29, docs-class only) but stayed DORMANT due to a data-gap bug: `automerge-decide.yml` fed empty check/approver data → always GESTURE → actuator refused. L2 P0 (branch `ce-L2-automerge-canary-livedata`, dev-4) wires LIVE PR data into the decide step → eligible docs-class PRs reach AUTO → the armed path fires. So **merging L2 = the R1 live-arming flip** (R1 was pre-granted in the day-arc, exercised after build+verify within the envelope).

**How to apply:**
- Live envelope = `run_mode=ceo` + **docs-class only** + author≠approver + required-checks-green + single-PR + audit-logged. M/L (feature/epic) and non-docs never auto-merge.
- **Rollback = set `CE_AUTOMERGE_KILL_SWITCH=true`** (actuator re-reads live policy, refuses) OR unset the arming vars.
- Before merging L2, the reviewer MUST verify the safety properties: disarmed-by-default preserved, kill-switch override works, envelope enforced, the P0 PR cannot self-arm (pull_request CI runs the base/main dormant workflow).
- After go-live, SPOT-CHECK the first real docs-class auto-merge + its audit record.
- P1 follow-ons (deferred): Surface-B broker run-mode systemd wiring, `ce automerge kill-switch` CLI, single-PR mechanical gate, operating_mode_policy↔run_mode bridge. [[ce-mandatory-containment-decision]] [[ce-dayshift-arc-autonomous-authority]]

## Detail (moved from index 2026-07-05)
- merging the L2 live-data fix flips docs-class auto-merge LIVE within the ratified ceo/docs envelope; repo already armed (ce-ops#356); kill-switch=rollback.
