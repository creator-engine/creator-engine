---
name: ce-gate-authority-vs-containment-doctrine
description: Gate/approval authority and containment are ORTHOGONAL axes; attestation decouples them; the moat is human-rooted ratification
metadata: 
  node_type: memory
  type: project
  originSessionId: 7ed7fba2-2c2b-4884-b503-f02c682d85b0
---

Worked out with the Operator 2026-06-27. Reframes how to think about "who holds the gate" and the fleet switch.

**Core insight — two axes we had accidentally welded:**
- **Containment = ISOLATION** (no raw creds in the agent; everything via brokers/cred-injection). A *security* property. Keep it always — pure defense-in-depth.
- **Authority = the right to perform a binding act (approve/merge).** A *governance* property — purely "who the human delegates to."
We coupled them only by wiring approval to *direct credential possession*. The broker/transport-deputy already breaks that for push; **attestation (ce-ops#289 SO_PEERCRED) breaks it for approve** — once you can cryptographically prove an approval came from *the real attested agent inside the real container*, a contained agent can safely hold delegated gate authority. So **#289 is the keystone** that decouples containment from authority, not a tail-end bug.

**The moat is NOT "contained agents never approve"** (that was a roadmap-stage artifact, absent attestation). The real moat is **authority rooted in human ratification + proof the actor is who it claims.** Human ratification is irreducible at the root of every delegation chain, but it **amortizes** (per-PR → policy-pre-delegated → near-full-delegation-with-audit) — never reaches zero human authority.

**Who holds the gate:** whoever the human delegates it to. Containment is irrelevant to that choice given attestation. Today ce-dev-2 holds it **by delegation/convention** (the operator-interface dev), NOT by being uncontained — if ce-dev-2 were contained+attested it could hold the gate identically. The contained/uncontained gate split is artificial; "move beyond it" (Operator directive) is sound *on top of #289*.

**Three DEPLOYMENT modes** (topology of humans→agents): **solo** (1 human + 1 CE; human is the gate, amortized by policy), **team** (N humans each with a CE; each holds their delegated approve, peers cross-approve — `docs/contracts/peer-authority.md` = two distinct humans for privileged merges), **skynet** (1 operator → M autonomous agents; operator delegates gate authority across the fleet — our de-facto internal setup, the OpenClaw/Steinberger pattern).

**Three RUN modes** (how much approval the human pre-delegates down the attested graph): **Dev** (approve most by hand), **CEO** (pre-delegate classes, ratify exceptions), **strangeLoop** (near-full delegation + audit).

**Operational implications:** (1) reframe the "fleet switch" from "contained vs uncontained" to "wire delegation+attestation so the operator can grant gate authority to any agent"; (2) **#289 jumps to top priority** (+ #285 socket-durability as its operational sibling); (3) the self-review broker's hard APPROVE-refusal becomes **policy-gated, not absolute** — refused by default, grantable to an attested+delegated seat. Relates [[ce-three-deputy-governance-model]], [[ce-authority-attaches-to-form]], [[ce-push-deploy-authority-model]], [[ce-energy-efficiency-ceo-mode-gravity]].
