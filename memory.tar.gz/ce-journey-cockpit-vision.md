---
name: ce-journey-cockpit-vision
description: "Operator product directive (2026-06-14, 2nd pass; forge=ce-ops#45): the cockpit's DEFAULT face must be a novice-solopreneur 'factory journey' (Frame→Shape→Build→Review→Ship, zoomable) + a dead-simple 'what needs me' decision surface — NOT the expert fleet-ops board (which is NOT product-demo-ready)"
metadata: 
  node_type: memory
  type: project
  originSessionId: f6051cd7-5007-4d0f-9f8a-6ce9e4fbfe1f
---

**Operator product directive (2026-06-14 — 2nd discussion; refines/forge-anchored at ce-ops#45 "the journey cockpit").** The shipped cockpit (B.1–B.8) is a **fleet-ops board built by expert operators for expert operators** (locks/queues/meters) — correct for us, **WRONG as the solo-dev's front door, and NOT product-demo-ready.** ⚠️ Correction of a Claude error: the cockpit *running* (TUI mounts) ≠ it is the right product or "[DEMO-READY]".

**Target user = a novice solopreneur with NO software background**, who must answer in one glance: *what is my CE factory doing · where is it in the process · what does it need from me (and what does that decision mean)?* **Strategic anchor (NVIDIA-aligned, RTX consumer push):** CE lets **everyone become a creator of software — your (NVIDIA-powered) home computer becomes a software factory that turns ideas into apps**; the cockpit is the window into that factory. This makes the journey cockpit *pitch-central*, not merely a post-pitch flagship.

**Design:**
- **Journey spine = the stage-vocabulary canon** (Frame→Shape→Build→Review→Ship; `docs/architecture/stage-vocabulary.md` — fractal, already canonized "NEXT: G-7 surfaces it," never cashed in). Five stations; each active Scope = a marker on the arc.
- **Zoom:** click a phase → drill into what HAS / IS / WILL happen at that altitude (the fractal vocab supports it natively); click out → back to the whole-process picture.
- **Keystone = "Operator input/action needed"** — THE most important surface, because ratification is the bottleneck and CEO/strangeLoop is the usage attractor ([[ce-energy-efficiency-ceo-mode-gravity]]). North star: **"a decision inbox, not a dashboard."** Each ⏸️ item opens a **plain-language clarification** (what it is · what approve/reject does · what it costs — non-expert language; templates-per-class first, model-assist behind an honesty-gated dial).
- **Persona dial:** journey board = default (CEO-mode); the expert ops board = a Dev-mode "dig-in" toggle.
- **Grounding (ZERO spine churn):** L2 already exposes board `phase`, `phase_counts`, the AWAITING-OPERATOR escalation queue (B.2/B.8), seat_detail waterfall, meters — the journey view = a new **pure L2 join** + L3 work (Textual clickable now; web/PWA L3 likely better long-term, #28/#37). Honesty: marker/roadmap must be machine-derived, never painted.

Forge = **ce-ops#45** (refined 2026-06-14, + a Codex GPT-5.5 design review dispatched). Relations: #1 Cockpit-B · #20 CEO-mode framing · #31/#46 notify→act · #32 autonomous context · stage-vocab + shaping-UX canon. Twin of [[ce-cockpit-b-design-ratified]] (the expert board this demotes) + [[ce-stage-vocabulary-canon]].
