---
name: ce-no-anthropic-sdk-per-token-billing
description: "CE's own model-calling surfaces must NOT bill per-token via Anthropic Agent SDK/API; use subscription-backed or cheap-API/self-hosted model access"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 169d3cef-709b-4bce-82ab-bc9d1d64a305
---

**Standing Operator constraint (2026-06-29):** Do NOT build CE's own model-originated surfaces (the support agent's hosted bot, and any future CE-internal model caller) on the **Anthropic Agent SDK / Anthropic API**, because that bills **per-token** instead of riding a flat **subscription**. The Operator explicitly rejected the support-agent research synthesis's "Claude Agent SDK (Python) direct" recommendation.

**CONFIRMED (web-verified 2026-06-29): Claude is entirely OFF the table for CE's own model surfaces — not just a billing preference.** Anthropic **banned third-party harnesses from using Claude subscriptions effective 2026-04-04**, restricting OAuth tokens exclusively to Claude Code + Claude.ai (it was flat-subscription token-arbitrage). So riding a Claude *subscription* via a subprocess/3rd-party harness is **prohibited**, and the Agent SDK/API route is **per-token** (rejected). Net: CE's own surfaces cannot use Claude at all. (Sources: The Register 2026-02-20; VentureBeat — Anthropic cuts off subscription access for 3rd-party harnesses.) A support-agent design researcher recommended "ride the Claude subscription via Claude Code subprocess" — that is WRONG/outdated; do not repeat it. **OpenAI subscriptions, by contrast, are still usable with 3rd-party harnesses** (we already ride OpenAI ACCT-B via codex, [[ce-codex-shared-account-subscription]]).

**Allowed model-backend lanes for CE-hosted surfaces (cheapest-first):**
1. **Self-hosted on our own GPU** (DGX vLLM, [[ce-dgx-brain-vllm-serving]]) — zero marginal cost, full data control. REQUIRED for the internal-infra tier (internal docs can never go to a 3rd-party API → forces self-hosting). Also the NVIDIA-pitch story ([[ce-nvidia-v35-strategy]], NemoClaw).
2. **Subscription-backed** (OpenAI/xAI) — programmatic access is via the coding-agent CLI (codex on the fleet's GPT subscription, [[ce-codex-shared-account-subscription]]); zero marginal cost but shares the weekly quota pool and is a heavier harness.
3. **Cheap API via OpenRouter** (or similar) — tiny per-call cost, minimal harness, wide model choice; OK for the **external/product-lens** tier only (data leaves our infra). Needs the budget cap ([[ce-ops#355]]).

**How to apply:** when scoping any CE surface that calls a model on CE's own dime, default to self-hosted (DGX) or a subscription/cheap-API lane — never Anthropic per-token. The `ce ask` CLI (#354) is already model-agnostic (subprocess `CE_SUPPORT_AGENT_MODEL_CMD`), so no Anthropic lock-in there. The harness (chat loop) is commodity; the cost decision is the **model backend**. Related: [[ce-rent-or-fork-before-reinvent]] [[ce-cockpit-resource-envelope-routing]] [[ce-codex-shared-account-subscription]].

## Detail (moved from index 2026-07-05)
- NEVER Anthropic Agent-SDK per-token; internal tier FORCES self-hosted (DGX vLLM); `ce ask` #354 already model-agnostic via subprocess.
- must ride subscription / self-hosted-GPU / cheap-OpenRouter-API.
