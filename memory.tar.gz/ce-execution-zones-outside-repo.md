---
name: ce-execution-zones-outside-repo
description: "Provision gate worktrees + reviewer-seat clones OUTSIDE the repo (or gitignore /ce-worktrees/ + /ce-review-venues/) so they don't pollute the tracked tree"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 66600213-b685-49ca-97ea-ab7b38539848
---

**Operator directive (2026-06-07, during G-4):** CE gate execution provisions per-gate git **worktrees** (`ce-worktrees/<gate>/`) and per-PR **reviewer-seat clones** (`ce-review-venues/pr<N>-<ts>/`) — these were being created **inside the repo dir and were NOT gitignored**, so they show up as untracked pollution on other branches and risk accidental `git add`.

**Why:** a worktree/clone is a separate working tree, never content of the canonical tree; it must not appear tracked or as untracked noise.

**How to apply:** either provision these zones OUTSIDE the repo (e.g. `~/projects/ce-worktrees/`), OR ensure `/ce-worktrees/` and `/ce-review-venues/` are gitignored. G-4's PR added both to `.gitignore` (as instance-local execution zones, alongside the existing `.hermes/` / `.ce/*/cache/` instance-zone lines). Going forward, prefer external paths and/or rely on the gitignore guard. Relates to [[ce-controller-launch-method]] (how reviewer seats are launched).
