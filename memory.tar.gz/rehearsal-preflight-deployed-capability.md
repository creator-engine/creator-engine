---
name: rehearsal-preflight-deployed-capability
description: "Before any destructive/expensive rehearsal or demo, verify the DEPLOYED artifact actually has the capability the rehearsal exists to test — merged-to-main is NOT deployed-to-public-installer"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d1d26e0a-8fd4-4c97-a61a-4c02d6d4db11
---

Operator 2026-06-16 (logged as a CE-dev-record miss): I wiped ce-dev-3 to a clean stranger and drove the full install rehearsal BEFORE verifying that creator-engine.dev served the #233 brownfield-apply build the rehearsal existed to test. It did not — the download mirror was last republished at #231, so the deployed wheel was `ac513c4f` (#225) with `onboard_apply_live` ABSENT; the team-mode brownfield `--apply` would have dead-ended at `e2_brownfield_seam_unavailable`. Compounding miss: during the pre-wipe audit, the `dev3-apply` pane literally showed that exact `e2_brownfield_seam_unavailable` refusal and I recorded it without connecting it to the rehearsal's stated goal. Cost: wasted tokens + time, and ce-dev-3 taken DOWN (dev-pace setback) with no path to finish until the build is deployed.

**Why:** the rehearsal's entire goal was a team-mode BROWNFIELD onboarding of ce-dev-3. "An installer is live" (#226 merged, real install.sh) is NOT the precondition — the precondition is that the DEPLOYED wheel contains the end-to-end capability under test. Merged-to-main ≠ deployed-to-public-mirror; this is the recurring republish gap ([[ce-batch-pr-merge-tax]]). I checked the install-gate, not the capability-gate.

**How to apply:** for ANY destructive or expensive rehearsal/demo, the FIRST precondition (front-loaded per [[ce-precondition-frontloading-doctrine]]) is a preflight that ASSERTS the deployed artifact satisfies the rehearsal's stated goal — served-wheel SHA == current main AND the specific target capability module/flag is present — run BEFORE any wipe/install. Prevent-by-design, not observe-and-react ([[ce-no-mvp-quality-from-day-1]]). Any in-hand evidence of the target capability refusing (e.g. `e2_brownfield_seam_unavailable`) is a STOP-and-verify signal, never a footnote ([[audit-findings-against-operator-directives]]). Bake a reusable preflight script into the rehearsal runbook. [[ce-vps-install-rehearsal]] [[ce-arc-dod-live-install]]
