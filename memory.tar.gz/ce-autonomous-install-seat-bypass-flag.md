---
name: ce-autonomous-install-seat-bypass-flag
description: Launch the rehearsal/demo install-drive agent with --dangerously-skip-permissions so the autonomous install runs hands-off
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 7520a031-5b7e-497e-b56f-0427b09ba70a
---

For the ce-dev-3 install dress-rehearsal / the NVIDIA self-install demo (and any "agent autonomously installs CE from `llms.txt`" drive), launch Claude Code with **`--dangerously-skip-permissions`** so it runs hands-off.

**Why:** without the flag, claude stops at every shell command ("Waiting for permission…"), which breaks the autonomous-install narrative and forces manual approval of each step (babysitting). The 2026-06-14 rehearsal #1 was set up WITHOUT the flag (Controller setup miss), so the agent halted repeatedly. The install still completed (E1: signed-spec verify → offline wheel install → `onboard --inventory`), but the flow was not hands-off.

**How to apply:** bake `--dangerously-skip-permissions` into the rehearsal/demo seat launch — e.g. the asciinema-recorded pane runs `asciinema rec <file> -c "claude --dangerously-skip-permissions"`, or run `claude --dangerously-skip-permissions` after auth. Note: the privileged `onboard --apply` is still operator-gated regardless (answers + sudo + GitHub-App browser click). [[ce-vps-install-rehearsal]] [[ce-arc-dod-live-install]]
