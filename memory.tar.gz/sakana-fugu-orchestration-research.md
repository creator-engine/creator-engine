---
name: sakana-fugu-orchestration-research
description: "Sakana AI 'Fugu' (Conductor + Trinity, ICLR 2026) — peer-reviewed validation that a small learned orchestrator amplifies a fixed frontier-model pool; relevant to CE's orchestration + grader-outside theses"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 1d2b80cf-3e65-45d8-9c6a-745a135534db
---

Sakana AI "Fugu" release (researched 2026-06-22 via sub-agent). Fugu the product = closed API wrapping two ICLR-2026 papers; the papers are the substance:
- **Conductor** (https://arxiv.org/abs/2512.04388) — 7B RL orchestrator emits a full NL agentic workflow (per-step subtask + worker-model + access-list), designs chain/tree/debate topologies + per-worker prompts, outcome-only reward, can recurse (self-as-worker = test-time-scaling dial). A 7B Conductor **beats GPT-5 / Gemini-2.5-Pro / Sonnet-4 individually at ~3 steps** (LiveCodeBench/GPQA/MATH500 SOTA).
- **Trinity** (https://arxiv.org/abs/2512.04695) — 0.6B evolved (CMA-ES) coordinator assigning **Thinker/Worker/Verifier** roles per turn; loop terminates on Verifier ACCEPT. 86.2% LiveCodeBench v6.
- Release page: https://sakana.ai/fugu-release/ (product benchmarks are images only / vendor-stated; PDF tech report unreadable — treat product claims as unverified, papers as solid).

**Relevance to CE:**
- **Validates thesis (c)** ("get more from existing models via orchestration, don't wait for newer ones") — peer-reviewed + quantified → cite in the NVIDIA pitch deck. [[ce-nvidia-v35-strategy]]
- **Trinity's Verifier ≈ CE grader-outside, but theirs is an LLM (hallucination-prone); CE's DETERMINISTIC gate is the stronger version** → position CE's deterministic CI/merge gate as the "Verifier slot." Sharpens differentiation, doesn't threaten it. [[ce-product-north-star]]
- **Learned dispatcher** = research direction for the foreman/seat-class/model-effort-routing layer (ce-ops#163): a small model could *learn* delegation from outcome reward vs CE's current hand-written routing heuristics. [[ce-model-effort-routing-policy]]
- Recursive self-as-worker maps onto controller-spawns-workers + strangeLoop self-improvement. [[ce-controller-spawns-many-workers]]

Note: the research sub-agent flagged the release page's model names (Fable 5/Opus 4.8/GPT 5.5/Gemini 3.1) as "fictional" — that's its training-cutoff artifact; those are the real current (June 2026) frontier models.
