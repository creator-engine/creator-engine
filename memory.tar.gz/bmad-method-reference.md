---
name: bmad-method-reference
description: "BMAD Method (closest competitor) — its 4-phase workflow GROUNDED 2026-06-07; Operator intent: CE implements the 4-phase workflow in its OWN AUGMENTED (externally-graded) way. Maps to CE's 5 shaping-dialogue loci. Phases 2–4 ≈ pilot spine now; phase-1 analysis + heavy PRD hierarchy → deferred toward CEO-mode."
metadata:
  node_type: memory
  type: reference
  originSessionId: f88769c7-b410-4b31-969c-ba0298d72b98
---

**BMAD = CE's closest competitor.** Operator intent (2026-06-07): CE should implement BMAD's 4-phase workflow **in its own augmented way** (externally-graded, artifact-ratified). Grounded from `docs.bmad-method.org/reference/workflow-map` (2026-06-07) — no longer "assume from memory":

**BMAD 4 phases** (each emits a doc that "becomes context for the next"; `project-context.md` = "constitution"):
1. **Analysis** (optional) — explore/validate: brainstorming-report, research, product-brief, prfaq.
2. **Planning** ("what to build + for whom") — PRD (create/update/validate via "coached discovery") + UX (DESIGN/EXPERIENCE).
3. **Solutioning** ("how + break into stories") — architecture.md + ADRs, epics-and-stories, an implementation-readiness gate (PASS/CONCERNS/FAIL).
4. **Implementation** — sprint-planning, create-story, dev-story (code+tests), code-review, correct-course (mid-sprint re-route), retrospective.

**grill-me skill** (mattpocock) = the DIALOGUE MECHANIC for CE's shaping: one question at a time · recommend an answer for each · walk the decision tree · explore the code instead of asking when answerable. Matches the (A) shaping-dialogue style + [[offer-recommendation-on-options]].

**CE's 5 shaping-dialogue loci** (stages BACKLOG→SHAPE→READY→RUN→REVIEW→MERGE), mapped to BMAD:
1. pre-Scope discovery (BACKLOG) ≈ BMAD **Analysis** — optional/thin in pilot.
2. SHAPE→READY / DoR gate ≈ BMAD **Planning** = **the (A) Scope-shaping dialogue** (draft+flag+ask-minimum; appetite human-set; decompose; ends at the bet ratification) — **pilot-core (G-6)**.
3. READY / plan-approval gate ≈ BMAD **Solutioning** (agent proposes the how + ADRs; human ratifies `plan_approved()`; story breakdown = crosswalk) — **pilot-core (G-6 + inner gate)**.
4. RUN escalation ≈ BMAD Implementation **correct-course** (boundary/scope-expansion at the Scope/class edge) — pilot via the **G-4 action gate**.
5. REVIEW re-shaping (result reveals mis-shaping → follow-up Scope) — pilot, lightweight.

**CE augmentation over BMAD:** each phase output is a governed ratifiable ARTIFACT on the external-grader spine (Scope DoR-gated → `plan_approved()` → boxed run + evidence chain + G-4 gate + ◆ Completion Report), NOT just a doc. Human owns value judgments (appetite/boundary/class); agent drafts; deterministic gates grade — the external grader BMAD lacks.

**Roadmap placement / reconciles the "CEO-mode deferred" stance:** CE already implements BMAD phases 2–4 (augmented) = the pilot spine (G-6 + G-4). Phase-1 Analysis + the heavy PRD→epic→story hierarchy = the fuller augmented layer; pilot is **Scope-only** with the **crosswalk** as the optional bridge; the full analysis/PRD-driven flow leans toward **CEO-mode (deferred v3.5/v4)** — see [[ce-v3-product-vision]]. Cross-refs: [[ce-agile-shape-open-question]] (XP+Kanban+Shape-Up appetite), [[ce-v3-roadmap-to-pilot]], [[agent-research-discipline]].

## Detail (moved from index 2026-07-05)
- CE implements it its own externally-graded way.
