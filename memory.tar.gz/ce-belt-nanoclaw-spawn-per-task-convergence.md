---
name: ce-belt-nanoclaw-spawn-per-task-convergence
description: "The belt's spawn-per-claim loop = nanoclaw-styled containerized controllers; Operator's LIMITLESS prior art"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5bc52056-d810-41c3-bacc-32bca88f5d2d
---

CE's belt architecture (persistent host poll → claim → **launch a fresh task-scoped agent per claimed work-item**) converges with the **move away from tmux into containerized (nanoclaw-styled) controllers** ([[ce-every-agent-containerized-direction]], [[openshell-nemoclaw-stack]]). In the containerized model "launch" = **spawn a fresh CONTAINER per task** (not a tmux pane / not re-waking an idle agent). The container IS the task-scoped agent — born to do one work-item, exits when done — which dissolves the "a prompt directive can't re-wake an idle agent" problem entirely: you never re-wake, you spawn.

**Operator prior art (LIMITLESS):** forked **nanoclaw** (https://github.com/LIMITLESS-LONGEVITY/nanoclaw) and customized it; a nanoclaw **"architect" was spawned on a VPS per task**, coordinated via **Discord groups**. Maps cleanly to CE:
- nanoclaw architect-per-task ⟶ CE belt's spawn-per-claim governed lane.
- Discord groups (coordination bus) ⟶ CE **forge-as-hub** (review-requests / assignments / claims).
- The persistent supervisor that spawns ⟶ the host-level belt poller (systemd/linger, decoupled from agent /clear) = OpenShell control-plane/supervisor shape.

**Why it matters:** this is proven prior art for exactly where CE is heading (every-agent-containerized, pre-pitch critical path). Worth mining the LIMITLESS nanoclaw fork for reusable patterns when the belt-launch / containerized-controller work is scheduled. **Polling (not push) is the durable default** because the spawner is outbound-only/self-contained [[ce-belt-feed-polling-default-push-premium]]; push needs a persistent listener anyway, so the agent is never the durable loop either way.
