---
name: ce-fleet-retirement-clean-install-program
description: "Operator line-in-the-sand — retire the run-from-source patchwork fleet, replace each seat canary-style with a genuine clean CE install; two milestones (installed-now, containerized+no-tmux later)"
metadata: 
  node_type: memory
  type: project
  originSessionId: a5799e45-b562-4e65-b393-dc6c0c4d2251
---

**Operator line-in-the-sand (2026-06-22):** stop validating CE autonomy on the hand-patched, run-from-source dev fleet ("the measuring instrument is pre-calibrated by us"). Retire the fleet and replace each seat, **canary-style one at a time** (fleet never fully down), with a genuine **clean install** of CE — the install lifecycle itself becomes the thing under test. This is the real fix for [[ce-bake-gaps-into-ce-not-conventions]] applied to deployment, and the dogfooding gap #198.

**Decisions confirmed:** (1) **dev-4 / DGX retired first** (local, most observable, pitch-critical containerization target); (2) **build `ce brain init`** so the clean install is genuinely clean (no manual genesis step); (3) **two-milestone sequence confirmed.**

**M1 — retire source-patchwork → installed `ce` (doable now, still tmux):** signed-wheel install works today (`docs/install.sh` → venv → offline wheels → `~/.local/bin/ce`; #80/#190/#173 merged). Per seat: drain work → save identity → wipe patchwork checkout → clean-install → `ce brain init` → validate → promote. **Acceptance gate:** the clean-installed seat completes one real end-to-end cycle (pickup→claim→allocate→launch governed lane→work→PR) with ZERO source-tree / hand-bootstrap intervention.

**M2 — containerize + retire tmux (needs 3 builds first):** the containerized/no-tmux end-state is **scaffolded, not built** (gVisor/OpenShell backends registered but unimplemented A.2b; `deploy/dgx-*-runsc/Dockerfile` are lab scaffolds w/ no CE inside; tmux hard-wired in `lane_runtime.py:742`). Build order: `ce brain init` (#206, M1 prereq) → headless/non-tmux visibility backend (#207) → CE container image consuming the signed wheel (#208, blocked-by #207).

**Arad test install POSTPONED → Sat 27 Jun 2026** (Operator 2026-06-22): deferred to give leeway for fleet-initiation + autonomous-devs + company-brain + forge-belt work. Gate = GitHub Team upgrade on `chmod735-dor` (rulesets probe `gh api repos/chmod735-dor/mythos/rulesets`; 404 as of 22 Jun = upgrade still pending). On 200 → apply CE protection floor (required reviews + work-sizing). Re-probe scheduled for 27 Jun morning (needs a DURABLE schedule — session crons don't survive).

**Tickets:** #206 ce brain init (M1 prereq, worker building 2026-06-22) · #207 headless visibility backend (M2) · #208 CE container image (M2). Parents/context: #198 dogfooding, #115 mandatory containment, #82, #205 (launch-leg harness that surfaced the brain/tmux gaps). Aligns with [[ce-every-agent-containerized-direction]] + the ~Sept NVIDIA pitch ([[ce-nvidia-v35-strategy]]).

## Detail (moved from index 2026-07-05)
- M1 installed-now / M2 containerize+retire-tmux (#207/#208).
- canary-replace each seat w/ clean `ce` install.
