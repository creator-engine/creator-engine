---
name: ce-seats-foremen-self-managed-fanout
description: "Seats are foreman-controllers that self-manage concurrency and self-pick forge tickets; don't single-task-assign them"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 87adf545-0606-41c1-a287-c1d201274e70
---

Operator correction (2026-06-21): the dev seats (dev-1/3/4) are **foreman-controllers**, not single-task workers. **codex has built-in fan-out** — it can dispatch multiple concurrent threads (the codex equivalent of Claude Code's ultracode dynamic workflows). Each seat **knows best how many concurrent workflows it can manage** and should **pick up tickets from the forge in accordance with its own capabilities + current load** — not wait to be handed one PR at a time.

**Why:** maximizes parallelism and matches the forge-as-hub model; the controller's job is to keep the forge queue stocked + hold the merge gate, not to micro-assign. (Also corrects the wrong fact "codex lacks native fan-out" that nearly propagated via #166.)

**How to apply:** when dispatching, point seats at the forge work-queue and let them self-select per capacity (with claim-before-start `🔒 in-compose` collision guard until the belt lands); do NOT send single-task one-PR briefs as if they're workers. The autonomous "poll forge + self-pickup per capacity" end-state is exactly the #55 pickup belt (PR #302); until it merges, the controller routes freed seats to the next ready ticket as the manual stand-in. Foreman directive is durable in each seat's `~/.codex/AGENTS.md` (sha 0610b86c). Related: [[ce-codex-foreman-directive-durable]] [[ce-devs-are-controllers-not-seats]] [[ce-controller-spawns-many-workers]] [[ce-controller-steers-seats-execute]].
