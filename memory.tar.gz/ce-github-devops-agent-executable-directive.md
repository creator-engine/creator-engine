---
name: ce-github-devops-agent-executable-directive
description: Operator directive 2026-06-16 — ALL GitHub devops/admin must be agent-executable via one-time max-grant + PoLP (granted≠executed)
metadata: 
  node_type: memory
  type: project
  originSessionId: e2cf4ccf-fa9b-4239-ad01-0e065000d886
---

**Operator directive, 2026-06-16 (DIRECTIVE — execute):** ALL GitHub devops/admin work must become **agent-executable**. The Operator will NOT click GitHub UI buttons — it's time-wasting, infeasible for solo devs in the agentic era, and **impossible in CEO/strangeLoop modes** (human progressively out of the loop). Triggered by the manual pain of the cedev1vps-cmd credential saga (PAT mint = UI-only, org PAT-request approval = UI-only, code-owner review, branch protection).

**Required architecture:** a human performs a **ONE-TIME action granting CE the most-privilege access possible** on GitHub, **stored securely**, then CE executes every devops task under the **Principle of Least Privilege** — *powers granted differ from powers executed* (mirrors [[ce-autonomous-authority-doctrine]] granted≠exercised, and [[ce-installation-grant-is-mint-ceiling]] scope-down-per-token-never-above-install). GitHub App + per-task short-lived scoped installation tokens is the vehicle; extends CE's existing ce-forge App + minter (ce-ops#87/#88).

**Status:** research workflow `wf_8f6a9d1c-2f1` launched 2026-06-16 (6 facets current-docs-grounded → adversarial verify → synth) → design doc `.ce/state/research/DESIGN_CE_GITHUB_DEVOPS_AUTOMATION_20260616.md`. On completion: relay exec summary to Operator + file a ce-ops ticket. This is a standing product direction, not a one-off. [[ce-energy-efficiency-ceo-mode-gravity]] [[ce-product-north-star]]
