---
name: ce-public-private-ops-architecture
description: "RATIFIED 2026-06-10 (ADR-0001): two-tier repos — PUBLIC creator-engine/creator-engine (OSS code) + a PRIVATE ops repo (strategic arc/backlog/designs/memory). Confidential never goes public."
metadata: 
  node_type: memory
  type: project
  originSessionId: 3d6c61d0-a2de-4549-96f6-26d4d9e12958
---

**RATIFIED as Decision Record ADR-0001 (Operator, 2026-06-10).** CE's FIRST real Decision Record (dogfoods the [[ce-v35c-strangeloop-coordination-design]] ADR concept). Fixes three converged pains: data-loss risk (arc lived only on an OOM-prone laptop), work-stays-local (no forge-tracked backlog), and competitive confidentiality (the main repo is PUBLIC → can't track strategy there).

**The architecture:**
- **PUBLIC** `creator-engine/creator-engine` (OSS) — code, public docs/roadmap, **code-gate PRs** (the dogfood-visible governance), community issues/bugs/public features.
- **PRIVATE ops repo** (seeded by `chmod735/ce-arc-backup`; final = `creator-engine/ce-ops` if org-perms, else the renamed personal one) — the confidential strategic arc: designs-of-record, competitive intel, NVIDIA pitch plan, **the backlog as private Issues + a project board**, Decision Records, coordination/resume state, a memory snapshot.

**Classification rule:** PUBLIC = OSS code · public docs/roadmap · code-gate PRs · community issues. PRIVATE = strategy (NVIDIA/competitive/moat) · the full arc + backlog + sequencing rationale · designs-of-record · coordination · memory. **Default = PRIVATE unless explicitly cleared public** (deny-by-default). Crosswalk: a public code-PR may have a private strategic parent-issue; the public artifact carries no confidential WHY.

**✅ STANDUP EXECUTED 2026-06-10:** private repo **`creator-engine/ce-ops`** created (org-owned, verified PRIVATE) — 218 files migrated (decision-records [ADR-0001 + ADR-0002 v4-posture], 32 designs, 4 mandates, 107 resume-states, 70-file memory snapshot), `README.md` (classification rule), `backlog/README.md`, `sync-ops.sh` (HTTPS sync helper). **Live backlog = 7 lane Issues (#1–#7) under milestone #1 `01-Jul NVIDIA pitch`** (Cockpit-B · v3.5-E · v3.5-F · v3.5-G token-econ · v4 · strangeLoop-C · determinism), each crosswalked to design+public-PRs+roadmap. Public `creator-engine#83` noted (no private content). `chmod735/ce-arc-backup` stays as the raw unstructured mirror.

**📋 CE Program Board (added 2026-06-10, Operator-requested):** org Projects-v2 board **<https://github.com/orgs/creator-engine/projects/1>** = the Operator's program-level visual overview (complement to the Cockpit's fleet-now view). Items = the 7 lane Issues + open/landed code PRs; fields = **Status** (Done/In review/In flight/Queued/Post-pitch) + **Anchor** (01-Jul pitch / v3.1 VPS pilot / Both / v4 horizon). Linked to both repos. **Maintain it: update item Status at every lane transition (PR opened→In review, merged→Done, wave fired→In flight); add new lanes/PRs on creation.** gh now holds the `project` scope (granted 2026-06-10).

**Durability + sync:** the off-box private repo is the durable truth; `~/Documents` + `.hermes` stay as working copies; sync via **`/home/nefarious/projects/ce-ops/sync-ops.sh "<msg>"`** (commit+push over HTTPS — [[ce-github-push-https-not-ssh]]) at every checkpoint/resume-state + end-of-session. The v3-coordination A-cluster (`forge/backlog.py`) later AUTOMATES this forge-projection — this is the human-process-first dogfood ahead of it. Twin of [[ce-learning-reference-reports]] (which kept designs in `~/Documents` — now ALSO mirrored privately/durably). Relates to [[ce-nvidia-v35-strategy]] (the confidential part), [[ce-oom-crash-resume-script-footgun]] (the durability trigger).

## Detail (moved from index 2026-07-05)
- Related: [[ce-design-artifacts-in-ceops]]
- default PRIVATE.
- C creator-engine vs PRIVATE ce-ops.
