---
name: ce-bare-ce-usage-decision
description: "RATIFIED 2026-07-05 — bare `ce` stays usage+exit 2 (script-safe); `ce launch` = advertised entry verb; revisit auto-launch with tenant feedback"
metadata: 
  node_type: memory
  type: project
  originSessionId: d9bfe94b-1dfa-43f4-960c-a14a67aa550b
---

Operator ratified 2026-07-05 (ce-ops#441, CLOSED): bare `ce` (no args) keeps concise
product-branded usage + exit 2; `ce launch` is the advertised entry verb in all docs/onboarding.

**Why:** reversibility asymmetry — auto-launching the governed session on bare `ce` is trivial to
add later but breaking to retract once users/scripts rely on it. Operator's own lean was
launch-on-bare-`ce` (non-technical users expect it) and he ratified the conservative default
anyway — an explicit revisit is expected once Arad/Nitzan usage feedback exists.

**How to apply:** don't propose bare-`ce` behavior changes as tickets; when tenant feedback on the
entry experience arrives, surface the revisit as a product decision referencing ce-ops#441.

## Detail (moved from index 2026-07-05)
- revisit w/ tenant feedback.
- ce-ops#441 CLOSED.
