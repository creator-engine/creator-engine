---
name: ce-g5-cost-enforcement-optout
description: "APPROVED design requirement (2026-06-07) — G-5 cost-enforcement must be OPT-OUT-able; explicit ratified + operator-facing toggle, spend-cap/runaway-detection split, surfaced via a Default-vs-Custom INSTALLER profile (G-7), with educate-at-opt-out. Must shape the G-5 + G-7 planning prompts."
metadata: 
  node_type: memory
  type: project
  originSessionId: bfad4f55-cd9e-4e98-9c51-eab66260a4be
---

**APPROVED design requirement for G-5 (tokenomics) + G-7 (install surface)** — surfaced 2026-06-07 from the scenario "a developer wants NO spend cap and wants the module OFF (no budget concern, prioritizes dev speed)." The G-5 design (pilot-roadmap §G-5) is framed *deny-by-default* and does NOT currently specify opt-out — this requirement fills that gap. The architecture already supports it: the orchestrator's **DI-seam pattern** (capabilities are injectable closures gated on `None` in `run_assembly.make_run_driver()`; an unwired cost-gater is inert) makes "fully off" structurally trivial; the trust core (ratification gate, evidence spine/audit overlay, runtime-policy deny-surface) is mandatory and never opt-out-able.

**The requirement — 4 points (1–3 approved as written; 4 added by the Operator):**

1. **Opt-out allowed, but only as an explicit, recorded, RATIFIED human choice.** The *agent* can never disable cost-enforcement; the *human* can, and it lands in the runtime-policy + the evidence chain ("ran with cost-enforcement disabled by operator ratification"). "Grader-outside-the-agent" applied to config.

2. **Operator-FACING toggle.** Add an enable/disable field to the **runtime-policy** (not just the dev-side composition-root seam) — the actor turning it off is a developer/operator, not a CE-dev rewiring code.

3. **Split "spend CAP" from "runaway DETECTION."** The cap/budget (friction) is opt-out-able; KEEP a near-free circuit-breaker that escalates on anomalous spend even when the hard cap is OFF — a runaway agent-loop bug burns real money even for someone with no budget concern; the unlimited-budget dev still wants that net.

4. **Tie opt-out to the INSTALLER profile (Operator-added).** CE's installer offers two profiles (industry naming): **Default / Typical / Standard** (opinionated safe path — all governance ON incl. cost-enforcement with a sane default envelope) vs **Custom / Extended / Advanced** (user selects which OPTIONAL modules to enable/disable, e.g. disable cost-enforcement). Guardrails:
   - The MANDATORY trust core (ratification gate · evidence spine · runtime-policy deny-surface) is **never a checkbox** in either profile — Custom ≠ "disable safety," only "disable optional governance modules you don't value." You cannot install a CE without an external grader.
   - The install-time choice **writes the recorded/ratified runtime-policy** (point 1) — the human ratifying the install profile IS the provenance. Extends the existing "CE's governance model applied to its own install" story (pilot-roadmap §7.1).
   - **Educate at opt-out (Operator-accepted):** when the user disables cost-enforcement in the Custom flow, surface the honesty note — *disabling won't materially speed runs (it's a deterministic, zero-token gate); it removes config friction + the spend ceiling; we recommend keeping lightweight runaway detection even if the hard cap is off.* Prevents a misinformed opt-out.
   - **Reconfigurable post-install** — the runtime-policy field is re-ratifiable; profile choice ≠ permanent lock-in (Default users can go Custom later without reinstall). Note: the G-7.1 "two modes" (one-liner vs agent-native) is the *delivery* axis; this Default/Custom is the orthogonal *feature-selection* axis.

**Cross-gate split:** the opt-out MECHANISM (runtime-policy cost field + enable/disable + the cap/runaway split) lands in **G-5**; the installer PROFILE UX (Default vs Custom + educate-at-opt-out) lands in **G-7**. G-5's design MUST make the field installer-settable; G-7's installer MUST offer the two profiles incl. the cost toggle. Neither gate drops it.

**How to apply:** bake into BOTH the G-5 planning prompt (mechanism) and the G-7 planning prompt (installer profiles) when the controller composes them. Until then: open requirement, not built (G-5/G-7 are designed-not-built). Cross-refs: [[ce-product-north-star]] (cost-efficiency as a first-class, user-chosen property), [[ce-v3-roadmap-to-pilot]] (G-5 = #1 pilot blocker; G-7 = install), [[ce-v3-product-vision]], [[ce-dev-process-stays-on-v1]].
