---
name: ce-codex-successor-controller-live
description: "20260709 ~18:15: ce-governed codex successor MAIN controller launched on ce-pilot-1 (gpt-5.6-sol, yolo-via-config, takeover-evidence path) with Operator ratification to drive the strangeLoop arc; full launch recipe + gotchas"
metadata: 
  node_type: memory
  type: project
  originSessionId: dbe6fa03-2e04-4ee6-883c-ece92e12f9bf
---

2026-07-09 ~18:15 UTC, Operator directive (weekly Claude usage ~90%, Operator heading to bed):
launch a ce-governed codex MAIN controller to take over arc driving. **Ratification verbatim
handed over**: codex controller drives the strangeLoop arc; Claude controller winds down
(one-face preserved — [[ce-one-face-doctrine]]).

**State**: LIVE in tmux `ce-dev2-controller:codex-controller` (host ce-pilot-1, user ce-dev-2),
model **gpt-5.6-sol high**, YOLO via config, repo ~/creator-engine. Handoff doc (Operator
ratification §0, board, seats, DGX gap, 4 dead mandates, standing mandates, first acts):
`/home/ce-dev-2/creator-engine/.ce/state/research/ARC_HANDOFF_CODEX_CONTROLLER_STRANGELOOP_20260709.md`.

**Working launch recipe (repeatable, main-HEAD ce)**:
1. `python3 -m venv .venv && .venv/bin/python -m pip install -e ./validators` → `.venv/bin/ce` (0.3.4+<sha>).
2. codex CLI: `npm config set prefix ~/.npm-global && npm install -g @openai/codex`.
3. `~/.codex/auth.json` = fleet account (neckar@ 2dc1bc68; JWT-decode to verify); config.toml:
   `model = "gpt-5.6-sol"`, `approval_policy = "never"`, `sandbox_mode = "danger-full-access"`
   → ce detects **bypass_mode=config** (this IS the governed yolo; no --codex-arg needed;
   explicit alternative = `--codex-arg=--dangerously-bypass-approvals-and-sandbox`).
4. Evidence packet (15-MIN TTL — mint fresh right before launch):
   `ce takeover --from <session> --harness codex --repo-root <repo> --dry-run --json > packet.json`
   (exit 1 with evidence_gaps is FINE — launch validates kind/initial_state/harness/host/age only).
5. `ce launch --harness codex --backend host --repo-root <repo> --session <tmux-session>
   --window codex-controller --controller-id ce-dev-2 --host-id ce-pilot-1 --purpose <p>
   --role controller --takeover-evidence packet.json --json` (run `--preflight` first).
6. Launch mints `.ce/state/controller-evidence/codex-controller-promotion.<host>.json`
   (cdxd ok + ring1 smoke pass); first launch posture = read-only, packet enables foreman
   authority per ce-ops#471 Ring-1 promotion.
7. Hand off via `tmux send-keys -l "<pointer + sha256>"` then `Enter`; verify acknowledgment.

**Gotchas**: `codex exec` smoke-test hangs when run via harness background shell — run
foreground with timeout. `codex login status` refuses helper-binary creation under /tmp
CODEX_HOME (warning only). Weekly pool at handoff: 28% left (shared neckar@ account).
[[ce-471-program-ratified]] [[ce-dev2-vps-migration-bundle]]
