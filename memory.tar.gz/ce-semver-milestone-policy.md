---
name: ce-semver-milestone-policy
description: RATIFIED (2026-06-12, ce-ops#48) — semver bumps tie to ratified program milestones only (0.2.0 = self-hosting milestone, gate queued; 0.3.0 candidate = pilot-ready); +sha stays derived; v1 EOL path = same ticket
metadata:
  type: project
---

**Operator-RATIFIED 2026-06-12 (ce-ops#48):** semver moves ONLY at ratified program milestones — each bump a one-line governed gate citing the milestone evidence; never per-gate/per-week (signal preservation). **0.2.0 = the self-hosting milestone** (retirement condition, 2026-06-12) — gate QUEUED first post-bridge-tranche slot; **0.3.0 candidate = v3.1 pilot-ready.** The `+<short-sha>` half stays machine-derived (#25/#214; live-git → baked `BUILD_GIT_SHA` fallback = build-time HEAD, correct by design). Same ticket carries the **v1 EOL path** design (condition-gated P1 deprecation-notices → P2 frozen-archive/ratchet → P3 removal-on-ratification; [[ce-v1-v3-coexistence-not-deletion]] holds until P3). [[ce-dev-process-stays-on-v1]]

## Detail (moved from index 2026-07-05)
- ; v1 EOL P1→P3.
