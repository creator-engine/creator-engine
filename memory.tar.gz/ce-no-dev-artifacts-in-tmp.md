---
name: ce-no-dev-artifacts-in-tmp
description: "Dev-work hygiene (Operator, 2026-06-23): never keep anything needed for dev work under /tmp — it's periodically cleared (reboot/tmpfiles). Clones, builds, toolchains, durable artifacts go in a persistent home (~/ or the repo)."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: a3bac9be-36f9-4b41-a61c-0f86c4d754cc
---

**Operator rule (2026-06-23):** `/tmp` (and tmp/ scratch) is periodically deleted, so NOTHING needed for dev work should live there — clones, build outputs, toolchains, anything we'll reuse. Workers default to `/tmp` scratch; **brief them to use a durable path** (under `~/` or inside the repo) for anything that must survive.

**Why:** a build/clone in `/tmp` evaporates on reboot/tmpfiles-sweep → silent loss + rework; on the DGX this bit us when a worker left the herdr-ce clone + ARM build in `/tmp/herdr-ce`.

**How to apply:**
- In every worker brief that clones/builds, specify the DURABLE target path (not `/tmp`).
- Ephemeral truly-throwaway scratch (a temp file deleted in the same run) in `/tmp` is fine; anything reused later is not.
- Tool-managed durable homes are OK as-is: `~/.cargo` + `~/.rustup` (Rust toolchain), `~/.venv`-style venvs.

**Current durable locations (DGX `cedev2`):** main repo `~/creator-engine`; **herdr fork dev clone `~/herdr-ce`** (creator-engine/herdr-ce, with the verified aarch64 `target/release/herdr` build); Rust toolchain `~/.cargo` + `~/.rustup`. Use `~/herdr-ce` for the herdr build units (U3+), never re-clone to `/tmp`. (NB: `~/creator-engine/.ce/state/` is the resume root per [[ce-resume-state-seat-header-protocol]]; `tmp/` in-repo is git-ignored scratch — also not for durable artifacts.)

## Detail (moved from index 2026-07-05)
- brief workers w/ durable paths. Related: [[ce-execution-zones-outside-repo]]
- herdr dev clone=`~/herdr-ce`.
- clones/builds go DURABLE (~/).
