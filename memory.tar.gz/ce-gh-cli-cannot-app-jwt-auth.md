---
name: ce-gh-cli-cannot-app-jwt-auth
description: "gh CLI cannot authenticate as a GitHub App via a JWT → CE's mint leg needs an HTTPS-Bearer adapter, not a gh-shell runner (G-3.7.1 design pivot)"
metadata: 
  node_type: memory
  type: reference
  originSessionId: a4f152c6-b77c-4f29-be7d-9bdea76e3fba
---

Current-dated doc-grounding (2026-06, while composing the G-3.7.1 App-JWT mint seam) established a load-bearing constraint that **supersedes the planning/ledger assumption** that `mint_scoped_token` runs "through an App-JWT-authenticated `gh_runner`":

- **`gh`/`gh api` CANNOT authenticate as a GitHub App via a JWT.** gh sends `Authorization: token <GH_TOKEN>`; GitHub App-JWT auth **requires `Authorization: Bearer <JWT>`** (docs.github.com: "if you are passing a JWT, you must use Authorization: Bearer"). The cli/cli project states "GitHub CLI only accepts access tokens." Putting the JWT in a `gh api -H "Authorization: Bearer …"` flag would **leak it into argv** (violates CE's value-in-env-only hygiene invariant).
- **Canonical split:** mint (App→installation token) needs Bearer-JWT over **direct HTTPS**; the *use* leg (installation token→repo ops, G-3.4 `authenticated_gh_runner`) keeps `gh`+`GH_TOKEN` (that works because the installation token IS an access token).

**How to apply:** CE's mint runner (`forge/app_jwt_runner.py`, G-3.7.1) is an **HTTPS-Bearer adapter** — it honors the `GhRunner` `(argv,input_text)->CompletedProcess` contract (so `mint_scoped_token` stays byte-unchanged, parsing its `gh api` argv) but issues the request itself with the Bearer header via an injectable transport (default stdlib urllib, `# pragma: no cover`). The App JWT: RS256, `iss`=App **client id** (string), `iat`=now−60s, `exp`≤now+600s (CE uses +540 for clock-drift margin). The App private key never enters the module — only behind an injected RS256 `signer` (PEM-on-tmpfs custody = D1, wired live in 3.7.3). Don't re-litigate "why not just use gh" — gh can't do it. Installation tokens are the stateless `ghs_<appid>_<jwt>` ~520-char/two-dot opaque format (2026 brownout) — treat opaque (covered by [[ce-v3-g3-program-resume]]'s `_redact.py` + opaque-mint regression). Related: [[ce-substrate-acp-decision]] (drive/observe substrate), custody research `~/Documents/ce-g37-planning-research-20260606.md`.

## Detail (moved from index 2026-07-05)
- Related: [[ce-codex-mcp-connector-vs-gh-cli]] [[ce-github-devops-agent-executable-directive]]
- → CE mint leg = HTTPS-Bearer adapter.
