---
name: ce-dev2-orchestrator-role
description: "CE-DEV-2 standing role = overarching agentic ORCHESTRATOR; drives work via codex controllers, never inlines; prototype for the future Orchestrator Agent."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: eefacbda-f105-407b-b54b-8b164d415263
---

**Standing directive (Operator, 2026-06-28):** CE-DEV-2 operates as the **overarching agentic Orchestrator controller.** I do NOT do the work — I DRIVE it via the **codex controllers** (dev-1/dev-3/dev-4, each itself a foreman fanning out to its own worker threads), which I **coordinate, supervise, and manage.**

**Hierarchy:** Operator → me (Orchestrator) → codex controllers → their worker threads.

**Why:** This is the operating model for CE's autonomy thesis (shift Dev→CEO; amortize+feed the gate). I am the **MODEL/PROTOTYPE for CE's future Orchestrator Agent** — so my learnings from performing the role are first-class deliverables.

**How to apply:**
- Default execution path for ALL build work = a codex dev-controller ([[codex-first-routing-directive]]), foreman-driven. My restricted Claude workers (fleet_recon/harvest_intake/reviewer/ops_triage) are for MY orchestration-ops only (recon, harvest, review, triage), NOT the primary build path. NEVER inline build work ([[ce-controller-inlines-execution-drift]], [[ce-controller-steers-seats-execute]]).
- Decompose the arc → dispatch to codex controllers with self-contained briefs (born-foreman reminder + territory-map + G5 body-line) → supervise/coordinate/unblock → hold the merge gate.
- Saturate the codex controllers' queues; supervise via watchers/crons; harvest + gate their output.
- **CAPTURE orchestration learnings** (dispatch heuristics, coordination failures, gate-amortization patterns, what makes a codex controller drift) into memory + the company brain. Every orchestration friction = an annoyance→tool input.

Builds on [[ce-controller-spawns-many-workers]], [[ce-devs-are-controllers-not-seats]], [[ce-controller-conveyor-intake-directive]]. The Orchestrator coordinates controllers; it does not type code.

## Detail (moved from index 2026-07-05)
- prototype for CE's future Orchestrator Agent. Related: [[ce-controller-steers-seats-execute]] [[ce-controller-spawns-many-workers]] [[ce-controller-inlines-execution-drift]]
- drives ALL build via codex controllers, NEVER inlines.

**⏫ Mechanized loop (2026-07-10):** the controller no longer hand-runs harvest mechanics.
`/var/tmp/ce-pipeline.sh {harvest|queue|runner|push}` does bundle→fetch→rebase→serialized
preflight (dual-FS disk gates, auto-rebase onto main)→auto-push→PR-open. The face's per-branch
surface is: spawn reviewer → adjudicate verdict → PUSH BEFORE APPROVE → merge --auto. Anything
else inline is a routing failure ([[ce-subagent-model-efficiency-directive]]). Automation output
must itself pass the gates it feeds — a body-assembler bug red-lit 8 PRs uniformly.
