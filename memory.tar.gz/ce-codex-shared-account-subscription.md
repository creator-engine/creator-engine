---
name: ce-codex-shared-account-subscription
description: All CE codex work-seats share ONE OpenAI account; one subscription upgrade lifts the whole codex fleet
metadata: 
  node_type: memory
  type: project
  originSessionId: 5f2b5f45-8ec4-4ec3-9b6e-1196f3b2bc05
---

All three CE codex work-seats — dev-1, dev-3, dev-4 — authenticate to the **same OpenAI account** (`account_id 2dc1bc68-20c8-4bdb-a669-1c9827216458`; the `~/.codex/auth.json` was copied across seats). So they draw from **ONE shared weekly usage pool** — a per-seat "weekly N% left" footer is the whole codex fleet's remaining budget, depleting across all concurrent codex seats.

**Implication:** a single subscription upgrade (Operator 2026-06-20: willing to take GPT Pro/Codex from **x5 → x20** as the CE factory runs at high gear) lifts ALL codex seats at once — maximum leverage, one lever. Do it proactively before a seat walls mid-build (e.g. dev-3 was at ~15% weekly while starting the #109 Landlock build).

**FALLBACK (Operator 2026-06-24):** a SECOND GPT Pro x20 subscription is available — Operator's stance is "run the first to 0%, then switch to the second." So do NOT self-throttle on the codex weekly limit ([[ce-dont-self-throttle-on-quota]]); drive the fleet hard, and surface ONCE when the first account walls so Operator swaps to the second sub.

**Caveat:** multiple concurrent codex sessions on one ChatGPT account can risk throttling / ToS concerns (concurrent-use); the higher tier may also relax this. Watch for it. This raises the codex ceiling but does NOT change the real bottleneck — Operator-ratification throughput ([[ce-agent-paced-estimation]]). Reinforces [[codex-first-routing-directive]] (push work to codex, spare Claude Max): expanding codex capacity is the lever that makes aggressive codex routing sustainable. Still route by reasoning need, not waste ([[ce-model-effort-routing-policy]]).
