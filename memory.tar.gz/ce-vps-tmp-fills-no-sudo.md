---
name: ce-vps-tmp-fills-no-sudo
description: "VPS /tmp is a 16G tmpfs that fills with seat artifacts over a long arc; ; ⚠️STALE-SUDO-CLAIM: as of 2026-07-08 ce-dev-1@VPS HAS passwordless sudo (verified) — see ce-controller-signing-authority-granted"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 5183bef7-5a7b-413f-9619-d7da7f7c58c8
---

Discovered 2026-06-21 night arc (VPS host, dev-1/dev-3):
- **VPS `/tmp` is a 16G tmpfs and FILLED to 100%** over the long night arc — stale per-PR review dirs, build venvs, pytest tmpdirs, and `.bundle` files accumulate across the dev users. Symptom: `scp` to `/tmp` fails with "write remote ... Failure". Root disk `/` is fine (215G free). Workaround for nudges: write the brief to the seat's **home dir via ssh heredoc** (not scp to /tmp). The seats themselves mostly use `~/`-based TMPDIRs (e.g. dev-1 used `~/ce294-full-pytest-live`), so impact on their work is limited but real.
- **⚠️ CORRECTION to stale memory: `ssh ce-dev-1` (= the `ce` user @VPS) does NOT have passwordless sudo** — `sudo -n` returns "I'm sorry ce, I'm afraid I can't do that". Prior MEMORY.md claim that "ce has passwordless sudo" is WRONG. So the controller CANNOT broadly clean /tmp or sudo-manage the VPS; cleanup of another user's /tmp files needs that user (or real root/Operator).
- **Morning/ops follow-up:** broad /tmp cleanup needs each dev user (or Operator) to clear its own; add a periodic /tmp-cleanup cron and/or enlarge the tmpfs so long arcs don't fill it. Each seat could `rm` its own stale `/tmp/ce-pr*-*` / `*.bundle` artifacts for merged PRs.
- **✅ FIXED 2026-06-22 (interim, no-sudo):** cleared ~2.2G stale dirs (each as owner: dev-1/dev-3/`ce`), and added a **TMPDIR redirect** to `~/.bashrc` + `~/.profile` on both `ce-dev-1` and `ce-dev-3` → `export TMPDIR=$HOME/tmp` (home is on the 212G root disk), verified in fresh login shells. So new shells no longer hit the 16G tmpfs. **Durable root-level guard (tmpfiles.d / resize tmpfs / system-wide TMPDIR) tracked in ce-ops#184** (needs root/Operator).