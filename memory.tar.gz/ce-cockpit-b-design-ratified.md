---
name: ce-cockpit-b-design-ratified
description: Cockpit-B (v3.5-B) design-of-record RATIFIED with all 5 forks resolved; B.1–B.7 gate cluster being composed — the live Cockpit lane resume pointer
metadata: 
  node_type: memory
  type: project
  originSessionId: 3d6c61d0-a2de-4549-96f6-26d4d9e12958
---

**RATIFIED (Operator, 2026-06-09 evening) — the v3.5-B Cockpit design-of-record + all 5 forks.** Design: `~/Documents/ce-cockpit-b-design-20260609.md` (governed architect seat, orchestrator-reviewed EXCELLENT; keystone claim independently verified). The Cockpit = CE's visible governance/operations surface; north star = make "the grader lives outside the agent" VISIBLE; the wedge = the **governance/authority panel** (standing envelope + **live REFUSED feed** + ratifier attribution) — confirmed near-empty white space across all 2026 agent-ops tools (FABRO/Devin/Factory/Cursor/Copilot/Bedrock ship none of the triad).

**The 5 RATIFIED fork dispositions (bake into all B-gates; do not re-litigate):**
1. **Substrate = Textual hybrid, phased** — `ce cockpit` TUI-primary (SSH-native, daemonless), `--serve` browser mode later (B.6; bind 127.0.0.1 + token + Host-header).
2. **Refusal-record spine seam = YES, in B.3 (keystone):** wire `hook_check` deny → append `runtime_agent_action{classification:denied}` to the spine (record already in schema `runtime-evidence.schema.yaml:376,480`; hook imports NO spine today → net-new **V1→shared** seam, allowed; verify version_boundary green).
3. **Execution model = MVP read-only + "emit the exact governed command"**; in-Cockpit request-execution (Operator-attributed) later (B.5).
4. **Demo honesty = persistent "DEMO — seeded data" watermark** in `CE_DEMO=1`.
5. **Subscription estimate = MEASURED spend + context% now; ESTIMATED headroom = labelled placeholder** until the estimation research task lands.

**Also ratified:** harness-paper **F1 (read-only Deep-Telemetry projection) FOLDS IN as the L2 core** — one view-agnostic module = Cockpit read-model + telemetry surface + future-GUI backend ([[ce-cockpit-frontend-agnostic-core]] = HARD principle 6: L1 spine/registry JSON · L2 pure JSON-serializable projection · L3 Textual binds only). **F2 (loop_governor) stays in the strangeLoop track** (= gate B-C1; [[ce-v35c-strangeloop-coordination-design]]).

**IN FLIGHT:** gate-composition architect seat (Fable 5/xhigh, governed) composing the **B.1–B.7 batch-strict cluster** from mandate `.hermes/launch/v35b-cockpit-gates-architect-20260609T175218Z/COCKPIT_B_GATES_COMPOSITION_MANDATE.md` → deliverable `~/Documents/ce-cockpit-b-gates-<UTC>.md` → orchestrator review → per-gate Operator ratification → execution. **MVP for 01-Jul = B.1 + B.3 + `CE_DEMO=1`** (the demo: a seat refused a `git push` on camera). Gates: B.1 skeleton+L2+demo · B.2 board+seat-detail · B.3★ governance panel+refusal seam · B.4 resource meter · B.5 approvals inbox · B.6 --serve+brand · B.7 catalog+insights. New deps Textual+watchfiles (flag); CLI on `v3_cli` not frozen `ce_cli`. [[ce-competitive-cockpit-b-inputs]] [[fabro-competitor-reference]] [[ce-nvidia-v35-strategy]]
