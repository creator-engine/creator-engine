---
name: ce-runsc-seat-worktree-in-memory-loss
description: "runsc contained-seat container-fs writes live in RAM (shmem overlay) — OOM/sentry death = TOTAL loss of uncommitted+unextracted work; commit-early, extract-early"
metadata: 
  node_type: memory
  type: project
  originSessionId: 46fbbf10-9bed-41a5-a4fd-040713bc0bcb
---

2026-07-07 incident (dev-3 / ce-vps-codex, VPS): host global OOM killed the runsc
sentry mid-unit (full validate-pr inside gVisor; sentry total-vm 51GB, shmem-rss
5.6GB). `docker export` of the stopped container showed `var/tmp/` EMPTY — the
runsc profile (`runsc-gvproxy-ptrace`) keeps the writable overlay in sentry memory
(shmem), so container-fs writes (including /var/tmp worktrees) never reach disk.
~75 min of unit work unrecoverable. Also: restart of the stopped container was
impossible because the launcher stages the codex config bind-source in host /tmp
(tmpfiles-cleaned) — [[ce-no-dev-artifacts-in-tmp]] applies to CE's OWN launcher.

**Why:** contained seats on this profile are one OOM away from total work loss at
all times; the host had no swap and the container no memory cap (mem=0), and the
full test suite inside gVisor is the natural trigger.

**Deeper root cause (found ~21:4xZ same night):** host /tmp is a 16G tmpfs
([[ce-vps-tmp-fills-no-sudo]], durable fix = ce-ops#184) and held 13G of
pytest-of-ce-dev-1 tmpdirs from THREE concurrent `-n auto` full-suite preflights —
tmpfs pages are RAM, so dev-1's preflights directly squeezed dev-3's sentry.
Shared-host rule: serialize full suites, TMPDIR on disk, bound -n, post-run
cleanup (added as slice (d) on ce-ops#500).

**How to apply:** (1) Treat contained-seat work as volatile until extracted —
harvest promptly on READY; prefer briefs that commit early and often. (2) At
relaunch/image work: bind-mount the worktree root to host disk OR set a container
memory limit + host swap so the OOM killer hits pytest, not the sentry. (3) Fleet
incident ticketed in ce-ops (2026-07-07, dev-3 OOM umbrella; see also
[[ce-oom-crash-resume-script-footgun]]). (4) Seat relaunch stays canonical-only
[[ce-seat-relaunch-canonical-launch-only]].
