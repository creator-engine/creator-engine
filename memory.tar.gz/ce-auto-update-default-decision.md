---
name: ce-auto-update-default-decision
description: Operator decision (2026-06-30) on ce auto-update default behavior — apply-but-opt-in (prompt-based) with non-interactive fallback to notify-only.
metadata: 
  node_type: memory
  type: project
  originSessionId: 260724fc-e8c5-4c0e-98f6-94726041d899
---

**Decision (Operator, 2026-06-30):** for a custom agentic harness, `ce`'s default auto-update behavior should be **Apply, but Opt-In (Prompt-Based), with a non-interactive fallback to Notify-only.**

Concretely, on the SOLO end-user path:
- **Interactive (TTY) startup:** if a newer signed release is available, **prompt** the user to apply now (apply on consent — a human-in-the-loop gate, not silent).
- **Non-interactive (no TTY / agent-driven):** **fall back to notify-only** (never auto-apply silently in a non-interactive context).
- **Contained/fleet seats:** unchanged HARD NO self-update — updates flow controller→`fleet_rollout`, denied at `hook_check` (`toolchain_self_update`). Auto-update logic must be statically off there.

**Why:** balances "updates shouldn't be left to the user" (prompt nudges + one-keystroke apply) against the risk of silent code-swap mid-run; the prompt keeps a human consenting to executing fetched code.

**How to apply / build implications** (research report: `.ce/briefs/ce-auto-update-mechanism-REPORT-20260630.md`):
- CE already has the strong self-updater (`update.py`: SSHSIG verify-before-execute, out-of-band DNS anchor, offline wheel install, atomic swap+rollback, downgrade-refused). Build = trigger + prompt UX + config, not greenfield.
- P0: lightweight spec-only startup check (no wheel fetch) + fetcher timeout/fail-open + posture-gate-off in governed seats + the interactive prompt / non-interactive notify fallback.
- Because apply is CONSENT-gated (not silent default), the signed **recall/min-version kill-switch** (P2) is strongly recommended but is a HARD prerequisite only for any future SILENT apply-default — not for consent-prompt apply. Still build it: it's the only defense against a bad-but-validly-signed release / `ce-root-v1` compromise.
- Channels: stable users (Arad → 0.3.x) get latest SIGNED release; contributors (Nitzan) stay on git/main-HEAD (do NOT build "track main" into the signed updater). See [[ce-govern-rented-surface-updates]].

## Detail (moved from index 2026-07-05)
- ce auto-update = apply-but-opt-in (prompt on interactive startup) + notify-only fallback non-interactive; seats stay hard-no via fleet_rollout. ce update engine already strong; build trigger+prompt+recall-floor. Report: .ce/briefs/ce-auto-update-mechanism-REPORT-20260630.md.
