---
name: ce-push-deploy-authority-model
description: "Operator principle + finding — automate the mechanical push, human-gate ratify+merge; authoring agent must NOT self-deploy, orchestrator CAN push; formalize + harden"
metadata: 
  node_type: memory
  type: project
  originSessionId: e4d491a1-31cc-4d9d-8c27-865b01612c59
---

**Operator principle (2026-06-08, approved in-discussion):** *automate the mechanical, human-gate the accountability.* In CE's governed SDLC the **human gates are RATIFY** (the SHA-pinned scope) **and MERGE** (final accountability for the artifact/product). The **PUSH is the mechanical step between ratify and merge → it should be automatable** while preserving stability, safety, and human accountability for what CE produces.

**The mechanics (verified 2026-06-08 on the v3.5-A.1 / D.0.1 lanes):**
- **The authoring agent MUST NOT self-deploy.** A governed seat's Ring-1 hook **hard-denies `git push`** (restricted "deploy" mechanic; there is **no deploy-authority envelope** by design — only `pr_review` has one, via `CE_REVIEWER_AUTHORITY_REF`; `hook_check.py:181,296–305`). The agent must NOT evade it (gaming the grader is forbidden). PROVEN exemplary: the D.0.1 seat refused to craft a `git -C` evasion and escalated — see [[ce-nvidia-v35-strategy]] pitch-evidence.
- **The ORCHESTRATOR (design-lane co-pilot) session CAN push** — verified: a push from this session succeeded while the seats' governed sessions are denied. So the **working pattern = orchestrator performs the mechanical push (Operator-authorized); the seat then opens the PR** (`gh pr create` is unrestricted) → independent reviewer venue → **Operator merge.** Do NOT ask the authoring agent to push.

**Remedy/design follow-ups (flagged):**
1. **Formalize** this — the orchestrator-can-push / authoring-agent-cannot split currently works partly *incidentally* (the orchestrator session's hook posture). Make it **intentional**: an explicit deploy-authority for orchestrator/automation vs a hard deny for the authoring agent. Operator directive: *if a session's hook ever prevents the legitimate mechanical push, that violates the core principle → remedy it* (don't work around).
2. **Harden the guard-gap** the D.0.1 seat surfaced: the push classifier regex (`\bgit\s+push\b`) is **dodgeable** (`git -C <dir> push`, env tricks). Make the deploy classifier evasion-robust. (Surface-not-exploit was the right call — [[audit-findings-against-operator-directives]].)

**How to apply now:** when a governed seat finishes green + rebased and is push-blocked, the orchestrator pushes the branch (the mechanical step), the seat opens the PR, route to independent review, Operator merges. Pair with [[batch-strict-mode-gate-workflow]] + [[independent-reviewer-venue-rule]] + [[ce-reviewer-token-and-merge-mechanics]].

## Detail (moved from index 2026-07-05)
- Related: [[ce-governed-seat-cannot-push]] [[ce-gate-authority-vs-containment-doctrine]]
- orchestrator session CAN push.
- author agent must not self-deploy.
