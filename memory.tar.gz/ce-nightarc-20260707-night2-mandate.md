---
name: ce-nightarc-20260707-night2-mandate
description: "RATIFIED night-arc 2026-07-07→08: lanes N-A..N-E (board drain via re-review→gate, C5 evidence, D4 packet/D3 dry-run canary/D6 drill-if-standby-live, intake queue, 0.3.4 assemble-only); OVERNIGHT GATE AUTHORITY EXPLICIT; supersedes the 20260706 night mandate"
metadata: 
  node_type: memory
  type: project
  originSessionId: 46fbbf10-9bed-41a5-a4fd-040713bc0bcb
---

Operator ratified 2026-07-07 ~22:xxZ, verbatim as proposed, plus explicit: "gate
authority stands overnight" — controller approval after independent review = merge
trigger for remediated heads.

SSOT: `.ce/state/research/NIGHTARC_MANDATE_CE_DEV2_20260707_NIGHT2.md` (dual-written
CE-DEV-1) + DECISIONS_20260707.md item 7. Lanes: N-A conveyor drain (re-review
remediated heads #883/#884/#886/#887/#888 + Option A design PR + dev-3 follow-ups);
N-B C5 evidence (promotion declaration = Operator); N-C D4 Ring-1 packet assembly
(no flip) + D3 dry-run shadow canary + D6 drill #1 ONLY IF standby verified (it was:
ce-controller tmux alive, 61% ctx, authed); N-D intake queue #888-remediation →
ce-ops#500(c) launcher-/tmp fix → #499 design; N-E 0.3.4 assemble-only.

Hard stops: the standing set + Option A DESIGN-ONLY (materialization-authority ruling
is a morning Operator question) + VPS host-resource rules (serialize suites, TMPDIR on
disk, bounded -n). Morning queue items 1-7 at the top of the mandate file.

Supersedes [[ce-nightarc-20260706-live-mandate]].
