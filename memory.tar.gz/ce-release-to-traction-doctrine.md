---
name: ce-release-to-traction-doctrine
description: Ship a WORKING CE to real users to win traction; quality-where-it-counts; gate the release on a real DoD
metadata: 
  node_type: memory
  type: project
  originSessionId: 66ba17c2-15bc-4894-a232-cbc995c57d15
---

Operator strategic directive (2026-06-24): we can't forever "sharpen the axe" (build OpenShell/containment/OpenBao/etc. depth) — we must **ship a version that actually works and onboard real users** to win traction + investor backing, or lose the race to a lesser-but-working competitor. **Playbook = OpenClaw/NanoClaw:** release early/imperfect → traction → backing (OpenAI; Docker+Monday) → level up. [[ce-nvidia-v35-strategy]]

- **Quality is NOT compromised** — it IS the thesis (why we integrate complex innovative stacks before everyone). The shift is **"quality where it counts"**: the *user-facing surface* (install + first-value loop) must be bulletproof; *enterprise depth* (full gVisor/herdr contained controllers) sequences BEHIND traction. Reconciles with [[ce-no-mvp-quality-from-day-1]] — minimal-sufficient surface, done right, not gold-plated.
- **Apply our own methodology to the business milestone:** define a **release DoD** (binary, probe-verified, fail-closed criteria); if we don't hit it, we DON'T release — we slip. The rehearsal/dry-run IS the grader-outside-the-agent.
- **How to apply:** target = first test users (Arad + others) + contributors onboarded; release tagged v0.3.0 pilot ([[ce-semver-milestone-policy]]) on DoD-pass. Live program state in newest `RESUME_STATE_CE_DEV2_*`. Related: [[ce-arc-dod-live-install]], [[ce-agent-pointed-install-model]], [[ce-parallelize-everything-scale-the-gate]].

## Detail (moved from index 2026-07-05)
- DoD-gated (miss→slip).
- quality-where-it-counts.
