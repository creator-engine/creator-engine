---
name: ce-brain-evidence-pin-doctrine-ratified
description: "RATIFIED 2026-07-02 — brain evidence hash pins only for atomic-by-design artifacts; behavior claims use probe/projection; migration + guard-widening queued via ce-ops#407"
metadata: 
  node_type: memory
  type: project
  originSessionId: cae4382b-381a-490e-962a-afb1d5769495
---

Operator ratified (2026-07-02, ce-ops#407): whole-file `evidence_sha256` pins in `.ce/brain/assertions.yaml` are reserved for atomic-by-design artifacts (signed manifests, ADRs, release policy — 3 pins kept: VERSIONING_AND_RELEASE_POLICY.md + ADR-0013 ×2). All 27 other D1b hash pins migrate to `probe:`/yaml-path-projection evidence in ~23 per-file slices (churn-priority: pr_preflight.py → integrator_belt.py → wheelhouse/SHA256SUMS → workflows → docs).

**Why:** whole-file pins on hot files froze the merge lane 2026-07-02 (#740/#742 merge-group failures; chained-supersede defect #743 made it repo-wide) and impose a per-edit supersede + count-ratchet obligation forever.

**How to apply:** dispatch SSOT = `creator-engine/.ce/briefs/ce407-evidence-pin-doctrine-RATIFIED.md`. All ledger-append PRs SERIALIZE (chain-hashed). Separate small fixes: path-based volatile-workflow guard widening; `ce brain repin` AFTER migration. The `test_ce_brain_drift.py` active-count constant is a deliberate ratchet — every correct_claim bumps it (+1 per corrected assertion); put the bump in every supersede brief. [[ce-l2-automerge-golive-decision]]

## Detail (moved from index 2026-07-05)
- ce/briefs/ce407-evidence-pin-doctrine-RATIFIED.md; count-ratchet bump in every supersede brief.
- 27 D1b pins → probe/projection in ~23 serial slices; SSOT=.
- for atomic artifacts (3 kept).
