---
name: controller-drive-work-through-own-fork-workers
description: "When I (controller) already hold a task's context, drive it through MY OWN fork/subagent workers — not a blind remote seat that must re-derive it."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 89f9bfcf-5542-47e6-9c3e-213df46ba6b1
---

When I have the full context for a task — especially a controller-diagnosed fix, or anything whose crux is **live verification I can do but a remote contained seat cannot** — drive it through **my own workers**: a `fork` (inherits my entire conversation context) or a subagent in a worktree. I am a foreman with my own fan-out, not just a relay to dev-1/3/4.

**Why:** I diagnosed the Integrator `latestReviews`→`latestOpinionatedReviews` bug with complete ground-truth (live API proof), then reflexively shipped the fix to remote seat dev-4 — which has to re-derive the context AND can't live-verify (no token on the box). Operator: *"you ARE a controller with workers, drive it through YOUR workers — you already have the context."* The Integrator's repeated live-only discovery bugs (query-var collision, brace imbalance, latestReviews) all slipped **precisely because contained seats can't live-test against the real API** — only my own box can.

**How to apply:**
- Controller-diagnosed / context-heavy / needs-live-verification → spawn a `fork` or worktree subagent (runs on my box, with my tokens, can live-verify). This is the DEFAULT, reached for FIRST.
- Reserve remote contained seats (dev-3/dev-4) for self-contained build work that does NOT need my live context or a live API check.
- "Don't inline" ≠ "always remote-seat it." It means: stop typing the work myself AND stop blind-shipping context-heavy work to seats — fan it out through my own workers that carry the context.

Related: [[ce-controller-spawns-many-workers]], [[ce-controller-inlines-execution-drift]], [[ce-seats-foremen-self-managed-fanout]].
