---
name: ce-pr-work-class-line-format
description: "PR \"Declared work class\" line must be a bare size token (tiny/story/feature/epic), exactly one line, no parenthetical — specify this in every build brief"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2b67ead0-9d4c-41c1-974e-43b059ac1239
---

The G5 `work_sizing_floor` CI gate ("Validate governance artifacts") requires the PR body contain **EXACTLY ONE** line matching `- **Declared work class:** <tiny|story|feature|epic>` with a **bare single token** — no parenthetical, no extra words. It is a **SIZE** class, NOT the `v1/v3` `_versions.py` layer label (different thing entirely).

Size bands (`checks/work_sizing_floor.py:_size_band`): tiny `<400` / story `400-799` / feature `800-1000` / epic `>1000` changed lines. The gate's count appears to exclude some test/carrier lines (PR #367 with 830 raw additions validated as `story`). It's a FLOOR — declaring ≥ the diff's band is accepted (over-declaring OK); the format/validity check runs first.

**Why this is in memory:** I caused 2 CI failures on 2026-06-23 by leaving `<class>` underspecified in dispatch briefs — a worker wrote `v3` (#364) and another wrote `feature (v1 governed-lane-launch ...)` (#368); the parenthetical made the gate see "zero valid lines → must contain exactly one." Recurring footgun (also ce-ops#214).

**How to apply:** every build-brief conventions list must say verbatim — *"PR body line: `- **Declared work class:** <bare one of tiny/story/feature/epic>` — exactly one line, no parenthetical, no v1/v3."* Related: [[ce-pr-path-manifest-carrier-required]].
