---
name: ce-arm-watcher-for-every-dispatch
description: Every seat dispatch MUST be paired with a progress/stall watcher — un-watched delegated work gets silently dropped
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9856ffdc-c843-4966-a075-107dc335e56a
---

Operator flag 2026-06-17: after dispatching dev-1 (E3 verify) + dev-3 (§8c), the Operator asked "have you set up watchers to check on dev-1/dev-3 progress" — I had NOT. That same gap is exactly why the **E3 verify-first got silently dropped** earlier (dev-1 was `/clear`ed and nothing was watching to notice the task never ran).

**Why:** the Controller's whole value is steer + MONITOR; a dispatch without a watcher is fire-and-forget, and on a remote/cleared seat the task can vanish with zero signal. Completion is not self-announcing.

**How to apply:** the moment I dispatch ANY seat (local or VPS), arm a harness-tracked background watcher that fires on (a) the completion milestone (a file/commit/PR/verdict appearing — reliable gh/git poll), AND (b) a **stall/idle** signal (pane shows no "esc to interrupt" for K consecutive polls) so a drop/await is caught, not just success. Watchers do NOT survive `/clear` → **re-arm on every resume** and record the watcher id in the resume state. For long/overnight monitoring spanning multiple resumes, consider a CronCreate job instead. Pairs with [[report-context-each-turn]] and the resume-state protocol.

## Detail (moved from index 2026-07-05)
- gh api --jq not grep.
- a progress+stall watcher (re-arm on resume).
