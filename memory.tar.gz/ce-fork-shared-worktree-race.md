---
name: ce-fork-shared-worktree-race
description: "Dispatched forks inherit my cwd and race me in the SAME git worktree — branch churn, lost commits, getcwd errors"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 61b01e4e-f0fa-453a-90f8-03a849b5c415
---

When I `Agent(subagent_type: "fork")` for file edits, the fork inherits my full context **including my current working directory**, so it operates in the *same* git worktree I'm in. If I keep working there too, we collide: the fork created branches (`*-clean`), checked out my branch, reset HEAD, and deleted/recreated dirs — my validated commit got orphaned (recoverable via reflog) and a `getcwd: cannot access parent directories` error appeared mid-command.

**Why:** a fork is not sandboxed to its own filesystem; "fork" isolates context, not the worktree. Two writers, one worktree = race.

**How to apply:** (1) For parallel file edits, give each fork its OWN isolated worktree (`isolation: "worktree"`) OR don't also edit in the shared tree yourself — pick one driver. (2) If a race already happened, my commit survives as a git object: find it in `git reflog`, then `git worktree add -b <unique-name> <path> <SHA>` with a branch name the fork can't claim, and certify there. (3) Identical-context forks often produce a byte-identical result (same tree SHA) — verify with `git rev-parse <a>^{tree}` vs `<b>^{tree}` before discarding either. Relates to [[controller-drive-work-through-own-fork-workers]] and [[ce-controller-via-workers-operational-lessons]].
