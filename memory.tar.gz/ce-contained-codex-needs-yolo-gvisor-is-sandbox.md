---
name: ce-contained-codex-needs-yolo-gvisor-is-sandbox
description: Contained codex (inside gVisor) must disable its OWN inner sandbox — set sandbox_mode=danger-full-access (+approval_policy=never = YOLO); nested bwrap fails inside gVisor and kills exec.
metadata: 
  node_type: memory
  type: project
  originSessionId: 2fe171be-e2b8-479e-b208-4b0153b128cf
---

A codex seat launched INSIDE gVisor (the contained+herdr stack, [[ce-mandatory-containment-decision]]) **cannot execute any shell command** if codex's own `sandbox_mode = "workspace-write"` (the default). Codex uses Landlock/seccomp → falls back to bundled **bubblewrap**, and bwrap needs `unshare(CLONE_NEWUSER|CLONE_NEWPID)` + seccomp ops that gVisor's Sentry blocks (cap-drop=ALL + no-new-privileges make it worse). Symptom: codex reports "bubblewrap is unavailable" / "No permissions to create a new namespace" and silently fails before running `git`, spawning workers, etc. — the contained foreman can think/talk but not act.

**Fix (architecturally correct, NOT a workaround):** gVisor IS the sandbox, so codex must not double-sandbox. In the contained codex home's `config.toml` set `sandbox_mode = "danger-full-access"`. Combined with the pre-existing `approval_policy = "never"` (autonomous-foreman posture) this yields codex **YOLO mode** (banner: `permissions: YOLO mode`) — which the Operator confirmed is required for dev-4 to do its job (unattended exec + worker fan-out). Equivalent CLI: `codex --dangerously-bypass-approvals-and-sandbox` / `--yolo`; approvals-kept variant is `codex --sandbox danger-full-access`. This is SAFE because the gVisor boundary holds — YOLO-inside-containment is the whole thesis.

PROVEN 2026-06-23 on dev-4 (first born-contained controller): with the fix, `git log` ran clean inside gVisor; probe stayed backend=gvisor/contained=true/gaps=[] (containment posture unchanged — danger-full-access only drops codex's redundant inner layer). Bake into the clean-build spec for EVERY contained codex seat (VPS dev-1/dev-3 next). Clean-home path on DGX: `/home/cedev4/.codex-contained`. Related: [[ce-seat-relaunch-canonical-launch-only]], [[ce-contained-controller-push-model]].
