---
name: ce-provisioning-hardening-architect-findings
description: DESIGN-of-record + 3 gates for the governed-provisioning/Ring-1-fidelity hardening; headline = the examples-fixture footgun is LOAD-BEARING for worktree governance
metadata: 
  node_type: memory
  type: project
  originSessionId: 3a9f0615-7e56-447f-85d1-e272fbcb6628
---

Architect design (2026-06-09, seat `prov-hardening-architect-20260609T060405Z`, brief sha `bd35efeb…`, grounded @ `97dbc28`). Design-of-record: `~/Documents/ce-governed-provisioning-hardening-design-20260609.md` (sha `9ee3ad47…`). Three proposed gates in `.ce/state/research/ce-governed-provisioning-hardening-architect-20260609T060405Z/`: **A** skew-guard (`94ec13f6…`), **C** envelope-none (`b639d0d0…`), **B** decision-then-gate (`f82c4cf7…`). Awaiting Operator + design-lane ratification.

**Three durable, empirically-verified facts (not derivable from git/code alone):**
- **(A)** The *shipped* wheel `validators/wheelhouse/creator_engine_validator-0.1.0-py3-none-any.whl` is the documented install artifact but is **never built/exercised in CI** (CI installs only deps; `requirements.txt` is `--no-emit-project`; all gates run from `PYTHONPATH=validators` source). It's currently **4 `.py` mismatches + 36 source files missing** vs source (predates the entire v3 surface; its `hook_check.py` is the OLD hard-deny — the exact stale wheel that bit the dogfood discovery). Fix = wheel↔source fidelity guard in `packaging_runtime.verify_packaging_contract` + rebuild + re-pin SHA256SUMS.
- **(B) HEADLINE — materially deeper than the brief framed.** Posture `rglob`s the whole posture-root and matches tracked `examples/**/claims/*.yaml` as **live governing claims**. Worktree seats carry NO real ledger (`…/ce-worktrees/*` have no `.hermes/active-work-ledger`); the real ledger is **0-live at rest**. So **worktree-seat governance is currently load-bearing on the examples footgun** — a naive "scope to ledger / exclude examples" flips every active worktree seat to `ungoverned`. Correct fix = launch-pinned `--ledger-root` injection (mirror `reviewer-authority-ref`) so the real claim is reachable, THEN scope (examples excluded by construction), transition-safe. B needs a topology DECISION before build.
- **THE COUPLING that makes B high-risk:** the push/deploy hard-deny fires **only under `posture=="governed"`** (`hook_check.py:387`); `git push`→`deploy`. So flipping a seat to `ungoverned` silently downgrades the SACRED hard-deny to advisory. Posture correctness is load-bearing for the hard-deny → B carries 4 mandatory regression tests incl. "git push still hard-denied under a real governed seat".
- **(C)** `pco-allocate --envelope-ref none` flows verbatim → claim `envelope_ref: "none"` → empty manifest → silent no-write-authority seat. Core `allocate(envelope_ref="none")` is INTENTIONALLY contracted (`test_pco_allocator.py:533`) → fix at CLI layer only (`--no-write-authority` opt-in + loud banner); don't touch the core.

version_boundary: none of A/B/C adds a module/check/shared→version edge → V3_RUNTIME stays 28, V1=21, registry=47 (unless an impl factors a new module — then `_versions.py` + `test_version_boundary.py` count, the A.1 lesson). Item 1 (stale-wheel dev-venv reinstall → editable) already DONE by orchestrator. Relates to [[ce-push-deploy-authority-model]], [[ce-governed-seat-cannot-push]], [[audit-findings-against-operator-directives]], [[ce-nvidia-v35-strategy]].

## Detail (moved from index 2026-07-05)
- push hard-deny posture-gated.
- examples/**/claims/ load-bearing for worktree-seat governance.
