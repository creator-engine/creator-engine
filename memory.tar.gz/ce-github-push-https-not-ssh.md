---
name: ce-github-push-https-not-ssh
description: "Durable host-state (2026-06-10): SSH port 22 to github.com is blocked on this dev box (git push over SSH HANGS); push via HTTPS using gh's credential helper. gh/HTTPS auth is healthy."
metadata: 
  node_type: memory
  type: reference
  originSessionId: 3d6c61d0-a2de-4549-96f6-26d4d9e12958
---

**Durable host-state (this dev box, observed 2026-06-10):** **SSH (port 22) to `github.com` is BLOCKED/unreachable** — `ssh -T git@github.com` times out (exit 124). The `origin` remote is an SSH URL (`git@github.com:creator-engine/creator-engine.git`), so a plain **`git push` HANGS silently** (the symptom: a backgrounded push task that never returns, no output past the first echo).

**NOT the cause (ruled out):** ssh-agent/keyring is healthy (`ssh-add -l` lists keys, `SSH_AUTH_SOCK=/run/user/1000/gcr/ssh`); HTTPS to github works; `gh api user` works (token auth fine). So it is specifically the SSH transport/port, not auth, not a general outage.

**THE FIX — push over HTTPS via gh's credential helper:**
```
gh auth setup-git                 # idempotent — configures git's HTTPS credential helper
git push https://github.com/creator-engine/creator-engine.git <branch>:<branch>
gh pr create --base main --head <branch> ...
```
Proven: pushed `v35e-site-onboarding` → opened PR #187 this way after the SSH push hung. **Always wrap git-network ops in `timeout` (e.g. `timeout 30 git push …`)** so a future SSH hang fails fast instead of stalling a background task. Do NOT rewrite `origin` to HTTPS globally without Operator sign-off (host-config change affecting all worktrees) — use the explicit HTTPS URL per-push. Sibling host-state of [[ce-validator-editable-install]]; surfaced during the [[ce-oom-crash-resume-script-footgun]] recovery (independent of the OOM — likely a network/firewall condition). Operator may want a durable fix (SSH-over-443, or switch the remote to HTTPS).
