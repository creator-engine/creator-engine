---
name: ce-dual-format-emission-doctrine
description: "RATIFIED 20260708: CE-native duality — two probabilistic engines (human + agent); every user-facing artifact ships BOTH formats: agent gets md/yaml (source/SSOT), human gets rendered HTML. md-sources ship INSIDE bundles by default."
metadata: 
  node_type: memory
  type: project
  originSessionId: 695aa14d-c79d-4e91-b1ae-53e0a0689b2d
---

**RATIFIED by Operator 2026-07-08** (during the Arad T4 md-sources decision): CE serves
two probabilistic engines — the human and the agent — and caters to each in its most
relevant format. The agent-facing format is md/yaml (the source, the SSOT); the
human-facing format is rendered HTML (offline, interactive where useful). This is now
the RATIFIED DEFAULT for all user-facing CE artifacts: welcome packs, guides, journey
emissions, completion reports.

**Why:** The install model is agent-pointed — the user's coding agent consumes the pack
as much as the user does. Shipping only HTML starves the agent; shipping only md starves
the human. The duality mirrors the human-side-harness insight ([[ce-guided-journey-ui-vision]]):
same content, one SSOT, two render targets — and the HTML must never become a second
source of truth (render of the md, not a fork of it).

**How to apply:** Bundles include the .md sources alongside index.html (md = source,
html = render; copy-clean blocks in both). Applies to [[ce-welcome-pack-html-primary]]
(which this generalizes), the dark-factory guide pattern, and future read-model/webui
emissions. Product-lens scrub ([[ce-public-docs-product-lens-doctrine]]) applies to BOTH
formats equally — the md ships to the tenant too.
