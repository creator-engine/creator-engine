---
name: ce-changelog-workflow-obligation
description: "Operator directive (2026-06-13): changelog maintenance is a FIRST-CLASS CE governed-workflow obligation — Controllers/seats author a changelog entry per release-surface change like real devs, CI-enforced"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 007fae82-2337-48b8-b3cc-8387a2280726
---

**Operator directive (2026-06-13):** changelog maintenance must be PART OF the CE workflow — Controllers (and their build seats) update the changelog when they change something, exactly as developers do at a software company. It is a **per-change obligation**, not a periodic chore.

**✅ DESIGN RATIFIED 2026-06-14 (ce-ops#65, "approved as written").** 6 OQs resolved (all per lead rec): docs/site = NOT release-surface · no-changelog ack = self-serve declaration · 0.2.0 span = to tag-cut · assembler = CE-native (no towncrier dep) · Scope-B lands after #226 · ramp = neutral→dogfood→require. Release-surface path-set = `validators/creator_engine_validator/**`. **Build = post-rehearsal** (scopes A–D, NOT rehearsal-critical); ratified WITHOUT a Codex review (proven carrier pattern, collision-clean). **0.2.0 backfill** (CHANGELOG.md → real 0.2.0 from the merged trail + `[Unreleased]`) queued as an immediate, docs-only, pre-rehearsal-safe win. Manual fragment-discipline is in effect NOW.

**Why:** CE is gaining active users + contributors (VPS pilot 14-Jun; #63 DCO/contributor-guide just landed). Today's `CHANGELOG.md` is a **stale stub** (pinned at "planned 0.1.0" while the product is at `0.2.0`/self-hosting), **0 git tags**, and **NOT CI-enforced** — so it silently drifted. A user/contributor-facing version-history surface is table-stakes for an SDLC product, and unenforced docs rot.

**How to apply (the CE-native shape — mirror the carrier pattern):**
- **Per-PR changelog FRAGMENT, not edits to one shared `CHANGELOG.md`** — same per-PR-file pattern as the `.ce/pr-manifests/<branch-slug>.md` carrier (ce-ops#21), so parallel seats don't hit the shared-file merge-tax. e.g. `.ce/changelog/<branch-slug>.md` with a Keep-a-Changelog category (Added/Changed/Fixed/Removed/Deprecated/Security); assembled into `CHANGELOG.md` + a GitHub Release at each version tag (git-cliff/towncrier-style, fed by CE's disciplined conventional commits).
- **CI "changelog-fidelity" gate** for release-surface PRs (touching `validators/creator_engine_validator/**` etc.): blocks merge if no fragment — same grader-outside enforcement as `verify-path-manifest`. Internal/no-user-impact changes consciously declare "no changelog" (a real-dev decision), never silently skip.
- **Mandate discipline:** EVERY release-surface gate mandate lists the changelog fragment in its closed manifest + instructs the seat to author it — like the carrier + wheel-pair rules. Apply this to every mandate composed from now on (manual discipline until the CI gate lands).
- Tie entries to **git tags + GitHub Releases** ([[ce-semver-milestone-policy]]); reconcile the dormant publication gate (tag `0.2.0` = self-hosting). The held batch (#54/#56/#58) + RS (#223) PRs add fragments when they rebase+land post-rehearsal.

Twin of [[ce-pr-path-manifest-carrier-required]] + [[batch-strict-mode-gate-workflow]] + [[ce-precondition-frontloading-doctrine]].

**2026-06-19 status + linkage:** the #65 changelog-fidelity CI gate is STILL unshipped (current CI enforces the path-manifest carrier + packaging contract, NOT a changelog gate); manual fragment discipline remains in effect. Per Operator 2026-06-19, #65 is folded into the [[ce-derived-artifact-trust-path-fix]] / ADR-0006 (ce-ops#133, #91) doc-currency pass — the changelog gate is the first concrete instance of the CURATED-layer staleness gate. Design-seat dispatch deferred until the #115/#113-P3 tracks land.

## Detail (moved from index 2026-07-05)
- + CI gate + named in every release mandate.
