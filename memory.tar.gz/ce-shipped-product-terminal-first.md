---
name: ce-shipped-product-terminal-first
description: "What CE actually ships today = governed CE, TERMINAL-FIRST (the user's own coding-agent TUI); the rest is ecosystem/internal — the definitive app-vs-ecosystem model"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9c67b023-0ac9-402b-9806-fa1c581c5303
---

Settled 2026-06-25 (Operator-driven), grounds all docs/website "what do we ship" copy. THREE tiers (openclaw-style):

- **🏭 The Engine — what `install.sh` gives a single user (the whole product for solo):** a governed CLI + governance **hooks** (per-tool deny gate) + the external **grader** (validators) + envelope/spine/ledger, wiring the user's OWN coding agent (Claude Code / Codex) through Frame→Shape→Build→Review→Ship on their repo. **TERMINAL-FIRST: `ce launch` opens the user's own agent TUI; CE is the invisible governance wrapper, not a replacement UI.** Single controller, uncontained, their creds.
- **🧩 Ecosystem add-ons (optional, scale into):** forge-automation/**belt** (autonomous merge-on-approval — Operator default = "the FIRST one-command add-on"), **cockpit** (optional read-only TUI; journey view Frame→Ship IS merged but behind the `textual` extra), **containment** (gVisor/herdr), **secret-identity/transport-deputy** (OpenBao). 
- **🔒 Internal-only (NOT shipped):** our fleet wiring (dev-1/3/4, our OpenBao + merge-queue config, the courier mechanics). tmux/herdr = internal transport, never user UX.

**UI honesty:** NO desktop/web app ships. `ce cockpit --serve` = the TUI in a browser (textual-serve). The web control UI = **ADR-0008 design + mockups (Vite+Lit, openclaw-grounded), NOT built** — mockups at `tmp/webui-shots/`. Honest line: "you use CE through your own coding agent; the journey cockpit + web UI are designed but not the shipped surface." Containment is the marketing headline ("Built with OpenShell") but ships as an in-flight add-on — Ecosystem page must carry maturity badges. [[ce-positioning-ease-not-governance]] [[ce-every-agent-containerized-direction]]

## Detail (moved from index 2026-07-05)
- NO web/desktop app ships.
- ecosystem=belt/cockpit/containment/secret-identity.
