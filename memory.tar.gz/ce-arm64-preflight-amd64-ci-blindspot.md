---
name: ce-arm64-preflight-amd64-ci-blindspot
description: DGX arm64 local preflight cannot see amd64-only test failures — green validate-pr can still go red in CI; check platform-gated tests when touching release-coupled pins
metadata: 
  node_type: memory
  type: project
  originSessionId: 24d4baec-5a34-4c46-86c1-fbdfbc0bf75a
---

Local `ce validate-pr` on the DGX (aarch64) skips/differs on platform-gated tests; CI's
amd64 runner executes them. 2026-07-05 incident: PR #841 (seat-image digest pin) was
preflight-GREEN locally but failed CI — `test_onboard_apply.py::
test_runtime_posture_emits_valid_default_docker_runtime_policy` (amd64-side) pinned the
seat-image placeholder digest `sha256:000…0` that the pin PR replaced.

**Why:** the baseline-diff gate compares local baseline vs local head — both arm64 — so an
amd64-only expectation change is invisible until CI.

**How to apply:** for any PR touching release pins/digests/image refs, grep tests for
hardcoded refs+placeholder digests across the WHOLE tree (not just tests that ran locally),
and treat the daemon skip-reason `governance_check_not_success` on an approved PR as the
signal to read the CI failure, not to retrigger. Prefer tests deriving expectations from
surfaces/manifest.yaml over literals. [[ce-run-full-preflight-before-push]]
[[ce-pr-path-manifest-carrier-required]]
