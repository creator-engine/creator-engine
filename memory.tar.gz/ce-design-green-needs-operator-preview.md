---
name: ce-design-green-needs-operator-preview
description: "Operator process rule (2026-06-12): design seats NEVER self-declare green — rendered-screenshot review vs the ratified reference + Operator preview gate green BEFORE any pr leg"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2bae9844-7348-4cd1-9a89-54226b622914
---

**Operator process rule (standing, 2026-06-12, ruled with the site-v8 PR1 rejection):**
**design seats never self-declare green.** A design gate's GREEN requires, before any
`cev3 pr` leg fires:
1. **rendered-screenshot review against the ratified reference** (render the actual artifact,
   compare to the design package's reference bar — not markup inspection), and
2. **Operator preview** — the Operator sees the render and gates green.

**Why:** the v8 PR1 seat passed every mechanical check I could run (manifest exact, snapshot
byte-identical, no scope creep, marker protocol exact) and STILL failed Operator design review
on visual quality — manifest/test gates cannot grade aesthetics; only a rendered artifact
against the reference + the Operator's eye can.

**How to apply:** bake both legs into every design-lane scope/mandate (the seat renders + the
Controller raises an AWAITING-OPERATOR preview before the pr leg); a design seat's marker is a
HANDOFF signal, not green. Twin of [[ce-website-design-claude-only]] (the routing half of the
same ruling); extends [[ce-awaiting-operator-queue-rule]].

## Detail (moved from index 2026-07-05)
- Related: [[ce-website-design-claude-only]] [[ce-website-versioning-policy]] [[ce-site-lane-resume]]
- rendered-shot vs reference + Operator preview before any PR.
