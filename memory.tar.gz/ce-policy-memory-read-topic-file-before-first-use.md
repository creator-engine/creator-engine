---
name: ce-policy-memory-read-topic-file-before-first-use
description: Policy-class memories (rules governing every action of a type) must be read in FULL from the topic file before first use each session — index hooks can be stale and have actively contradicted the ratified rule
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 24d4baec-5a34-4c46-86c1-fbdfbc0bf75a
---

2026-07-06 Operator postmortem demand (model-routing violation): the controller ran a whole
night of spawns on Sonnet 5 because the MEMORY.md index hook still said "every spawn sets
`model` explicitly / Sonnet=substantive" while the Operator's 2026-07-04 correction (pins
to Sonnet-4.6; OMIT `model` so frontmatter wins) lived only in the topic-file body, never
read. The index actively instructed the violation, and a later index trim faithfully
preserved the stale line.

**Why:** index hooks are recall cues, not SSOT; corrections get banked into topic files and
the hook can lag. For a rule that fires on EVERY action of a type (spawn routing, approval
mechanics, signing), acting from the hook alone turns one stale line into a whole-session
systematic violation.

**How to apply:** (1) Before the FIRST action of a governed type each session, open the
topic file in full — the hook only tells you which file to read. (2) When banking any
correction into a topic file, update the MEMORY.md hook line in the SAME edit — a
correction that doesn't reach the index is invisible next session. (3) When the Operator
asks "why did X happen," answer the failure CHAIN (what was consulted, what it said, what
was skipped), not just the mechanism. [[ce-model-effort-routing-policy]]
