---
name: ce-user-facing-vocab-no-bet-no-budget-frontload
description: "Operator ruling 2026-07-06 — \"bet\" metaphor is INTERNAL-only (off all user-facing surfaces); Budget is never front-loaded in user journey docs (subscription users, the majority, get the Goal/Done-when/Change-type trio; Budget = opt-in aside with % meter units)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 29dd98b5-49df-420a-bb46-8a29aafdd959
---

Operator ruling 2026-07-06 (Arad-pack review thread), extending the locked vocabulary trilogy ([[ce-stage-vocabulary-canon]], [[ce-shaping-ux-design]]):

1. **"Bet" is internal vocabulary.** The 2026-06-08 trilogy renamed Scope-card FIELDS user-facing (Goal/Done-when/Budget/Change-type/Ready over intent/acceptance_criteria/appetite/mutation_class/definition_of_ready), but the bet metaphor survived in user-facing prose (docs/guide/understanding-ce.md uses it 5×, incl. the mockup prompt "ratify & dispatch the bet?"). Ruling: extend the plain-language rule — user-facing surfaces say "approve the Scope"/"ratify" plainly; Shape Up bet/appetite lineage stays in docs/architecture/ only. Evidence it costs nothing: the codex-authored Arad journey guide used zero bet/appetite and lost nothing. Sweep of understanding-ce.md + product prompt strings rides the 0.3.4 journey-docs unit.

2. **Never front-load Budget in the user journey.** Most CE users ride SUBSCRIPTIONS not API ([[ce-no-anthropic-sdk-per-token-billing]]) — a $-budget setup is a concept they neither understand nor can use. The shipped CLI already supports this: `ce scope --budget` is OPTIONAL, and `--budget-unit %` (single-seat meter) with rolling_5h/rolling_weekly windows is the subscription-native cap; `$` = API-USD lane only. Ruling: quickstart/journey teaches the required trio **Goal, Done-when, Change-type**; Budget appears only as an opt-in aside ("on API billing, or want hard caps? set --budget"), lane-aware. Aligns with [[ce-cockpit-resource-envelope-routing]] (solo devs manage limits not $) and encode-recommendation-as-default.

**Why:** Arad-class users (CEO-mode, subscription, possibly non-technical) are the product's center of gravity; internal lineage vocabulary and API-lane concepts in their first documents create false complexity.
**How to apply:** any tenant-facing doc/journey/quickstart/pack authored from now on: no "bet"/"appetite", no Budget in the happy path. When writing the 0.3.4 journey doc pair (T1) and pack updates (T4), enforce as review bars. [[ce-public-docs-product-lens-doctrine]]
