---
name: ce-257-resign-merge-grant
description: "Operator standing grant 2026-06-19: once ce-ops#123 (PR #257 scanner mirror) passes author-rebase + first review + green, the dev-2 controller is authorized to re-sign (ce-root-v1) AND ratified to merge it autonomously."
metadata: 
  node_type: memory
  type: project
  originSessionId: 51ddd3b0-ba13-421c-a761-9039c84524ee
---

2026-06-19 (morning shift): The Operator reviewed the #257 situation in full and granted the dev-2 controller standing authority to COMPLETE PR #257 (ce-ops#123 brownfield scanner mirror) without further check-in, **conditioned on** the prerequisites being met first:

1. (1) author-quality rebase onto main resolving the `onboard_apply_live.py` conflict + (2) first-time independent review (reproduce + match the 4 scanner×arch sha256 + review scanner-exec wiring) + tests green — these MUST be done first (dev-3 = author, after Wave 3).
2. THEN: controller is **authorized to re-sign** (step 3, `ce-root-v1` — controller already has key + passphrase on laptop `~/.ce-keys/ce-root-v1`) **if a re-sign is needed**, and **ratified to merge** (step 4).

Bar carried regardless: reproduce hashes never transcribe [[ce-verifier-hash-false-positive]]; independent reviewer ≠ author. Grant is specific to #257; not a general re-sign/merge blanket. Related: [[ce-installation-grant-is-mint-ceiling]] [[ce-push-deploy-authority-model]].
