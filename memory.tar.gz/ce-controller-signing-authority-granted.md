---
name: ce-controller-signing-authority-granted
description: "GRANTED+VERIFIED 2026-07-08: persistent controller (CE-DEV-2) authorized to sign with ce-root-v1 (passphrase verified working) — release/spec signing no longer blocks on Operator; workers/standby still NEVER sign"
metadata: 
  node_type: memory
  type: project
  originSessionId: 46fbbf10-9bed-41a5-a4fd-040713bc0bcb
---

Operator grant 2026-07-08 (DECISIONS_20260708.md item 9): "you have the passphrase
for our OpenBao and I authorize you to sign so this too does not require anything
more from me." VERIFIED same day: ~/.ce-keys/ce-root-v1.pass unlocks ce-root-v1 and
derives a pubkey byte-identical to ce-root-v1.pub.

**Scope (exact — authority attaches to form):**
- The PERSISTENT controller (CE-DEV-2, this seat) may sign release/spec artifacts
  (e.g. the 0.3.4 cut, install-spec re-signs) without per-act Operator involvement.
- UNCHANGED: workers/seats NEVER sign [[ce-worker-must-not-sign-ce-root-v1]];
  standby/takeover controllers: signing categorically non-delegable (FORGE
  runbook + #883); ephemeral controllers: prohibited (#887 seam).
- Follow the spec-signing procedure playbook for the mechanics
  [[ce-release-spec-signing-procedure]]; signing events still get decision-file
  entries for audit.

Companion grant, same session: VPS passwordless sudo confirmed for the controller
(ssh dev1 = ce-dev-1, sudo -n PASS) — corrects the stale Jun-21 no-sudo claim in
[[ce-vps-tmp-fills-no-sudo]]; root ops on the VPS (e.g. ce-ops#184 tmpfs fix) are
controller-executable.
