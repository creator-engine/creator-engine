---
name: ce-release-spec-signing-procedure
description: "How the install apply-spec gets ce-root-v1-signed at release — offline root key on CE-DEV-2 only, team-mode Controller-signs handoff"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 7520a031-5b7e-497e-b56f-0427b09ba70a
---

Republishing/releasing the install apply-spec (`docs/llms-install.md`) requires a **`ce-root-v1` trust-root signature**. Production `onboard_apply.py` HARD-REFUSES any other `key_id` (`signed_spec_wrong_key`), so the dev-1 release key `ce-dev1-root-v1` passes `install.sh` but is REFUSED by `onboard --apply` — the exact path a republish exists to unlock. Governed seats (incl. dev-1) **structurally cannot sign**: the `ce-root-v1` PRIVATE key is Operator-laptop-held only, at `~/.ce-keys/ce-root-v1` on **CE-DEV-2** (0600; passphrase in `ce-root-v1.pass`; pubkey `…MLpJ`). Trust-root signing = a high-bar binding act, Operator-authorized EACH time — NOT covered by a standing "republish" grant (this is what dev-1 correctly escalated 2026-06-14).

Team-mode signing handoff (manual, per release):
1. Build seat emits `v3_installer.canonical_spec_bytes()` of its COMMITTED spec blob → a file; reports its sha256 (= the `content_sha256`).
2. Controller (on CE-DEV-2) pulls those exact bytes (verify sha256 across transfer) and signs:
   `ssh-keygen -Y sign -f ~/.ce-keys/ce-root-v1 -n ce-spec-v1 -P "$(cat ~/.ce-keys/ce-root-v1.pass)" <bytes>`
3. `value:` field = `base64 -w0 < <bytes>.sig` (base64 of the armored SSHSIG, single line). Verify the EXACT install path before handing off:
   `printf %s "$value" | base64 -d > s.sig; ssh-keygen -Y verify -f docs/keys/ce-root-v1 -I ce-root-v1 -n ce-spec-v1 -s s.sig < <bytes>` → must print `Good "ce-spec-v1" signature`.
4. Hand `value:` + `content_sha256:` back; build seat patches BOTH into the spec (`canonical_spec_bytes` placeholders those two lines out, so patching them never changes what the sig covers), re-verifies + greens suite + commits-LOCAL; Controller pushes.

This whole manual dance is the symptom motivating **ce-ops#80** (define + automate the release process). Minor hygiene debt: passphrase sits plaintext at `ce-root-v1.pass` next to the key. [[ce-dev1-own-credentials]] [[ce-push-deploy-authority-model]] [[ce-governed-seat-cannot-push]]

## Detail (moved from index 2026-07-05)
- seat emits bytes→Controller signs. Related: [[ce-base-only-refresh-microauth]] [[ce-257-resign-merge-grant]]
- s offline ce-root-v1 sig (CE-DEV-2 ~/.ce-keys only; the one non-delegable act).
