---
name: ce-release-process-design-ratified
description: "ce-ops#80 governed release process — RATIFIED 2026-06-16 (two-surface model + verify-release-surface-fresh gate)"
metadata: 
  node_type: memory
  type: project
  originSessionId: e2cf4ccf-fa9b-4239-ad01-0e065000d886
---

ce-ops#80 release/publish process — **RATIFIED by Operator 2026-06-16**. Design doc: `.ce/state/research/DESIGN_CE_OPS_80_release_process_20260616.md` (dual-written to VPS).

**Root cause (structural):** the *dev* wheelhouse is gated against source (`verify_wheel_matches_source` + `test_wheelhouse_built_surface.py`), but post-#224 the *published* mirror (`docs/downloads/<v>/`) is only checked for *internal* self-consistency, never matched to source → a source merge greens while the served surface silently stays stale (#226/#233).

**Ratified model — two surfaces:**
- **Surface A** = served mirror `docs/downloads/<v>/`: refreshes on EVERY installed-surface merge (not a tag).
- **Surface B** = immutable `git tag v0.X.Y` + GitHub Release: only at semver milestones.
Signing stays host-held `ce-root-v1` on CE-DEV-2 (Controller signs, seat re-greens; CI never holds the key — [[ce-release-spec-signing-procedure]]).

**Keystone = `verify-release-surface-fresh`** — Phase-0 pytest + CLI subcommand (sibling of `verify-path-manifest`) in `validate.yml`, fails closed, **content-hashes only (no signing key)**: asserts published mirror wheels hash-match the proven-fresh dev wheelhouse + the signed manifest's `sha256s_sha256`/per-wheel `sha256`/`install_sh` match the actual mirror files. Makes staleness impossible to merge.

**Sequencing (to not disrupt in-flight reviewed PRs):** merge #239/#238 → post-#239 manual republish (Phase-0 documented procedure; #239 is an installed-surface change → also unblocks dev-3 re-onboard) → THEN land the gate as its own PR. Relationships: [[ce-changelog-workflow-obligation]] (#65), #25 ce --version, #90 release-review identity, #224 pages-mirror, [[ce-semver-milestone-policy]].
