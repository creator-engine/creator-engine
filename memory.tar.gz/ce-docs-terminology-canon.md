---
name: ce-docs-terminology-canon
description: "When editing/adding canonical docs, use current CE terminology (Operator/Controller) + disambiguate the Hermes harness; ce_terminology_v2 is scoped to specs/v2 only, so docs/ canon is manual hygiene"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 66600213-b685-49ca-97ea-ab7b38539848
---

**Operator directive (2026-06-07, during G-4):** when authoring or editing canonical docs (esp. under `docs/`), build from a **current-terminology** source and use the canon: **Operator** (the human ratifying authority; legacy machine-role `source`) and **Controller** (the orchestrating author/coordination role; legacy `Hermes`-the-role). Always **disambiguate the Hermes harness** — the CE CLI / `.hermes/` toolchain / seat-launch substrate is a *tool* the Controller runs on, NOT the Controller role.

**Why:** pre-canon docs perpetuate `Source`/`Hermes`-role and conflate Hermes-role with Hermes-harness, undermining the terminology canon even where it's not mechanically enforced.

**Key scoping fact (verified):** the `ce_terminology_v2` check fires **only on artifacts under `specs/v2/`** (+ the bundled `ce-terminology-v2` fixtures) — it **never scans `docs/`** or `specs/001`/`002`. So docs terminology is **manual hygiene**, not a check failure. The legacy `source` role + `Source ratifies prompt:` line are **accepted on import** in `specs/001`/`002`; only NEW `specs/v2/` artifacts must emit `operator`.

**How to apply:** the `specs/001`/`002` corpus is still entirely legacy `Source`/`Hermes` (spec.md ~130/73). So do NOT blanket-rename a *reference* doc that mirrors/defers to that corpus — you'd desync it and break parity claims. Instead (the G-4 pattern, Operator-approved): add a **terminology-canon note** mapping the terms + disambiguating the harness, **convert the prose**, but **keep mirror-tables (e.g. the Actor/Tool Ownership Matrix) verbatim-aligned to the Feature-002 names**, with the note + a §h bridging clause. A full `specs/001`/`002` migration is a separate ratifiable gate. Bake "use current terminology + disambiguate the harness" into every doc-authoring/architect prompt. Twin of [[agent-research-discipline]].
