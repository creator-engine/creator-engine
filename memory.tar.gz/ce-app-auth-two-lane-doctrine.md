---
name: ce-app-auth-two-lane-doctrine
description: "RATIFIED 2026-07-03 — GitHub App auth is permanently two-lane; broker is default, self-custody kind:own stays first-class"
metadata: 
  node_type: memory
  type: project
  originSessionId: 731a9645-1f93-4719-ad13-113f9e5ec739
---

Operator ratified 2026-07-03: CE's GitHub-App auth is **permanently two-lane**. Lane 1 =
`kind: shared` + central CE-hosted mint-broker (default, low-friction; short-lived scoped
tokens; ce-ops#419 builds the deployable service). Lane 2 = `kind: own` (user registers own
App, holds own PEM locally, NO broker dependency ever) — stays a **first-class supported
option**, not a stopgap, because some users will refuse the central-service dependency
(availability + trust). Docs must present the choice per [[ce-user-choice-architecture]]
(broker as encoded default, own-lane as the no-dependency option). First live own-lane user:
Arad/mythos (App mythos-arad 4159494, installation 142925881).

**Why:** the broker makes CE an availability+security dependency; own-lane is the escape
hatch that keeps CE local-first-credible for security-conscious users/orgs.
**How to apply:** never design a forge feature that ONLY works via the broker; every
broker-path capability needs a kind:own equivalent (local PEM signer). When #419 ships,
migration to broker is opt-in, never forced.

## Detail (moved from index 2026-07-05)
- no broker-only features; broker migration opt-in.
- own self-custody stays first-class forever.
- kind.
