---
name: ce-agent-pointed-install-model
description: "CE's install novelty = user points THEIR agent at CE to install it (future norm w/ agent-out-of-box machines, NVIDIA+MS ~Sept 2026). 3 modes (agent-pointed / guided one-liner / one-liner-hands-to-agent); agent-install is FIRST-CLASS + GOVERNED (auto trust-verify + confirm-on-consequence + emit-audit), not forbidden."
metadata: 
  node_type: memory
  type: project
  originSessionId: 6bbff8e6-70c6-4729-b4d2-2376e936be75
---

Operator ruling 2026-06-23. Amends the night-arc #210 escalation "no onboarding-agent autonomous install-execution" — that was a controller-overnight HOLD deferred to the Operator; now ruled IN-SCOPE (governed).

**CE's NOVELTY over OpenClaw/NanoClaw:** a user installs CE by **pointing their own agent at it** — the agent reads CE's machine-readable install spec (`llms-install.md` already exists, signed) and carries out the install under the user's authority. Predicted to become THE norm once computers ship agents out-of-the-box (NVIDIA+Microsoft partnership, first machines ~Sept 2026 — aligns w/ the pitch timing).

**Three install modes (all supported):**
1. **Agent-pointed (PRIMARY/novel):** user's own agent reads CE's install spec + executes under user authority. CE's job = be cleanly agent-installable (verifiable, idempotent, well-specified steps).
2. **Guided one-liner (de-facto NOW):** single copy-paste one-liner → `install.sh` fully guided; human runs NO complex commands, script handles everything incl. the guided flow.
3. **One-liner-hands-to-agent (hybrid):** when install hits real complexity (infra/env/variable setup bash handles badly), the one-liner HANDS OFF to the user's agent to finish (user already has one; complex installs need agent reasoning).

**Safety rail (what the old escalation REALLY protected, sharpened):** the install agent = just another GOVERNED CE agent. **Auto trust-verify** (signature+DNS anchor, non-negotiable, before installing anything) + **confirm-on-consequence/irreversibility** (autonomous for low-risk reversible user-scoped steps: download/verify/venv/PATH-block; CONFIRM before sudo/system/cloud-infra/irreversible — `consequence×novelty×irreversibility` bar) + **emit audit record** (retrospective audit per [[ce-visibility-channel-emission-model]]). So "no autonomous install-execution" → **"no UNGOVERNED/unconsented install."** User invocation = consent.

**Handoff-confirmation UX (Operator 2026-06-23):** the user ALREADY consented by installing CE (explicit act) + ALREADY set trust via their agent's permission mode. Do NOT bolt on a scary re-confirmation — a non-technical user ("mom" who just wants her idea built) would ABORT. Resolution: **security is machine-side** (carry-only-verified-artifacts so the handoff can't re-open the trust chain; SAFE discovery `$CE_INSTALL_AGENT` → known harness binaries, NOT arbitrary-PATH scavenging) — done silently, no prompt. **The user-facing confirmation INHERITS the agent permission mode:** trusting/auto → NO extra prompt; cautious/ask → ONE super-friendly confirmation-of-FACT naming the agent ("I'll have Claude Code finish setting up — sound good? [Yes / use a different one]") — defaults to proceed, redirect-not-abort, ZERO jargon (never "authorize handoff"). Wording quality is load-bearing for adoption.

**Revises** the W5 `ce onboard` design (DESIGN_197_CE_ONBOARD.md): make agent-driven install first-class (NOT `--install-mode=print` default); print = manual fallback. The install agent is a governed agent.
Related: [[ce-v35e-onboarding-docs-lane]] [[ce-visibility-channel-emission-model]] [[ce-nvidia-v35-strategy]] [[ce-autonomous-authority-doctrine]] [[rehearsal-preflight-deployed-capability]] [[ce-installation-grant-is-mint-ceiling]].

## Detail (moved from index 2026-07-05)
- agent-install FIRST-CLASS + GOVERNED (verify+confirm-on-consequence+audit). Related: [[ce-install-dependency-model]] [[ce-autonomous-install-seat-bypass-flag]]
- r points THEIR agent at CE to install.
