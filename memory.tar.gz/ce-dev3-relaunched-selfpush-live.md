---
name: ce-dev3-relaunched-selfpush-live
description: dev-3 container relaunched 2026-07-02 to activate
metadata: 
  node_type: memory
  type: project
  originSessionId: dd93a51a-4d3b-4846-b875-08d845cb4ed5
---

dev-3 (contained VPS codex, container `ce-vps-codex`) was RELAUNCHED 2026-07-02
~05:43Z to activate the #723 launcher fix (egress broker socket parent-dir mount
+ dedup). The deferred controller op from the day-arc is DONE.

**Relaunch recipe that worked** (canonical launcher, as ce-dev-3 on the VPS):
`ssh dev1 'sudo -u ce-dev-3 env CE_VPS_IMAGE=creator-engine/codex-runsc:x86_64@sha256:<LOCAL_DIGEST> CE_VPS_REPO=/home/ce-dev-3/creator-engine CE_VPS_SEAT_ID=dev-3 CE_VPS_EGRESS_BROKER_SOCKET=/run/ce-egress/dev-3.sock CE_VPS_EGRESS_SELF_REVIEW_SOCKET=/run/ce-egress/dev-3-review.sock CE_VPS_CODEX_BIN=/home/ce-dev-3/.npm-global/bin/codex bash -c "cd /home/ce-dev-3/creator-engine && deploy/vps-runsc/run-vps-runsc.sh tui"'`

**GOTCHA:** the launcher's default `CE_VPS_IMAGE` pins a sha256 digest
(`42a402cd…`) that is NOT the digest of the locally-built image
(`f0032ada…` on the VPS). Default → `pull access denied … repository does not
exist` (there is no registry). Override `CE_VPS_IMAGE` with the LOCAL image
digest (`sudo docker images --digests creator-engine/codex-runsc`). Same class
of amd64/digest-pin footgun as the dev-4 arm64 base-digest issue (ce-ops#377).

**Verification after relaunch:** herdr pane responds (`herdr pane list` → w1:p1);
egress sockets mounted via parent-dir `/run/ce-egress/` (dev-3.sock +
dev-3-review.sock present, reachable); broker daemons alive
(`ce_egress_self_push_broker.py`, `ce_egress_self_review_broker.py`). The
self-push canary on branch `main` REFUSES (correct — broker enforces
branch-not-forbidden + author-allowlist); a clean GREEN canary needs a `ce-`
namespaced branch. Plumbing = proven working; the launcher fix is active.

Related: [[ce-dev4-rebuild-and-launch-canon]] [[ce-seat-relaunch-canonical-launch-only]] [[ce-contained-seats-have-git-egress]]

## Detail (moved from index 2026-07-05)
- GOTCHA = override CE_VPS_IMAGE with LOCAL image digest (default digest pin → pull-denied, no registry). Broker reachable; green canary needs a ce- branch.
- relaunched 2026-07-02 to activate #723 launcher fix.
