---
name: ce-welcome-pack-authorship-not-assembly
description: "Operator correction 20260708: welcome-pack work is AUTHORSHIP (top-tier model, content-architecture judgment), never assembly of existing md; T4 rot inventory + T5 canonical structure mandate."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 695aa14d-c79d-4e91-b1ae-53e0a0689b2d
---

**Operator correction 2026-07-08 (T4 Arad pack review):** I dispatched pack production
as an ASSEMBLY task (utility worker rendering existing md sources). The worker executed
faithfully, but the sources were architecturally rotten and only judgment could see it:
Welcome section stuffed with install content; NO explicit install section (Quickstart
assumed an install never shown); DEV mode presented as default when CEO MODE IS THE
DEFAULT (CEO missing entirely); spec-kit framed "being retired" when it HAS been retired
([[ce-speckit-full-retirement-ce-native-init]]); legacy .hermes instructions still
present (retired). Operator: "seeing how this has been bungled I want Fable level
intelligence doing this task properly."

**Why:** Rendering preserves rot. Content architecture (structure, mode ordering,
journey design) is authorship and needs the top-tier model with full doctrinal context
— the subagent-efficiency directive routes MECHANICAL work down-tier, not judgment work.

**How to apply:** (1) Welcome-pack and onboarding-doc revisions = fork/controller-tier
authorship tasks grounded in origin/main canon (tmp/ md sources are NOT canon — main
wins on conflict). (2) Canonical pack structure (T5 mandate): Welcome = short
orientation + where-to-go-next ONLY → dedicated "How To Install CE" section right after
Welcome → CEO-mode-first everywhere with DEV mode second (researched placement pattern)
→ pack itself designed as a guided journey (First Hour/Day/Week, you-are-here) →
tenant-neutral core + swappable "Your Pilot" addendum for tenant specifics.
(3) Purge-list greps for any pack revision: `.hermes`, `spec-kit`/`speckit`, "being
retired", DEV-default framing. [[ce-welcome-pack-html-primary]]
[[ce-dual-format-emission-doctrine]] [[ce-guided-journey-ui-vision]]
