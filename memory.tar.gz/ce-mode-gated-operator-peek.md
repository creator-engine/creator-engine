---
name: ce-mode-gated-operator-peek
description: "Operator-ratified cockpit requirement — mode-gated \"peek\" (inspect + interact) into headless contained controllers"
metadata: 
  node_type: memory
  type: project
  originSessionId: 3f9a25b8-879d-4819-b9bd-3847f6b938a9
---

Operator decision 2026-06-24 (ce-ops#226). Contained controllers now run safely **headless** — proven live (CEO/strangeLoop endgame, [[ce-energy-efficiency-ceo-mode-gravity]]). Headless work runs as a separate `codex exec`, invisible in `herdr attach` (which shows the idle interactive TUI pane). The cockpit MUST give the operator a **peek**: (a) visually inspect a controller's live activity AND (b) interact/intervene (send input — not read-only).

**Mode-gating:**
- **Dev mode → opt-OUT** (peek available by default; operator is hands-on).
- **CEO + strangeLoop modes → opt-IN** (capability exists, defaults OFF — delegated, but the operator is NEVER locked out and can always drop in).

Principle: **autonomy by default, not by walls.** Design home = herdr cockpit base (ce-ops#217 interactive/multi-session attach) + headless visibility backend (ce-ops#207) + journey-cockpit Dev-vs-CEO modes ([[ce-journey-cockpit-vision]], #45). This is the concrete closure of the witnessability gap: the *reliable* dispatch (`codex exec`) must also be witnessable + interactive through herdr, per mode. Relates to [[ce-cockpit-pivot-herdr-base]].
