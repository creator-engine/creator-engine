---
name: ce-speckit-superpowers-whathow
description: "Spec Kit + Superpowers WHAT/HOW combination for CE — research findings, ratified execution-contract rulings, role taxonomy lane"
metadata: 
  node_type: memory
  type: project
  originSessionId: 9d73b5a5-8838-47f6-9513-e86697828b8b
---

**Lane opened 2026-06-18.** Codex researcher (read-only, grounded in real repos) investigated combining GitHub **Spec Kit** (WHAT — spec/plan/tasks as durable ratified contract) + **Superpowers** (HOW — workflow discipline: worktree, strict TDD, one-subagent-per-task, review, finish). Report: `.ce/state/research/RESEARCH_speckit_superpowers_ce_combination_20260618.md` (Spec Kit @ `2dd1ca4`, Superpowers @ `b62616f`, CE @ `e211ce1`).

**Core finding:** CE already has BOTH halves — Frame→Shape = WHAT, Build→Review→Ship = HOW. CE is STRONGER than both on governance (external grader, Operator ratification, mutation classes, author/approver separation, PCO fan-in). CE is WEAKER on: (1) always-on skill ergonomics, (2) baked-in strict-TDD worker law, (3) the explicit ordered-tasks→execution **`do_not_replan` handoff contract**. Highest-leverage adoption = a CE-native **ratified-tasks → worker-execution contract** (`tasks.ce.yml` + `do_not_replan` + spec/plan/tasks SHA-binding + role-scoped task briefs + one visible worker/task + independent review + fan-in). [[ce-stage-vocabulary-canon]]

**RATIFIED 2026-06-18 (Operator):**
- **Strict TDD MANDATORY** for every code/schema task (explicit ratified waiver only).
- **One-worker-per-task = hard default**; Shape may bundle disjoint low-risk tasks only by explicit declaration.

**Controller recs on remaining open questions (awaiting Operator ratification):** OQ3 keep `researcher`/`integrator` as operational labels not schema enum (avoid sprawl); OQ4 auto-bootstrap governed-worker-lanes only, phased per-harness, never Operator/controller sessions; OQ5 ledger = ephemeral `.ce/state` + tracked summary packet at Review/Ship; OQ6 `/speckit.implement` → internal helper under CE task-brief executor (CE owns Build execution); OQ7 upstream-sync = pinned SHAs + on-release AND on-touch.

**ALL OQ recs RATIFIED 2026-06-18** (OQ3=labels, OQ4=governed-lanes-only/phased, OQ5=ephemeral+tracked-packet, OQ6=speckit.implement→internal-helper, OQ7=pinned-SHA+on-release/on-touch).

**Ticket sequence (dependency-ordered, from report §E.4):** (1) role taxonomy = **ce-ops#118 RATIFIED** (sibling of #116 [[ce-terminology-seat-to-worker]]); (2) KEYSTONE `tasks.ce.yml` handoff contract + `do_not_replan` SHA-binding = **ce-ops#119 BUILT 2026-06-18, commit `5d5825f`** in worktree `ce119-handoff` (schema `task-handoff.schema.yaml` + check `task_handoff_contract.py` + 19 strict-TDD tests w/ recorded red→green + `docs/contracts/task-handoff.md` + wheel rebuilt; path-manifest PASS). **NOW in dev-2 review→land queue** (distinct-controller review per ADR-0003); (3) task-brief generator + progress ledger; (4) strict-TDD evidence fields + validator gate; (5) role-scoped worker bootstrap; (6) task-scoped review evidence + fan-in; (7) upstream-sync check. #3–#7 filed against #119's contract once its schema lands. REJECT anything weakening external grading / independent review [[ce-no-mvp-quality-from-day-1]].
