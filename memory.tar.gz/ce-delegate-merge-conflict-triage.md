---
name: ce-delegate-merge-conflict-triage
description: Conflict assessment + rebase/merge mechanics = worker tasks; never burn controller context on git archaeology
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 49d77c00-85d4-4d3a-ae60-140408d981bf
---

Assessing a PR's conflict level (mechanical base-drift vs. deeper work needing a controller) and the rebase/resolve/rebuild/merge mechanics that follow are **worker tasks** — dispatch a sub-agent/worker for them; do NOT do the git archaeology (fetch, merge-tree, worktree rebase, reading conflict hunks) inline in the controller session.

**Why:** Operator correction 2026-06-21 — I started inspecting #296/#297 conflicts inline (worktree rebase, sed-ing conflict markers) instead of delegating. That is exactly the mechanical work that should not take up a controller's attention or context. The controller's job is to dispatch the triage/merge worker and hold the merge GATE (the binding act), not to resolve conflicts by hand.

**How to apply:** On any "merge PR X" that isn't a clean fast-forward, immediately dispatch a worker (worktree-isolated) to assess + (if mechanical) rebase/resolve/green/push, with a STOP-and-report rule if a conflict is non-mechanical. Give it the credential-discovery too. Controller does the final ratified merge or supervises the worker's merge. Same principle as [[ce-controller-steers-seats-execute]] and [[ce-controller-spawns-many-workers]] — this is the merge/conflict-specific instance.
