---
name: ce-controller-parity-iac-ssot-doctrine
description: "Operator direction 2026-07-07 — governed CE controller underperformed the ungoverned bespoke instance; gap = harness/authority/codified workflow, NOT model. CE controllers must be IaC-deployable and SSOT-fed (info + tools) from the forge."
metadata: 
  node_type: memory
  type: project
  originSessionId: edf19c2d-23e4-4021-942f-766a3d922458
---

**The 2026-07-07 standby-window finding, elevated to direction (Operator, ~18:xxZ):**

The codex standby was a PROPER CE-governed controller (launched via the canonical path) yet it
performed strictly WORSE than the ungoverned bespoke controller (Claude launched raw via
`claude --dangerously-skip-permissions`). Throughput collapsed for four verified reasons:
1. **Gate paralysis** — treated the AGENTS.md-vs-handoff authority conflict as a total stop
   (not even PR comments); ready work piled up undischarged.
2. **No intake** — round-cycled existing PRs only; never restocked seats; every queue empty.
3. **Serial venue** — one-at-a-time seat-delegated reviews, no controller-side parallel worker
   fleet; pressured reviewers into thoroughness shortcuts.
4. **No codified forge loop** — verdict posting, claims upkeep, carrier mechanics live only in
   the primary controller's session practice.

**The strategic reading (Operator's words, near-verbatim):** the capability gap was "almost
entirely harness, authority, and codified workflow, not raw model." The bespoke harness
*instance* is optimized better than the CE product itself — meaning CE's most capable (only
truly functional) controller is a snowflake on one host; if the DGX burns, the factory loses
its controller. **The gap is access to information and bespoke tools.**

**Direction (MUST close):**
- CE controllers must be **IaC-deployable** — spin up a controller from code, no hand-tuning.
- Once deployed, a controller gets EVERYTHING it needs — **information AND tools — from a SSOT
  in the forge** (not from a resident session's memory, not from host-local scratch state).

**Existing slices already in flight (link, don't duplicate):** ce-ops#488 (hydration contract —
decision/lesson records + `ce brain hydrate`), ce-ops#495 (forge-housekeeping runbook in
takeover hydration), the #471 drill program (gate authority under takeover). Program ticket: **ce-ops#496**. Child slices: **#497**
(scratchpad-tooling absorption — zero session-authored scripts acceptance), **#498** (Hermes +
NanoClaw first-class controllers, timeframe RATIFIED 2026-07-07: T0 Jul 21 matrix rows/adapter/
seam-design → T1 Aug 11 governed worker unit each → T2 Aug 31 parity acceptance test +
NanoClaw ephemeral loop — pre-NVIDIA-pitch). [[ce-codex-standby-forge-housekeeping-gap]]
[[ce-orchestration-replaces-model-upgrade-pitch]] [[ce-two-plane-os-architecture-ratified]]
[[ce-ephemeral-controllers-nanoclaws-direction]]
