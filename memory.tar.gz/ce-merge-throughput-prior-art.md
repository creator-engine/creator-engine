---
name: ce-merge-throughput-prior-art
description: "WHERE the 'how do GitHub/Microsoft/Google solve reviewed-head-vs-merged-head?' discussion + conclusions live: ce-ops/designs/ce-merge-throughput-prior-art-20260612.md. Conclusion = GitHub merge queue; trigger ≥3 concurrent PRs OR 3rd authoring host (NOW HIT)."
metadata: 
  node_type: memory
  type: reference
  originSessionId: f6051cd7-5007-4d0f-9f8a-6ce9e4fbfe1f
---

**The "how was the reviewed-head-vs-merged-head problem solved by the software giants (GitHub/Microsoft/Google)?" discussion + conclusions** — sparked 2026-06-12 by the per-PR-carrier gate-spec (ce-ops#21) + the serial-merge tax — is durably saved at:
- **`~/projects/ce-ops/designs/ce-merge-throughput-prior-art-20260612.md`** (PRIMARY — the private durable repo, web-grounded reference report "Merge-Throughput Prior Art — Industrial Solutions & CE Adoption Recommendation") + a `~/Documents/` working mirror.
- Companion CE designs (same date, same lane): `ce-f6-merge-concurrency-design-DRAFT-20260612.md` (the CE F6 design), `ce-f6-merge-concurrency-fork-inventory-HOLD-20260612.md` (fork inventory), `ce-21-per-pr-carrier-gate-spec-DRAFT-20260612.md` (the spark).

**Conclusions:** the giants all solve reviewed-vs-merged-head the SAME way — **test the speculative MERGE state (what gets merged IS what's tested) and reject any locally-forged merge unless bit-identical** (report §6, the F6 adjudication, with a per-system table). Prior art surveyed: GitHub native **merge queue** (prime candidate — public-repo free, tests the `merge_group`, composes with `enforce_admins`), bors-ng/homu, OpenStack Zuul (speculative dependent pipelines), Uber SubmitQueue / Chromium CQ / Google TAP (extreme scale), Mergify/Trunk (vendor). **Recommendation = phased: Phase 1 (trigger = ≥3 concurrent ratified PRs/week OR a 3rd authoring host) → enable GitHub merge queue** (drop the up-to-date rule, add `merge_group` to CI, decide the squash fork); Phase 2 (only if MQ ceiling hit) → bors-lineage self-host. CE's binding external gate is preserved (the queue only merges after CE's required checks pass on the merge group; audit post-hoc).

**⚠️ THE TRIGGER IS NOW HIT (2026-06-14):** the `#225→#223→#226` serial-merge tax (the collapse) + onboarding **ce-dev-3 (a 3rd authoring host)** = exactly the Phase-1 condition. **Cite this prior-art + adopt GitHub merge queue — stop re-deriving the merge tax from scratch each time** (the "forgetting" this memory exists to end). [[ce-batch-pr-merge-tax]] [[ce-base-only-refresh-microauth]] [[ce-vps-install-rehearsal]] [[ce-learning-reference-reports]]
