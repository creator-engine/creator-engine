---
name: ce-brain-supersession-brief-checklist
description: "Any unit editing a brain-pinned artifact needs THREE things pre-authorized in the brief — ledger path, main-vintage ce invocation, count-ratchet test bump"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d9bfe94b-1dfa-43f4-960c-a14a67aa550b
---

ce-446 (2026-07-05) cost THREE blocked-seat round-trips on one unit because the brief authorized
none of the follow-on obligations of editing a brain-pinned artifact (.github/workflows/validate.yml).

**Why:** editing any artifact with a tracked brain assertion pin triggers a chain: (1) the drift
gate demands a ledger supersession → `.ce/brain/assertions.yaml` must be in the closed set;
(2) `ce brain correct/verify` on a seat with an installed wheel older than the ledger vintage
false-REDs (CE-BRAIN-LEDGER-INVALID) → brief must mandate main-vintage invocation
`PYTHONPATH=validators python3 -m creator_engine_validator.ce_cli <cmd>`; (3) the supersession
raises the active-record count → `validators/tests/unit/test_ce_brain_drift.py` count-ratchet
assertion must be bumped → that file must be in the closed set. Per
[[ce-brain-evidence-pin-doctrine-ratified]] ("count-ratchet bump in every supersede brief") — the
doctrine already said this; the brief just didn't apply it.

**How to apply:** before dispatching ANY unit that touches a file appearing as `evidence_ref`/
`scope.artifact` in `.ce/brain/assertions.yaml` (grep it first), include all three items in the
original brief: ledger path in closed set + main-vintage invocation line + ratchet test in closed
set with the expected count bump. Related: [[ce-validate-pr-brain-drift-false-red]], stale-wheel
skew = ce-ops#49.

## Detail (moved from index 2026-07-05)
- else 3 round-trips (ce-446 lesson).
- main-vintage ce + count-ratchet test.
