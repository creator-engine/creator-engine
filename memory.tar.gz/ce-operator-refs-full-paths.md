---
name: ce-operator-refs-full-paths
description: "Operator directive 2026-07-08 — any artifact referenced to the Operator (previews, reports, queue items) must include its FULL absolute path"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f99580bf-11af-4c3c-9cba-aa07611522b9
---

Operator directive (2026-07-08, on the AWAITING-OPERATOR queue): when telling the Operator
about an artifact — a preview to open, a report to read, a file in their queue — always give
the **full absolute path**, never a short name like "T5.1 preview".

**Why:** the Operator acts on these items directly (opens them in a browser/editor); a short
label forces them to ask or hunt. This is the second time path-omission cost a round-trip
(first: "T4→T5 preview — I need the full path", same day).

**How to apply:** every ⏸️ AWAITING-OPERATOR item and every "in your hands" deliverable line
includes the absolute path (e.g. `/home/cedev2/creator-engine/tmp/ce-welcome-pack-t5/index.html`).
Same for resume-state files listing Operator-queue items. [[ce-awaiting-operator-queue-rule]]
