---
name: ce-brief-novelty-check-semantic-not-grep
description: "Novelty checks in dispatch briefs must test the deliverable seam, not a bare keyword grep — bare greps false-positive on unrelated hits and cost a BLOCKED round-trip"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bf3ba1e9-857f-48aa-b00e-01842235e58a
---

A dispatch brief's novelty check ("verify not already landed before coding") must be SEMANTIC —
phrased against the actual deliverable seam — not a bare keyword grep.

Occurred 2026-07-04: the ce-440-s2 brief said "grep ce_cli.py + v3_cli.py for `deprecat` (must be
zero hits)". dev-4 correctly followed it and signaled `BLOCKED already-landed` on v3_cli.py:4499 —
an unrelated `--work-root` argparse help string ("deprecated and refused"), not the cev3-binary
deprecation notice S2 was to add. Cost: one full BLOCKED→verify→addendum→resume round-trip.

**Why:** seats execute checks literally (that's the point of [[ce-verify-not-already-landed-gotcha]]);
an over-broad check converts their discipline into a false stop.

**How to apply:** when authoring the novelty check, name the seam the deliverable lives in
("a stderr notice emitted on the cev3 console-script invocation path in v3_cli main()"), not a
token that can appear anywhere in the file. If a grep is the mechanism, scope it (function/region)
and tell the seat what non-matching hits look like. Corrections still go pointer+SHA as an
addendum file per [[ce-seat-dispatch-prompt-pointer-sha]].

**Second failure mode (2026-07-05, ce-npm-path-fix): presence-of-fix ≠ reachability-of-fix.**
The seat found an `npm prefix -g` fallback present on main and signaled already-resolved — but the
fallback was UNREACHABLE (the buggy `npm bin -g` primary captured stdout error text, so the
`[ -z ]` fallback branch never fired; live canary had the corrupted PATH in hand). Phrase novelty
checks as a BEHAVIORAL bar ("does a tenant on npm>=9 get a clean PATH? reproduce with a stub")
rather than "is the fix-looking code present". When the brief stems from live canary evidence, say
so and require the seat to REPRODUCE before concluding resolved.

**Second failure mode (2026-07-05, inverse — false NEGATIVE):** the controller's own pre-dispatch
novelty probe for the ce-443 stuck-lease runbook grepped only `playbooks/ docs/` — but the
deliverable already existed at `deploy/conveyor-daemon/RUNBOOK.md` (landed via ce-388 the day
before). Cost: a duplicate PR (#829) needing a consolidation amendment. Rule: novelty greps run
against the WHOLE tree (`git grep origin/main -- .`), never a presumed-location subset; then
judge hits semantically. Both failure modes are the same root: the check must target the
deliverable seam, not a convenient keyword-or-directory approximation.

## Detail (moved from index 2026-07-05)
- bare keyword greps false-positive → BLOCKED round-trip (ce-440-s2).
