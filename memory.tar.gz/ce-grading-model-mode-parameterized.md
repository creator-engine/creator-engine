---
name: ce-grading-model-mode-parameterized
description: "RATIFIED grading/ratification model: independence = MODEL-diversity not identity; stack parameterized by delegation-level (run-mode); spine-first, autonomous merge HELD behind contained controller"
metadata: 
  node_type: memory
  type: project
  originSessionId: 61b01e4e-f0fa-453a-90f8-03a849b5c415
---

ADR `ADR_grading_ratification_model_20260626.md` (`.ce/state/research/`) RATIFIED by Operator 2026-06-26. Answers the "approver ≠ author identity" / sub-agent question and gates the live executor.

**Core finding (load-bearing):** reviewer independence is primarily a property of **model weights**, NOT identity or context-isolation. A same-model reviewer (even a different seat/identity) shares the author's *correlated errors* + self-preference (Kim 2025; Panickssery 2024; intrinsic self-correction degrades absent an external oracle — DeepMind 2024). So a context-isolated **different-model** sub-agent of the SAME seat **beats** a same-model second seat for correctness. The naive "approver ≠ author identity" merge guard is REJECTED — wrong-axis (identity defends forgery/collusion, not correlated blindness) and unsatisfiable at N=1.

**The model = stack + ratifier:**
- **Always-on deterministic spine = primary counting grader, every mode** (CI/validators/refusal-Ring1/`--require-carrier`/baseline-diff/tests). It's the external verifiable signal every agent grade anchors to, and what GitHub branch-protection structurally can't give a solo dev = CE's differentiator. No semantic grade counts on a red spine.
- **Semantic grader** = governed distinct venue with own identity/transcript/evidence/fan-in, **cross-model + adversarial + authorship-obfuscated**. Hidden background sub-agent NEVER counts.
- **Wall stays two-layered** (GitHub APPROVED necessary + HMAC approval-capability sufficient) + mode-appropriate independence attestation + risk-tier routing.

**Operator refinements (the decision log, §9 — these are the durable rulings):**
- **Organizing axis = DELEGATION LEVEL (CE run-mode), NOT team size.** Grader stack + human-ratifier scope = `(run-mode) × (risk tier) × (available model diversity)`. CE respects the user's grant and "does its best with what the *user* granted." Dev mode = human opted-in covers irreducible set; CEO/strangeLoop = user delegated review → spine + max available model-diversity, no synthesized human gate. Ties [[ce-energy-efficiency-ceo-mode-gravity]] [[ce-user-choice-architecture]].
- **Irreducible set + single-model fallback are MODE-relative, not fixed lists.**
- **Sequencing: spine-first NOW, autonomous live-merge HELD behind contained controller.** Build now = additive safety only (spine, mode-param + independence attestation on evidence, interim no-controller-self-approval). HELD = un-stubbing the privileged-action broker for autonomous merge (the stub in `devops_privileged_action_broker.py`). Rationale: spine can only ADD gates; only autonomous actuation can break things, and that waits for containment (Operator top priority).
- **Human-ratifier exit = ENDGAME not permanent.** Full agent autonomy of the irreducible set is the named industry endgame (Anthropic/Cursor/Steinberger), gated on a demonstrated-maturity bar; current posture keeps the human in.
- **`policy_sha` must bind mode+tier** so a permissive-mode capability can't replay as a stricter-mode approval.

Refines ce-ops `ADR-0003-reviewer-independence-isolation-domain` (adds the model-diversity axis + solo relaxation) and closes three-deputy §92 step-5 for the grading axis. Implementation = separate Source-ratified slice. Related: [[ce-three-deputy-governance-model]] [[ce-contained-seats-cannot-submit-reviews]] [[ce-review-model]].
