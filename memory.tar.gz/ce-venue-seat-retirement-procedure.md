---
name: ce-venue-seat-retirement-procedure
description: How to retire a spent governed reviewer venue / seat from the orchestrator shell (pco-release is unreachable there)
metadata: 
  node_type: memory
  type: reference
  originSessionId: 0dd6e0d5-5231-47c3-ba50-45bcdf86f9d1
---

Retiring a spent CE-governed seat from the **orchestrator (non-governed) session** — verified 2026-06-08 retiring PR172-Reviewer (%662) + a free controller (%611).

**Only retire a seat at a clean final stop with no further work** (e.g. a reviewer venue that already submitted its `gh pr review` — determination is durable on the PR; an author seat only AFTER its PR merges, since reviewer findings would route back to it).

**Procedure:**
1. **Save the transcript first.** `tmux capture-pane -p -t <pane> -S - > ~/Documents/ce-seat-transcripts/<seat>-<date>.scrollback.txt`. For a venue the raw `.jsonl` lives in a *dedicated* `~/.claude/projects/-home-...-ce-review-venues-<venue>/` dir (stable, copy it too). The **main-repo** project dir (`-home-nefarious-projects-creator-engine-canonical`) rotates `.jsonl` filenames fast (compaction) and several active seats share it → can't reliably pin one seat's `.jsonl`; scrollback is the fallback and is sufficient.
2. **Kill the pane:** `tmux kill-pane -t <%id>`. Each seat = its own tmux window, so this frees the window too. Identify your OWN pane via `echo $TMUX_PANE` and never kill it.
3. **Venue-only teardown** (free controllers have no pco footprint, skip): the governed `pco-release` IS reachable from the orchestrator as a **validator subcommand** — `PYTHONPATH=validators validators/.venv/bin/python -m creator_engine_validator pco-release` (NOT a standalone binary and NOT `ce pcl`; that's why a PATH/binary search comes up empty). It must run from inside the venue worktree (refuses from root) and is finicky (exited 1 even on prior "successful" g20021/g20030 cleanups). The by-hand equivalent below is safe because these are gitignored instance-local operational markers, NOT the signed `ce pcl` chain:
   - `git worktree remove --force /home/nefarious/projects/ce-review-venues/<venue>` then `git worktree prune`
   - `rm -rf .hermes/active-work-ledger/{claims,leases,panes}/ce-claude-<lane>-reviewer .hermes/active-work-ledger/locks/<lane>-review.lock`
   (For a *governed* teardown instead, run `pco-release` from inside the worktree on a governed seat — but it's finicky, exited 1 even on prior "successful" g20021/g20030 cleanups.)

`ce` lives at `validators/.venv/bin/ce` (not on PATH from a bare orchestrator shell). The active-work-ledger already carries many stale unreleased claims from long-merged gates (g20021/g20073/pr109/pr146/pr151…) — a separate hygiene sweep, low-harm. Twin of [[ce-push-deploy-authority-model]] (orchestrator session does the mechanical ops authoring seats can't) + [[ce-controller-launch-method]] (the launch side).
