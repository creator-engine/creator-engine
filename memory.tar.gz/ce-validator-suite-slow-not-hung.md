---
name: ce-validator-suite-slow-not-hung
description: "Full `pytest validators/` is SLOW (~tens of min), not hung — don't kill it early"
metadata: 
  node_type: memory
  type: project
  originSessionId: 12107b9f-7ec9-45ea-ac1d-acc36f811671
---

**Durable env fact (2026-06-10, host):** the full `pytest validators/` suite runs
for **tens of minutes serially** and can look hung — a single integration test
(`test_ce_runtime_evidence_examples.py::test_check_examples_includes_runtime_evidence`)
takes **~66s alone**. Cause: `cli check-examples` runs **every registered check
per example path** (~15 paths), and heavy checks re-scan the whole tree each call —
`version_boundary.build_edges` AST-walks the entire `creator_engine_validator`
package; `pane_registry`/`container_instance.iter_container_instance_records`
`rglob`s. With `pytest -q | tail`, stdout buffers so the output file stays **0
bytes until the very end** — reinforcing the false "hang" impression. A process
pinned at **99% CPU, STAT R** (not D/sleep) is *grinding*, not deadlocked.

**Why:** I killed it at 16 min thinking it hung, then proved baseline `f5be2f6`
"hangs" too — but timing the isolated test to completion (66s) showed it just
needs time. No `pytest-xdist` installed; host = 12 cores / ~10Gi free (parallel
would be safe but env unchanged).

**How to apply:** budget **45–60 min** for a full `validators/` run; launch it in
the background with a long timeout and confirm completion by the process exiting
(not by tailing buffered `-q` output). Don't deselect or "fix" these checks —
they pass, they're just slow. Only the umask `test_hook_scripts_…_posix_sh` is a
tolerated F. Pairs with [[ce-oom-crash-resume-script-footgun]] (watch RSS if you
ever parallelize).
