---
name: ce-claude-seat-worktree-isolation-launch
description: "How to launch an ISOLATED Claude build seat via `cev3 drive --spawn` (the CC-D-7 mcp-config gotcha + work-claim/manual-lock conflict)."
metadata: 
  node_type: memory
  type: reference
  originSessionId: b6ecb753-e72e-431e-a479-7b9d57560d78
---

Launching a **Claude** governed build seat in an isolated worktree (proven 2026-06-13, ce-ops#43).

- `cev3 drive --spawn` runs the seat in the **current cwd** and writes the seat's mcp config under `<--root>/dispatches/<run_id>/mcp/ce-mcp.json`. Ring-0 **CC-D-7** requires the launched `--mcp-config` to be a NON-escaping RELATIVE path from cwd (`v3_seat_bridge.py:489-496`).
- **Consequence:** a Claude seat CANNOT launch in an external worktree with `--root <main>/.ce/state` — the relpath escapes with `..` → refused (`launch_refused`). (Codex seats are exempt; CC = Claude Code.) This is why codex seats run from `ce-worktrees/` fine but claude ones don't.
- **FIX (Claude + isolation):** copy the ratified scope into `<worktree>/.ce/state/scopes/`, then run drive from **inside** the worktree with `--root <worktree>/.ce/state`. mcp config lands in the worktree → clean relpath. The run's state (dispatch/events/evidence) then lives in the **worktree's** state root, NOT main's — monitor `<worktree>/.ce/state/dispatches/<run_id>/events.jsonl` directly (the cockpit reading main's root won't auto-see it).
- **Bonus:** the seat edits its OWN worktree `validators/` copy → the orchestrator's editable install + the live Ring-1 hook stay stable through the build.
- **Gotcha — detached HEAD:** worktree spawns leave the worktree on a detached HEAD; create the named branch yourself BEFORE the seat edits (`git -C <wt> checkout -b <scope-id>`), so local commits land on a pushable branch.
- **Gotcha — claim conflict:** do NOT post a manual `🔒 in-compose` comment when you'll use `cev3 drive --ticket` — #218 `work_claims` parses it as a "legacy" claim and the auto-acquire foreign-refuses (`claim_active_foreign_claim`). The structured `wclaim-…` IS the forge-visible lock. Release a stale self-claim programmatically: `work_claims.release(parse_ticket(t), _make_gh_runner())` (no CLI exists). Same-holder re-acquire can still lose the deterministic re-read to an un-released prior claim (`claim_lost_after_reread`) — release first.
- `cev3 drive` needs a Ready+ratified Scope: `cev3 scope <ID> --goal … --change-type … --done-when … --budget N --budget-unit % --budget-window per_run` then `cev3 ratify <ID> --approver-ref <HEX64>` (value-free digest binding the Operator's forge ratification).

Twin of [[ce-controller-launch-method]] + [[ce-codex-seat-launch-method]]; respects [[ce-execution-zones-outside-repo]]; claim-lock interplay with [[ce-compose-claim-lock-rule]].
