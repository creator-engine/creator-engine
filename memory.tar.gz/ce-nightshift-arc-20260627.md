---
name: ce-nightshift-arc-20260627
description: "Night-shift arc locked 2026-06-27: cut 0.3.0 (primary), then drive Wave 0/2/3/4 in parallel. Pointers to live resume state + cut-prep."
metadata:
  node_type: memory
  type: project
  originSessionId: 305f7b7a-c243-45dd-bb68-b776fabd09ec
---

Night-shift arc **locked by Operator 2026-06-27 ~17:10Z**. PRIMARY objective = **Wave 1: cut the fresh 0.3.0 release** (closes the onboarding loop the Arad dogfooding exposed — 0.2.0 is broken for real users). After 0.3.0 lands, CONTINUE driving the rest in parallel (Operator standing direction): Wave 0 hygiene (close-bot diagnosis + 7 drifted tickets; land #591), Wave 2 arm-the-spine (AutoReview #292, R2 auto-merge flip, first belt run — Operator gestures), Wave 3 finish ARC-2 (#279→#280→#277) + re-feed dev-1/3/4 + Nitzan BUILD arc, Wave 4 annoyance→tool + agent-self-authored AGENTS.md.

**Live state = newest `RESUME_STATE_CE_DEV2_NIGHTARC_*` in `.ce/state/research/`** (open it + MEMORY.md first). **Wave-1 execution detail = `RELEASE_030_CUTPREP_FOR_OPERATOR_SIGN_20260627.md`** in the same dir — stages 0.3.0 to the signing seam so the Operator's ce-root-v1 sign is ONE clean gesture (Phase B = R-reserved).

Onboarding follow-through rides alongside: Arad band-aids (#331/#332) are install-scoped — the 0.3.0 release is their real fix; see [[ce-arad-pilot-onboarding]]. Tickets from this session's dogfooding: #331/#332/#333/#334/#335.
