---
name: ce-dev1-access-method
description: "durable host-state: CE-DEV-1 access = ssh ce-dev-1 (167.233.98.189, user ce, key ce-pilot-vps); laptop gho_ tokens are IP-bound (401 from VPS) — PATs portable; gh device-flow per-box"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 2457e0af-87f4-4a24-9180-884b72b2db0d
---

**CE-DEV-1 (Hetzner CX53 `ce-pilot-1`) access — verified 2026-06-10:**
- `ssh ce-dev-1` → config entry: HostName **100.72.252.20 (TAILNET-ONLY)**, User **ce** (has sudo; root denied for this key), IdentityFile `~/.ssh/ce-pilot-vps`. The old `limitless`/`limitless-public` ssh entries are STALE (wrong IP / dead tailscale node).
- **HARDENED 2026-06-10 (Operator-approved):** Hetzner firewall **11116404 `ce-dev-1-tailnet-only`** — inbound = UDP 41641 + ICMP ONLY; public IP 167.233.98.189 is unreachable on :22 BY DESIGN (don't "fix" it). Emergency re-entry: detach the firewall via the Hetzner API (`~/.config/hetzner/api-token.md`, 0600, authoritative for server facts) or the Hetzner web console.
- **GOTCHA: laptop `gh` OAuth tokens (`gho_`) are IP-bound — same token = `chmod735` on the laptop, 401 from the VPS. PATs ARE portable** (reviewer PAT works from the box). So each box needs its own `gh auth login` device-flow for chmod735; reviewer PAT lives in VPS `~/.hermes/.env` (0600).
- Continuity runbook (tmux-first + `.ce/` state-root canon + checklist state): `ce-ops/designs/track2-prephase2-continuity-runbook-20260610.md`. [[ce-pilot-env-hetzner-vps]]
