---
name: ce-welcome-pack-html-primary
description: "Operator decision 2026-07-06 — tenant welcome packages are HTML-first (interactive browser bundle, \"website\" experience); Markdown files are source/reference material"
metadata: 
  node_type: memory
  type: project
  originSessionId: 29dd98b5-49df-420a-bb46-8a29aafdd959
---

Operator decided 2026-07-06 (Arad 0.3.3 pack review, recorded in the codex relay envelope
CE_DEV2_CLAUDE_RELAY_ARAD_PACKAGE_20260706T1222Z.md decision 1): **tenant welcome packages ship as
an interactive HTML bundle** (`index.html` primary deliverable) — easier for humans AND agents to
view, navigate, search. Markdown files remain source/reference; whether they ship inside the
bundle stays a per-send Operator choice (was still open for the Arad send).

**Why:** side-by-side comparison during the Arad pack preview; HTML gave the "website" experience.
**How to apply:** author future tenant packs HTML-first: journey/docs sections first-class in the
nav, anchored sections, copy-clean command blocks (no `$` prefixes), verify in a real browser
render (the pack's simple renderer mishandled wrapped list continuations once — render-check every
revision). Pairs with [[ce-user-facing-vocab-no-bet-no-budget-frontload]] and the T1 journey-doc
pair (ce-ops#485) — once T1 ships on the site, packs link instead of duplicating.
