---
name: ce-github-identity-model
description: CE GitHub identity model — devs author as their OWN user account + own app; overwatch PATs + devops app = the automation/devops identity
metadata: 
  node_type: memory
  type: reference
  originSessionId: fdf1f630-c8da-4de0-86e1-9d24db177a6a
---

Each CE dev = a separate developer who installed CE → has their OWN GitHub **user account** (e.g. dev-3 = `ce-dev-3`) AND their **own GitHub App** (e.g. dev-1's `ce-forge-dev1`); they **author PRs under their own user-account identity** (push/gh-auth = the user account, like dev-3's `ce-dev-3` login). The app is the dev's CE installation/automation, NOT the PR-author identity.

The **overwatch `chmod` + `ce` PATs** (stored `~/.ce-keys/overwatch.env` on the DGX; ⚠️ BOTH authenticate as **`chmod735`**) + a separate **devops GitHub App** = the **devops/automation identity**, used to make GitHub devops (review/merge/triage) automated + efficient. **Implication:** `chmod735` is a legit **independent reviewer** of a dev-authored PR (different identity, review = devops work) — NOT self-review.

**Verified account roster (2026-06-19) — registry = ce-ops#137 (SSOT):**
- `chmod735` (id 150906340) = main overwatch / CE-org OWNER = devops/automation identity; both overwatch PATs auth as this. ⚠️ `chmod745` does NOT exist (typo, collides w/ ubuntuaws745-cmyk).
- `cedev1vps-cmd` (292754681) = dev-1's account · `cedev4vps-coder` (294754021) = dev-4's · `ce-dev-3` (293633657) = dev-3's · `ubuntuaws745-cmyk` (286082568) = **dev-2's (me)**.

**Cutover incomplete — only dev-3 correct; ALL accounts exist (NOT blocked, just unwired):**
- dev-3 ✅ wired to `ce-dev-3` everywhere.
- dev-1 ❌ commits+pushes as `chmod735`; SHOULD be `cedev1vps-cmd` — cred ALREADY on seat at `~/.ce-keys/reviewer.env` (verified). Just rewire git-config + gh-auth + push; then re-author #275 + re-sign (`ce-dev1-root-v1`).
- dev-4 ❌ generic `Codex <codex@openai.com>` + shared `app/creator-engine-forge`; SHOULD be `cedev4vps-coder`.
- dev-2 (me) ❌ shared forge App (#274); SHOULD author as `ubuntuaws745-cmyk`.

Fix = per-seat config rewire (no account creation needed). chmod735-overwatch then reviews/merges dev PRs. See [[ce-per-dev-identity-secret-storage]] [[ce-dev1-own-credentials]] [[ce-team-mode-host-architecture]].

## Detail (moved from index 2026-07-05)
- Related: [[ce-per-dev-identity-secret-storage]] [[ce-dev1-own-credentials]] [[ce-independent-audit-small-blast-radius]]
- overwatch+devops App = automation identity.
