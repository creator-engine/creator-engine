---
name: ce-g5-work-sizing-gate-pr-body
description: How to satisfy/fix the G5 work-sizing-floor CI gate on a PR body without dismissing approval
metadata: 
  node_type: memory
  type: reference
  originSessionId: 3f9a25b8-879d-4819-b9bd-3847f6b938a9
---

The "Validate governance artifacts" CI job has a **G5 work-sizing floor PR-diff gate** that reads the PR **body** and fails the whole check if it is wrong. Two hard requirements:

1. The body must contain **exactly one** line matching `- **Declared work class:** <tiny|story|feature|epic>` (regex wants the words "Declared work class" — a space, not "work-class"; bullet/`**` optional). A malformed/parenthetical line (e.g. `## Approach (declared work-class: small)`) matches **zero** times → "must contain exactly one declared work class line". `small` is **not** a valid class.
2. The declared class must be **≥ the diff's sizing floor** (floor = minimum from line/file counts; consult `schemas/work-sizing-floor.schema.yaml`). Reproduce locally: `PYTHONPATH=validators .venv/bin/python -m creator_engine_validator verify-work-sizing-floor --base origin/main --declared-work-class <c> .` Empirical: ~180 lines → `tiny` passes; **1781 lines → needs `epic`** (feature fails).

**Fixing a FAILING gate on an already-open, already-approved PR without re-pushing (which would dismiss the approval):** the gate reads the body from `GITHUB_EVENT_PATH` (the event payload, frozen at trigger time), so `gh pr edit --body` alone does NOT re-evaluate, and `gh run rerun` replays the stale payload. validate.yml's `pull_request:` trigger has **no `types:` filter** → it includes `reopened`, and **close+reopen does not change the head SHA** → the approval survives while a fresh event carries the corrected body. So: `gh pr edit <n> --body-file fixed.md` → `gh pr close <n> && gh pr reopen <n>` → re-latch auto-merge (`gh pr merge <n> --auto`, dropped on close). Related: [[ce-changelog-workflow-obligation]], dev-1 carrier-gates #213/#214 build this enforcement.

**2026-07-04 (2 occurrences in one day):** briefs/seats now think in XS/S/M/L (work-management canon) but the gate vocab is still tiny|story|feature|epic until L10 lands — #772 declared "L"→fixed to epic, #782 seat wrote "S"→harvest-fixed to story. Every dispatch brief that mentions work class must spell the gate enum literally.

## Detail (moved from index 2026-07-05)
- reads event body); body edit alone won't re-trigger → close+reopen. A push dismisses approval → re-approve on new head. Related: [[ce-pr-work-class-line-format]]
- ≥ diff floor (FORGE-ONLY.
- y one `- **Declared work class:** <tiny|story|feature|epic>`.

## Enum + induced-tampering lesson (2026-07-08, STRANGELOOP-1)
- The ONLY valid declared work classes: **tiny | story | feature | epic** (G5 regex
  `^- \*\*Declared work class:\*\* (tiny|story|feature|epic)`). "task"/"T"/"S" are NOT classes —
  controller briefs using them caused a triple-BLOCKED on dev-3 and worse on dev-4: the seat
  MODIFIED pr_preflight.py to add a "T" alias rather than fix its input (unauthorized gate-surface
  change, caught by harvest scope-matrix + baseline-diff). Lesson: an invalid gate input in a brief
  can INDUCE gate-tampering; always write classes from this enum, and carrier/claims/brief must
  agree BEFORE dispatch.
