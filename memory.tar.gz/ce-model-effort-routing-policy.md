---
name: ce-model-effort-routing-policy
description: "Operator rule: token efficiency is a KEY metric; effort follows PoLP — Fable 5 at high (not xhigh); Opus 4.8 xhigh = CONTROLLERS ONLY (other roles high-max, medium for simple); non-Fable tasks → Codex/Opus 4.8"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3d6c61d0-a2de-4549-96f6-26d4d9e12958
---

**Operator directive (2026-06-10, post-Fable-5 adoption): token efficiency is now a KEY METRIC** — in CE's software development and as a general business metric. Model/effort routing policy for every seat/lane I launch or recommend:

- **Fable 5 → `--effort high`** (NOT xhigh). Fable's reasoning is strong enough that xhigh is wasteful spend for the same outcome; reserve any exception for an explicit Operator call.
- **Tasks that do NOT require Fable-level reasoning/capability → route to Codex (GPT-5.5) and/or Opus 4.8, both at `--effort xhigh`.** The cheaper-model-at-max-effort beats the top-model-by-default.
- Pick the model by the task's reasoning ceiling, then set effort per this table — don't default everything to the newest/top model.

**Operator reinforcement (2026-06-11, PR #200 retro):** efficiency is the general operating
principle, token efficiency the concrete case — route every dispatched task to the model+settings
with the best cost/performance SUFFICIENT for it. Concretely: any task NOT requiring very high
reasoning (i.e. not extremely complex) → **Codex GPT-5.5 at `effort:xhigh` is THE default
dispatch target** (powerful + very token-efficient); Fable 5/high and Opus 4.8/xhigh are for the
genuinely hard tiers. Pairs with [[ce-controller-steers-seats-execute]] — the dispatch decision
happens at every seat launch, which is now the standard way work gets done.

**Why:** the binding constraint is shifting from capability to token spend; routing is where the leverage is. This GENERALIZES [[ce-codex-controller-budget-offload]] (which was about preserving the Claude weekly limit + grading GPT-5.5's CE-adherence — both still apply) and AMENDS the seat specs baked into [[ce-controller-launch-method]] / [[ce-codex-seat-launch-method]] (which say "Opus-4.8/xhigh" as the default peer spec — now: choose tier first).

**⚠️ INTERIM HEURISTIC — to be SUPERSEDED (Operator, 2026-06-10):** this prose/estimation policy is exactly what CE should NOT ship. Token efficiency = a TOP, IMMEDIATE priority + an NVIDIA-pitch differentiator (CE gives devs a token advantage, and dogfoods it). It must become a **data-driven, CODIFIED routing policy** produced by a scientific-method program (observe→research→hypothesize→experiment→analyze→codify): run representative CE task-classes across the model×effort matrix, measure token-cost (MEASURED, from the spend/usage meters) AND quality (CE's **grader-outside checks = the objective quality instrument** — the part everyone else routes blind on), find the efficiency frontier per task-class, emit a machine-readable `model_routing` schema (task_class→model/effort + quality-floor + evidence link), enforce it at `ce launch`, surface it in the Cockpit routing advisor ([[ce-cockpit-resource-envelope-routing]]). Codex/GPT-5.5 has ample usage room (use it more, esp. for non-Fable-grade tasks). Program proposed 2026-06-10; until it lands, use the heuristic below BUT log each routing choice as a hypothesis-to-test.

**⏫ Operator upgrade (2026-06-12, velocity-week evidence):** codex GPT-5.5 xhigh is now graded **ON PAR with Opus 4.8** (trial ledger: compose/amend series B+ → A− → clean-PASS across #25/#38/#43/E1–E4). **Prefer codex+GPT-5.5-xhigh as much as possible** — including code-class implementation seats via `cev3 drive --spawn --harness codex` (allowed mutation classes none/docs/code; higher classes still need the ratified override). Exceptions that stay Claude: the VERIFY leg of compose cycles (cross-model independence is the point), reviewer venues (codex venue = explicitly deferred, `codex_review_deferred`), and genuinely Fable-grade reasoning tiers. Parity caveat stands: evidence-parity, not in-band-enforcement-parity — external gates carry codex governance.

**⏫ Operator refinement (2026-06-16) — PoLP effort is PROVIDER-RELATIVE (ce-ops#92):** the principle is universal — **always optimize token usage: pick the minimal model + effort that meets CE's quality bar; NEVER compromise quality** (PoLP cuts cost at FIXED quality, never quality). But "minimal necessary" is weighed against each provider's **token scarcity**, so the same task routes differently per provider:
- **Anthropic (SCARCE — hard weekly limits) → ration tightly.** `Opus 4.8 @ xhigh` = **CONTROLLERS ONLY**. Non-controller roles → Opus 4.8 at **lower effort** (`high`/`medium`) OR **Sonnet 4.6** at its highest / 2nd-highest reasoning. This controller-only-`xhigh` ceiling is specifically the **Anthropic-scarcity rationing rule**.
- **OpenAI Codex / GPT-5.5 (ABUNDANT — near-unlimited) → the ceiling lifts.** `gpt-5.5 @ xhigh` is fine for **almost any role** — exactly why codex+gpt-5.5-xhigh is the broad default dispatch target (this resolves, rather than contradicts, the 2026-06-12 "prefer codex-xhigh" line: it's abundance, not a contradiction). Still minimal-necessary, but the efficient floor is much higher when limits aren't binding.

Net: **scarcity sets the rationing tier; quality is the invariant.** The SoT routing table (role × task-tier → {model, effort}) must be **provider-aware**. To be encoded into the agent-native SoT (ce-ops#91); standing directive until then. Pairs with [[ce-independent-audit-small-blast-radius]] (least-privilege framing) + [[ce-controller-steers-seats-execute]] (decision happens at every seat launch).

**How to apply (interim):** when composing any launch (`ce launch --claude-arg=--model … --claude-arg=--effort …`), justify the tier in one line (Fable-grade reasoning needed? → fable-5/high; mechanical/simpler governed task? → codex or opus-4.8/xhigh). Same rule when sizing Workflow/subagent fan-outs. Surface the routing choice in the launch report so the Operator can correct the calibration. Relates to [[ce-cockpit-resource-envelope-routing]] (the product-side governed routing advisor — CE's own product should embody this same policy).

**⚠️ APPLIES TO THE `Agent`/Task TOOL TOO — `model` param is MANDATORY on every spawn (Operator correction 2026-06-28):** in-process subagents (`Agent` tool: fleet_recon / architect_research / ops_triage / harvest_intake / implementer / reviewer / verification, AND Workflow `agent()`) **INHERIT the controller's model (Opus 4.8) when `model` is omitted** — which silently violates this policy. I spawned a whole session's workers on Opus by omitting it. RULE: **never omit `model` on a subagent spawn; set it explicitly every time, justified.** Controller-only-Opus ⇒ NO worker runs Opus by default. Default tier map (Anthropic-scarce):
- **Haiku 4.5** → mechanical: `ops_triage` (search+file one issue), simple liveness `fleet_recon`, `verification` (run tests + report).
- **Sonnet 4.6** → substantive workers: `architect_research` (read+author briefs), `implementer` (code/tests), `harvest_intake` (extract+preflight+push), `reviewer`, deep/reconciling `fleet_recon`.
- **Opus 4.8** → only the controller (me) and a worker task I explicitly judge Opus-grade, stated in the spawn. `fable` only for Fable-grade reasoning.
The `Agent` tool exposes `model` (sonnet|opus|haiku|fable) but NOT effort — so for in-process subagents, model is the only lever; for `ce launch` seats set both. Surface the chosen tier per spawn so the Operator can recalibrate.

**⏫ Operator re-reinforcement (2026-07-09):** most efficient model per task, and **NEVER
Sonnet 5 for subagents, regardless of task** — it is token-inefficient (tokenizer ≈ +30%).
This is now a categorical ban, not a preference. Verification of actual model per spawn
(grep '"model"' on task output files) is part of the compliance loop, not optional.

**⏫ Operator correction (2026-07-04) — "sonnet" now means Sonnet 4.6, NOT Sonnet 5:** Sonnet 5 is extremely token-heavy (new tokenizer ≈ +30% tokens for the same text, heavier reasoning spend); default all sonnet-tier workers to **`claude-sonnet-4-6`** unless Sonnet 5 is absolutely necessary. DONE: all 6 agent-role frontmatters pinned to `model: claude-sonnet-4-6` (repo `.claude/agents/`: architect_research, implementer, reviewer; user `~/.claude/agents/`: fleet_recon, ops_triage, harvest_intake; verification stays haiku). GOTCHAS: (1) agent definitions are CACHED at session start — mid-session frontmatter edits don't apply until the next session (verified: post-edit smoke spawn still ran claude-sonnet-5); (2) the Agent tool's `model: "sonnet"` enum resolves to the harness default (currently Sonnet 5) and OVERRIDES nothing — omit `model` on spawns of pinned roles so the frontmatter pin wins; (3) verify actual model via `grep '"model"' <task output_file>`, not the agent's self-report.

## Detail (moved from index 2026-07-05)
- Sonnet=substantive (architect_research/implementer/harvest/reviewer), Opus=controller ONLY. Codex effort DEFAULT=high; Claude controllers=high (not xhigh). Related: [[ce-claude-controllers-effort-high-not-xhigh]] [[codex-first-routing-directive]] [[ce-merge-mechanics-off-frontier-model]]
- Haiku=mechanical (recon/triage/verification).
- spawn sets `model` explicitly.

**⚠️ Violation postmortem (2026-07-05 night, CE-DEV-2):** controller passed `model: sonnet`
explicitly on ~15 pinned-role spawns (reviewer/implementer/harvest_intake/fleet_recon/
ops_triage), overriding every claude-sonnet-4-6 frontmatter pin → whole night ran Sonnet 5;
contributed to hitting the 10:30pm session limit. ENFORCEMENT RULE: for the six pinned
roles, NEVER set `model` on Agent spawns — omit it, the frontmatter pin wins. Haiku
mechanical spawns may still set `model: haiku` (verification role) — that alias is correct.
Coverage gap found: catch-all `claude` agent type has no pin and the tool enum can't
express 4.6 → created pinned `utility` agent (~/.claude/agents/utility.md, model:
claude-sonnet-4-6) for controller-side chores; available NEXT session (defs cached at
session start).

## GPT-5.6 adoption RATIFIED 2026-07-10 (canary-gated)
Operator-ratified fleet routing (full table: .ce/state/research/MODEL_ROUTING_GPT56_RATIFIED_20260710.md):
seats default **gpt-5.6-terra high** (replaces gpt-5.5 high) · escalation **sol medium**
(authority-adjacent only, controller-approved; Sol guidance = start LOW efforts) · agent-organs/
verify **luna** (codex analog of Haiku=verify-only) · **terra-xhigh DEFERRED** until terra-high
canary reads out. Fleet flip only after ONE-seat ONE-arc canary (dev-4 relaunch) beats the
5.5-high ledger baseline on first-READY green rate / review bounces / corrective round-trips.
Rationale: shared weekly pool is the binding constraint; Terra ≈ 5.5-quality at ~half burn.
Codex CLI 0.144.1 update ordered same window (standalone installs: `codex update`).

**⏫ GPT-5.6 FLEET FLIP EXECUTED (2026-07-10, Operator-ratified + Operator-accelerated):**
Ratified table (file: repo .ce/state/research/MODEL_ROUTING_GPT56_RATIFIED_20260710.md):
seat default = **gpt-5.6-terra high** (Terra ≈5.5-quality at ~half burn); escalation =
**gpt-5.6-sol medium** (authority-adjacent code only, controller-approved per unit; Sol prefers
LOWER efforts); agent-organs/verify = **gpt-5.6-luna**; terra-**xhigh DEFERRED** until the
canary reads out (then one comparative unit vs sol-medium). The one-seat canary was accelerated
to all three seats by live Operator direction at a fleet-wide stop-point window: dev-4, dev-3,
dev-1 ALL relaunched on terra-high + codex 0.144.1 same window (dev-1 via
`codex resume <thread> -m gpt-5.6-terra` — thread survives, context recompacts). Canary metrics
still owed vs the 5.5-high ledger baseline: first-READY green rate, review bounces, corrective
round-trips. LAUNCH-CONFIG DEBT: the launcher toml heredocs still write model="gpt-5.5"
(argv -m overrides at launch) — repo flip is a pending seat unit; configs+this memory must not
drift (the flip unit closes it).
