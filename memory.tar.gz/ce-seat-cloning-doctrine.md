---
name: ce-seat-cloning-doctrine
description: "Ratified 2026-07-04: no same-role seat clones while token-pool-bound; clone only when ROLE or POOL differs; gate stays singleton; foreman fan-out is the in-seat multiplier."
metadata: 
  node_type: memory
  type: project
  originSessionId: aec618e9-c79b-4668-b514-e18af1e298d1
---

Operator ratified (2026-07-04, "fully agreed on all points"): cloning seats/controllers (e.g. a second dev-4) is mechanically easy — container+UID+herdr socket+forge identity+registry entry+SeatProbeSpec are all config, the substrate is clone-compatible — but is the WRONG move while:
1. All codex seats share ONE account weekly token pool ([[ce-codex-shared-account-subscription]]) — a same-role clone splits the pool, adds coordination cost, adds no capacity.
2. The real bottleneck is review + merge-gate throughput, not build parallelism — the arc's automation (auto-review routing, docs-class automerge, harvest daemon) attacks that instead.
3. Singleton discipline: every clone widens the surface where claims/territory must hold (same hazard class the daemon lease gate closes).

**Clone WHEN role or pool differs:** dedicated DevOps seat (ce-ops#384 persona), docs seat, per-tenant seats (Mythos/contributor), or when seats ride separate accounts / self-hosted GPU tier — then a clone is real capacity with real isolation value.

**Never clone the merge-gate controller:** two gate-holders racing approvals is the exact failure mode the governance model prevents. Controller's multiplier = worker fan-out ([[ce-dev2-orchestrator-role]]); seat's multiplier = foreman multi-worktree batching ([[ce-seats-foremen-self-managed-fanout]]). Endgame: the gate becomes policy (automation), not a busier controller.
