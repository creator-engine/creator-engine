---
name: ce-merge-queue-strict-antipattern
description: "Rebase-loop-hell root cause: 'require branches up to date' (strict) ON together with a merge queue → O(N²) update-branch churn. Disable strict when a merge queue exists; it's set in BOTH the ruleset AND classic protection."
metadata: 
  node_type: memory
  type: project
  originSessionId: 61b01e4e-f0fa-453a-90f8-03a849b5c415
---

**The bug (diagnosed 2026-06-26, the recurring "rebase loop hell"):** GitHub `strict` = "require branches to be up to date before merging" enforced AT THE SAME TIME as a merge queue is self-defeating. The merge queue ALREADY tests each PR against latest main (builds `gh-readonly-queue/main/pr-N` = main+PR, runs required checks there, merges if green). `strict` ADDITIONALLY demands every PR be manually up-to-date before it can even ENTER the queue. So with a batch of N approved PRs: each merge bumps all others to BEHIND → each needs `update-branch` (firing a redundant PR-head CI run) → re-enter queue → queue re-runs CI on the merge-group → merge → bumps the rest again = **O(N²) churn + double CI**. It's churn, not deadlock (PRs still merge), but it burns hours + CI.

**The fix:** turn `strict` OFF when a merge queue exists. **Safety is unchanged** — the required check still runs on the queue's up-to-date merge-group commit (the authoritative gate). This is GitHub's own guidance for merge-queue repos. Done 2026-06-26 on `creator-engine/creator-engine`.

**Gotcha — strict was set in TWO places (must flip BOTH):**
1. Ruleset (`ce-reference-protection-floor`, id 17946690): `required_status_checks` rule → `strict_required_status_checks_policy: false`. Update via `gh api -X PUT repos/.../rulesets/<id>` with the full ruleset body (name/target/enforcement/bypass_actors/conditions/rules), changing only that boolean.
2. Classic branch protection: `gh api --method PATCH repos/.../branches/main/protection/required_status_checks -F strict=false`.
GitHub UNIONS rulesets + classic protection (most-restrictive wins) — the `branches/main/protection` API reflects the union, so flipping only the ruleset left classic strict=true still enforcing it. Verify BOTH read false.

**Going-forward conveyor behavior:** do NOT manually `update-branch` BEHIND PRs to enqueue them — with strict off, just enqueue approved+green PRs (`gh pr merge <n> --auto`); the queue rebases+tests+merges each in turn. update-branch only when there's a genuine content CONFLICT (DIRTY), not merely BEHIND. The merge queue groups up to 5 entries with `grouping_strategy: ALLGREEN` — one failing PR fails the whole group + evicts (that's why a dangling-link PR poisoned batches); fix/eject the offender, don't fight the queue. Ties [[ce-merge-queue-offloads-mechanics]] [[ce-base-only-refresh-microauth]].
