---
name: ce-v3-roadmap-to-pilot
description: full-stack-first roadmap MVP→pilot — LANDED on main 2026-06-06 (G-3.7 CLOSED; docs/v3-roadmap.md carries the pilot gate-map G-3.7b→G-7 + the v3.0 MVP-complete / v3.1 pilot-ready milestones; designs at docs/architecture/pilot-*.md); next gate = G-3.7b
metadata: 
  node_type: memory
  type: project
  originSessionId: 080d99e1-0600-42db-a6f5-66f72e1682bd
---

**Operator decision (2026-06-06): build to PILOT-READY, full-stack-first.** The dev test group will pilot CE on a real greenfield OSS project and will WAIT for a pilot-ready build, so we build the full designed-but-unbuilt stack (contract · tokenomics · coordination) + product surface BEFORE exposing a pilot (NOT fastest-usable-pilot-first).

**Design artifact (source of truth):** `~/Documents/ce-v3-roadmap-to-pilot-design-20260606.md` (snapshot in the `ce-v3-design/` package; indexed). APPROVED + revised after Operator review.

**Two milestones:**
- **v3.0 "MVP-complete"** = governed-run engine proven live end-to-end **incl. merge** (open→review→merge). End of G-3.7b/G-3.8.
- **v3.1 "pilot-ready"** = a developer can USE it — full stack, cost-safe, installable, drivable. End of G-7.

**Gate clusters (build order = bottom-up dependency):**
- **G-3.7b** (CI-pure: merge-seam + live-merge-identity seam + `pr_merged` run-outcome model) → **G-3.8** (the ONE out-of-envelope LIVE merge spike + the final G-3.7 roadmap flip) → **v3.0**.
- **G-3.9** — D1–D6 cleanup (D0 already done), **launcher-guarded**: the lane/launch/tmux deletion (D2) DEFERS to post-G-7.0 — don't cut the live `ce launch`/`ce hud` substrate the build runs on; `worker_runtime` isolation primitives are re-homed into the enforcer, not deleted.
- **G-4** agent-interaction contract (`AgentActionEvent`/`decide()`/`runtime_agent_action`; builds on `classify()`+`mutation_class`) → **G-5** tokenomics gate (`spend_cap`/circuit-breaker/`max_concurrent_runs`; reuses G-4's escalation+evidence machinery) → **G-6** coordination (Scope + backlog + DoR-wiring + crosswalk; Scope-only) → **G-7** product surface (v3 work-driving CLI + seat-launch replacement + **two-mode operator-typeless install: a one-liner + a signed/verified agent-native `llms-install.md`**; MCP-install post-pilot) → **v3.1**.

**Deferred to post-first-pilot:** cockpit UI · ACP/acpx Tier-A transport · durable Skill axis · OpenShell backend (G-2.3) · CEO-mode/BMAD.

**In-repo `docs/v3-roadmap.md` extension — ✅ LANDED on `main` (PR #147 / `ab83629f`, 2026-06-06), FOLDED into the program-closing G-3.7 roadmap flip** (one docs PR closed G-3.7 + laid the pilot gate-map + the two milestones + the deferred backlog + next-pointer→G-3.7b). The G-4…G-7 detailed designs are committed fresh-clone-durable at `docs/architecture/pilot-{roadmap,deployment-transport,uiux-model}.md` (PR #146 / `7095cfb`) — the per-gate planning prompts CITE those in-repo docs (NOT the instance-local `~/Documents` corpus). **G-3.7 is CLOSED; the first working v3 live drive is proven** (governed App-JWT mint → one real PR → value-free evidence + ratification record → correct revoke; gated merge deferred to G-3.7b/G-3.8). Live in-flight gate state = the Controller's newest `RESUME_STATE_CE_V3_G3_PROGRAM_*`.

**Pilot deployment reference:** `~/Documents/ce-pilot-deployment-transport-matrix-20260606.md` — the two scenarios (Claude+Max → CC-hooks; Codex+Plus → ACP-via-access-token post-pilot), the transport auto-select logic, the deployment invariants (gVisor box · two-credential custody · dev-as-reviewer for N=1 · two-mode installer), and the cost regime.
**N=1 review-independence RESOLVED (2026-06-06):** "agent-author ≠ dev-reviewer + deterministic gates" IS enough for a solo pilot — no governed reviewer-agent venue needed at N=1 (deterministic CI = the author-independent floor; the dev never self-reviews code; scales to >1 / reviewer-agent venue + risk-tiered human-ratification for high-blast classes). Strictly stronger than bare-agent coding.

**Pilot UI/UX reference:** `~/Documents/ce-pilot-uiux-model-20260606.md` — pilot surface = the Operator's **own agent + `ce` CLI + GitHub** (no CE-spawned Controller; cockpit deferred). CE injects a **branded/structured experience layer** into the agent TUI: `ce session` frame + status line · named SHAPE→READY→RUN→REVIEW→MERGE stages · the **◆ CE Completion Report** (v3 heir to the v1 completion report) · artifact awareness (inspect every run artifact). The v1 visible-Controller/tmux/canonical-line model is the BUILD HARNESS (D2-deleted), not the product. Graduates into the full CE Cockpit post-pilot.

Related: [[ce-v3-product-vision]], [[v3-roadmap-doc-reference]], [[ce-coordination-design-resume]], [[ce-substrate-acp-decision]], [[ce-agile-shape-open-question]], [[ce-acpx-fork-vs-learn-decided]], [[batch-strict-mode-gate-workflow]].
