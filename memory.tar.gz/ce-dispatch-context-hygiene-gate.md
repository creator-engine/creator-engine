---
name: ce-dispatch-context-hygiene-gate
description: "Before dispatching work to any dev/seat, check its context %; if >40% used, /compact (related task) or /clear (unrelated task)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b33e7c4e-624c-4dc8-becb-f71e010bd662
---

Before dispatching ANY new task to a seat (dev-1/3/4 or a worker), FIRST check that seat's context usage. If context **>40% used**:
- new task is **related** to its current/prior context → send **`/compact`** (preserve the relevant reasoning)
- new task is **unrelated** → send **`/clear`** (start clean; stale context would pollute)

Only dispatch once the seat is at a healthy context level.

**Operator reinforcement (2026-07-04): this INCLUDES dev-1** — /clear dev-1 before dispatching its next task, same as dev-3/dev-4 (the day-arc mandate's "/clear dev-3+dev-4 before new dispatch" line reads as ALL seats now). dev-1 is tmux-driven: `ssh dev1 'tmux send-keys -t ce-dev1-orchestrator:2.0 "/clear" Enter'`, then verify the input box cleared before sending the pointer. Mid-rework rounds on the SAME thread (REWORK2→3) don't need it; a NEW mandate does.

**Why:** a seat at high context dispatched a fresh task either drops in-flight reasoning or carries irrelevant baggage; both degrade output quality. Operator standing directive 2026-06-27 (night-shift arc).

**How to apply:** this is the DISPATCH-TIME gate — complements [[ce-controller-conveyor-intake-directive]] / `ce-conveyor-tend.sh`, which only auto-`/compact`s IDLE seats >40% on the hourly cron. The dispatch gate is stricter: it fires at re-feed time and chooses compact-vs-clear by task relatedness. Respect [[ce-codex-seats-cannot-self-compact]] — only compact/clear an IDLE seat (never mid-task). See [[ce-seat-dispatch-prompt-pointer-sha]] for the dispatch mechanic itself.

## Detail (moved from index 2026-07-05)
- Related: [[ce-codex-seats-cannot-self-compact]]
- >40% → /compact (related) or /clear (unrelated).
