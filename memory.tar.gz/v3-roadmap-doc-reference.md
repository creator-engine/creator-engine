---
name: v3-roadmap-doc-reference
description: "docs/v3-roadmap.md (on main since PR #121, merge 160f08d4) is the DURABLE in-repo v3 roadmap — consult it FIRST in any where-are-we/where-next workflow, alongside the live [[ce-v2-roadmap-progress]] checkpoint and [[ce-v3-product-vision]]"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 25a8677f-1abb-4dff-b8e1-c3b652f27a24
---

**`docs/v3-roadmap.md`** is now tracked on `main` (landed via PR #121, merge commit `160f08d41b6ab219ff7193d8edc4c8e41fc25245`, 2026-06-03). It is the **durable, shareable, in-repo** roadmap, deliberately created so "where are we / where next" no longer depends on agent memory alone.

**What it contains:** orientation (the three planes — A coordination→forge, B scope→CI, C runtime safety→container+thin-policy); design-source pointers (the architect reports); the **G-i/ii/iii → G-1 → G-2 → G-3 MVP gate map**; a **per-gate STATUS table** (Gate | scope | PR | commit | status — every MERGED row derivable from `git log --oneline main`); a **code-location table** for `validators/creator_engine_validator/` (gate→file); a governance note; and a **maintenance footer**.

**PROTOCOL — consult it as part of the where-are-we/where-next workflow, together with my other resources:**
- **`docs/v3-roadmap.md`** (in-repo, durable) = the shareable snapshot of gate status + the code map. Read it for the overall shape and what's merged.
- **[[ce-v2-roadmap-progress]]** (agent memory, "▶▶ ON RESUME" block) = the LIVE, finer-grained batch state: current prompt SHAs, in-flight PRs, the exact immediate-next action. Authoritative for "what do I do right now."
- **[[ce-v3-product-vision]]** = the LIVE design rationale. **Architect reports** under `.ce/state/research/v3-*-architect-*/` = the deep design source-of-truth.
- Cadence = [[batch-strict-mode-gate-workflow]]; review = [[independent-reviewer-venue-rule]].

**MAINTENANCE (going forward):** when a gate's PR merges, update `docs/v3-roadmap.md`'s status table per its own footer — flip the row to MERGED + add the merge-commit short SHA; keep every row derivable from `git log`. Because it is tracked content, that update is its own docs slice through the normal batch flow (compose→ratify→execute→review→merge), exactly like the PR #121 + its post-G-2.1-merge carrier-refresh did. Don't let the table drift from `git log`.

**CAVEAT (deferred Operator decision):** the doc's design-source pointers point into **gitignored `.ce/state/research/`** (instance-local), so in a fresh clone those links dangle — the gate map / status / code-map all resolve, but the architect reports do not travel with the repo. A DEFERRED decision (agreed 2026-06-03, to revisit) is whether to copy the key architect reports into a committed `docs/architecture/` path as its own small docs slice. Until then, the design rationale stays instance-local.
