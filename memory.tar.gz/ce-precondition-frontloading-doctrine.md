---
name: ce-precondition-frontloading-doctrine
description: "Operator doctrine (2026-06-12, ce-ops#33) — after a plan is ratified, collect ALL Operator-side preconditions (credentials, access, confirmations) BEFORE \"go\"; execution then runs unattended with escalation as the only Operator re-entry"
metadata: 
  node_type: memory
  type: project
  originSessionId: bfd80365-c499-4779-a81e-19909ae7ac19
---

**Operator doctrine (2026-06-12, stated on ce-ops#33 but general):** CE workflows that execute ratified plans must insert a **precondition-collection stage between final ratification and "go"** — gather every Operator-side dependency (credentials, account access, billing/DNS confirmations, any manual precondition) up front, so that once "go" is given **the Operator does nothing further unless an execution problem genuinely requires input** (⏸️ escalation = the only re-entry point).

**Why:** mid-execution "paste your API key" moments are a security smell (credentials in hot context) AND re-create the Operator-as-polling-dependency bottleneck. Front-loading makes the handoff discrete, auditable, and scrub-disciplined. This is the batch-strict-mode a-priori-ratification doctrine extended from *decisions* to *materials*.

**How to apply:** when composing any gate/runbook whose execution needs Operator-side items, derive an explicit precondition checklist FROM the ratified plan and complete it before execution starts (the client-zero Phase-0 intake pack is the proven instance). Five-stage shape on ce-ops#33: interview → ratify research envelope → design → ratify plan + collect preconditions → unattended execution. [[batch-strict-mode-gate-workflow]] [[ce-client-zero-brownfield]] [[ce-awaiting-operator-queue-rule]]
