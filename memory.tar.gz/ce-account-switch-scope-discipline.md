---
name: ce-account-switch-scope-discipline
description: "Operator correction 2026-07-06: during account switches touch ONLY the target seats' auth — controller's own auth got switched as a side effect, wasting Operator time restoring it"
metadata:
  type: feedback
---

During the 2026-07-06 night codex fleet account switch, the controller's own auth on the
controller host got switched too — the Operator had to spend time restoring it, mid-departure.
The instruction was ONLY the codex seats (dev-1/3/4).

**Why:** any auth-affecting command run with default homes (e.g. `codex exec`/`codex login`
without an isolated `CODEX_HOME`, or anything triggering a token refresh/rotation on the
controller host's own credential files) mutates the CONTROLLER's identity, not a seat's. Auth
files are shared-per-host, not per-role; the blast radius of a "validation" call is the whole
host account.

**How to apply:** (1) Scope every switch action to the explicit seat auth-file list built from
the JWT-decode map — never run login/exec/refresh against a home not on that list. (2) Token
validation for a staged auth = copy the auth.json to a THROWAWAY `CODEX_HOME=$(mktemp -d)` and
validate there, never in-place on a live home. (3) The controller's own auth (Claude AND codex
standby) is out of scope for fleet switches unless the Operator names it. (4) Before/after each
switch step, re-verify untouched homes are byte-identical (sha256). Relates
[[ce-openai-account-switch-playbook]] [[ce-seat-relaunch-canonical-launch-only]].
