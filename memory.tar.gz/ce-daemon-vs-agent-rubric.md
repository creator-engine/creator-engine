---
name: ce-daemon-vs-agent-rubric
description: "2026-07-08 direction: route factory organs by DECISION TYPE — authority/mechanics = deterministic daemon; judgment = agent-organ (deterministic trigger + plain-text policy + proposal into deterministic disposer); Steinberger pattern = agents on deterministic skeleton"
metadata: 
  node_type: memory
  type: project
  originSessionId: 610efb0b-4c03-43ec-a265-97e9f566f502
---

**Operator question 2026-07-08 + controller analysis (Steinberger evidence):** we defaulted
c4/c5-class daemons to deterministic without a rubric. Steinberger's factory has NO deciding
daemons — his pattern is **deterministic skeleton (GH Action/cron/policy-line triggers) +
probabilistic organs (Codex agent per issue/review, reading plain-text vision.md/AGENTS.md) +
human ratifying aggregated evidence** (ClawSweeper 15k issues; AutoReview one-line trigger).
Source: .ce/state/research/PETER_STEINBERGER_AUTONOMY_ANALYSIS_20260627.md.

**RUBRIC (route by decision type, not task name):**
- Transport/mechanics/AUTHORITY acts (poll, detect, enqueue, merge, deterministic commit
  construction, allowlist enforcement) → deterministic daemon. Fail-closed, token-free,
  auditable. (Our alpha over Peter — he runs a single trust domain, zero authority layer.)
- JUDGMENT (semantic dedup of seat tickets vs arc, severity/work-class inference, reviewer
  expertise tie-break, review verdicts) → probabilistic agent-organ, ALWAYS: (a) deterministic
  trigger; (b) versioned plain-text policy input; (c) output = PROPOSAL into a deterministic
  validator/disposer (grader-outside applied to the daemon layer); (d) token-rationed: event-
  fired, small-model, tight prompts ([[ce-model-effort-routing-policy]]).
- Concretely: c4 assignment = deterministic matrix + optional agent tie-breaker; review itself
  = agent (as today). c5 triage = agent judgment riding the daemon belt, advisory-only disposal.

**Memory-layer corollary (Operator emphasis):** factory organs need the same hydrate contract
controllers got (#888) — dual store: deterministic ledger/assertions + vector/graph recall
(current recall index = placeholder; gbrain wikilink-graph recommendation stands). Related:
[[ce-guided-journey-ui-vision]] [[openclaw-steipete-prior-art]] [[ce-brain-on-fake-embeddings]]
[[ce-471-program-ratified]]
