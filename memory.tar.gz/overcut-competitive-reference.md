---
name: overcut-competitive-reference
description: "Overcut (overcut.ai) competitive reference — enterprise agentic-SDLC control plane (Amplication pivot); the model for the \"Overcut layer\" (forge-side automation); report in ~/Documents + ce-ops/designs (2026-06-12)"
metadata: 
  node_type: memory
  type: reference
  originSessionId: bfd80365-c499-4779-a81e-19909ae7ac19
---

**Overcut (overcut.ai)** — "enterprise control plane for agentic SDLC," Yuval Hazaz / Amplication pivot, launched Sep 2025, shipping ~every 17 days; enterprise customers, thin community traction, no disclosed funding. Report: `~/Documents/ce-overcut-competitive-reference-20260612.md` (+ ce-ops `designs/`), 22 live sources, HIGH confidence on mechanics (their docs exposed as raw markdown incl. llms.txt).

**Governance verdict (moat axis):** harness-enforced *inside their vendor runtime*, cooperative at the forge boundary — no forge-external binding gate; grader and agent share one vendor. Stronger than [[fabro-competitor-reference]], structurally weaker than CE's grader-outside. Different buyer (enterprise vs solo-dev); medium-term convergence risk given velocity; adjacent space heavily funded (Entire $60M seed).

**Import corpus → ce-ops#34 lane** (trigger taxonomy · workflow.json+prompt-files as ratifiable artifacts · lock-keys/priority queues · role-scoped agents with physically-absent tools · ratification-gated retrospective memory · session override grammar). Their engine-swap under one product (Claude Agent SDK as one of several) validates the RunnerBackend posture. Layer 3 of [[ce-three-layer-pitch-thesis]]. Siblings: [[bmad-method-reference]], [[openclaw-steipete-prior-art]].

## Detail (moved from index 2026-07-05)
- harness-enforced inside vendor runtime = CE moat (Layer-3).
