---
name: ce-controller-via-workers-operational-lessons
description: "Hard-won rules for driving build work via parallel workers + review gates (controller's own lane)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b3164b23-844b-4519-95a0-cf1b7dd75602
---

Operating the controller's own build lane via spawned workers (Operator wants this, not just routing — [[ce-controllers-proactive-pickup]] [[ce-controller-spawns-many-workers]]). Lessons from the 2026-06-22 autonomy-flip push:

**Why:** workers run to completion reliably; the codex seats burst-then-idle, so critical build work belongs on controller workers, seats on review.

**How to apply:**
- **Parallel workers on DIFFERENT branches MUST each get an isolated git worktree** (`git worktree add /home/cedev2/<name> -b <branch> origin/main`); two workers in one checkout clobber git HEAD (had a near-miss). Each worker brief must hardcode its own worktree cwd ("work EXCLUSIVELY in /home/cedev2/<name>"). Clean up with `git worktree remove --force` after push.
- **One designated reviewer per PR.** Two reviewers → thrash + duplicate CHANGES_REQUESTED. If a seat mechanically re-posts a resolved finding (byte-identical body that never references the fix commit), dismiss it via `gh api -X PUT repos/.../pulls/<n>/reviews/<id>/dismissals -f message="<audit reason>" -f event=DISMISS` — but ONLY after a genuine independent approval of the actual fix. The reviewers WERE right on real bugs; don't dismiss a genuine finding.
- **Worker tests must use production-realistic inputs.** A real bug (lease_id > 64 chars) hid behind short synthetic test ids; the unit tests passed but the live path failed. Briefs must demand realistic fixtures.
- **Prefer an offline e2e harness over serial live canaries** for a multi-precondition path: a live canary peels one gate per run (slow + pollutes the forge with throwaway claims). A harness in a fully-initialized test workspace surfaces ALL gates at once. (Live canary recipe when needed: fresh throwaway ce-ops issue + unique label + fresh `--state-root` + ONE poll; repeated polls cause claim-churn / `already_seen` / `lost_after_reread`.)
- **Verify each worker's core diff yourself before pushing** — but trust the independent reviewer to catch what you miss (this session: my reviews missed a TOCTOU race AND a fail-open path that reviewers caught).
