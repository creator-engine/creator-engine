---
name: fabro-competitor-reference
description: "FABRO (fabro.sh / Qlty) — CE's closest LIVE direct competitor; same \"grader-outside-the-agent\" thesis but cooperative-not-enforced; key Cockpit + website + NVIDIA-pitch input"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 3d6c61d0-a2de-4549-96f6-26d4d9e12958
---

**FABRO — "the open source dark software factory for expert engineers"** = CE's closest LIVE direct competitor (researched 2026-06-09, two deep-dives). Two reports OUTSIDE the repo: competitive/technical `~/Documents/ce-fabro-competitive-research-20260609.md`; design/brand `~/Documents/ce-fabro-design-research-20260609.md`. Sources: docs `https://docs.fabro.sh`, repo `github.com/fabro-sh/fabro`, site `fabro.sh`.

**Who/what:** built ~single-handedly by **Bryan Helmkamp (brynary)** — Code Climate founder, now **Qlty Software Inc.** (FABRO is © Qlty) → exactly CE's external-grader/code-quality lineage, a credible operator not a toy. MIT, **Rust 88% + TS 10%** (React web UI), single static zero-dep binary, REST API + OpenAPI + SDKs. As of 2026-06-09: **901★ / 101 forks / 3,819 commits / 70 releases** (stable v0.254.0, near-daily nightlies), created 2026-03-13 (~3 mo old). **Bus factor 1** (brynary ≈ 3,619 commits); thin public buzz (one 2026-03-16 "Introducing Fabro" blog post, no HN/Reddit launch thread).

**The core strategic finding:** FABRO shares CE's *conviction* — don't let an agent grade itself (its flagship "definition-of-done" workflow enforces "no single agent both implements AND verifies", even separate models) — **BUT its external-grading is COOPERATIVE, not ENFORCED.** Agent nodes self-report outcome JSON; the gate is external only if the graph author wires it. **No non-bypassable Ring-1 validator, no signed capability envelopes, no quorum/peer-authority, single-tenant w/ ZERO user isolation (stated).** → **That gap is CE's moat.** Don't copy FABRO's self-reported verification or single-tenant model; that contrast IS CE's wedge.

**Where FABRO is genuinely AHEAD (what CE should learn):** (1) **workflow-as-diffable-Graphviz-DOT file** — process graph reviewable as a PR, renders free → CE should build the same BUT annotate nodes w/ envelope/authority (graph = process AND authorization manifest, the thing FABRO structurally can't do); (2) **CSS-like model "stylesheets"** routing models per-node by selector specificity (low-effort, feeds the cost-meter); (3) **provider-neutral by construction** — 7 providers + Ollama + LiteLLM + fallback chains → de-risks CE's Anthropic-centricity, strengthens NVIDIA/local-inference thesis; (4) production polish — REST/web surface, Daytona cloud sandboxes w/ egress controls, SSH/VNC/VS Code into live runs, retrospective cost analytics, auto-PR + auto-merge, mid-run "steering"; (5) sharper brand.

**Where CE WINS:** enforced (not cooperative) governance; cryptographically-attested external authority; governed multi-agent **quorum** (FABRO multi-agent = mechanical fan-out/fan-in only); automated governed PR-review under branch protection (FABRO leaves review manual); envelope-scoped per-seat isolation.

**BRAND finding — "dark" is FANUC lights-out FACTORY, NOT cyberpunk** (docs explicitly disclaim no-humans = "minimal human interaction with the code"). Aesthetic = cool industrial **control-room navy/teal** — directly OVERLAPS CE's "Control-Room Violet". Tokens (from CSS): base navy `#0f1729`, text `#f7f9fb`, **primary teal `#67b2d7`**, accents amber `#f0a45b`/coral `#e86b6b`/mint `#5ac8a8`. Fonts **Outfit/Lexend/Fira Code**. Stack: **Astro+Tailwind v4** site, **Mintlify** docs, **React+SSE** app. → **CE rec: Fabro owns teal/navy; CE own VIOLET harder + lean mission-control/aerospace (more NVIDIA-credible than "factory"); don't concede the "dark-factory/lights-out SDLC" category LANGUAGE — differentiate loudly on ENFORCED, externally-attested governance/trust.**

**Product UI is REAL = Cockpit-gold** (for [[ce-competitive-cockpit-b-inputs]] / Cockpit-B): kanban **Run board** (Working/Pending/Verify/Merge → maps to CE **Frame→Shape→Build→Review→Ship**), **Run detail** = live SSE event stream + diffs + usage + Stages tab (full agent convo/tool calls), **Run Events** waterfall timing, a **verification scorecard** (Traceability/Readability/Reliability/Coverage/Maintainability/Security), in-browser **human-gate** answering, **Insights** DuckDB/SQL analytics, and a **`FABRO_DEMO=1`** static-mock demo mode. → **CE should build a `CE_DEMO=1` mock-data Cockpit (highest-ROI for the 01-Jul NVIDIA pitch) + add the layer Fabro lacks: a governance/authority panel (envelope, granted authority, who ratified which gate, what the seat is REFUSED).**

Sibling competitor-intel of [[bmad-method-reference]] + [[openclaw-steipete-prior-art]]; feeds [[ce-nvidia-v35-strategy]] (01-Jul), Cockpit-B, and the website redesign ([[ce-site-lane-resume]]).

## Detail (moved from index 2026-07-05)
- grader-outside thesis but COOPERATIVE-not-ENFORCED = CE moat.
