---
name: ce-work-management-canon
description: "Operator-ratified (2026-06-30) CE work-management canon: hierarchy (Roadmap→…→Ticket), 3 classification axes, the 5 term-collision resolutions, work-class=XS/S/M/L, Backlog=Projects-board, process SSOT."
metadata: 
  node_type: memory
  type: project
  originSessionId: 9cc9934a-6a57-49e0-b6fd-bf167a20994b
---

Operator-ratified 2026-06-30 (synthesis from `WORK_MGMT_REALITY_MAP_20260630.md`). Resolves systemic term-collisions + the missing layers that caused commissioned work (#37) to vanish. Implementation = arc lane **L10**.

## Hierarchy (strategic→execution, telescoping by time)
**Roadmap** (program plan, months) ⊃ **Workstream** (durable theme, WS-1..7) / **Milestone** (dated target) ⊃ **Wave** (phase toward a milestone, weeks) ⊃ **Arc** (Operator-ratified execution SHIFT w/ G/R grants, hours-days) ⊃ **Lane** (parallel segment WITHIN an arc) ⊃ **Ticket** (unit = a ce-ops issue).

## Classification = 3 ORTHOGONAL axes per ticket (stop cramming into one label set)
- **Type** — what KIND (feature/fix/chore/research/design/process/epic). NOTE: `user-story` was secretly doing double-duty as type AND "deferred" — split that; deferral is the Schedule axis.
- **Schedule/horizon** — WHEN (milestone membership / Backlog status). Undefined-schedule = the invisibility bug.
- **Work-class** — PR SIZE (see below). PR-level, orthogonal to Type.

## Work-class = XS/S/M/L (renamed from tiny/story/feature/epic — kills the story/feature/epic collisions)
- **The GATE** (realized PR size): metric = **included diff LOC**, deterministic, already wired (`work_sizing.py`/`work_sizing_floor.py`). Bands: XS<400, S 400-799, M 800-1000, L>1000. **Evolve metric → diff TOKEN-COUNT** (agent-native, density-honest) as an L10 refinement.
- **Separate `effort_estimate`** planning field = agent-tokens or agent-hours (a FORECAST, informs sequencing, does NOT gate a PR — not diff-computable). [[ce-agent-paced-estimation]]
- **Metric RATIFIED (Operator 2026-06-30): diff-LOC NOW → diff-tokens LATER.** Keep current LOC thresholds for the gate; the token-count metric is a deferred L10 refinement.

## The 5 collision resolutions (RATIFIED)
| Term | Canon |
|---|---|
| **story/feature/epic** | work-class → **XS/S/M/L** |
| **Lane** | = arc segment ONLY; persistent ce-ops Lane issues #1-7 → rename **"Program:"** |
| **Roadmap** | = program-plan only; `docs/product/ROADMAP.md` → **"Feature Map"**; forge_triage blocker-label → **`aggregate`** |
| **Wave** | = roadmap phase; arc-internal → **"Batch"** |
| **Triage** | = the function; halves = **triage-planner** (ce_triage queue) + **pickup-filter** (forge_triage claim) |

## Structural fixes (the #37 root cause)
- **Backlog = the GitHub Projects v2 board** (org project 1) as live SSOT — Status (Queued/In-flight/In-review/Done) + Anchor (milestone). MUST be kept current.
- **Promotion mechanism:** explicit per-arc promotion step (Backlog→arc Lane) + **ce-ops#376 sweep** as the safety-net surfacing unscheduled/commissioned tickets so nothing rots.
- **Process SSOT = NEW `ce-ops/process/work-management.md`** (analogous to identity-registry.yaml for topology) — defines the full flow + this canon. Its absence caused the whole problem.

## Implementation (arc lane L10)
1. Write `ce-ops/process/work-management.md` SSOT. 2. XS/S/M/L code migration (work_sizing*, validate gate, PR-body convention, docs) w/ back-compat alias window. 3. Adopt+populate Projects board; relabel Lane#1-7→Program. 4. Wire #376 sweep + per-arc promotion step. 5. (later) diff-token metric + `effort_estimate` field.
Related: [[ce-mode-axes-canon]] (the tier/mode canon — same disambiguation pattern), [[ce-sdd-feedback-loop-gap]].

## Detail (moved from index 2026-07-05)
- 3 axes (Type/Schedule/Work-class); work-class→**XS/S/M/L** (diff-LOC gate→tokens; +`effort_estimate` planning field); collisions fixed (Lane=arc-only/#1-7→Program, Roadmap→FeatureMap, Wave→Batch); Backlog=Projects-board; **process SSOT=new ce-ops/process/work-management.md**. Impl=L10.
- hierarchy Roadmap→Workstream/Milestone→Wave→Arc→Lane→Ticket.
