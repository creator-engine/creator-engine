---
name: ce-speckit-full-retirement-ce-native-init
description: "Spec-kit is retired COMPLETELY; replicate needed capabilities CE-native (e.g. ce init, not ce speckit init). Never ship spec-kit naming/scaffolding, even into user projects."
metadata: 
  node_type: memory
  type: project
  originSessionId: d0a9fc77-23a0-480d-a261-1a7d96e0d811
---

Operator decision (2026-07-02): **spec-kit is retired completely** — extends constitution 2.0.0 / PR #676 ("no new dependencies on spec-kit CLI/skills/scaffolding") to mean NO spec-kit-branded scaffolding ships at all, **including into user projects**. If we need a capability spec-kit had, research it and build it CE-native.

Concrete: ce-ops#367 was "scaffold .specify + speckit skills to user projects (`ce speckit init`)". PR #722 (that approach) was CLOSED. #367 redirected to a CE-native **`ce init`** that scaffolds CE's own on-ramp — spec/plan/tasks per shipped work-sizing tiers, anchored to the Frame→Shape→Build→Review→Ship stage vocabulary, CE conventions (changelog fragment, carrier, declared-work-class, `ce validate-pr`), CE-authored skills — with zero `.specify/`, zero `speckit` name, zero ported spec-kit files.

**Why:** spec-kit was a rented surface we've outgrown; keeping its branding/scaffolding (even user-facing) sends a mixed message and creates maintenance drag for a thing we're leaving. **How to apply:** any "port/keep speckit X" request → reframe as "build CE-native equivalent." Watch for a new top-level `ce` group tripping test_v1_docs_reconciliation + needing `gen_cli_reference.py --write` (was the mechanical blocker on #722). Related: [[ce-sdd-feedback-loop-gap]] [[ce-rent-or-fork-before-reinvent]].

## Detail (moved from index 2026-07-05)
- #367 redirected.
- replicate needs CE-native (`ce init` not `ce speckit init`); #722 closed.
