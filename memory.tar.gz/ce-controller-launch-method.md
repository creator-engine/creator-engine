---
name: ce-controller-launch-method
description: "DEFINITIVE method for a CE Claude Code Controller to launch a peer CE Controller seat (Opus 4.8 / xhigh) under CE governance — ce launch (NOT ce lane launch), exact command, governance verification"
metadata:
  node_type: memory
  type: reference
  originSessionId: 7342fd02-41b6-4cf1-bf0b-03f7920c5b1d
---

How a seated CE Claude Code Controller launches a **peer CE Controller seat** (proven 2026-06-01, launching `ce-claude-opus48-xhigh-b`). A Claude Code Controller can do this exactly like a Hermes Controller — it is within the seated Controller's own domain (CC-G-D Ring 0), not a Hermes-only capability.

**Two launch paths — do not confuse them:**
- **`ce launch` / `ce hud`** (RV1-063, `launch_runtime.py`) = the **Controller-SEAT launcher** — opens/attaches a visible tmux pane running the harness. **This is how you launch a peer Controller.** No pre-allocated claim needed.
- **`ce lane launch`** (RV1-030, `lane_runtime.py`) = the claim-bound **worker-LANE** primitive (`--role {architect,implementer,reviewer,verification}`, requires `pco-allocate` first). For spawning workers, NOT a peer Controller. (There is no "controller" role — a Controller is a *seat*, not a lane role.)

**`ce` is `python -m creator_engine_validator.ce_cli`** (console-script `ce`, often not on PATH). Invoke via the isolated runner: `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=validators uv run --isolated --no-project --python /home/linuxbrew/.linuxbrew/bin/python3.14 --with PyYAML==6.0.3 --with jsonschema==4.26.0 --env-file /dev/null python -m creator_engine_validator.ce_cli <args>`. (Validator CLI = `creator_engine_validator.cli`; `pco-allocate` lives there.)

**Exact peer-Controller launch (verified; matches the `CE-Gov-Controller-Opus-4.8-xhigh` precedent):**
1. Provision a CE-owned mcp-config (REQUIRED — `--strict-mcp-config` kills the seat if missing): `mkdir -p .hermes/launch/<id>/mcp && printf '{"mcpServers":{}}' > .hermes/launch/<id>/mcp/ce-mcp.json` (gitignored).
2. `ce launch --harness claude --session <tmux-session> --window <name> --claude-arg=--model --claude-arg=claude-opus-4-8 --claude-arg=--effort --claude-arg=xhigh --claude-arg=--name --claude-arg=<Name> --claude-arg=--dangerously-skip-permissions --mcp-config .hermes/launch/<id>/mcp/ce-mcp.json --json`
   - The builder AUTO-injects `--setting-sources project --strict-mcp-config --mcp-config <ce-path>`; pass model/effort/name/skip-perms as `--claude-arg=` (use `=` for dashed values).
   - **Always `--dry-run` first** to confirm the plan: if `--dangerously-skip-permissions` survives into the plan command, the Ring-0 hook-pack confirmation passed (CC-D-6) and full-permission mode is sanctioned. Refusals (`--bare`/`-p`/`agents`/`--remote-control`/local-settings/skip-perms-without-confirmed-pack/non-strict-or-non-CE-owned-mcp) fire before any side effect; no hidden fallback.
3. **Governed cwd matters:** `launch_runtime` calls `ensure_pane` WITHOUT cwd, so the new tmux window inherits the launching pane's cwd. Launch from the canonical repo root so the peer loads its OWN committed `.claude/**` hook-pack → genuinely governed (verified: a new window in the session inherited the repo-root cwd). Result pane boots `Opus 4.8 with xhigh effort`, `⏵⏵ bypass permissions on`, no trust-dialog stall (`--setting-sources project`).
4. **Seed it** pointer-style via `tmux send-keys -t <pane_id> -l "<instruction>"` then `tmux send-keys -t <pane_id> Enter` — point it at a bootstrap file you wrote under the gitignored `.hermes/launch/<id>/BOOTSTRAP.md`. A fresh CE Claude Code seat in this project **auto-loads the same project memory** (MEMORY.md + memory files), so it boots with full CE context — only give it identity + mandate + constraints.
5. **Reversible:** `tmux kill-window`/`tmux kill-session`. Monitor via `tmux capture-pane -p -t <pane_id>`; archive transcript with `tmux capture-pane -p -S - -t <pane> > evidence/...txt` + sha256 (see [[independent-reviewer-venue-rule]] proven method).

**PROVEN end-to-end (2026-06-01):** the peer `ce-claude-opus48-xhigh-b` booted governed, self-verified its posture, and exercised CE PCO — allocate→verify→release with **3 simultaneous distinct-id LIVE claims coexisting** (it, the Hermes `g2-reviewer-maintainability-docs`, and a `g20073` engineer lane), `scan-active-work-ledger`+`-conflicts` PASS, released to a tombstone with no dangling state. Two side-observations: (1) `pco-release` does NOT delete the lane/driver git branches, and (2) the Ring-1 hook classifies `git branch -D` as `alter_repo_settings` and **denies** it without a G2.007.2 envelope — so a governed seat leaves benign local-only branches behind (the seat correctly did NOT route around the hook). Both are minor; possible future polish (pco-release branch cleanup / hook classifier review).

**PCO note:** `ce launch` spawns the seat only — it writes NO claim/lease/pane-registry record. PCO (claims/leases/pane registry) is exercised when the peer Controller subsequently allocates lanes under **its own distinct `controller-id`** (must differ from every other Controller, e.g. `ce-hermes-controller`, to avoid claim collision). `pco-allocate` honors the root-checkout invariant (PCO-031) — run it from a non-root worktree with `--ledger-root` = canonical-root `.hermes/active-work-ledger` (see [[v2-gate-validation-and-lane-execution]]). The seat-contract posture this launch produces is exactly what G2.007.0/.1 formalized (see [[ce-v2-roadmap-progress]]).
