---
name: ce-codex-seats-cannot-self-compact
description: Codex work-seats cannot self-invoke /compact on instruction — the controller must drive context hygiene via the pane
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5183bef7-5a7b-413f-9619-d7da7f7c58c8
---

Discovered 2026-06-21 (dev-3, 13% ctx): a **codex seat cannot invoke `/compact` itself** — it's a TUI/user command, not available to the codex model's tool surface. dev-3 verbatim: *"I can't invoke the UI /compact from this tool surface, so I'm treating this as a hard context boundary."*

**Implication:** telling a codex seat to "run /compact first" in a dispatch brief is an unreliable no-op — the seat can only ration its remaining context, not model-invoke a refresh.

**BUT codex AUTO-compacts at a low threshold (confirmed 2026-06-21: dev-3 13%→74% unaided).** So a starved codex seat usually self-recovers — task continuity preserved via summary. Don't panic-restart a low-ctx codex seat; it will likely auto-compact. Force a clean reset (restart) ONLY for a deliberate full wipe, and ONLY at idle (never mid-productive-work — it discards the recovered context + interrupts live work).

**How to apply (controller context-hygiene for codex seats):**
- Do NOT rely on instructing a codex seat to "/compact". Instead the CONTROLLER drives it:
  1. Send `/compact` as a literal keystroke into the seat's tmux pane (controller-driven UI invocation), OR
  2. Restart the seat (clean exit → relaunch; AGENTS.md foreman directive survives) — same mechanism as the dev-4 full-auto relaunch, and resets to 100% ctx, OR
  3. Let codex auto-compact (don't depend on it for a seat that's rationing).
- A codex seat below ~20% ctx should NOT be handed a full new slice — first refresh it (pane /compact or restart), then dispatch. Have it finish only light in-flight work and stand by.
- Claude Code seats (and the controller) CAN self-/compact; this constraint is codex-specific. Ties [[ce-seat-relaunch-canonical-launch-only]] (restart mechanics), [[codex-first-routing-directive]] (most work-seats are codex).