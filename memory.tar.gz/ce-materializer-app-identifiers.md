---
name: ce-materializer-app-identifiers
description: "ce-materializer GitHub App (Option A write-to-main carrier, decision 11) — IDs, custody, bypass wiring, verified 2026-07-08; arming still gated on IaC precondition"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 610efb0b-4c03-43ec-a265-97e9f566f502
---

**ce-materializer GitHub App** (Operator-created 2026-07-08, decision 11 = Q2 ruling): App ID
`4244593` · Client ID `Iv23liiGvA6Ipo0Oc4E4` · owner org `creator-engine` · installation
`145152358` (repo_selection: selected → creator-engine/creator-engine ONLY) · permissions
contents:write + metadata:read ONLY. PEM: `~/.ce-keys/ce-materializer.2026-07-07.private-key.pem`
(0600) + env mirror `~/.ce-keys/ce-materializer-app.env`. TODO: migrate PEM to OpenBao
`ce-kv/forge/materializer#private_key` once a writable admin token exists (pickup token is
read-only; see [[ce-openbao-admin-recovery-blocked]]).

**Protection wiring (verified 2026-07-08):** classic branch protection on main DELETED (was a
1:1 subset); ruleset `ce-reference-protection-floor` (id 17946690) is the SOLE enforcement layer
— required_status_checks + pull_request + merge_queue, active — with ce-materializer as the only
bypass actor (Integration, mode=always). Chain verified: mint→scratch-ref write (201/204)→
negative scope check (404 on ce-ops)→revoke. Actual push-to-main deliberately untested until
arming.

**Arming gate:** decision 1 — the materializer may not be armed until the one-click IaC
singleton-redeploy unit is on main (PR #895 lane). Registry entry in
`ce-ops:infra/identity-registry.yaml` still to be PR'd. Related: [[ce-471-program-ratified]],
DECISIONS_20260708.md items 1/2/11.
