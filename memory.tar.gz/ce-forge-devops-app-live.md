---
name: ce-forge-devops-app-live
description: "ce-forge-devops GitHub App is LIVE (max-grant devops App) — app_id 4070181, installation 140711774, all repos, full ceiling"
metadata: 
  node_type: memory
  type: project
  originSessionId: e2cf4ccf-fa9b-4239-ad01-0e065000d886
---

**`ce-forge-devops` GitHub App is LIVE (2026-06-16)** — the org-level max-grant devops App from [[ce-github-devops-agent-executable-directive]] / ce-ops#99. Operator registered + installed it.
- **app_id 4070181**, client_id `Iv23liBFX6trlpl6j7UA`, slug `ce-forge-devops`, owner `creator-engine`.
- **installation_id 140711774**, repository_selection = **all** creator-engine repos.
- Granted the **full ceiling** (administration/contents/pull_requests/members/organization_administration/organization_personal_access_token_requests+tokens/secrets/environments/… all write). This is the "most-privilege grant"; CE mints scoped-down per task (granted≠executed).
- PEM: `~/.ce-keys/ce-forge-devops.private-key.pem` (600, sign-only, pubkey-fp `0e265388…`). Config: `~/.ce-keys/ce-forge-devops.json`. PEM never leaves host.

**Proven working:** App-JWT auth + PoLP scoped mint + a real org write (created team `agent-reviewers` id 18053526 with a `members:write`-only 1h token).

**Mint method (no PyJWT/cryptography in venv → use openssl):**
```
b64url(){ openssl base64 -A | tr '+/' '-_' | tr -d '='; }
H=$(printf '%s' '{"alg":"RS256","typ":"JWT"}'|b64url); P=$(printf '%s' "{\"iat\":$(($(date +%s)-60)),\"exp\":$(($(date +%s)+540)),\"iss\":\"4070181\"}"|b64url)
JWT="$H.$P.$(printf '%s' "$H.$P"|openssl dgst -sha256 -sign ~/.ce-keys/ce-forge-devops.private-key.pem|b64url)"
# scoped token: POST /app/installations/140711774/access_tokens -d '{"permissions":{"<perm>":"write"}}'
```
**`ce-forge-reviewer` also LIVE** — app_id 4070254, client_id `Iv23liaZdOmqAiIDzKqI`, **installation 140713804** (all repos), minimal perms `{pull_requests:write, contents:read, metadata:read}`, PEM `~/.ce-keys/ce-forge-reviewer.private-key.pem` (fp `7f3446ed…`), config `ce-forge-reviewer.json`.

**Open-question #4 RESOLVED (empirically, 2026-06-16):** an App bot CANNOT join a team → `PUT .../teams/agent-reviewers/memberships/ce-forge-reviewer%5Bbot%5D` = **HTTP 422 Validation Failed** (the bot exists as a user, `GET /users/…[bot]`=200, but can't be a team member). ⇒ **Drop the bot-in-CODEOWNERS-team approach.** The reviewer-App's recorded APPROVE IS the independent review (distinct identity ≠ author, no 422). Use a **ruleset** with `required_approving_review_count:1` (NOT `require_code_owner_review`) + `ce-forge-devops` as `bypass_actor` (`bypass_mode:pull_request`). No machine-user, no PAT. **P1 manifest D3 to update:** App-review-counts + ruleset, not team-membership. (Still TODO-verify: does pull_requests:write alone make the App's APPROVE count toward the gate, or does it need contents/repo write? test on first agent PR.) Team `agent-reviewers` (id 18053526) now likely unneeded.

**Irreducible UI gap (confirmed):** registering/installing a GitHub App has NO API (UI/manifest-flow only) — the one hard human bootstrap. Everything else (rulesets/branch-protection/merges/CODEOWNERS/PAT-approval/team mgmt) IS agent-executable via ce-forge-devops. Next: P1 build (ce-ops#99) wires these into CE's minter.

**Security hygiene:** browser downloads leave App PEM copies in `~/Downloads` (shredded devops+reviewer; STILL THERE 2026-06-16: `ce-forge-dev3.*.pem`, `creator-engine-live-spike.*.pem` — flagged to Operator, not auto-shredded). Sweep `~/Downloads` for `*private-key.pem` after any App bootstrap.
