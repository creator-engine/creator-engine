---
name: ce-reviewer-stale-base-false-carrier-mismatch
description: "Review worktrees with a stale origin/main produce false \"carrier/diff mismatch\" REQUEST_CHANGES — fetch fresh + verify authoritatively before trusting"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 69d258f7-dd44-46f6-b57e-19edfe8f7334
---

Governed review workers compare the PR branch against the repo's `origin/main` ref. If that ref is STALE (behind the real remote main), the reviewer sees phantom changes — files that already moved on main appear "changed by this PR" — and files unchanged by the PR get reported as an undeclared carrier path-set → a **blocking "carrier incomplete / diff mismatch" REQUEST_CHANGES that is FALSE.**

**Observed twice (2026-06-30/07-01):** #695 (reviewer read the stale rc2 working-tree downloads) and #706 (reviewer's origin/main still had `tiny/story/feature/epic`; main had already migrated to `XS/S/M/L`, so it wrongly flagged pull_request_template.md + authoring-a-governed-pr.md as undeclared diff files).

**Third strike (2026-07-04, #772) — new wrinkle:** a worktree AT the correct PR head still misleads about MAIN-side state. The PR branched before #776 merged, so the worktree's ce_cli.py lacked V3_FORWARDING_SHIMS; the read-only reviewer (no git/Bash) concluded "the doc's `ce` verbs don't exist" and REQUEST_CHANGES'd. Controller `git show origin/main:<file>` refuted it in one command. Guardrail addition: when a doc/code PR's correctness depends on MAIN-side code (not the PR's own diff), embed the controller-verified main-side facts (or the relevant `git show origin/main:` excerpts) IN the reviewer brief — the reviewer cannot fetch or run git.

**Fourth strike (2026-07-06, #856) — root-checkout-as-baseline variant:** reviewer flagged ~7 capabilities as "undeclared scope" because it compared the PR worktree against `/home/cedev2/creator-engine/validators/...` — the ROOT CHECKOUT, which sits on the old `ce-release-0.3.1-rc2` branch, NOT main. Every flagged item was verbatim in merge-base 6c61be74; the real diff was exactly the declared 3 changes. Round-2 worker refuted with `git show <merge-base>:<file>` + `git diff <merge-base>..HEAD`. Guardrail addition: reviewer briefs must state the merge-base SHA and forbid using the root checkout as baseline — baseline reads go through `git show <merge-base>:<path>` only.

**Guardrail (controller):**
1. Before creating a review worktree, `git fetch origin main` so the base is current. Consider passing the reviewer the explicit fresh base sha.
2. NEVER accept a "diff/carrier mismatch" or "install-breaking artifact mismatch" finding at face value — VERIFY authoritatively: `gh pr view <n> --json files` (GitHub's own file list) + a fresh three-dot `git diff origin/main...HEAD` + the fact that `ce validate-pr` (which runs `verify-path-manifest --require-carrier`) already PASSED. If those three agree and contradict the reviewer, the reviewer hit a stale base — override with the evidence documented in the approval.
3. Reviewer substantive findings (logic/security/precision) are usually sound; only the base-relative "what changed" findings are stale-prone.

Relates to [[ce-fetch-worktree-before-reviewer-dispatch]] (fetch the BRANCH) — this adds: also refresh the BASE. And the general [[ce-verify-not-already-landed-gotcha]] / rc2-stale-checkout trap.

## Detail (moved from index 2026-07-05)
- NEVER trust a "diff/carrier mismatch" finding — verify via `gh pr view --json files` + fresh three-dot diff + the fact validate-pr passed (happened #695 + #706).
