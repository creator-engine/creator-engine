---
name: ce-codex-standby-forge-housekeeping-gap
description: "Operator observation 2026-07-07 — codex standby controller handled builds/reviews fine but mishandled forge housekeeping (foreman-of-foremen workflow); needs codified runbook in takeover hydration, not conventions."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: edf19c2d-23e4-4021-942f-766a3d922458
---

Operator observation (2026-07-07, after the codex standby controller's ~10:00-12:46Z solo
window): the standby drove seat dispatch/repair/review competently but was weak at **forge
housekeeping** — the main-controller (foreman-of-foremen) workflow around the forge: PR/board
hygiene, claims lifecycle upkeep, carrier/changelog gate mechanics, verdict posting flow,
ce-ops sync, closing loops after merges. Root cause: that workflow lives in CE-DEV-2's memory
and practice, not in any artifact the standby hydrates.

**Why:** takeover continuity is a ratified P0 (#471); a standby that can't run the forge loop
degrades the factory exactly when continuity matters.

**How to apply:** per [[ce-bake-gaps-into-ce-not-conventions]] — the fix is a TICKET + codified
forge-housekeeping runbook wired into the `ce takeover` Hydrate phase (alongside the
[[ce-brain-supersession-brief-checklist]] and decisions files), not ad-hoc coaching. Filed as
ce-ops issue (see ticket). When composing standby/takeover hydration packets, include the
forge-housekeeping runbook pointer explicitly.
