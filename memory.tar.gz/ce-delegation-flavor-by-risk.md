---
name: ce-delegation-flavor-by-risk
description: "When to pick a dedicated governed seat vs an in-context subagent for delegated compose/work — the risk & debuggability axis (Operator, 2026-06-09)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f6bb90e2-c057-447e-84aa-a7e9e20515d8
---

**Operator rule (2026-06-09):** when the safety knob is turned up, prefer a **dedicated governed seat** over an in-context subagent for delegated work — *even for compose/research*. The seat's value is NOT that the Ring-1 hook gates the work (for a doc-only compose it gates nothing — no source mutation, no push). The value is that a dedicated seat is an **independently inspectable surface** — its own tmux pane, transcript, and visible tool calls — so if a "simple" task balloons you can watch it and debug it. A subagent's work is collapsed/opaque inside the orchestrator context.

**Why:** today's session (PR #180–#185 batch-merge tax, the A.2b live-run HALT, the path-manifest carrier miss) proved that seemingly-simple CE tasks routinely have a long tail. Observability is the hedge that keeps a surprise from eating an afternoon — which matters precisely when you're trying to move on (e.g., to §3).

**How to apply:** default to a governed seat for delegated work during high-surprise / safety-posture periods, or whenever a task's true complexity is uncertain. Reserve plain in-context subagents for genuinely-bounded, low-risk fan-out. Do NOT conflate "governance / the hook" with "dedicated seat" — the debuggability win is the seat's isolation, not the hook. In a calmer setting the same compose might be a subagent. Pairs with [[ce-controller-launch-method]] (how to launch), [[ultracode-usage-policy]] (workflow approval), [[batch-strict-mode-gate-workflow]].

## Detail (moved from index 2026-07-05)
- calmer → subagent OK.
