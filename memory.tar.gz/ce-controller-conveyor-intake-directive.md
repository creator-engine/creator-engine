---
name: ce-controller-conveyor-intake-directive
description: Operator sign-out 2026-06-25 — controller owns all dev intakes + drives an hourly cron conveyor; foreman/multi-lane; /compact idle seats >40%
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 10ed6d19-ae37-4db2-8564-f31b3cf45718
---

Operator standing directive at sign-out (2026-06-25). Four parts:

**(a) Controller owns ALL dev intakes — for now.** Until contained-seat self-push/self-review go live ([[ce-three-deputy-governance-model]] / ce-ops#242/#243, gated on the W5 token-leak audit), the credential-less seats commit locally and the controller (me, CE-DEV-2) extracts → validates on host → pushes → reviews-as-ce-dev-2 → armed wall merges. This RE-ACTIVATES intake ownership that [[ce-controller-owns-dev1-intake]] marked retired. Watchers + hourly crons keep the conveyor moving: `ce-seat-check.sh` (:00), `poll-devs.sh` (:05, read-only), belt-canary pickup (:03/5min), `ce-conveyor-tend.sh` (:30).

**(b) Every controller is a foreman — including me. NO inlining.** Drive work via fanned-out workers, never inline execution (recon/audits/git-ops/probes → workers). Workers MUST conform to CE-defined roles — consult the runbook BEFORE spinning one ([[ce-worker-roles-and-dispatch]]): 4 canonical roles in `.claude/agents/` (architect_research, implementer, verification, reviewer), governed by spec 005 §d.2 / ce-ops#244; dispatch via `ce lane launch --role …`; runbook `playbooks/controller/briefs/dispatch.md`. Do not improvise roles. Today's lesson: a seat reporting "done" without host validation can be red (dev-4 #252 shipped with an uncaught docs-recon failure — the seat had no pytest).

**(c) Multi-thread / multi-lane = the power multiplier.** Saturate the codex default of ~6 threads/seat via foreman fan-out FIRST; we currently use ~1 of 6 (five lanes idle per box). "The number isn't the constraint; our utilization is." → **stock each seat's QUEUE with multiple bounded units, never one serial brief** ([[ce-seats-foremen-self-managed-fanout]]). Only bump `[agents] max_threads` AFTER saturating the default (start ≤5, never >8) — see [[ce-parallelize-everything-scale-the-gate]]. Controller likewise drives several lanes concurrently.

**(d) /compact idle seats >40% used, hourly.** `ce-conveyor-tend.sh` reads each seat's codex context% via the herdr TUI seam and sends `/compact` (herdr `pane send-text "/compact"` + `send-keys Enter`; tmux for dev-1) — but ONLY when the seat is IDLE, since compacting mid-task discards in-flight reasoning ([[ce-codex-seats-cannot-self-compact]] "force reset only at idle"). codex auto-compacts near its own limit anyway; this just keeps headroom proactively.

**Why:** the controller is the live bottleneck (extract/push/review) until #242/#243 land; the conveyor + foreman-fan-out + multi-lane keeps the factory running at sign-out without the Operator. **How to apply:** on each wake/turn — tend seats (compact idle>40%), extract+validate+push+review any committed seat work, re-stock empty queues with vetted bounded units (merge-log-checked, Refs≠done), keep ≥3 lanes live per seat.

## Detail (moved from index 2026-07-05)
- NO inlining; saturate codex threads. Crons: seat-check :00, poll-devs :05, conveyor-tend :30.
- (extract→validate→push→review-as-ce-dev-2) + queue-stocking; NO seat idle.
