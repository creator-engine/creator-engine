---
name: ce-worktree-pythonpath-installsh-false-fail
description: "Testing a worktree with PYTHONPATH=validators FALSE-FAILS test_install_bootstrap (PYTHONPATH leaks into install.sh's subprocess venv → pip skips the app wheel → no cev3 script)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 0a8bea8d-23fe-4c41-b94c-effa4c1935d0
---

**LESSON (2026-06-13, ce-ops#71 build):** Running the validator suite from a
worktree with `PYTHONPATH=validators pytest …` makes
`validators/tests/integration/test_install_bootstrap.py::test_install_sh_creates_venv_runs_inventory_and_idempotent_rerun`
FAIL with `INSTALL_REFUSED entrypoint_missing: cev3 absent or not runnable` — a
**FALSE NEGATIVE**, not a code bug.

**Why:** that test shells out to `docs/install.sh`, which builds a fresh
`/usr/bin/python3.14 -m venv` and `pip install`s the app wheel into it. The
subprocess inherits `PYTHONPATH=validators` from the parent pytest env, so inside
that venv `creator-engine-validator==0.2.0` is already importable → pip treats it
as **already-satisfied → skips installing the wheel → no `cev3`/`ce` console
scripts** (deps like `jsonschema` aren't on PYTHONPATH, so they install — telltale:
venv `bin/` has `jsonschema` but no `cev3`; `pip show` Location = the worktree).

**How to apply:** to test a WORKTREE's code without leaking, do NOT set
`PYTHONPATH`. Instead make the package importable via an editable finder:
`cp -a /home/ce/creator-engine/.venv /tmp/<v>`, then `sed -i` the worktree path
into `…/site-packages/__editable___creator_engine_validator_0_1_0_finder.py`
MAPPING, and run `env -u PYTHONPATH /tmp/<v>/bin/python -m pytest …`. (Editable
`.pth`/finder lives in the PARENT venv's site-packages, which a fresh subprocess
venv does NOT inherit — so no leak.) NEVER edit the shared canonical `.venv`
(other governed seats depend on it) — copy it. Sharpens [[ce-validator-editable-install]];
twin of [[ce-validator-suite-slow-not-hung]].
