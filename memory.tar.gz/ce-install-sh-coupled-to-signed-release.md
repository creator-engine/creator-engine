---
name: ce-install-sh-coupled-to-signed-release
description: Editing docs/install.sh OR install-answers.schema.yaml breaks the signed install (llms-install.md pins both) unless re-signed or version-bumped
metadata: 
  node_type: memory
  type: project
  originSessionId: 69d258f7-dd44-46f6-b57e-19edfe8f7334
---

`docs/install.sh` is NOT freely editable — it is transitively covered by the signed install spec. Chain: the signed `docs/llms-install.md` pins `sha256s_sha256` = sha256 of `docs/downloads/<version>/SHA256SUMS`, and that SHA256SUMS contains the hash of `install.sh`. The `release_artifact_parity_guard` ALSO requires `docs/install.sh` == `docs/downloads/<version>/install.sh` byte-for-byte. So **any change to `docs/install.sh` changes the published SHA256SUMS → changes `sha256(SHA256SUMS)` → no longer matches the signed `sha256s_sha256` → `artifact_hash_mismatch` → the live install REFUSES.**

**Observed 2026-06-30 (N1d):** a seat added an ssh-keygen preflight to `docs/install.sh`, dutifully mirrored it into `docs/downloads/{0.2.0,0.3.0,0.3.1}/`, and broke 0.3.1's signed chain (SHA256SUMS went `da44ce6b`→`6768ec7c` while the signed spec still pinned `da44ce6b`). Caught at harvest before push.

**Observed again 2026-07-05 (ce-415-followup-tinies):** the pin set is BROADER than install.sh —
the signed `llms-install.md` ALSO pins `answers_schema_sha256` = sha256 of
`validators/creator_engine_validator/schemas/install-answers.schema.yaml`. A "tiny" schema-default
edit RED-failed 4 test_install_bootstrap integration tests (`artifact_hash_mismatch`) at host
harvest. Seat false-green cause: those tests are `@requires_ssh_keygen` and silently SKIP inside
containers lacking ssh-keygen — only the host preflight executes them. Any brief touching a
hash-pinned file (install.sh, downloads/**, install-answers.schema.yaml — grep llms-install.md
for `_sha256:` pins to enumerate) needs the release-op STOP line.

**Rule:** changes to `install.sh` (or any signed/published release artifact under `docs/downloads/<current-version>/`) are a RELEASE operation — they require either (a) a **version bump** to a new release that gets freshly signed, or (b) a **re-sign** of the current spec (the non-delegable ce-root-v1 controller act, see [[ce-release-spec-signing-procedure]]). A published version's artifacts are FROZEN. Put this guard in every dispatch brief that touches install.sh/downloads. The L7 auto-release pipeline is the proper home for install.sh changes (bump→sign→publish). Non-artifact code (the Python verify path: install_spec_signature_guard.py, update.py, v3_cli.py) is safe to edit standalone. Relates to [[ce-release-cut-off-current-main-not-feature-mergebase]].

## Detail (moved from index 2026-07-05)
- sh or docs/downloads/<ver>/ breaks the signed install (SHA256SUMS→sha256s_sha256 mismatch); it's a RELEASE op (bump+sign), not a standalone edit. Put in briefs that touch install.sh.
