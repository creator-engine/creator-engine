---
name: resume-state-claims-are-self-attestation
description: Resume-state claims are UNVERIFIED self-attestation — never copy a consequential claim forward without re-probing; mark PROBED vs ASSERTED
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 4d7ce6e3-ba6d-4f97-ae66-1f3e9598f80c
---

Forensics (2026-06-23) found the false "dev-4 CONTAINED gVisor" belief — which reached the Operator as fact and underpinned a same-night plan — originated in **this controller's OWN resume-state chain** (`.ce/state/research/`, ce-dev2 lineage, 06-19→06-21), e.g. `RESUME_STATE_CE_DEV2_20260620_ARC_EXEC.md:8` + ~6 siblings. It was **never true** (the same chain elsewhere admits the gVisor lane is "scaffolded, not built"), was **copied forward each context-rotation without re-probing**, then **silently dropped 06-22 — never falsified**. No code silent-fallback (wrappers/backends are fail-closed); the live seat just never went through them and containment was asserted in prose.

**Why this matters:** the resume-state chain — my continuity mechanism across `/clear` — is an **unverified attestation channel**. A claim written once propagates as truth across sessions. This is how a controller lies to itself (and the Operator) without anyone intending to.

**How to apply (every resume-state I write):**
1. Mark every load-bearing claim **PROBED** (cite the probe/command) vs **ASSERTED**.
2. NEVER copy a consequential/governance/containment claim forward without **re-probing it THIS session**.
3. When dropping a claim, **falsify it explicitly** — no editorial deletion.
4. Especially: runtime state (contained? egress? identity? push-capability?) is PROBED, never remembered.

Machine guard = ce-ops#221 (containment PROBED not reported). Reinforces [[ce-verifier-hash-false-positive]] (reproduce never transcribe), [[audit-findings-against-operator-directives]], [[ce-knowledge-ssot]] (capabilities PROBED not remembered).
