---
name: ce-website-versioning-policy
description: CE website is explicitly version-archived — snapshot the outgoing docs/index.html into site-archive/ in the same governed PR on every site change
metadata: 
  node_type: memory
  type: project
  originSessionId: 521e4ee7-d627-4b71-8e76-25cbd2e3b51e
---

**Operator directive (2026-06-07):** the Creator Engine website (`creator-engine.dev`, served from `docs/index.html`) must be explicitly versioned and tracked, not just recoverable via git history.

Policy (also documented in-repo at `site-archive/README.md`):
- The live site is always `docs/index.html`.
- When it is replaced, **in the same governed PR**, snapshot the outgoing bytes verbatim to `site-archive/index-vN-<slug>.html`, add a row to the `site-archive/README.md` version ledger (version · date · file · live commit · content SHA256 · notes), and promote the incoming version to "current — live".
- `site-archive/` is at repo root, tracked, but **NOT served by GitHub Pages** (Pages serves `docs/` only).

Versions to date: v1 = cyan launch (`b4fcce…`, #151); v2 = "Control-Room Violet" cyberpunk-neon redesign (`bcac9fbf…`, #155); v3 = FOMO + visual-augmentation pass (`fac5fa4d…`, #160); v4 = vocabulary-consistency tidy to the canon (`58adf49f…`, #173); **v5 = consumer-facing redesign** (`f39afa2f…`, **PR #174**, shipped 2026-06-08) — "two-altitude descent" (consumer promise → mechanism proof), title *"Turn your computer into a software factory you can trust,"* neon-lime *create/safe/go* accent over Control-Room Violet, a **"Built for security with NVIDIA OpenShell"** section (OpenShell isolates the runtime, CE governs the work — complementary infra, NOT an NVIDIA product → the OpenShell *security* positioning is approved-PUBLIC copy; the partnership/NVentures strategy stays private), and a consumer-worry→CE-mechanism safety table. Canon vocab retained. Design base is still "Control-Room Violet."

**v5 source-of-truth:** the approved redesign drafts live OUTSIDE the repo at `~/Documents/ce-website-redesign-round{1,2}-20260608/`; the **approved final = `round2/claude-v2-CORRECTED.html`** (NOT codex's — codex says "OpenShell *isolation*"; the Operator's quote "Built for security with NVIDIA OpenShell —" matches Claude's verbatim). Deployed by copying that file → `docs/index.html` via #174.

**Dropped-deploy LESSON (2026-06-08):** v5 was Operator-approved in a conversation that got `/cleared`, but the approval + the deploy were **never persisted or committed**, so the live site silently stayed on v4 while everyone assumed v5 was up. The live-bytes hash matched v4 — looked like a cache issue but wasn't. **When the Operator approves a site design, persist it AT approval-time (this memory) AND open the deploy PR immediately** — don't leave an approved redesign sitting only in `~/Documents`. A live/cache mismatch theory must be tested by hashing the live site vs the *approved* draft, not just vs `main`. (A [[persist-decisions-at-confirmation]] instance for site work.)

**BRAND UPDATE — live is now v8.1 "Factory Floor" (verified 2026-06-25 audit; supersedes the v5/"Control-Room Violet" claims above as CURRENT state).** The `site-archive/README.md` ledger now runs v1→v8; **consult that ledger for the live version, not this memory's list.** Live palette: violet `--violet #A06BFF` (bright `#B98CFF`, deep `#6E3CD6`) accent + warm near-black ink `#0C0B0A`/panels + paper `#FAF8F1` + moss `#7FB069` (go) + oxide `#E08B4C` (amber) + gate-red `#E0605C` (the single human-gate color); fonts Inter/system + SFMono. "Control-Room Violet" was the design base through ~v6.1; v8 retired the Choice cinematic, kept violet as accent. Deploy = **GitHub Pages serving `docs/` of main directly** (no workflow deploy; `docs/CNAME`=creator-engine.dev, `docs/.nojekyll`). No SSG exists — `docs/` is a flat pile of raw `.md` + the single hand-authored `docs/index.html`.

Every site change ships through the batch-strict governed flow ([[batch-strict-mode-gate-workflow]]) carrying its `.ce/pr-path-manifest.md`.
