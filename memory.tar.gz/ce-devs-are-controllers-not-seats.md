---
name: ce-devs-are-controllers-not-seats
description: "Each CE dev (dev-1/2/3/4) IS an independent controller, NOT a worker-seat — don't conflate peer controllers with the governed seats they spawn"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f7be5efa-fbab-480f-9569-a78cd97fcc3d
---

Each **CE dev (dev-1, dev-2, dev-3, dev-4) is by definition a CE *controller*** — an independent developer who installed CE on their own machine, with their own gmail + GitHub identity, collaborating on the CE repo in **team mode**. They are **peers**, not subordinate seats. (That is the whole reason for per-dev identities [[ce-per-dev-identity-secret-storage]] and the host-bound reviewer pairing [[ce-team-mode-host-architecture]].)

**The model:** a controller **spawns governed worker seats** (roles: implementer/researcher/reviewer per ce-ops#118) and manages them. The §7-governed, Ring-1 **push-block applies to those spawned WORKER seats** ([[ce-governed-seat-cannot-push]]), **NOT** to the dev-controllers. A controller pushes/merges as its own identity (merge stays human-gated [[ce-push-deploy-authority-model]]). The spawn/manage layer is currently **tmux**; v3.5 moves away from it [[ce-post-tmux-direction]].

**Why:** I (dev-2) repeatedly mis-described dev-1/3/4 as "my governed work seats hard-blocked from push." Wrong — they are peer controllers. (Operator correction, 2026-06-19.)

**How to apply:** Don't call dev-1/3/4 "seats" or imply they can't push. **As of 2026-06-19 the Operator RETIRED the dev-2 central-banking stopgap** ([[ce-controller-owns-dev1-intake]] superseded): **each dev-controller now pushes its OWN PRs as its OWN identity**; dev-2 (me) + Operator only *coordinate* the work until the forge automates ticket-pick + autonomous tackling (then controllers pick tickets and tackle them autonomously). Reviews cross the host-bound pairing; merges human-gated. Precondition to watch: each controller needs working own-identity push creds + push not hook-blocked — if a controller reports `PUSH-BLOCKED`, that's a provisioning gap to close, not a reason to revert to central-banking.
