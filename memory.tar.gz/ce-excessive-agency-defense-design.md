---
name: ce-excessive-agency-defense-design
description: CE defense-in-depth vs indirect-prompt-injection → destructive authenticated GitHub action; persisted design doc in ce-ops; NVIDIA-pitch NeMo material
metadata: 
  node_type: memory
  type: reference
  originSessionId: feb61ee1-f75d-487b-a752-0273a24dbeb8
---

**Persisted:** `creator-engine/ce-ops` → `designs/DESIGN_excessive_agency_defense_20260624.md` (committed 2026-06-24, ce-dev-2). Source = ultracode workflow `ws657ng74` (13 agents, 6 adversarially-verified lanes).

**Threat:** indirect prompt injection (poisoned issue/PR/comment) hijacks a *legitimately-authenticated* contained CE agent into a destructive authenticated action (force-push main, `DELETE /git/refs`, settings/webhook/secret mutation). Network/credential layers (OpenShell/OneCLI/OpenBao) do NOT stop it — the agent has legit write access; defense must move to **intent-validation + capability-minimization**.

**6 layers (kill-chain order):** L0 JIT least-priv App tokens · L1 L7 verb/path egress (Pipelock fork) · L2 MCP gateway (IBM ContextForge) · L3 NeMo Guardrails sidecar-verdict from Ring-1 hook · L4 out-of-band signed-intent escrow (reuse Ed25519 seam) · L5 typed-intent reader/writer (Integrator = writer side).

**Headline findings:** CE is **~70% on structural scaffolding** (Ring-1 hook, MUTATION_CLASSES blast-radius taxonomy, AWAITING-OPERATOR escrow, Ed25519 verify, Integrator writer-posture all in-repo). **Single highest-leverage control = L0 JIT least-priv tokens** — platform-enforced 403, GA today, CE owns every prereq; **= the [[ce-three-deputy-governance-model]] #228 cred-injection convergence**. **3 quick-wins (days)** fold into the Phase-1 herdr arc: (1) API-surface classifier in `hook_check.py` (today's biggest hole — injection via GitHub API dodges the CLI-keyed deny-map); (2) fail-closed App-grant minimum; (3) **Ring-1 deny raw git/gh/curl from workers + gVisor egress→OneCLI-only** (= the load-bearing work for a *safe* herdr attach). NeMo 75%→98.9% numbers REAL but measure generic policy violations, NOT destructive-git-detection — bench our own. Relates: [[ce-whole-fleet-to-containment-ratified]] · [[ce-nvidia-v35-strategy]].
