---
name: ce-onecli-adoption-ratified
description: OneCLI ADOPT-WITH-CONDITIONS RATIFIED 2026-07-04 — solo API-credential lane; 8 binding conditions; CE broker keeps governance lane
metadata: 
  node_type: memory
  type: project
  originSessionId: ff7c6aad-2efc-4c15-b974-baf109538a8e
---

Operator ratified 2026-07-04 (form-echoed on ce-ops#436): **OneCLI is adopted as CE's solo credential lane, ADOPT-WITH-CONDITIONS as written** in the diligence report `.ce/state/research/CE436_ONECLI_DILIGENCE_20260704T052354Z.md` (sha256 58865709822c…ba7e, authored dev-1).

The 8 binding conditions (all checkable): (1) CE-owned pinning — immutable digest, no `latest`, no self-update, rented-surface ratification for updates; (2) supply-chain verification (GHCR manifest digests arm64+amd64, CLI checksums) recorded in CE manifest; (3) policy split — OneCLI = API-credential injection lane ONLY, CE broker keeps ALL push/PR/governance authority; (4) launch-guard resolved via narrow AUDITED placeholder-sentinel exception (value-aware: refuse credential-named env unless value is exact registered sentinel AND proxy env points at gateway — never weaken name-check broadly); (5) admin API + Postgres network-isolated from agent-reachable networks (compose topology + CI guard, same shape as one-service-mounts-socket); (6) master key = plain file `/app/data/secret-encryption-key` — document honestly, mandate backup, never claim keychain protection; (7) headless = token-paste flow; (8) security watch on upstream unauth-exposure issues (#263/#268/#2903).

**Why:** rent-before-reinvent — building CE-native meant N-OS vault adapters forever; OneCLI collapses that; CE builds only its differentiator (governed-push broker).

**How to apply:** implementation rides the [[ce-two-plane-os-architecture-ratified]] canonical runtime image (solo compose topology). Fallback to CE-native thin gateway ONLY if license/pinning/isolation/placeholder conditions fail. [[ce-govern-rented-surface-updates]] [[ce-rent-or-fork-before-reinvent]]
