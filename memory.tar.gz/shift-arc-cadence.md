---
name: shift-arc-cadence
description: "Run a planned day-shift arc AND night-shift arc every day — attainable per-shift goals, filed as a ce-ops tracking ticket."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 6af27a0a-f480-4d6a-a107-3a8f00691c0d
---

Operator directive 2026-06-17: from now on, run a **day-shift arc** and a **night-shift arc** *every day*. Each arc = a planned set of attainable goals for that shift.

**Why:** planning creates structure and order; attainable per-shift goals beat an open-ended backlog. The arc is the shift's contract.

**How to apply:** at each shift boundary — (1) review the open ce-ops ledger + the *other* shift's outcomes, (2) identify the most *related + pressing* tickets (find the keystone that unblocks the most), (3) draft a themed arc with grouped scopes + a dependency map, mirroring the **#93 format** (a "Plan overview" tracking ticket: theme, mermaid dependency map, grouped scope-tickets, what's deferred/parked), (4) present to Operator for refinement, then file as a ce-ops tracking ticket. Reference [[ce-v3-g3-program-resume]] for live program state and [[persist-decisions-at-confirmation]] for reconciling done items.

First day-shift arc = 2026-06-17 (harden Ring-1 to a real control + clean state; dev-4 deferred to 06-18).
