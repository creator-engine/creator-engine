---
name: ce-cockpit-pivot-herdr-base
description: "Cockpit pivot (Operator, 2026-06-23): re-base the FORWARD cockpit on a herdr FORK (interactive/multi-session/resizable agent-attach), not the Textual read-only viewer or the hand-rolled PTY backend #368. Keep L2 read-model + Fork-2 seam; redesign L3 as a governed overlay on herdr."
metadata: 
  node_type: memory
  type: project
  originSessionId: a3bac9be-36f9-4b41-a61c-0f86c4d754cc
---

**Operator pivot (2026-06-23).** The CE Cockpit's real product need is a **live, interactive, multi-session agent terminal** with governance overlaid — which is herdr's problem space, not the Textual read-model viewer's. Trigger: the "Stream" section must (A) be **resizable** (agent sessions stream a lot), (B) be **interactive** — the user can talk to / steer the agent herdr-style, (C) handle **multiple concurrent coding-agent sessions** (CE runs many at once). The current Textual cockpit was built read-ONLY by design (ratified Fork 3 = observe + emit-command, never attach), so it *structurally cannot* meet A/B/C. The hand-rolled PTY backend (#368) was not designed from the ground up for these needs either.

**Decision: re-base the forward Cockpit on a herdr FORK** ([[ce-rent-or-fork-before-reinvent]] applied to the substrate). herdr (Rust ratatui multiplexer; resizable panes, live interactive attach, multi-session, agent-status, harness hooks, socket API; local-first/headless = fits CE's constitution) becomes the base. **Supersedes** the "extend #368" path AND the forward Textual L3.

**Distillation — preserve vs redesign (NOT a throwaway):**
- **PRESERVE (genuinely-CE, view-agnostic):** L2 read-model `cockpit_readmodel.py`, the Fork-2 refusal-record spine seam in `hook_check.py`, the CE_DEMO seed, the governance data model. (The design-of-record's principle-6 — "a future GUI replaces L3 ONLY, consuming the same L2 read-model" — was built for exactly this.)
- **REDESIGN (L3 only):** Textual standalone viewer → a **governed overlay on the herdr fork**. Lean **fresh redesign distilling the CE-cockpit learnings**, not bolting the old Textual app into herdr.

**The CE customization (the moat, not just renting herdr):** governed interactivity — steering a live agent = an **attributed Operator action on the spine**; the **refusal feed + envelope matrix overlay the live panes**; never-a-new-authority / grader-outside holds even WITH interactivity (the read-only MVP had sidestepped this via Fork 3).

**Phasing (corrected by Operator 2026-06-23):** NVIDIA pitch = **September** (the "01-Jul" in the cockpit doc/#74 is a stale demo-milestone). The **herdr-fork cockpit will be up and running by END OF THIS WEEK** (agentic pace + compounding autonomy work landing today). So there is NO phasing tension — the herdr-fork IS the cockpit and the Sept artifact; the Textual cockpit collapses to a **learnings + L2-donor**, NOT a stopgap. HOLD all Textual-L3 polish (incl. the withdrawn `cev3 cockpit --screenshot` rec) — don't gild the donor. Drive the herdr fork NOW (eval+design → build this week).

**RATIFIED 2026-06-23 (Operator):** **Posture A** (AGPL source-available fork; Python governance stack runs as a SEPARATE PROCESS over the herdr socket → copyleft covers only the rented multiplexer, the moat stays proprietary) + **fork supersedes #368** (retire `pty.fork`, keep its registry seam). herdr license CONFIRMED = `AGPL-3.0-or-later` (Cargo.toml verbatim). "Start the UI this week." Build started at U1. AGPL §13 obligation: publish modified-herdr source to network users — acceptable for a forked commodity; fork lives PUBLIC (creator-engine side), governance stays PRIVATE (ce-ops) via process separation. The separate-process boundary is LOAD-BEARING (don't link Python into the AGPL Rust binary). **GATE "Fork-AGPL-firewall" — ✅ CLEARED by legal dep (Operator, 2026-06-23).** Posture A's proprietary-moat rests on "separate process over a socket = separate work, outside AGPL copyleft" (arm's-length IPC = separate works; §13 only obligates publishing the modified *herdr* source). Operator confirmed this is checked + cleared with CE's legal department — the separate-process boundary is legally sound to keep CE's Python governance stack proprietary. No remaining legal blocker for the herdr fork / pilot. Keep the boundary architecturally clean (never link Python into the AGPL binary) so the cleared position holds. **U2 DE-RISK DONE 2026-06-23:** herdr builds clean on DGX aarch64 (cargo+Zig 0.15.2, ~83s, no GPU dep) — the flagged Fork-aarch64 risk is RETIRED. Fork AGPL-compliant (NOTICE+boundary committed ff92496). U1=PR#378, U2=PR#379 (both open); U3 (live terminal_kind=herdr + retire #368) gated on both landing.

**Path:** eval ticket **ce-ops#217** (expanded to "herdr as Cockpit base", fork-vs-extend-#368, license, containment fit, governed-interaction model) → then a **fresh cockpit-on-herdr design** (reuse L2 + Fork-2 seam) → build. Build awaits eval + design + Operator go. Relates: cockpit lane #1, journey cockpit #45, [[ce-cockpit-b-design-ratified]] (L3 superseded forward), [[ce-cockpit-frontend-agnostic-core]] (the L2/L3 split that makes this cheap), [[ce-post-tmux-direction]], #368.

## Detail (moved from index 2026-07-05)
- eval=ce-ops#217. Related: [[ce-cockpit-b-design-ratified]] [[ce-cockpit-frontend-agnostic-core]]
- redesign L3 as governed overlay.
- KEEP L2 read-model+Fork-2 seam.
