---
name: ce-fleet-deployment-surfaces
description: "How merged CE code reaches running fleet seats — merged≠deployed; 3 distinct surfaces (hook=pull, launcher-inject=relaunch, capability=needs-runner)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 4d7ce6e3-ba6d-4f97-ae66-1f3e9598f80c
---

**Merged to main ≠ deployed on the live fleet.** Our seats are long-lived run-from-source checkouts; landing a PR changes `main`, not what a running seat executes. There are **three distinct deployment surfaces** (confirmed 2026-06-23 via deployment-surface map):

1. **Per-tool-call hooks (e.g. §7 foreman hard-deny in `hook_check.py`)** — invoked from `.claude/hooks/ce-pretooluse.sh` → `hook-check` **in the seat's checkout**. Deploys the moment the seat's checkout is on main-with-the-code. Seats branch fresh off `origin/main` per task, so it deploys **automatically at each seat's next unit boundary — NO relaunch.** Don't force-rebase mid-build (that's the run-from-source patchwork we're retiring per [[ce-fleet-retirement-clean-install-program]]).
2. **Launcher-inject (e.g. born-a-foreman charter + worker_spawn capability in `brain_bootstrap.py`)** — injected AT LAUNCH, pinned in the seat's `CE_BRAIN_BOOTSTRAP_REF` env. Existing seats carry the OLD charter → **requires a canonical `ce launch` relaunch** ([[ce-seat-relaunch-canonical-launch-only]]). This is the canary-relaunch step.
3. **Capability libraries (e.g. Integrator MVP ce-ops#216)** — merged pure modules (eviction_detection/deterministic_resolvers/executor/integrator_escalation) **do nothing until a RUNNER drives them.** No poller/daemon/CLI wires them; live merge actions are fail-closed in `integration_queue_dry_run.py`. "Deploy" = **build the runner** (ce-ops#218: belt-poller now → always-on daemon as the full-autonomy direction), gated + dogfooded on a real DIRTY PR.

Clean-install path EXISTS (`pyproject.toml` console_scripts `ce`/`cev3`; ce-ops#206) but v1.0 fleet still runs from source — target deploy folds all three into the clean `ce` install canary-replace.

## Detail (moved from index 2026-07-05)
- launcher-inject=canonical relaunch · capability=needs RUNNER (#218). Don't force-rebase mid-build.
- hook=pull/next-branch NO-relaunch ·.
