---
name: ce-cockpit-frontend-agnostic-core
description: "HARD Cockpit design rule — Layer-2 projection/read-model stays view-agnostic so a future full GUI is non-blocked; Textual is one view, additive not committing"
metadata: 
  node_type: memory
  type: project
  originSessionId: 3d6c61d0-a2de-4549-96f6-26d4d9e12958
---

**Operator requirement (2026-06-09), locked as Cockpit-B design principle 6.** The Cockpit must be built as **three layers** so a future **full GUI/app for CE** (web SPA / Tauri / Electron / native) is never blocked by the Textual (TUI + `textual serve`) choice:

- **L1 — source of truth:** the evidence-spine (JSON, hash-chained) + pane/claims registry (`.hermes/active-work-ledger/`) + spend ledger. View-agnostic, already exists.
- **L2 — projection / read-model:** a **pure, JSON-serializable Python module** that folds L1 events → board cards, refusal feed, envelope matrix, resource meters, and emits governed commands. **VIEW-AGNOSTIC + REUSABLE.**
- **L3 — view:** Textual widgets that only *bind* to L2.

**THE HARD RULE:** *all board/refusal/envelope/meter computation lives in L2 — NEVER buried in Textual widget callbacks.* If projection logic leaks into widget code, a future GUI must re-derive it. Keep L2 pure + JSON-serializable (expose an `ce cockpit --json` / local read-API seam) → a future GUI replaces **L3 only**, consuming the same L2 + L1 JSON.

**Why this is the right first move, not a terminal-only commitment:** `textual serve` is additive (browser-as-terminal over WebSocket — see [[explain textual serve in ce-cockpit design]] context); Textual + a future GUI can coexist long-term (TUI for SSH/headless power-users, GUI for a broader audience — cf. k9s+Lens, lazygit+GitKraken). Textual ships cheap/fast/daemonless/demo-ready for the **01-Jul NVIDIA pitch** without committing CE to a heavy GUI stack prematurely; by the time a full GUI is justified, L1+L2 are already its backend.

**Convergence:** L2 is the SAME module as harness-paper **feature F1** (the read-only "Deep Telemetry" projection over the spine — [[ce-code-as-harness-paper-learnings]]). Build it once, view-agnostic → serves the Cockpit TUI + the telemetry/retrospectives surface + a future GUI. **This is a HARD constraint for the Cockpit B-gates, not optional.** Design-of-record: `~/Documents/ce-cockpit-b-design-20260609.md` §3.0 principle 6. Twin of [[ce-competitive-cockpit-b-inputs]].

**Operator product review + MODE CORRECTION (2026-06-12, ce-ops#45):** CE has THREE modes — **CEO · DEV (default) · strangeLoop (experimental)**. CEO mode = the **JOURNEY board** — process picture · where-am-I on the Frame→Ship arc · what-needs-me · click-through PLAIN-LANGUAGE clarifications (never assume an experienced developer) · visual roadmap/arc. DEV mode (default) = the technical fleet-ops cockpit (B.1–B.8 = its maturing face) evolving toward FINE-GRAINED control + in-depth understanding, NOT simplification; the mode switch IS the persona dial. L2 rule unchanged (journey state = a new pure read-model join; Scope state derives the stage skin). Post-pitch G-7 flagship — the expert cockpit stays correct for the 01-Jul demo.
