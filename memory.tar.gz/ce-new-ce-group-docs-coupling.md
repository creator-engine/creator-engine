---
name: ce-new-ce-group-docs-coupling
description: "Adding a top-level `ce` CLI command group forces README.md + test_v1_docs_reconciliation.py edits — name them in the gate manifest"
metadata: 
  node_type: memory
  type: project
  originSessionId: 1237f298-b167-4e2b-bd25-8c2d2c5436a4
---

**LESSON (ce-ops#38 implementation, 2026-06-12):** any gate that adds a new
**top-level `ce` command group** (e.g. `ce claim`) has a hidden out-of-manifest
coupling that closed-manifest gate specs keep missing:

- `validators/tests/unit/test_v1_docs_reconciliation.py` introspects the argparse
  parser and asserts the as-built `ce` group inventory against a **hardcoded set**
  (`test_as_built_ce_inventory_matches_expected`) AND that **`README.md` documents
  every group** (`test_readme_documents_every_ce_command_group`).
- So a new group breaks BOTH unless the manifest also includes `README.md` and
  `validators/tests/unit/test_v1_docs_reconciliation.py`. There is **no** code-side
  workaround — a top-level group always trips the inventory guard.
- **THIRD coupling (confirmed ce-ops#42 W8, 2026-06-28):** a new group also makes the
  **autogen CLI reference** `.ce/reference/cli.generated.md` stale → gate
  `VAL-AUTOGEN-STALE-CLI` (`checks/cli_reference_autogen_sync.py`) fails closed.
  Regenerate + commit it: `python scripts/gen_cli_reference.py --write` (verify with
  `--check`). Do NOT hand-edit. So the FULL coupled path-set for a new `ce` group is:
  **README.md + test_v1_docs_reconciliation.py + .ce/reference/cli.generated.md** (plus
  carrier/changelog). A dispatch brief that omits the autogen reference will STOP-LINE
  the seat on an out-of-scope required file (dev-1 W8 did exactly that — correct behavior).

ce-ops#38's ratified 15-path manifest omitted both → unsatisfiable (couldn't honor
zero-out-of-manifest-diff AND full-suite-green). Resolved by an **Operator-ratified
+2-path amendment** (15→17, recompute the path-set hash). A SECOND forced conflict
in the same gate: spec mandated `--ticket` REQUIRED on `cev3 drive/review --spawn`,
but the manifest excluded `test_v3_cli.py` whose `--spawn` tests omit a ticket →
implemented `--ticket` as **optional-but-honored** (mirrors v1 `--claim-ticket`),
deviation declared in the carrier.

**Apply:** when composing ANY gate spec that adds a top-level `ce` group, pre-list
`README.md` + `test_v1_docs_reconciliation.py` in the manifest. Same class as the
wheel-pair rule. Twin of [[ce-pr-path-manifest-carrier-required]] and
[[ce-dispatch-ordering-discipline]]; the optional-ticket deviation pairs with
[[batch-strict-mode-gate-workflow]] (halt+declare over scope-creep).

**GENERALIZED (ce-s1a, 2026-07-05) — the coupled-regen family is wider than new groups:**
- New CLI FLAG/CHOICE values (e.g. a new --backend choice) → `.ce/reference/cli.generated.md`
  stale (`gen_cli_reference.py --write`).
- Schema file edits → `.ce/reference/schemas.generated.md` stale (`gen_schema_reference.py --write`).
- A new module importing across the shared→v3 boundary (e.g. a new runner backend importing
  runner.backend/gvisor_proxy_backend) → version_boundary VAL-VERBND-SHARED-EDGE unless
  baselined in `_versions.py`.
Any of these missing from a brief costs a full BLOCKED/failed-preflight round-trip (ce-s1a: 2
root causes → 40 test failures via the check-examples cascade; looked like ~30 unrelated
regressions but was mechanical). Brief authors: name the regen commands + allowlist step in the
allowed paths whenever a unit adds CLI surface, schema content, or cross-boundary imports.

## Detail (moved from index 2026-07-05)
- test_v1_docs_reconciliation → manifest must name README.md + that test.
