---
name: ce-resume-state-seat-header-protocol
description: "Protocol (2026-06-14, after a /clear topology misread): every RESUME_STATE must lead with seat-identity + host-topology; bare local pane ids forbidden as cross-seat refs"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f6051cd7-5007-4d0f-9f8a-6ce9e4fbfe1f
---

**Origin (2026-06-14):** after a `/clear`, the dev-2 design seat read the program RESUME_STATE, saw "dev-1 … pane `%3` … I OWN its intake," ran `tmux capture-pane -t %3` against the **local** tmux, found nothing, and wrongly reported dev-1's seat dead + its #226 revision stranded. Ground truth: this host = **CE-DEV-2**; **dev-1 is the remote Hetzner VPS** and its controller is **remote pane `%3` in a remote tmux**, driven from the orchestrator session — never local. The Operator: "I need to be able to trust our save-state and resume-state protocols."

**Root cause = LOAD failure, not a save gap.** The topology memories ([[ce-team-mode-host-architecture]], [[ce-dev1-access-method]], [[ce-controller-owns-dev1-intake]] — which literally warns "%3 is a remote tmux, not visible in the local laptop tmux") all EXIST, but `MEMORY.md` was 32 KB vs the 24.4 KB load budget, and those entries sat below the ~line-75 cut → they silently never loaded. Compounded: the resume file used first-person "I" + a bare pane id, assuming a seat-frame that wasn't in context.

**Why:** a resume file is read by a DIFFERENT seat after context loss. It cannot assume the reader knows who/where it is. First-person "I" and bare local handles (`%3`, `%131`) are ambiguous across seats and hosts.

**How to apply:**
1. **Every `RESUME_STATE_*` opens with a `SEAT IDENTITY & TOPOLOGY` header:** which host+seat WROTE it; the peer-seat → host → reach-method map (e.g. "dev-1 = remote Hetzner, `ssh ce-dev-1`, controller = REMOTE pane %3 in a remote tmux"); the resume-root path (host-dependent: laptop `.ce/state/research/`, VPS `~/creator-engine/.ce/state/research/`).
2. **Qualify every pane/tmux ref by host+session** (`ce-dev-1 remote-tmux %3`), never a bare local id; state explicitly when a handle is NOT local.
3. **No naked first-person "I"** for ownership/actions — name the seat ("the dev-2 Controller owns intake").
4. **Before acting on a resume pointer that names a pane/host/file, VERIFY it resolves on THIS host** (tailscale/tmux/ls) before concluding state — don't infer "dead/stranded" from a failed *local* lookup of a *remote* handle.
5. **Keep `MEMORY.md` under the 24.4 KB load budget** so seat-identity/topology entries (kept at the TOP) always load. Compress index lines ≤ ~180 chars; detail lives in topic files. Twin of [[report-context-each-turn]] / [[persist-decisions-at-confirmation]].
6. **CAPTURE THE TRANSCRIPT, don't summarize it.** When the Operator asks to preserve a conversation, or at any heavyweight state-save, COPY the session's JSONL transcript into the resume package and reference it — a hand summary is lossy and drops the granular decision-context + the exact conversational position. The harness already persists every session at `~/.claude/projects/-home-…canonical/<session-id>.jsonl` (nothing is truly lost, but it's invisible unless the resume-state points to it). Bind transcripts under `.ce/state/research/transcripts/` with an INDEX; render a readable `.md` if useful. (Second failure 2026-06-14: a 28-line summary stood in for the morning-shift transcript the Operator explicitly asked to keep.)
