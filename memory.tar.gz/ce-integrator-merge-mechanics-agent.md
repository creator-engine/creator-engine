---
name: ce-integrator-merge-mechanics-agent
description: "The Integrator — CE's first-class autonomous merge-mechanics agent (owns rebasing/conflict-resolution); ratified-in-principle 2026-06-23"
metadata: 
  node_type: memory
  type: project
  originSessionId: 2b67ead0-9d4c-41c1-974e-43b059ac1239
---

**Answers "who owns rebasing in CE?"** — the **Integrator**, a first-class CE role (Operator-approved name + design-in-principle, 2026-06-23). Doc: `ce-ops/designs/DESIGN_INTEGRATOR_merge_mechanics_20260623.md`; ticket **ce-ops#216**.

**Principle:** split merge **MECHANICS** (rebase/resolve/re-green/re-enqueue → Integrator, **never reaches the user**) from merge **RATIFICATION** (governed gate; user only on a genuine **product** decision). The user must never see a rebase. Refines [[ce-push-deploy-authority-model]]; sibling of [[ce-merge-queue-offloads-mechanics]].

**Design (grounded in Claw's ClawSweeper — researched 2026-06-23):**
- First-class role **distinct from review/build agents** (Claw's proposer-vs-lander split: `clawpatch` proposes/never lands; `ClawSweeper` lands).
- **Deterministic-first, read-only-LLM-resolver, deterministic-executor-writes** — the conflict LLM holds NO write authority (write creds minted only after it exits). This is already CE's posture ([[ce-governed-seat-cannot-push]], minter-gate).
- **Control plane + scheduled-ephemeral contained execution**, NOT a long-lived daemon (Crabfleet shape; fits containment).
- **Escalation = CE's differentiator/whitespace:** mechanical conflict resolved silently; product-decision conflict → **plain-language choice** via the contact-on-need/channel layer ([[ce-visibility-channel-emission-model]], notify_feed webhook #364) — never a diff/marker/technical label (Claw only escalates technically to a maintainer).
- **Composes from existing CE pieces:** notify_feed/#364, governed can't-push seat, spine executor, belt polling, ratification gate, M2 container (#207/#208).
- Phase-3 structural fix: **per-module registration** to kill the `_versions.py` single-registry collision class (the conflict that triggered this design).

## Detail (moved from index 2026-07-05)
- rebase/conflict mechanics (user never sees a rebase); ce-ops#216.
