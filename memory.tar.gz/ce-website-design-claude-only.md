---
name: ce-website-design-claude-only
description: "Operator directive 2026-06-11 — ALL website design tasks go to Claude-only agents (Opus 4.8 or Fable 5, effort:high), never Codex/GPT-5.5, for design consistency"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2bae9844-7348-4cd1-9a89-54226b622914
---

**Operator directive (2026-06-11, v7 ratification):** all `creator-engine.dev` website DESIGN tasks are handed to **Claude-only agents** — Opus 4.8 `effort:high` or Fable 5 `effort:high`, chosen by the task's complexity/reasoning ceiling. NOT to Codex/GPT-5.5 seats.

**Why:** keep the site's design language consistent — one model family's aesthetic across all design iterations.

**How to apply:** when composing/launching any site-lane task (layout, art, logo, CSS, copy-styling), route to a Claude seat/subagent and state the model+effort choice in the launch. Codex remains fine for non-design site mechanics (e.g. pure infra/CI legs). Refines [[ce-model-effort-routing-policy]] for the site lane; pairs with [[ce-website-versioning-policy]] + [[ce-site-lane-resume]].


**AMENDED (Operator, 2026-06-12 — after the site-v8 PR1 failure):** **Fable 5 is BARRED from all web-related design work.** The v8 PR1 build (Fable seat) was rejected as amateurish — misaligned hero, basic static conveyor image, nothing like the ratified reference (software-factory.dev). Routing for web design = **Opus 4.8 / effort xhigh**, never Fable, never Codex. Recorded as a graded-trial datum: Fable-5 web design = FAIL. Process lesson: design seats must NOT declare green on self-assessment — a visual checkpoint (screenshot/preview against the reference, Operator eyes) gates green for design work.
