---
name: codex-first-routing-directive
description: codex-first routing — ALL work seats on codex+gpt-5.5; codex effort DEFAULT = HIGH (not xhigh) per 2026-06-22 benchmark review; only the 3 controllers stay claude-code
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 3d84878f-7476-4bab-8598-c35b8c1edce1
---

**⚡ EFFORT UPDATE (Operator, 2026-06-22, standing):** every codex agent used by the CE dev team **defaults to reasoning `high` (NOT `xhigh`)** — decided after reviewing several benchmarks. **dev-1/3/4 already manually switched.** Apply to all newly-launched codex seats (`ce launch --harness codex` + config/effort=high) and any codex relaunch. (So both fleets now run `high`: Claude controllers [[ce-claude-controllers-effort-high-not-xhigh]] + codex agents — convergent.) The xhigh references below are SUPERSEDED for effort; the codex-first ROUTING (work→codex, controllers→claude) still stands.

**Standing directive (Operator, 2026-06-17, effective immediately):** route ALL work to **codex + gpt-5.5** (effort now `high` per the 2026-06-22 update above; was xhigh). Only the **three controller seats** (dev-1, dev-2, dev-3) remain on **claude-code**. Every launched work seat — reviewer, verifier, builder, researcher — is codex now, NOT claude.

**Why:** the Claude Max subscription is burning abnormally — **38% of the WEEKLY limit in ONE day** (first day of the weekly window). Weekly reset = **Wed 01:59 UTC**. Goal: survive on remaining tokens until reset.

**How to apply:**
- Do NOT launch claude work seats (reviewer/verify/build). Use [[ce-codex-seat-launch-method]] (`ce launch --harness codex --session <n>`; codex bypass-mode).
- Controllers stay claude for ORCHESTRATION ONLY — minimize controller (incl. my own dev-2) claude burn; push the heavy reasoning to codex seats.
- Codex seats lack the Ring-1 reviewer-authority hook → run under Codex external-gate posture (Env-2): independent analysis + distinct-actor `gh pr review` as `ubuntuaws745-cmyk`; controller holds the merge gate.
- **Trajectory / STATUS 2026-06-18:** dev-4 = first codex controller (DONE — Stage-1 proved Codex-as-controller + CE-on-NVIDIA-aarch64). **dev-1 CONVERTED to codex controller 2026-06-18** (codex-cli 0.139.0 @ `~/.npm-global/bin/codex` as user `ce`, authed; safe-overlap: codex up+resumed from `RESUME_STATE_CE_V3_G3_PROGRAM_20260618T0334Z.md` BEFORE killing claude %3; runs in tmux `ce-orchestrator:codex-ctrl` %195; claude %3 retired, no claude proc for ce). **dev-3 CONVERTED to codex 2026-06-18** (codex-cli 0.141.0 @ `~ce-dev-3/.npm-global/bin/codex`; headless OAuth kept failing → **copied `ce`'s `~/.codex/auth.json` to ce-dev-3** — Operator-ratified: subscription auth has NO per-inference identity to lose, and the governance-critical FORGE identity stays per-dev (separate git/token mechanism); doctor ✓ auth chatgpt; safe-overlap resume from `RESUME_STATE_ce109_s8c_20260618.md`; runs tmux `dev3-onboard:codex-ctrl`; old claude orphaned the pane-kill → SIGKILL'd 816270; NO claude on VPS). **✅ CONVERSION COMPLETE: dev-1 + dev-3 + dev-4 ALL codex; only dev-2 (this seat) on claude = token-survival goal achieved.** dev-3 pending handoff: ce109 unpushed `9a0948e`, 5 failing tests → needs fix/review before push (dev-2 = review venue).
- **Codex headless-auth lesson:** on a headless VPS, `codex login` OAuth (localhost:1455 callback) is fragile; reliable paths = `codex login --with-api-key` (stdin) OR copy an existing `~/.codex/auth.json` (same fleet/subscription). Codex self-update prompt on launch can kill a fresh seat → SKIP it. Conversion = safe-overlap pattern: verify codex authed+up+resuming, THEN retire claude. Supersedes all-three-claude in [[ce-claude-controllers-effort-high-not-xhigh]].
- Relates to the burn problem behind [[headroom-eval-no-go]] + ce-ops#112 (CE-native token saver).
