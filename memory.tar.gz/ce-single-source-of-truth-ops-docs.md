---
name: ce-single-source-of-truth-ops-docs
description: "Operator wants a single source of truth (authoritative, code-synced docs) for CE ops so the controller consults docs in advance instead of reverse-engineering code"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: cb9529a3-0334-40ee-9ca9-b0f0434abc87
---

Operator directive 2026-06-21 (after I reverse-engineered the codex launcher live — `codex_launch_spec.py`, the CDX-D-6 bypass-mode check, the seat isolation model from `/proc` — to spin up seats): **CE needs a single source of truth.** The controller should be able to consult authoritative documentation and understand *in advance* what is possible and how it's done — NOT go exploring the code every time.

**Why:** ad-hoc exploration is slow, repeated each session, and (worse) UNSAFE — a controller guessing at governance/launch/containment internals is exactly how a mis-governed or credential-exposed seat gets created. The rules already exist in code (refusal clauses, launch contract, isolation model); they're just not discoverable as docs.

**How to apply:** (1) When a capability lacks an authoritative doc, that's a CE product gap → file a ticket ([[ce-bake-gaps-into-ce-not-conventions]]), don't just learn-and-move-on. (2) Prefer consulting the SSOT doc before reverse-engineering; if none exists, the exploration's findings should feed the doc. (3) The SSOT must be kept in sync with the code (drift-tested / generated), or it becomes another stale trap — see [[ce-resume-state-seat-header-protocol]] for the cost of stale topology docs. First instance → seat launch / governance / containment runbook (filed this session; ties to #148 seat-launch-from-unprovisioned-env).
