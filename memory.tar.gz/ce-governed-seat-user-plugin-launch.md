---
name: ce-governed-seat-user-plugin-launch
description: How to launch a governed CE seat that also loads a user-level Claude plugin (e.g. frontend-design)
metadata: 
  node_type: memory
  type: reference
  originSessionId: 5f2b5f45-8ec4-4ec3-9b6e-1196f3b2bc05
---

To launch a **governed** CE seat (§7 hooks active) that ALSO has a **user-level plugin** (e.g. `frontend-design`), use `--setting-sources user,project` in the seat's claude argv — NOT `--setting-sources project` (the default governed recipe).

Why: the §7 governance hooks live in **project** settings (`creator-engine/.claude/settings.json` → PreToolUse/Stop → `.claude/hooks/ce-*.sh`), while plugins are enabled in **user** settings (`~/.claude/settings.json` → `enabledPlugins`). `project`-only loads hooks but drops the plugin; `user,project` loads both (hooks are additive, governance unchanged). Effort/model from user settings also apply (xhigh + opus-4-8) — the seat's `◉ xhigh` footer is the quick proof user source loaded.

Governance is NOT weakened: the launch already uses `--dangerously-skip-permissions`, so the PreToolUse hook is the real gate regardless of permission mode; adding `user` only adds the plugin + user prefs, it can't remove the project hooks.

Full DGX seat launch (shell-wrapper workaround for the `ce launch` direct-spawn bug): `tmux new-session` (shell) + `remain-on-exit on`, cwd = the worktree (so `$CLAUDE_PROJECT_DIR` resolves there and project hooks load), then `send-keys`: `claude --model=claude-opus-4-8 --dangerously-skip-permissions --setting-sources user,project --strict-mcp-config --mcp-config <empty {"mcpServers":{}}>`. The plugin files must exist for the launching OS user (`~/.claude/plugins/...`). Used for the web-control-UI design seat (ce-ops#28).

## Detail (moved from index 2026-07-05)
- governance unchanged.
- gives user plugins w/ project hooks.
