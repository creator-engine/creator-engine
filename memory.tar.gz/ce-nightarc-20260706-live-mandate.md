---
name: ce-nightarc-20260706-live-mandate
description: "LIVE ARC = NIGHT 2026-07-06→07, ratified D1-D8 all yes; lanes N-A..N-E; parity+fleet-homogeneity+Arad-journey+dark-factory; hard stops: no comms/sends/signing/arming/dev-1-containment-execute"
metadata:
  type: project
---

NIGHT ARC 2026-07-06→07 RATIFIED (Operator ~17:2xZ: "night arc ratified as written, D1-D8 all
yes"). SSOT: .ce/state/research/NIGHTARC_MANDATE_CE_DEV2_20260706_NIGHT.md (+ DECISIONS_20260706.md
entry 8 — the controller-agnostic record, written FIRST per doctrine; this file is the mirror).

Lanes: N-A parity critical path (round-cycles → C5 cutover D1 → #228 JIT build D2 → contained
gate canary SHADOW D3 → concurrent soak clocks); N-B fleet homogeneity (#479/#480 → Ring-1 smoke
D4 → dev-4 clean-install relaunch D5 → dev-1 containment PREP-ONLY → drill #1 D6); N-C Arad
journey (#485/#486/#487/#489/#490, ZERO sends, morning = Arad-send readiness note); N-D dark
factory (dep-unlock shadow audit, #488 slice 1, #491 slice 1, #482/#483/#484 designs); N-E
hygiene (evidence-based gate, 90-min checkpoints, 0.3.4 ASSEMBLE-ONLY D8).

D7: dev-3 switched commit-only → BROKER SELF-PUSH for docs/code-class (delivered ~17:3xZ);
reviews + gate-adjacent units stay commit-only.

**Why:** the two north-star clocks (containerized-controller parity; whole-fleet same-version
containerized) + Arad-package program + dark-factory objectives, batched so the Operator could
leave the factory to the controller overnight.
**How to apply:** hard stops override everything: no external comms/sends (Arad/Nitzan/public),
no signing, no dep-unlock arming, no mythos/settings changes, no ghcr publish, no dev-1
containment EXECUTION, gate authority never leaves CE-DEV-2. Morning report surfaces
AWAITING-OPERATOR first. Supersedes [[ce-nightarc-20260705-live-mandate]].
