---
name: ce-contained-seats-cannot-submit-reviews
description: "Contained (Model-B, zero-cred) seats can't SUBMIT PR reviews — review submission needs its own host-side credentialed chokepoint, the review analog of the push/publish-gate."
metadata: 
  node_type: memory
  type: project
  originSessionId: 2fe171be-e2b8-479e-b208-4b0153b128cf
---

A fully contained seat ([[ce-contained-controller-push-model]] Model-B = zero creds in the box) **cannot submit pull-request reviews**: `gh pr review` needs a token both to fetch the private repo's diff AND to post the review. This is the **review analog of the push problem** — just as Model-B routes pushes through a host-side / publish-gate ([[ce-integrator-merge-mechanics-agent]], #399) credentialed chokepoint, *review submission* needs its own credentialed chokepoint: the contained seat produces the verdict (judgment), and a host-side credentialed path submits it **as that seat's identity** (preserving peer-review [[ce-review-model]] — NOT submitted as overwatch, which is merge-mechanics-only).

Surfaced by the dev-3 VPS containment canary (2026-06-23). **Key implication:** you cannot convert the LAST credentialed (non-contained) seat without stranding the fleet's review/merge-submission capacity — every seat contained ⇒ nobody can submit a peer review. So during fleet conversion, keep ≥1 credentialed seat as reviewer until the review-submission chokepoint exists. This is why dev-1's VPS conversion was deferred to the supervised morning (dev-3 converted first as canary; dev-1 held as the credentialed reviewer). Follow-on: design a review-submission gate (verdict-in-box → host-side attributed submit), sibling of the publish-gate. Same applies to the contained controller (W5) and DGX dev-4.
