---
name: ce-claude-controllers-effort-high-not-xhigh
description: "STANDING — every CE controller on Claude Code + Opus-4.8 runs effort:high, not xhigh (until further notice)"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9856ffdc-c843-4966-a075-107dc335e56a
---

Operator directive 2026-06-17 (until further notice): **every CE Controller running Claude Code + Opus-4.8 uses `effort:high`, NOT `effort:xhigh`.** dev-2 (me) and dev-3 already switched by the Operator; dev-1 to be switched at its next clean stop.

**Why:** token efficiency at the controller tier — xhigh's extra reasoning headroom isn't worth the cost for orchestration/steering work; high is the right ceiling for a Claude controller. (This OVERRIDES the "Opus 4.8 → xhigh" guidance in [[ce-model-effort-routing-policy]] for the controller role specifically; codex seats keep gpt-5.5 xhigh.)

**How to apply:** new Claude/Opus-4.8 controller sessions start at `/effort high`. To switch a running controller without losing state: save a full resume state → `/clear` → `/effort high` → resume state. For dev-1 (remote, I'm its router): drive that sequence into its pane at its next clean stop (relay `/clear`, `/effort high`, then a resume prompt). Revisit only on explicit Operator change.
