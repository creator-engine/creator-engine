---
name: ce-mac-onboarding-via-linux-container
description: Mac onboarding via a Linux container (NemoClaw/Docker) using existing Linux wheels — likely lets us defer the native-Mac (Seatbelt + Darwin wheels) port entirely
metadata: 
  node_type: memory
  type: project
  originSessionId: 169d3cef-709b-4bce-82ab-bc9d1d64a305
---

**OQ-1 = Option A RATIFIED (Operator, 2026-06-29):** Linux bwrap+Landlock+seccomp + deny-by-default egress proxy for os-native; macOS Seatbelt as a parallel lane; gvisor-proxy stays default; os-native user-elected + fail-closed; CE-native jail deferred. Unblocks ce-ops#353 (os-native selectability fix) + #352 (macOS lane).

**The strategic simplification (Operator "aha") — CORRECTED attribution:** the Linux runtime on a Mac comes from a **container/VM (Docker/Podman/VM)**, NOT from "NemoClaw" (NemoClaw is the onboarding/blueprint wrapper; OpenShell is the sandbox runtime — see [[openshell-nemoclaw-stack]]). On a Mac, OpenShell sandboxes via Docker/Podman/VM → a **real Linux kernel** → CE runs *inside* with bwrap+Landlock-equivalent isolation provided by the container, and the installer sees `uname=Linux` → **existing Linux wheels work → no Darwin wheel builds and no offline ce-root-v1 re-sign.**

**Consequence (conclusion stands, mechanism corrected):** Mac support can ship **TODAY via a Linux container/VM** (Docker Desktop standalone, or OpenShell-orchestrated on the NVIDIA platform) using existing wheels — Nitzan's viable path now. The **native-Mac port (#352: Seatbelt backend + Darwin wheels + re-sign) becomes DEFERRABLE** — a later nice-to-have only for users who refuse a container runtime (truly-native, no-Docker Mac).

**The one cost:** requires a container/VM runtime on the Mac. Acceptable for v1. Reframe #352 → "Mac-via-container now; native Seatbelt later if demand."

**Corrected component model (per [[openshell-nemoclaw-stack]]):** OpenShell = zero-trust **sandbox-orchestration runtime** (gateway control-plane + sandbox/supervisor enforcement; sandboxes via Docker/Podman/VM or k8s pods) — same axis as CE's gvisor/os-native backends. NemoClaw = **reference blueprint / lifecycle / onboarding wrapper** that installs OpenShell + operates agents inside it (NOT a harness). The harness/agent (OpenClaw/Hermes/Codex/Claude) runs INSIDE the OpenShell sandbox. **CE FIT:** on the NVIDIA platform CE DELEGATES isolation to OpenShell as a first-class RunnerBackend (no own gVisor — would double-jail); standalone CE = os-native (OQ-1)/gvisor. So OQ-1 governs the STANDALONE isolation path; OpenShell governs the ON-PLATFORM path — different contexts, not competing. Ties to [[ce-deployment-tiers-solo-vs-team]].

## Detail (moved from index 2026-07-05)
- NemoClaw/Docker Linux container on Mac → bwrap+Landlock works inside + existing Linux wheels → DEFER native-Mac port (#352 Seatbelt+Darwin-wheels+re-sign). Nitzan onboards via Docker Desktop today.
