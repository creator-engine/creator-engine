---
name: openshell-nemoclaw-stack
description: "NVIDIA OpenShell sandbox-orchestration platform + NemoClaw reference stack + agent citizens (OpenClaw, Hermes); the real 01-Jul demo target and CE's integration surface."
metadata: 
  node_type: memory
  type: reference
  originSessionId: 246cec36-0c18-4fea-aba8-efebb75868e0
---

**Authoritative (Operator, 2026-06-13) — CORRECTS the "OpenShell/RTX agentic stack" framing in [[ce-nvidia-v35-strategy]].** OpenShell is NOT RTX-bound (RTX is just a future native host, GA ~Sept-2026; not a prereq).

**OpenShell = a sandbox-orchestration platform** splitting CONTROL-PLANE AUTHORITY from RUNTIME ENFORCEMENT:
- **Gateway** (control plane) owns durable state: sandboxes, policy revisions, runtime settings, provider records, inference config, session records, authorization decisions.
- **Sandbox + Supervisor** (enforcement) owns the local execution boundary: process identity, filesystem, network egress, credential injection, local logs, the agent child process.
- Deploy: LOCAL = gateway on workstation/dev host, sandboxes via **Docker / Podman / VM runtime**; REMOTE = gateway as a k8s cluster service, sandboxes as **pods** in a namespace.
- **Supervisor-initiated**: supervisor connects OUTBOUND to a known gateway endpoint, auths as a sandbox workload, holds a live session for control+relays → no gateway→sandbox reachability needed (no pod IPs / NAT / tunnels). Gateway pushes DESIRED STATE; supervisor applies locally, keeps last-known-good on refresh-fail, static isolation persists until sandbox recreated. Live ops (config/policy/cred/log/connect/exec/file-sync/relay) ride the same authenticated channel.

**NVIDIA NemoClaw** = open-source REFERENCE STACK / hardened blueprint for running always-on agents safely INSIDE OpenShell sandboxes: guided onboarding + hardened blueprint + routed inference + network policy + lifecycle, via ONE CLI.

**Agent citizens of NemoClaw:** **OpenClaw** = default + 1st first-class citizen (first tested/approved, most popular general-use agent — the one the competitive-install research covered). **Hermes agent (by Nous Labs / Nous Research)** = 2nd tested/approved NemoClaw citizen. ⚠️ CORRECTION (2026-06-14): Hermes is **NOT CE's own agent** — it's a THIRD-PARTY agent CE governs exactly like Codex/Claude Code. **CE is agent-AGNOSTIC governance, NOT an agent.** **DEFINITIVE (codebase, `docs/operations/HERMES_FORK_UPSTREAM_SYNC.md`):** CE forked Nous's Hermes; CE's **ONLY customization = the PCO completion-gate plugin** (a standalone, additive governance hook — "an opt-in runtime completion-report gate for Source-ratified CE work"; modifies NO upstream Hermes files). The fork is just a deployment vehicle for that one CE plugin (open remediation = relocate the plugin OUT of the fork into CE-owned/Hermes-user-plugin hosting so the fork can track upstream or retire). **So Hermes is governed by CE the SAME way Codex/Claude Code are** — a 3rd-party agent + a CE governance hook. "Ours" = the plugin, NOT the agent. (The CE "Hermes **harness**" / `.hermes/` tooling-name is a SEPARATE, name-colliding CE artifact.) Claude Code/Codex are NOT yet native to NemoClaw — Operator reads this as first-mover room, and CE building those adapters is delivered **implicitly** in the pitch (sleight-of-hand; CE/SDLC-automation is the main event, never the headline).

**ToS RESOLVED (Operator, 2026-06-13):** Claude runs safely under NemoClaw via the **API-key route** — NemoClaw docs list Anthropic as a *tested inference provider* using the **Anthropic Messages API + `ANTHROPIC_API_KEY`** (and "Other Anthropic-compatible endpoint" via `COMPATIBLE_ANTHROPIC_API_KEY`). API-key, NOT OAuth → sidesteps the OAuth/ACP ban ([[ce-substrate-acp-decision]]). Safe-by-default design = adopt OpenShell **isolation**, keep inference **native** per-provider via API key; NemoClaw-routed inference is a *supported option*, not required = user choice ([[ce-user-choice-architecture]]).

**CE FIT (synthesis):** OpenShell's gateway/supervisor split == CE's grader-outside thesis one layer down (authority vs enforcement, same shape) → technical alignment, not just narrative. OpenShell/NemoClaw govern the RUNTIME; they do NOT govern the SDLC (scope→gate→review→ship, ratification). CE = that missing SDLC-governance plane. → makes **OpenShell sandbox a first-class CE `RunnerBackend`**: on-platform CE DELEGATES isolation+egress+inference to OpenShell/NemoClaw (brings NO own gVisor — would double-jail); standalone CE = unprivileged srt default + gVisor opt-in. Directly reshapes the #71 user-level `--apply` decision (egress-proxy worry shrinks to the standalone path) and informs [[ce-substrate-acp-decision]]. Demo 01-Jul = to these creators.
