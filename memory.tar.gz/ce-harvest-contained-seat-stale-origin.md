---
name: ce-harvest-contained-seat-stale-origin
description: "When harvesting a contained no-egress seat, its local origin/main is stale so commits falsely appear \"ahead\" — reconcile against authoritative origin/main before pushing"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: b33e7c4e-624c-4dc8-becb-f71e010bd662
---

When harvesting work from a CONTAINED no-egress seat (dev-3/ce-vps-codex, dev-4 build seat/ce-dgx-codex), DO NOT trust `git log origin/main..HEAD` inside the container. The seat has no egress, so its `git fetch` silently fails and its local `origin/main` ref is stale — already-merged commits then falsely show as "ahead/unpushed."

**Always reconcile a harvest candidate against the AUTHORITATIVE origin/main** (via overwatch on my box: `git fetch` + check `git log origin/main`, and check whether the ticket/PR already merged) BEFORE extracting/pushing.

**Why:** 2026-06-27 night-shift, dev-3's container showed `ce-302-broker-namespace` 2 commits "ahead" — but ce-ops#302 was already merged via PR #567 (08:25Z, same branch). Harvesting it would have pushed a redundant/conflicting PR. The genuinely-trapped branch was `ce-292-autoreview` (#292 still open, no PR). Only that needed harvesting.

**How to apply:** harvest reconciliation checklist per branch — (1) is the ticket CLOSED/COMPLETED? (2) is there already a merged/open PR for it (`gh pr list --search "<n> in:title" --state all`)? (3) does authoritative origin/main already contain the change? Only push if all three say "no." This is why the controller owns intake for contained seats — they can't self-push (no gh auth, prompts disabled) AND can't self-verify against real main. See [[ce-controller-conveyor-intake-directive]], [[ce-contained-seats-cannot-submit-reviews]], [[ce-verify-not-already-landed-gotcha]].

## Detail (moved from index 2026-07-05)
- reconcile vs authoritative origin/main + ticket/PR state before pushing.
- fetch → merged commits look "ahead".
