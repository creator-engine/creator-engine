---
name: ce-review-model
description: "CE PR review = a SEPARATE dev controller reviews as its own developer account (peer review); overwatch/devops does merge mechanics only, never the reviewer-of-record"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: fdf1f630-c8da-4de0-86e1-9d24db177a6a
---

CE simulates a real software company: each dev controller IS an actual CE developer. So **you do NOT review your own PR by switching to a different GitHub identity — a *separate developer* reviews and comments.**

- **Reviewer-of-record = a separate dev controller**, acting as its OWN developer account (e.g. dev-1's PR → reviewed by dev-3 `ce-dev-3` or dev-2 `ubuntuaws745-cmyk`). Real peer review + comments.
- **Overwatch `chmod735` / devops PATs = automation ONLY** — the mechanical merge, branch-protection/labels/repo ops, token mint/relay. NEVER the reviewer-of-record. (This is what the overwatch tokens are for.)
- **Do NOT re-author a PR to enable a "self-review under another hat."** Relabeling the author is the wrong lever; independence comes from a different developer reviewing. (Killed my #275 re-author plan.)

**Why:** Operator 2026-06-19 — mirrors how actual software companies work; preserves genuine independence + provenance instead of one actor juggling identities.

**How to apply:** route any PR's review to a dev seat that did NOT author the work; merge mechanics performed by overwatch/devops; author-identity correctness is a separate, going-forward provenance concern (per-seat wiring), NOT a precondition for review.

**Review craft is a CE PRODUCT capability, NOT a controller convention → ce-ops#138** (bake into CE: inline line-anchored diff comments + CODEOWNERS-aware gate routing; do not hand-prompt it). Interim operating reality: reviewers should leave inline comments on the diff (not summary-only); the gate-satisfying approval must come from an eligible **code owner that is not the author**. CODEOWNERS is moving from the stale 2-owner `* @ubuntuaws745-cmyk @cedev1vps-cmd` to **4 equals** (`@cedev1vps-cmd @ubuntuaws745-cmyk @ce-dev-3 @cedev4vps-coder`; night-arc G5) — then any non-author dev satisfies the gate. See [[ce-github-identity-model]] [[independent-reviewer-venue-rule]] [[ce-bake-gaps-into-ce-not-conventions]].
