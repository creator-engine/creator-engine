---
name: ce-harvest-carrier-slug-must-match-branch
description: Harvest gotcha — CI path-manifest gate requires carrier filename stem == branch_slug(head ref); renaming the harvest branch breaks it
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 99085dc3-1b11-483f-9ea5-ca656b6f6db7
---

When harvesting a contained seat's branch, the CI "Validate governance artifacts" → **path-manifest PR-diff gate (G-ii, required-mode)** fails closed unless the carrier files' stem **exactly equals `branch_slug(head_ref)`** of the PUSHED branch. Two failures appear: `path_manifest_carrier_slug_mismatch` (manifest stem ≠ branch slug) and `path_manifest_changelog_required` (expects ADDED `.ce/changelog/<branch-slug>.md`, gets missing).

**Why it bites harvests:** harvest workers often rename the branch with a `-harvest` suffix (to avoid colliding with the bundle's original branch ref), but the seat's carriers keep the ORIGINAL slug → mismatch. Local `ce validate-pr` does NOT enforce the slug==branch match the same way CI required-mode does, so it passes locally then BLOCKS in CI (happened on #653 Tranche-2 harvest, 2026-06-29). PRs authored on the seat's own branch name (e.g. dev-1 self-push #654) are unaffected because slug==branch already.

**Why:** per-PR carrier convention (ce-ops#21) — each PR carries its closed manifest as `.ce/pr-manifests/<branch-slug>.md` + `.ce/changelog/<branch-slug>.md`, discovered from the diff by branch slug.

**How to apply:** in every harvest brief/flow, make the PUSHED head ref slug == carrier slug. Either (a) PREFERRED: push under the carrier's original branch name (fetch the bundle branch to a distinct LOCAL ref to avoid collision, but push the head ref matching the carriers), or (b) `git mv` BOTH carriers to the new slug AND regenerate the manifest via `carrier_gen.write_carriers(base=<merge-base>)` (rm build/egg-info first) so its internal slug + path-set match the renamed files. Verify before push: `verify-path-manifest --base <merge-base> --manifest-dir .ce/pr-manifests --head-ref <pushed-branch> --require-carrier` must pass. See [[ce-pr-path-manifest-carrier-required]] [[ce-run-full-preflight-before-push]].

## Detail (moved from index 2026-07-05)
- renaming harvest branch `-harvest` breaks it (local validate-pr misses it). Push under carrier's branch name OR git-mv carriers + regen manifest.
- needs carrier stem == branch_slug(pushed head).
