---
name: ce-launch-repo-root-not-pane-cwd
description: ce launch --repo-root sets the seat-ledger location but NOT the pane/process cwd — launch from inside the worktree or the seat builds on main
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9856ffdc-c843-4966-a075-107dc335e56a
---

`ce launch --harness codex --repo-root <worktree> --json` writes the seat record into `<worktree>/.hermes/active-work-ledger/seats/…` but the spawned tmux pane (and the codex process) inherit the **Controller's** cwd, NOT `--repo-root`. Confirmed 2026-06-17 (S2 build): launched against `~/ce-worktrees/ce103-s2-posture`, pane cwd came up as `~/projects/creator-engine-canonical` (main) — a build seat there would edit/commit on `main`.

**Why:** a build seat MUST work in an isolated worktree branch off `origin/main` (commit-local + HOLD, no push); a seat silently anchored to the main checkout pollutes `main`.

**How to apply:** launch the seat from INSIDE the worktree — `( cd <worktree> && /abs/path/.venv/bin/ce launch --harness codex --session <n> --repo-root <worktree> --json )`. Then VERIFY before seeding: `tmux display-message -p -t %<pane> '#{pane_current_path}'` and `readlink /proc/<child>/cwd` must both be the worktree. If wrong, `tmux kill-pane`, `rm` the stale `*--controller.yaml` seat record, relaunch. Sibling footgun to [[ce-launch-dryrun-leaks-claim-marker]]; see also [[ce-codex-seat-launch-method]] [[ce-execution-zones-outside-repo]].

## Detail (moved from index 2026-07-05)
- Related: [[ce-launch-dryrun-leaks-claim-marker]] [[ce-venue-seat-retirement-procedure]]
- launch build seats INSIDE the worktree.
