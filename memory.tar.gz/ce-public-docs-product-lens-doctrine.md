---
name: ce-public-docs-product-lens-doctrine
description: "Public docs MUST be written through the PRODUCT lens — never cite ce-ops tickets, never present our internal dev-setup (merge queue, Integrator daemon, fleet, our OpenBao) as \"the product\"; internal machinery belongs in clearly-labeled ecosystem add-ons or not at all"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9c67b023-0ac9-402b-9806-fa1c581c5303
---

**Operator correction 2026-06-25 (frustrated, rightly):** the public docs I drove (esp. README "Current Status", which PR #465 expanded) leaked (1) confidential `ce-ops#NNN` ticket refs and (2) our INTERNAL dev-fleet machinery presented AS the product — the **merge queue, the Integrator belt daemon, the approval-capability wall, transport-deputy, our OpenBao** — exactly the things we agreed are internal/ecosystem, NOT the shipped product ([[ce-shipped-product-terminal-first]]). The reviewer even flagged the `ce-ops#` refs; I approved anyway. My miss.

**Why:** agents writing docs grounded in OUR internal repo + tickets default to an internal dev-progress changelog voice. Without an explicit editorial lens + a hard guard, public docs keep leaking internal framing.

**How to apply — every public-docs change (README, creator-engine/docs site, ce-playbooks):**
1. **NEVER cite `ce-ops#NNN`** (or internal PR#s, internal ADR strategy, dev-1/3/4, host/tailnet/Hetzner/DGX, our OpenBao deployment) in public docs. These are confidential.
2. **Write through the PRODUCT lens** = governed CE TERMINAL-FIRST (the user's own coding agent + the grader/hooks/envelope). Describe what a USER gets/does, not "what WE built this week in our fleet."
3. **Internal machinery → ecosystem section, clearly labeled as optional add-ons** (the belt/merge-automation = "first add-on"; containment; secret-identity) — or omit. Do NOT present the merge queue / Integrator daemon / fleet as core product behavior.
4. **GUARDRAIL to build:** a CI test that FAILS if any public doc (README, docs/**, the docs site) contains `ce-ops#` or internal host identifiers — so this can't recur. (Fold into [[ce-public-repo-confidentiality-program]].)
5. Bake the doc gap into the product (a guard), not just a one-time redaction. [[ce-bake-gaps-into-ce-not-conventions]] [[ce-public-private-ops-architecture]]

**BRAND / positioning voice (Operator 2026-06-25):** CE = the **"Dark Software Factory"** — a *serious* **governed-SDLC automation layer for agent-authored software work** (turns coding agents into auditable participants: scoped work, explicit identity, contained runtime, evidence capture, independent review, human-ratified gates). Public copy must read this way — NOT like "SDLC agentic slop automation." README intro lines 3-6 already nail it; keep that register. Concrete failure mode flagged: dangling links to now-deleted internal docs (e.g. `docs/v3-roadmap.md`) in the public README = slop signal → fixed in ce-ops#249 + a CI guard against dangling internal-doc links. [[ce-positioning-ease-not-governance]] [[ce-website-versioning-policy]]

## Detail (moved from index 2026-07-05)
- Related: [[ce-public-docs-playbooks-repos]] [[ce-public-repo-confidentiality-program]]
- ZERO ce-ops# refs; build a CI guard.
- internal→ecosystem-labeled-or-omit.
