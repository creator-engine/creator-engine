---
name: ce-fetch-worktree-before-reviewer-dispatch
description: "Before dispatching a reviewer worker for a self-pushed PR, fetch the branch + set up a review worktree — reviewers are read-only and can't fetch"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 169d3cef-709b-4bce-82ab-bc9d1d64a305
---

For any PR whose branch is NOT already on this host (esp. self-pushed seats like dev-1), the controller MUST, before dispatching the `reviewer` worker:
1. `git fetch origin <branch>:refs/remotes/origin/<branch>` (plain `git fetch origin <branch>` only populates FETCH_HEAD, not a tracking ref → `git worktree add origin/<branch>` then fails with "invalid reference").
2. `git worktree add .ce/wt-ce<N>-review origin/<branch>` and point the reviewer prompt at that worktree root.

**Why:** the `reviewer` subagent is read-only (Read/Grep/Glob only) — it CANNOT fetch or create worktrees. Dispatching it without the code present yields a false REQUEST_CHANGES ("branch not accessible / missing required evidence"), which is a non-finding I must NOT submit to the author's PR. Wasted a full ~5-min review cycle on #644 this way (2026-06-29).

**How to apply:** treat "fetch + worktree + verify a changed file is present" as a precondition of reviewer dispatch, same as the harvest worktree setup. Verify the worktree HEAD SHA matches the PR head before launching. Related: [[independent-reviewer-venue-rule]] [[ce-seat-dispatch-prompt-pointer-sha]] [[ce-harvest-contained-seat-stale-origin]]

## Detail (moved from index 2026-07-05)
- ce/wt-ceN-review` + verify a changed file present, THEN dispatch pointed at the worktree; else false "branch-not-accessible" REQUEST_CHANGES (≠ submit).
- fetch+worktree first.
