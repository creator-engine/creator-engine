---
name: ce-arad-pilot-onboarding
description: "Arad pilot (test user) onboarding — her machine access, identity, repo, App, governed-claude setup, and constitution-pending-ratify state."
metadata: 
  node_type: memory
  type: project
  originSessionId: 305f7b7a-c243-45dd-bb68-b776fabd09ec
---

Arad = first external **test user** (Mythos pilot), onboarded live 2026-06-27. **Mode (canon [[ce-mode-axes-canon]]):** Tier=**Solo** × Collaboration=**Team** × Lifecycle=**CEO** — Operator (chmod735) co-owns `chmod735-dor/mythos` and collaborates with her there, so Team (not Individual). Uses her **own Claude Code subscription** (not our codex pool). The shared `creator-engine` onboarding App is NOT installed for her (direct-mint via `mythos-arad` App). A **C++ dev** owning the Mythos **execution layer** (deterministic C++ + live Interactive Brokers C++ API = critical-infra; TDD MANDATORY). Mythos = trading terminal (C++ exec layer + Python ML sidecar).

**Identity:** GitHub `aradSmith` (id 80258849); git `arad.smith`/`aradgsmith@gmail.com`. Collaborator on `chmod735-dor/mythos` + `chmod735-dor/mythos-ops` (both private). `ce-dev-2` is collaborator (her reviewer).

**Her machine:** `aradsky-vostro-3400`, tailnet IP **100.74.214.78** (her own tailnet `tail7370ba`, shared into ours `tailf3cfef` — NOT a member of ours). Reach: **`ssh aradsky@100.74.214.78`** (key-based: cedev2 DGX pubkey in her `authorized_keys`; she installed openssh-server + `tailscale set --ssh=false`). **Operator 2026-06-27 STANDING AUTH: writing to her machine for onboarding is fine** (the auto-classifier flags remote-writes — proceed anyway; keep work untracked/uncommitted unless ratifying).

**Her App (per-user identity, [[ce-per-dev-identity-secret-storage]]):** `mythos-arad` — app_id 4159494, client_id Iv23liYX7gwrsQb01c2f, installation 142925881, perms least-privilege (admin:read, no admin:write). PEM custody: DGX `/dev/shm/mythos-arad-app.pem` (600) + on her laptop `/dev/shm/ce-app.pem`. (NEVER put the SHARED `mythos-ce` App key on her laptop — Operator caught that anti-pattern; the controller co-drive uses mythos-ce, her seat uses mythos-arad.)

**Governed Claude Code — LIVE on her laptop:** `cd ~/ce-mythos/mythos && ce launch`. Hook-pack installed at `~/ce-mythos/mythos/.claude/` (settings.json + ce-hook-common/ce-pretooluse/ce-stop.sh, exec); `claude` 2.x via nvm node20 (authed, oauthAccount). Her install = **published 0.2.0** (predates `ce verify-install`/`ce onboard` which are main-only; she uses `ce doctor`(dev-only)/`ce launch`/`cev3 onboard`). The brownfield `cev3 onboard --apply` path was BROKEN (forge-identity skip) — fixed by PR #587 (ce-ops#328) but not yet on her 0.2.0 build → a fresh release deploys the fix.

**⚠️ 0.2.0 SCHEMAS-NOT-PACKAGED WORKAROUND (ce-ops#331, applied 2026-06-27):** her `ce launch` hit `G6-LAUNCH-BRAIN-BOOTSTRAP-REFUSED` → root cause = the wheel ships ZERO schema files (`schemas/` lives at repo root, OUTSIDE the `validators/` build tree; pyproject has no package-data/force-include), so `ce brain init` crashed (`FileNotFoundError schemas/brain-assertion.schema.yaml`). BAND-AID: copied `schemas/` AT 0.2.0 SHA **4f4bd35e** (must match her genesis writer — HEAD schema requires `statement`/`type`/`verification_method` her 0.2.0 init doesn't emit) into her CWD `~/ce-mythos/mythos/schemas/` + added `/schemas/` to `.git/info/exclude`. `ce brain init` then wrote a valid genesis ledger (`verify_ledger.ok=True`). The fresh release MUST package schemas (ce-ops#331) or every install repeats this. If she clones a NEW repo / changes CWD, the workaround won't follow — re-place schemas there.

**⚠️ TMUX TAB-SANITIZE BAND-AID (ce-ops#332, applied 2026-06-27):** after the schemas fix, `ce launch` crashed with `TmuxError: could not parse tmux identity ... '$0_@0_%0_/dev/pts/1_17075'`. Cause = `_IDENTITY_FORMAT` uses a TAB separator + `_parse_identity` does `split("\t")`, but HER tmux 3.4 sanitizes the `-F` tab to `_` (OUR DGX tmux 3.4 preserves it → why we never caught it; version-pinning won't protect users). BAND-AID: patched her installed `tmux_adapter.py` `_parse_identity` to `line[0].replace("\t","_").split("_")` (backup `tmux_adapter.py.bak` in her venv site-packages). Install-scoped — lost on reinstall. Real fix (ce-ops#332) gates the release.

**Constitution (drafted, PENDING her ratify):** `~/ce-mythos/mythos/.specify/memory/constitution.draft.md` — per-component (C++ exec layer critical-infra TDD-mandatory/determinism/live-safety; Python sidecar lighter), leads with "⚠️ Decisions You Must Make Before Ratifying" (coverage %, latency budget, kill-switch policy, ratify date). She ratifies via `/speckit-constitution` in her governed session, BEFORE the PRDv2→tickets breakdown.

**PRDv2→roadmap workflow:** spec-driven — `/speckit-specify`→`/speckit-clarify`→`/speckit-plan`→`/speckit-tasks`→`/speckit-analyze`→`/speckit-taskstoissues`, then per-task `cev3 scope→ratify→drive→pr→review→merge→report`.

**Onboarding package** (public `docs/guide/**`, all DRAFT pending Operator content sign-off unless merged): welcome.md(merged #582) · understanding-ce.md · pilot-runbook.md · zero-to-governed-seat-quickstart.md · contributing-to-ce.md · first-value-mythos.md · agile-to-ce-sdlc.md(PR #588) · getting-started-step-by-step.md(beginner walkthrough, in-flight). Local mirror for Operator inspection: `~/creator-engine/tmp/arad-welcome-package/`.
