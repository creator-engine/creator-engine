---
name: ce-mythos-tenant-live
description: "Mythos = first live client tenant (2026-07-03) — Arad onboarded, repo governed, access/identity facts"
metadata: 
  node_type: memory
  type: project
  originSessionId: 731a9645-1f93-4719-ad13-113f9e5ec739
---

2026-07-03: **Arad = CE's first external user, LIVE** — governed session on governed
chmod735-dor/mythos (join PR #5 merged by her; ce-validate green; CE 0.3.1 signed install).
Durable facts: machine aradsky@100.74.214.78 (tailnet, key auth) · git via SSH remote (her key
registered) · her seat identity = mythos-arad App 4159494 / installation 142925881 kind:own (PEM
in her ~/.ce-secrets — HER custody per [[ce-app-auth-two-lane-doctrine]]) · adoption/infra App =
mythos-ce 4103119 / installation 141552951 (PEM ~/.ce-keys/mythos-ce.2026-06-20.private-key.pem,
controller custody; move to OpenBao tenant mount = tenant Phase 1) · third org App mythos-agents
reserved for fleet seats · reviewer floor aradSmith · package at her ~/ce-welcome.
Org-credential pointer (Operator, 2026-07-05): for the chmod735-dor org (Mythos repo) the
controller holds the **mythos-overwatch PAT** — ce-overwatch has NO standing there; any
sandbox/canary work in that org rides mythos-overwatch, never ce-overwatch.
OPEN: branch-protection floor UNENFORCED (free-org private repo; Operator deciding Team-upgrade
vs public; PRs-only rule meanwhile) · her constitution ratification pending (manual commit path).
Mythos = Model-C reference deployment for the contractor program (ce-ops#421).

**Why:** every future mythos/tenant session needs these access+identity facts without rediscovery.
**How to apply:** drive mythos work via the mythos-* Apps, never ce-* fleet identities; respect
PRs-only until protection enforced; tenant Phase 1 tasks live in the #421 program.
