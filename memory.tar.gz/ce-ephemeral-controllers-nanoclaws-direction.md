---
name: ce-ephemeral-controllers-nanoclaws-direction
description: "Operator direction 20260705 — dark-factory target incl. ephemeral spawn-on-event controllers (his NanoClaws Discord-@ precedent); design lives in ce-ops#454"
metadata: 
  node_type: memory
  type: project
  originSessionId: 83618d45-1ab2-454f-b05f-fbfa09d386a0
---

2026-07-05 Operator direction (design conversation, banked in **ce-ops#454** + comments):
- CONFIRMED: controller (dev-2) compiles ratified day/night-arcs; forge automation must turn the
  arc into served work division ("lanes"/cluster-job artifacts per clownfish pattern). Controller
  role trends toward arc-author + release-signer; seats pick work autonomously per arc.
- NEW piece 5: ephemeral controllers — spawn-on-forge-event (comment command/label/merge),
  single mandate, post results to forge, self-retire (`docker run --rm` of the canonical
  two-plane runtime image). Only always-on piece = thin listener (GH Action or webhook receiver).
- Operator precedent: his **NanoClaws** fleet — Discord app @-mention in a channel spawned the
  NanoClaw container on the hosting VPS. CE version uses the forge as the bus, not Discord.
- Bounds: A2-SEQ merge-gate stays SINGLETON (ephemeral controllers never hold the gate);
  ce-root-v1 signing stays persistent-controller-only. End-state human touchpoints = arc
  ratification + release ceremony (mirrors Steinberger keeping intent/triage central while
  distributing execution).
Related: [[ce-a2seq-singleton-cutover-ratified]] [[ce-two-plane-os-architecture-ratified]]
[[ce-dev2-orchestrator-role]]

## Detail (moved from index 2026-07-05)
- SSOT=ce-ops#454; gate stays singleton, signing stays persistent.
- spawn-on-event self-retiring controllers (NanoClaws precedent).
