---
name: ce-codified-actions-not-rediscovery
description: "CE ops procedures must be codified, self-verifying, agent-invokable actions in an SSOT — never re-derived from memory/handoff/scrollback each time."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 04cb5ced-a042-44e0-86cd-4bf66a556066
---

When I catch myself reconstructing an operational procedure — how to launch/relaunch a contained controller, dispatch to a seat, fire a reviewer venue, push Model-B, probe containment, retire a seat — from memory fragments, a stale handoff doc, or pane scrollback, that reconstruction IS the bug. It is the signal that CE lacks a codified, idempotent, self-verifying, agent-invokable playbook for that workflow. Do NOT hand-roll the one-off under momentum: it drifts (missed flags, trust loops, dispatch races, a torn-down fleet). Treat the absence as the gap to bake into CE — codify the workflow as an executable action with structured I/O that verifies itself, living in the deterministic SSOT.

Root-cause altitude: failures like the 2026-06-24 relaunch churn do NOT trace to a low-level flaw (foreground `--rm -it`); they trace to no-SSOT + no agent-native playbooks. The launcher flaw is a symptom. This is CE's own product (grader-outside-the-agent, governance-as-engine, agent-native SDLC) turned inward — and the test of a real playbook is identical to onboarding: a fresh controller with zero tribal knowledge (= a first user self-serving the install) runs it correctly and it self-verifies. So codifying ops playbooks is on the critical path to first users, not internal hygiene.

**Why:** Operator 2026-06-24: "I trace every one of these failures to us not having a SSOT and agentic-native playbooks for every ce workflow; you shouldn't rediscover anew what should be codified actions in ce." #162/#166 ticketed the SSOT but as *docs* (consultable) not *executable actions* (runnable) — a doc still lets me re-derive and get it wrong.

**How to apply:** before executing any multi-step ops procedure, look for the codified CE action and invoke/probe it. If none exists, the task becomes "codify the playbook," not "perform the incantation." Capabilities are probed by running the action, not remembered. Links [[ce-single-source-of-truth-ops-docs]] [[ce-knowledge-ssot]] [[ce-bake-gaps-into-ce-not-conventions]] [[ce-controller-inlines-execution-drift]].

## Detail (moved from index 2026-07-05)
- Related: [[ce-single-source-of-truth-ops-docs]] [[ce-controller-verified-bootstrap]] [[ce-knowledge-ssot]]
- codify as self-verifying SSOT action.
- procedure from memory/scrollback IS the bug.
