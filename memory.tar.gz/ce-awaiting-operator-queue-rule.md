---
name: ce-awaiting-operator-queue-rule
description: Operator feedback 2026-06-10 — pending-Operator confirms MUST be forge-visible at creation + surfaced FIRST after /clear; never carried only in resume-state prose
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2457e0af-87f4-4a24-9180-884b72b2db0d
---

2026-06-10: the N=1 gate's ADR-0001 amendment sat "awaiting explicit Operator confirm" across a session boundary, carried only in the resume-state checkpoint — the Operator had to ask for a status update to discover it ("why was this not brought to my attention? where is our CE machinery moving the conveyor belt?!").

**Why:** an item whose only blocker is a human decision must present itself. Resume-state prose is agent-readable memory, not an Operator-facing queue; relying on it makes ratification latency invisible and stalls the program's actual bottleneck (Operator throughput — see [[ce-agent-paced-estimation]]).

**How to apply:**
1. The moment anything enters awaiting-operator state → post a `⏸️ AWAITING-OPERATOR` comment on its ce-ops lane issue (decision needed + recommendation + what unblocks). Resume-state gets a pointer only.
2. First report after /clear → lead with the open AWAITING-OPERATOR queue before proposing new work.
3. On confirm → resolution reply on the marker + persist per [[persist-decisions-at-confirmation]].
Standing process issue: ce-ops#10. Cockpit escalations-queue projection = the machine guard (feeds ce-ops#1). Sibling of [[report-context-each-turn]].

## Detail (moved from index 2026-07-05)
- Related: [[ce-precondition-frontloading-doctrine]]
- `⏸️ AWAITING-OPERATOR` marker + surfaced FIRST after /clear.
