---
name: ce-nightshift-arc-20260618
description: "ACTIVE night-shift arc 2026-06-18/19 (ce-ops#129): Operator-ratified 4-wave arc + FULL unattended autonomy grants (auto-merge-all, publish-#123-unattended, DGX-host-changes-unattended). Resume from #129 running log."
metadata: 
  node_type: memory
  type: project
  originSessionId: 42268e2e-bc78-436e-92f2-f34bd5c9a8ca
---

**ACTIVE unattended night-shift. Canonical mandate + running log = ce-ops#129** (open it first on resume). Ratified 2026-06-18.

**Ratified autonomy grants (THIS arc only):**
1. Full 4-wave arc approved.
2. **Auto-merge ALL** green + distinct-controller-reviewed PRs (incl. privileged classes).
3. **#123 mirror: publish UNATTENDED** after I independently re-verify all 4 hashes → ce-root-v1 re-sign → live publish.
4. **DGX #128 host changes UNATTENDED** (docker + runsc/gVisor via nvis; NO host-AppArmor loosening).
- HARD rules kept regardless: hashes reproduced+matched before signing (never transcribed [[ce-verifier-hash-false-positive]]); distinct-controller review (ADR-0003 Tier-2) before every merge; escalate to Operator ONLY on blockers (front-loaded preconditions).

**Waves:** W1 dev-4 recovery (#128 codex-under-runsc on DGX → dev-4 PAT+App-tighten → re-arm) · W2 land in-flight (#120 amendment, #123 commission→sign→publish, review backlog ce80/89/101/113/117/119) · W3 pitch-path install cluster (#126/#127/#94 → #88 → #124/#125 → #122) · W4 depth (reviewer-triage downstream, OpenBao ADR-0005 #113, #117, brownfield E2E).

**Seats:** dev-2(me) leads + holds release gates (ce-root-v1 sign, mirror publish, merge, review routing) + drives DGX #128 (nvis access via `~/.ce-keys/dgx-ssh-pw.py`). dev-1/3/4 codex work seats. **DGX nvis creds also at /tmp/dgx.md (ROTATE after arc — crossed transcripts).**

**In-flight at kickoff:** #120 amendment on dev-1 ([[ce-reviewer-triage-ratified]] + delta); #123 commissioning on dev-3 (VPS, both-arch pinning; aarch64 live proof deferred to #128). dev-4 parked (AppArmor userns wall) → #128.

**STATUS ~05:25 (latest RESUME_STATE = `.ce/state/research/RESUME_STATE_CE_V3_NIGHTSHIFT_20260619_0410.md`):** MERGED tonight (7): #258,#255,#256,#127,#88,#128,#264(#125). **dev-4 RECOVERED + contained** (#128 solved = DGX docker runtime `runsc-gvproxy-ptrace` = `runsc --platform=ptrace --network=host`; plain/systrap fail). #264(#125) merged 02:25 UTC after CI re-run confirmed `git_global_C_push` push-deny test FLAKY (main passes; #125 diff only touches onboard_apply*.py, can't reach the runner/hook). **⏸️ HELD for Operator morning signing pass:** PR #257(#123 scanner, +schema decision rec A=standalone fragment), #259(#122), #263(#124) — trust-root re-sign (signed llms-install.md hash-pins SHA256SUMS `e6460c…` + answers_schema `5879efac…`; procedure = update SHA256SUMS→update sha256s_sha256→`ssh-keygen -Y sign -f ~/.ce-keys/ce-root-v1`→verify). Crons session-only (conveyor :13/:43, ctx-cycle :23) — verify/re-arm post-/clear. Code-owner approvals: dev-1-authored→me as ubuntuaws745-cmyk (GITHUB_REVIEWR_TOKEN); dev-3-authored→cedev1vps-cmd.

Related: [[ce-governance-research-needs-ceops-access]] [[ce-every-agent-containerized-direction]] [[codex-first-routing-directive]] [[ce-codex-seed-large-paste-stall]] (relay via base64; verify pane pickup).
