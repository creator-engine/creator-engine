---
name: ce-bugfix-54-56-58-deferred-batch
description: bugfix-54-56-58 batch is committed-local + PARKED past the 2026-06-14 VPS rehearsal; resume pointer + signed-release/dev-wheelhouse coupling lesson
metadata: 
  node_type: memory
  type: project
  originSessionId: 536995c2-574a-4bc3-aa91-67341d7a25ad
---

**PARKED (Operator deferral "Option 1", 2026-06-13).** Branch `bugfix-54-56-58`, commit
`9096825410cf20f42c1e21ab142a74b23e9f84b2` off base `e427b67` (#222). Three fixes, ONE branch,
committed LOCAL, NOT pushed, NO PR — held past tomorrow's (2026-06-14) VPS rehearsal:
- **ce-ops#54** — `schema.py:load_schema` anchors package schema names (`schemas/…`) to the package root
  (`parents[2]`) so `ce`/`cev3` load schemas from ANY cwd; user `--answers-schema` stays cwd-relative.
- **ce-ops#56** — `stamp_codex_transcript_locator` bounded settle (`CODEX_TRANSCRIPT_SETTLE_S`, capped at
  deadline) before first poll → kills the cold-codex transcript-locator race.
- **ce-ops#58** — `spawn_review_venue` fail-closed step-2.5 `gh api user --jq .login` guard vs the envelope
  `actor` (#218 wrong-identity leak); sources the seat-env via a bridge-local copy of lane_runtime's wrap.

**Gate state:** carrier `.ce/pr-manifests/bugfix-54-56-58.md` 9 paths, `verify-path-manifest` PASS; full
`pytest validators/` = **2 failed, 3031 passed, 2 skipped** — the 2 fails are EXACTLY
`test_packaging_contract.py::test_pages_mirror_{wheels_are_byte_identical_to_wheelhouse,sha256s_publishes_install_sh_and_wheels}`
and are Operator-ACCEPTED.

**Why those 2 are red (durable coupling lesson):** #220 added pages-mirror tests asserting
`docs/downloads/0.2.0/<wheel>` is byte-identical to `validators/wheelhouse/<wheel>` + matching SHA256SUMS.
But `docs/downloads/0.2.0/` is the **FROZEN signed-release wheel pinned in the signed spec**
(`docs/llms-install.md`), rehearsal-critical, **Operator-only re-sign** — so it must NOT be rebuilt. The
ce-ops#54/#58 edit forces a dev-wheelhouse wheel rebuild → wheelhouse wheel ≠ frozen mirror → those 2 go
red BY DESIGN. (Touching the mirror instead would break `test_install_bootstrap`, which verifies the frozen
mirror against the signed-spec pin — that test stays GREEN precisely because the mirror is untouched.)

**Resume after rehearsal:** re-scope #220's mirror tests to decouple the frozen signed-release from the
live dev wheelhouse, THEN this batch rebases onto current `main` → fully green → push → PR → reviewer venue
→ Operator merge. Related: [[ce-pr-path-manifest-carrier-required]] [[ce-new-ce-group-docs-coupling]]
[[ce-semver-milestone-policy]].
