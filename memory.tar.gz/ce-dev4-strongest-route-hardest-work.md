---
name: ce-dev4-strongest-route-hardest-work
description: "Operator directive 2026-06-19: dev-4 (DGX Spark) is CE's strongest machine — route the most complicated/demanding work to it when triaging and disposing tasks."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 51ddd3b0-ba13-421c-a761-9039c84524ee
---

Operator directive 2026-06-19 (morning shift): **dev-4 is our strongest machine — give it the most complicated and demanding work when triaging and disposing tasks.**

**Why:** dev-4 = the DGX Spark ([[ce-dev4-dgx-spark-access]]), the highest-compute seat in the fleet; matching the hardest/heaviest tasks to it maximizes throughput. Complements [[ce-model-effort-routing-policy]] (route by reasoning ceiling) — this adds a HARDWARE dimension to dispatch.

**How to apply:** in dispatch/triage, when work varies in difficulty/compute load, default the hardest item (deepest reasoning, heaviest build/test, most complex design) to dev-4. Caveats that still hold: dev-4 runs codex CONTAINED under gVisor (runsc-gvproxy-ptrace) and has NO forge identity → commit-local only, so push/merge stays controller-gated regardless ([[ce-push-deploy-authority-model]]); and never `C-c` its pane (tears down the container — relaunch only via run-codex-runsc.sh).

## Detail (moved from index 2026-07-05)
- never C-c its pane.
- push/merge controller-gated.
