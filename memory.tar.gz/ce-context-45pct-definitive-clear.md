---
name: ce-context-45pct-definitive-clear
description: "Operator standing rule 2026-07-04: controller context usage above 45% = DEFINITIVE checkpoint + /clear — not a judgment call."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: aec618e9-c79b-4668-b514-e18af1e298d1
---

Operator directive (2026-07-04, day-arc): when MY (controller) context usage crosses **45%**, that is a **definitive** trigger — write the resume-state checkpoint and /clear. Not discretionary, not "finish the current beat first" beyond the minutes needed to checkpoint safely.

**Why:** long-context controllers degrade (drift, re-derivation, stale-assumption risk) and the resume-state + MEMORY.md protocol exists precisely so /clear is cheap. Watchers and workers survive the clear (and may auto-resume — [[ce-clear-does-not-kill-subagents-auto-resume]]).

**How to apply:** monitor /context; at ≥45% → write RESUME_STATE checkpoint (newest-by-mtime convention, [[ce-resume-state-seat-header-protocol]]) → /clear. Same discipline already standing for seats (>40% → compact/clear before dispatch, [[ce-dispatch-context-hygiene-gate]]) — this extends it to the controller itself with a hard 45% line.

## Detail (moved from index 2026-07-05)
- seats stay 40%.
