---
name: ce-dev2-approval-is-the-merge-trigger
description: "In creator-engine, a ce-dev-2 review approval IS the merge trigger — the queue-daemon auto-merges any ce-dev-2-approved + green PR. Approving to \"clear the review gate\" while intending to hold the merge does NOT work."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 260724fc-e8c5-4c0e-98f6-94726041d899
---

The `queue-daemon` running on the DGX (`v3_cli queue-daemon --repo creator-engine/creator-engine --loop --interval 120 --authorized-reviewer ce-dev-2 ...`) polls every ~120s and **merges any PR that is approved by `ce-dev-2` and green**. So a `ce-dev-2` approval is not just a review gate — it is the **merge enqueue signal**.

**Why this bites:** On 2026-06-30 I approved #674/#675/#676/#677 as ce-dev-2 thinking I was only "clearing the review gate" and still personally held the merge. The daemon merged #676 on its next cycle, and #674 was about to merge **without the Operator's promised content-nod**. I caught it and converted #674 to **draft** to block the daemon.

**How to apply:**
- Only approve as ce-dev-2 when you are genuinely ready for that PR to MERGE. Approval ⇒ merge.
- To hold an otherwise-ready PR (awaiting Operator nod, merge-order, etc.): **convert it to draft** (`gh api graphql -f query='mutation($id:ID!){convertPullRequestToDraft(input:{pullRequestId:$id}){pullRequest{isDraft}}}' -f id=<nodeId>`), then mark ready again to release it. A draft PR cannot be merged by the daemon even when approved+green.
- Merge-ORDER cannot be enforced just by "approving in order" — the daemon merges whatever is green first. To sequence, keep later PRs in draft until predecessors land, or rely on the fact that order only matters for correctness (verify it actually does before bothering). See [[ce-merge-queue-offloads-mechanics]], [[ce-clear-does-not-kill-subagents-auto-resume]].

## Detail (moved from index 2026-07-05)
- Approving to "just clear review" still merges it. To HOLD: convert PR to draft (GraphQL convertPullRequestToDraft); order isn't enforced by approve-order.
- any ce-dev-2-approved+green PR (~120s).
