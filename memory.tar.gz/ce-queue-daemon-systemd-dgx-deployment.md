---
name: ce-queue-daemon-systemd-dgx-deployment
description: Merge-gate ce-queue-daemon MOVED to VPS ce-pilot-1 2026-07-09 (systemd, user ce-dev-2); DGX unit stopped+disabled; DGX history below
metadata: 
  node_type: memory
  type: reference
  originSessionId: f99580bf-11af-4c3c-9cba-aa07611522b9
---

**⚡ 2026-07-09 ~18:14 UTC: GATE RELOCATED DGX→VPS** (Operator-ordered after second DGX crash of the day; singleton-safe: DGX stopped+disabled FIRST). **Current canonical deployment (VPS ce-pilot-1):** systemd `ce-queue-daemon.service` + drop-in `10-vps-host.conf` (User=ce-dev-2, repo root `/home/ce-dev-2/ce-daemon-main`, state `.ce/state` under it), env `/etc/creator-engine/ce-queue-daemon.env` (root 0600), image `ghcr.io/creator-engine/creator-engine/ce-runtime:0.3.3` (amd64 from GHCR — DGX's local 0.3.2-main is aarch64, does NOT ship cross-arch), CA cert installed at `/usr/local/share/ca-certificates/ce-openbao-ca.crt`. OpenBao is now LOCAL to the gate (BAO_ADDR=100.72.252.20). Cutover gotchas: (1) state root must be chown 10001:10001 (fail-closed check); (2) stale `queue-daemon.lease` from the old host refuses startup — rm it via `sudo bash -c` (plain `sudo rm glob` silently fails, glob expands unprivileged); (3) systemd StartLimitBurst trips during fix loops — `systemctl reset-failed` before retry; (4) `armed_state_without_secret` on VPS = the gate CONTAINER can't reach local OpenBao — UFW (INPUT policy DROP) blocks docker-bridge→host traffic; fix (persistent): `ufw allow from 172.17.0.0/16 to any port 8200 proto tcp` (bao listens only on the tailnet IP; from-host curl succeeding proves nothing about from-container). Verified live 18:21: `daemon_pass_complete index=1 failed_count=0`. DGX unit left installed but disabled (re-enabling it would violate the singleton — never run both).

--- DGX-era history (superseded 2026-07-09) ---
**2026-07-08 gate outage root cause:** the C5 containerized gate was launched SESSION-OWNED — `nohup bash run-daemon-container.sh` (which `exec`s `docker run --rm`) as a child of an interactive controller session. When that session died at an API limit (~15:5x), the docker client was killed and `--rm` erased the container with zero trace in `docker ps -a` / events. Merged-but-never-deployed #895 was the standing fix; it is now DEPLOYED.

**Current canonical gate deployment (DGX spark-b824, since 2026-07-08 ~evening):**
- systemd service `ce-queue-daemon.service`, enabled, `Restart=always` — survives session death and reboot. Runs `deploy/daemons/run-daemon-container.sh queue-daemon` (container `ce-queue-daemon`).
- Deployment base: `/home/cedev2/ce-daemon-main` — now a **standalone clone** (was a linked worktree; converted because redeploy-singleton.sh rejects worktree `.git` files). Update it with plain `git fetch origin && git checkout --detach origin/main` before redeploys.
- Env file: `/etc/creator-engine/ce-queue-daemon.env` (root 0600) — GH_TOKEN (overwatch), BAO_TOKEN (from `~/.ce-keys/ce-approval-wall-token`), wall policy SHAs, `CE_DAEMON_IMAGE=creator-engine/ce-runtime:0.3.2-main` (proven C5 image, pinned), BAO_ADDR + BAO_CACERT duplicated for the health probe.
- DGX host drop-in: `/etc/systemd/system/ce-queue-daemon.service.d/10-dgx-host.conf` → `User=cedev2`, `CE_DAEMON_STATE_ROOT=/home/cedev2/ce-daemon-main/.ce/state` (the proven uid-10001 state), `CE_DAEMON_LOG_DIR=/home/cedev2`. Needed because the #895 unit hardcodes `User=ce-dev-1` (VPS); portability gaps ticketed in ce-ops.
- **Canonical redeploy/restart:** `bash deploy/singleton-redeploy/redeploy-singleton.sh --daemon queue-daemon --repo-root /home/cedev2/ce-daemon-main` (run `--dry-run` first). Never relaunch by hand/nohup again.
- Health: `systemctl is-active ce-queue-daemon` + `docker logs ce-queue-daemon` (structured JSON; `daemon_pass_complete` with `failed_count=0`).

[[ce-approval-wall-daemon-token-durable-recovery]] [[ce-merge-queue-offloads-mechanics]] [[ce-singleton-plus-iac-redeploy-rule]]
