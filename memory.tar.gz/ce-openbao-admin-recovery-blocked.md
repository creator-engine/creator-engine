---
name: ce-openbao-admin-recovery-blocked
description: OpenBao 2.5.5 VPS — admin-recovered + production wall secret MINTED + mint-on-approval BUILT/MERGED (#464) + daemon refreshed; wall arm is STAGED, last steps = daemon token→round-trip→flip armed:true (autonomous, quiet-queue). See newest RESUME_STATE V19+
metadata: 
  node_type: memory
  type: project
  originSessionId: 6c51a018-83e5-45dc-8943-a61fef8b0fc7
---

Production OpenBao (v2.5.5, raft, shamir 3/5, VPS `https://100.72.252.20:8200` / `https://ce-dev-1.tailf3cfef.ts.net:8200`, CA `/usr/local/share/ca-certificates/ce-openbao-ca.crt`, config `/etc/openbao/openbao.hcl`, bin `/usr/local/bin/bao`).

**ROOT CAUSE of the old `generate-root → 405` blocker (research-confirmed):** OpenBao 2.5.3 disabled `/sys/generate-root/*` by default (CVE-2026-5807, PR openbao#2912) behind listener flag **`disable_unauthed_generate_root_endpoints` (defaults `true`)**; the authenticated replacement only ships in 2.6.0-beta. So on 2.5.5 the legacy path is the only root-gen mechanism and ships OFF. Recovery keys are INERT for Shamir — use the 5 **unseal shares** (threshold 3) from the init bundle.

**ADMIN-RECOVERY + MINT EXECUTED 2026-06-25** (via sanitized script, listener is tailnet-only so the CVE window was ~seconds + private; cleanup trap reverts flag + re-unseals + revokes root on any exit):
1. ✅ flag→false, restart, unseal(3), generate-root (OTP+nonce+3 shares) → transient **root token obtained**.
2. ✅ flag reverted → restart → unseal → generate-root re-closed to **405** (window closed; minimal exposure).
3. ✅ **production wall signing secret MINTED** → `ce-kv` (kv-v2), path **`forge/approval-capability/wall`**, field **`signing_secret`** (strong random, written via stdin not argv).
4. ✅ read policy `ce-approval-wall-read` (single-path read on `ce-kv/data/forge/approval-capability/wall`); least-priv token **read-back proven OK**.
5. ✅ transient root token **revoked**; tmpfs shredded; final state clean (sealed=False, generate-root=405).
- ⚠️ the negative-access test printed `LEAK?` but that's a **grep-pattern artifact** in the test harness, not a real over-broad policy (policy is a literal single-path grant, OpenBao default-deny). **Re-verify cleanly at flip-prep.**

**STILL HELD — the FLIP (do NOT do until safe):** (a) verify the **capability-mint-on-approval flow is live** (transport-deputy #242/#243 self-push/self-review — dev-3/dev-4 building 2026-06-25; arming enforces on the LIVE integrator daemon → if the mint flow isn't operational, arming fail-closes and blocks the merge queue); (b) verify the **merge queue is quiet** (don't flip mid-release). Flip steps (need admin briefly again — same recovery method): create the daemon's read-only **AppRole** for the SecretRef; wire the DGX credential-wall daemon to VPS-OpenBao (BAO_ADDR + AppRole + SecretRef mount `ce-kv`/path `forge/approval-capability/wall`/field `signing_secret`, purpose `approval-capability-wall`, owner-ref `controller:integrator`, target `file:` 0600 tmpfs); flip the armed flag; re-verify the full marker round-trip (valid→ok, wrong→signature_mismatch, missing→exit1). Runbook: `docs/devops/openbao-approval-wall-arming.md` (#455). **Standing arm authorization holds** (Operator "go on OpenBao arm" 2026-06-25). SecretRef path/field are daemon CLI FLAGS (not hardcoded) — where I write must match what the live daemon is configured to read.

**Access:** `~/.ce-keys/openbao-init-bundle.pass` (0600, DGX) decrypts `/home/ce/open_bao.json.gpg` (5 unseal_keys_b64, threshold 3, recovery_keys empty, revoked root_token). VPS reach: `ssh dev1` = `ce-dev-1` w/ passwordless `sudo -u ce` + `sudo` root. `cat <pass> | ssh dev1 'sudo bash <script>'` DOES pass the passphrase to a script's `head -1`/stdin (worked 2026-06-26). [[ce-three-deputy-governance-model]]

**⚠️ EXACT PLACEMENT (cost a detour 2026-06-26): the toggle MUST go INSIDE the `listener "tcp" { }` stanza** — `sed -i '/^listener "tcp" {/a\  disable_unauthed_generate_root_endpoints = false'`. As a TOP-LEVEL HCL line it is silently ignored and generate-root stays 405 even after restart. SIGHUP does NOT apply it — `systemctl restart` (→ seal → unseal 3 shares) is required. Read THIS memory (not the 1-line index) before attempting.

**RE-RUN 2026-06-26 (success):** same recovery executed to store the dev-3 GitHub App private key in the vault → **`ce-kv/forge/dev-3`** (KV v2; fields `private_key`,`app_id`=4051975,`installation_id`=140271364,`app_slug`,`seat`). Per-dev App keys go to **`ce-kv/forge/<seat>`**. Still a disk-PEM gap elsewhere → [[ce-cross-repo-closes-is-noop]] sibling ticket ce-ops#266 wires the egress-broker minter to read App keys from OpenBao instead of disk. **ce-ops#266 MERGED (PR #533) 2026-06-26** — vault-backed `vault_signer` (per-call fetch → `/dev/fd` pipe → openssl, fail-closed, no key on disk/in logs).

**GATE β step-2 DONE 2026-06-26 (broker AppRole, same recovery ceremony):** created least-priv read-only policy **`ce-egress-broker-dev3-read`** (read on `ce-kv/data/forge/dev-3` ONLY) + AppRole **`egress-broker-dev3`** (token_ttl=20m, secret_id non-expiring). Live-proven: APPROLE_LOGIN_OK · SCOPED_READ_DEV3_OK · **DENY_OTHER_PATH_OK** (cannot read the wall path = least-priv confirmed, not over-broad). Broker runtime creds (role_id+secret_id+BAO addr/CA/mount/path/field) written to **`/etc/ce-egress/dev3-approle.env`** on the VPS (0600, root-only) — secret_id never printed to the controller transcript. Reusable script pattern: `scratchpad/bao_broker_approle.sh` (toggle-in-listener → restart → unseal3 → genroot → policy+approle → write creds file → probe scope → trap reverts+revokes). NEXT = GATE β step3 (bring up broker reading that env file + relaunch dev-3 with socket, no key in container) → step4 canary (Ring-1 deny-proof + dev-3 self-push/self-review).

## Detail (moved from index 2026-07-05)
- INSIDE the `listener` stanza → restart (not SIGHUP) → unseal 3 → generate-root → revert+restart+revoke. Per-dev App keys → `ce-kv/forge/<seat>`. Read full memory before attempting. Wall→vault wiring=ce-ops#266.
- `disable_unauthed_generate_root_endpoints=false`.
