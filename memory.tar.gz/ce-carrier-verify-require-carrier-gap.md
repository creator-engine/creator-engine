---
name: ce-carrier-verify-require-carrier-gap
description: "Local manifest verify MUST use --require-carrier and run gen-manifest AFTER carriers committed, or CI fails on missing changelog"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 66ba17c2-15bc-4894-a232-cbc995c57d15
---

Two recurring carrier-gate footguns that passed local checks but FAILED CI (`Validate governance artifacts`, the G-ii path-manifest gate) on #419 + #420 (2026-06-24):

1. **Local verify must match CI exactly** — run `verify-path-manifest ... --require-carrier`. Without `--require-carrier` the local check passes even when the manifest is missing a carrier row; CI runs WITH it and fails closed (`path_manifest_diff_outside_manifest` / `path_manifest_changelog_required`).
2. **`gen-manifest.py` computes the path-set from `git diff origin/main..HEAD` (COMMITTED diff)** — so it must run AFTER the changelog+carrier are committed, else the changelog isn't in HEAD's diff and gets omitted from the manifest. Correct sequence: write changelog → commit code+changelog → `gen-manifest` (now sees changelog; it unions the manifest path itself) → commit/amend manifest → push. The manifest pre-includes itself so no chicken-egg.

**Why:** the carrier gate (#410/#213) is now enforced fleet-wide; a missing changelog row silently passes my old local check and burns a CI round + blocks auto-merge.

3. **Branch-slug collision (the #487→#488 case, 2026-06-25)** — `--require-carrier` requires `.ce/changelog/<BRANCH-SLUG>.md` to be status **ADDED**. If that exact filename already exists on main (a prior PR shipped the same slug, e.g. a Refs-not-Closes partial), the carrier is "missing/modified" and CI fails `path_manifest_changelog_required`. The fix is NOT a differently-named fragment (the gate keys off the *branch slug*) — **rename the BRANCH itself** to a collision-free slug, then carriers match. pytest does NOT cover this; only the G-ii gate does, so it slips through a green suite.

**How to apply:** ALWAYS verify carriers with `--require-carrier` before push (`PYTHONPATH=validators python -m creator_engine_validator.cli verify-path-manifest --base <merge-base> --manifest-dir .ce/pr-manifests --head-ref <slug> --require-carrier`); check the branch slug doesn't collide with an existing `.ce/changelog/<slug>.md` on main (rename branch if so); run gen-manifest only after carriers are committed; and obey the STALE-REF TRAP — `git fetch origin 'refs/heads/X:refs/remotes/origin/X' --force` before any checkout/reset of a branch I pushed from a worktree (a stale local tracking ref reset #419 back behind its carrier commit). Related: [[ce-g5-work-sizing-gate-pr-body]], [[ce-changelog-workflow-obligation]].
