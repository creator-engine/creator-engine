---
name: ce-wall-daemon-token-expiry-restart
description: Wall queue-daemon dies (fail-closed) when its baked-in GH token expires; restart via the launcher
metadata: 
  node_type: memory
  type: project
  originSessionId: 69d258f7-dd44-46f6-b57e-19edfe8f7334
---

The DGX wall/queue-daemon (auto-merges ce-dev-2-approved+green PRs) bakes its `GH_TOKEN` (= `$CE_OVERWATCH_PAT`) into its env at launch. When that token rotates/expires, the daemon hits `gh: Bad credentials (HTTP 401)` and **fails CLOSED — the process exits** (correct safety behavior, but the daemon is then silently DOWN; approved PRs stop merging).

**Observed 2026-06-30:** daemon PID 43010 (launched ~2 days prior) died at 18:36Z on 401 because the overwatch PAT had rotated since its launch. In-queue PRs (#694/#695) still merged via the GH merge queue; only future merges stalled.

**Detect:** every fleet-check, `pgrep -af queue-daemon` (or check the known PID). DOWN = no match.
**Restart:** `setsid bash /home/cedev2/ce-wall-daemon-launch.sh >> /home/cedev2/ce-wall-daemon.log 2>&1 < /dev/null &` — the launcher re-sources `~/.ce-keys/overwatch.env` so it picks up the CURRENT valid token + re-wires the OpenBao approval-wall. Confirm a clean `daemon_pass_complete` (no 401) in the log.

**Fix-forward (ticket-worthy):** the daemon should refresh its token per-loop (or run under systemd with restart + a token-refresh hook) instead of baking it once. Relates to [[ce-dev2-approval-is-the-merge-trigger]].

## Detail (moved from index 2026-07-05)
- restart `bash ~/ce-wall-daemon-launch.sh`.
- check `pgrep queue-daemon` each fleet-check.
- 401-fail-closed when it rotates.
