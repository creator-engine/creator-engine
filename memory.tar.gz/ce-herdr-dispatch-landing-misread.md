---
name: ce-herdr-dispatch-landing-misread
description: "Don't judge whether a herdr/codex dispatch landed by the input box right after Enter — it clears and looks idle though the seat is working"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 6c51a018-83e5-45dc-8943-a61fef8b0fc7
---

Judging whether a dispatch LANDED by reading a herdr/codex pane right after pressing Enter is UNRELIABLE and caused me to send DUPLICATE dispatches repeatedly (2026-06-25, dev-3/dev-4 N3/N6).

On submit, codex CLEARS the input box and a rotating placeholder hint reappears (`Explain this codebase`, `Write tests for @filename`) — this LOOKS like an empty/idle prompt but the seat is actually working.

**How to verify a dispatch landed:** look for the `Working (Xs • esc to interrupt)` indicator or active tool-call lines in the scrollback — NOT the empty input box. If the pre-Enter box shows `tab to queue message`, the seat is BUSY and your send will QUEUE behind its current turn — do NOT pile on / re-send. Trust the seat's eventual completion report (`Worked for Xm` + structured report), which is reliable.

**Why:** repeated misreads → duplicate/conflicting queued instructions to working seats (wasted turns, possible rework). **How to apply:** after dispatch, confirm `Working`; if unsure, wait for the completion report rather than re-sending. The Operator watching live via herdr is the ground truth when available. [[ce-controller-spawns-many-workers]] [[ce-seats-foremen-self-managed-fanout]]

**THE OPPOSITE FAILURE (2026-07-05, bit TWICE in one session):** `herdr agent send` + `herdr pane send-keys Enter` in the same/back-to-back exec sometimes loses the Enter — the message sits UNSUBMITTED in the composer (visible as `› <your text>` above the status bar) and the seat idles for an HOUR+ while you think it's dispatched. The two states are visually distinct: SUBMITTED = composer shows a rotating placeholder (`Implement {feature}`); STUCK = composer shows your literal message text. **Mandatory post-send check:** read the pane; if your text is still in the composer, send `herdr pane send-keys w1:p1 Enter` again (safe — it only submits what's queued). If the seat was mid-turn when you sent (`tab to queue message` in status bar), expect the stuck state and re-Enter after its turn ends.

## Detail (moved from index 2026-07-05)
- herdr clear=Escape/ctrl+u (format ctrl+X). Related: [[herdr-cli-commit-and-readback]]
- verify landed via `Working` indicator.

**⏫ Addition (2026-07-06, CE-DEV-2):** when the seat is MID-TURN (Working spinner active), the
separate `send-keys Enter` does NOT submit — the codex composer switches to "tab to queue
message" mode. Send `send-keys Tab` instead; success = composer clears to placeholder + "alt+↑
edit last queued message" hint. So the full landing check is: composer text present → if seat
idle send Enter, if Working send Tab → verify composer cleared. The queued message is delivered
at the foreman's next stop point (no interruption of running units — this is the correct way to
append to a busy foreman's queue).
