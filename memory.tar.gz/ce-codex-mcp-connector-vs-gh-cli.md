---
name: ce-codex-mcp-connector-vs-gh-cli
description: Codex GitHub MCP connector tools prompt separately from approval_policy=never (and 404 on private ce-ops) — codex seats should use gh CLI for GitHub ops
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 5183bef7-5a7b-413f-9619-d7da7f7c58c8
---

Discovered 2026-06-21 (dev-4): `approval_policy = "never"` makes a codex seat hands-free for **shell** commands, but the **codex GitHub MCP connector** (`codex_apps.github.*`, e.g. `add_comment_to_issue`) has a **separate approval path** that `approval_policy` does NOT cover — so a "full-auto" codex seat STILL pops approval modals whenever it uses the connector. It's also flaky on the private `ce-ops` repo (returned `GitHub API error 404` on an issue comment).

**Why dev-1/dev-3 never hit this:** they use the `gh` CLI for GitHub ops — a shell command, auto-approved by `approval_policy=never`, authed by the seat's `$GH_TOKEN`. dev-4 was reaching for the MCP connector instead.

**How to apply:** instruct codex seats to use **`gh` CLI** for ALL GitHub operations (`gh issue comment`, `gh pr create/view/review`, `gh api`), NOT the `codex_apps.github.*` connector. That keeps them fully hands-free (no MCP modals) and avoids the connector's ce-ops 404s. If a connector modal does appear, "Allow for this session" (option 2) suppresses it for the session, but the durable fix is gh CLI. Ties [[ce-codex-seats-cannot-self-compact]] (sibling codex-seat gotcha), [[codex-first-routing-directive]] (whole work-fleet is codex, so this applies broadly).