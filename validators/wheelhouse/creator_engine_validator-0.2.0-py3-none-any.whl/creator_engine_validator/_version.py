"""GENERATED build identity — do not edit by hand.

Written by ``python -m creator_engine_validator.version --write-build-file``
(reads ``validators/pyproject.toml`` + ``git rev-parse --verify HEAD``).
Committed BEFORE the wheel build so the wheel==source byte-parity contract
(``packaging_runtime.verify_wheel_matches_source``) still holds. ``BUILD_GIT_SHA``
is the gate's merge-parent HEAD — the baked fallback a no-git wheel install uses.
"""

SEMVER = "0.2.0"
BUILD_GIT_SHA = "69fbe56ec7dccf15b25f3d835f7665f014276a0f"
