"""CE version-line taxonomy + the v1↔v3 coexistence boundary (G-3.9).

Single source of truth for *which version line* each module of
``creator_engine_validator`` belongs to. CE v1.0 (the ``ce`` launcher /
lane / PCO / hook coordination runtime) and CE v3.x (the orchestrator /
forge / runner execution runtime) **coexist** on a shared governance base
(the validator engine: the CLI, the check registry, every check, plus
``loader``/``reporting``/``schema``/``environment_guard``/``version`` and the
pure ``runtime_evidence_spine`` substrate).

Directive: ``ce-v1-v3-coexistence-not-deletion`` — v1 is RETAINED; v1 and v3
are independently-operable versions. The boundary is enforced by the
``version_boundary`` check against THIS taxonomy.

Invariant (see ``docs/architecture/VERSION_BOUNDARY.md``):
  * HARD: no ``v1`` module imports a ``v3`` module, or vice-versa. The two
    execution runtimes stay mutually isolated. No exceptions.
  * RATCHET: a ``shared`` (engine/durable-infra) module may import a
    version-specific module ONLY via a baselined, justified entry in
    ``BASELINE_SHARED_TO_VERSION_ALLOWLIST``. New ``shared``→version edges
    fail the check (the allowlist only shrinks).
  * ``shared`` may always be imported by anyone.

All names below are RELATIVE to the ``creator_engine_validator`` package
(e.g. ``"forge.merge"``, ``"checks.mutation_class"``). Any shipped module not
in ``V1_RUNTIME`` or ``V3_RUNTIME`` is ``shared`` by classification; if such a
module couples to a version line it is caught by the RATCHET above, which is
what forces a deliberate decision when new code is added.
"""

from __future__ import annotations

#: This module is part of the shared governance base.
__ce_version_line__ = "shared"

V1 = "v1"
V3 = "v3"
SHARED = "shared"

# --- CE v1.0 coordination/launch runtime surface (RETAINED, frozen-operational) ---
V1_RUNTIME: frozenset[str] = frozenset(
    {
        "__main__",
        "ce_cli",
        "lane_runtime",
        "launch_runtime",
        "claude_launch_spec",
        "hermes_launch_spec",
        # v3.5-F Q1: the per-seat OS resource-bounding wrap (pure builder +
        # systemd I/O edges) — launch mechanics, sibling of claude_launch_spec.
        # Reads the v3 runtime-policy resource fragment as DATA through the
        # existing policy-read seam (loader.load_yaml); imports no v3 module.
        "resource_bound_spec",
        "tmux_adapter",
        "transcript_archive",
        "pco_allocator",
        "hook_check",
        "hook_pack_confirm",
        # ``ce`` launcher subcommand runtimes (driven by ce_cli)
        "ce_event_runtime",
        "connector_runtime",
        "doctor_runtime",
        "fanin_runtime",
        "init_runtime",
        "integration_queue_dry_run",
        "packaging_runtime",
        "pcl_runtime",
        "side_effect_ledger_runtime",
        "worker_runtime",
    }
)

# --- CE v3.x orchestrator/forge/runner execution runtime surface ---
V3_RUNTIME: frozenset[str] = frozenset(
    {
        "orchestrator",
        "run_assembly",
        "evidence_sink",
        # forge adapter family
        "forge",
        "forge._redact",
        "forge.app_jwt_runner",
        # v3.5-C α-precursor: the Projects-v2 backlog reader/writer + the
        # forge-projected advisory claim (assignee + Status=Running, §A.4);
        # consumed by the A-C4 forge_claim_dedup gate.
        "forge.backlog",
        "forge.change",
        "forge.change_status",
        "forge.credential_runner",
        "forge.github_repo_config",
        "forge.merge",
        "forge.plan_approval",
        "forge.scoped_token",
        # runner backends
        "runner",
        "runner.audit_overlay",
        "runner.backend",
        "runner.cc_hook_adapter",
        "runner.gvisor_proxy_backend",
        "runner.noop_backend",
        # v3.5-A.1 OpenShell backend (defined; registration deferred to A.2)
        "runner.openshell_backend",
        # v3 G-5 tokenomics: the pure spend gate (admission + circuit-breaker)
        "runner.spend_gate",
        # v3.5-D.0.1 compute-demand artifact: the live usage tap
        # (transcript → spend-ledger; reuses runner.spend_gate, pure core + 1 I/O edge)
        "runner.usage_tap",
        # v3.5-B.1 Cockpit: the L2 read-model (= the harness-paper F1
        # Deep-Telemetry projection; pure JSON-serializable fold, principle 6)
        "runner.cockpit_readmodel",
        # v3.5-B.1 Cockpit: the CE_DEMO seed (Fork F-b: its own module — the
        # independently-reviewable pitch artifact)
        "runner.cockpit_demo_seed",
        # v3 G-6 coordination: the outer-loop Scope dispatch spine
        "coordination",
        # v3.1-G1 live-spawn keystone: the assemble->spawn bridge. Crosses to the
        # v1 launcher as SUBPROCESS + DATA only (`ce launch --json`, files + argv +
        # JSON) — imports NO v1 module, so the HARD invariant + the ratchet stay
        # untouched by construction (AST-asserted in test_v3_seat_bridge).
        "v3_seat_bridge",
        # v3 G-7 product surface: the distinct work-driving CLI (``cev3``)
        "v3_cli",
        # v3 G-7 product surface: the session frame + unified status line render
        "v3_session",
        # v3 G-7 product surface: the Frame→Shape grill-me + chat→Scope dial
        "v3_shaping",
        # v3 G-7 product surface: the ◆ CE Completion Report + artifact awareness
        "v3_report",
        # v3 G-7 product surface: the two-mode installer logic + cost opt-out
        "v3_installer",
        # v3.5-B.1 Cockpit: the L3 Textual view (binds to L2 snapshots ONLY;
        # a future GUI replaces this module alone — principle 6)
        "v3_cockpit",
    }
)

# --- Baselined shared->version couplings (ratchet floor; derived from the full
#     import graph on main @ ab482ee, post-grounding). Each entry is a real,
#     pre-existing edge with a justification. The allowlist only shrinks. ---
BASELINE_SHARED_TO_VERSION_ALLOWLIST: frozenset[tuple[str, str]] = frozenset(
    {
        # The unified validator CLI hosts v1 launcher subcommands (lazy imports).
        # The v3 CLI arrives at G-7 as a DISTINCT entry point, not by mutating these.
        ("cli", "hook_check"),
        ("cli", "pco_allocator"),
        # The shared env/packaging-contract guard reuses the v1 packaging contract
        # types; candidate for extraction into a shared packaging-contract module.
        ("environment_guard", "packaging_runtime"),
    }
)

# --- v3 plane-C SCHEMAS (G-4.1). The v3-classified schema surface the
#     ``v3_naming_hygiene`` check scans for bootstrapping-harness residue, paired
#     with the v3 CODE surface (``classify(...) == V3``). Paths are repo-root
#     relative. Declared (not derived) so a rename is caught (COMPLETENESS) and
#     the set is an explicit ratchet floor. v1/shared schemas are NOT listed. ---
V3_SCHEMAS: frozenset[str] = frozenset(
    {
        "schemas/runtime-policy.schema.yaml",
        "schemas/runtime-evidence.schema.yaml",
        "schemas/scope.schema.yaml",
        # v3.5-E.3: the two-mode-installer answers file (the v3 installer
        # surface's input inventory — single source of truth for the
        # `install_answers` check + the `v3_installer` engine).
        "schemas/install-answers.schema.yaml",
        # v3.1-G1: the dispatch record — the on-disk handoff a `cev3 drive
        # --spawn` materializes (`v3_seat_bridge`) and `cev3 collect` folds.
        # Value-free: digests + shape refs only.
        "schemas/dispatch-record.schema.yaml",
        # v3.5-B live feeds: the local AWAITING-OPERATOR queue consumed by the
        # Cockpit L2 read-model. Value-free local mirror records only.
        "schemas/escalation-record.schema.yaml",
    }
)

# --- Neutral v3/v3.1 LOCAL-STATE root (G-4.1). The CE-namespaced, gitignored
#     instance-local state root for the v3 execution runtime — NEVER ``.hermes/``
#     (the v1 bootstrapping-harness residue, retained frozen for v1 only) and
#     NEVER ``.claude/`` (Claude Code's own tool dir; using it would re-bind CE
#     state to one harness — the same mistake). The v3 sink/driver are already
#     path-neutral (``evidence_sink(root)`` / ``make_run_driver(root)`` take the
#     write-root as a parameter), so this is the convention/default the v3 work-
#     driving CLI (G-7) wires production state under. See
#     ``docs/contracts/v3-naming-hygiene.md``. ---
V3_LOCAL_STATE_ROOT = ".ce/state"

# --- Baselined v3 naming-hygiene exceptions (G-4.1 ratchet floor). Each entry is
#     (repo-relative-file, residue-token) — a justified, pre-existing residue in
#     the v3 surface. EXPECTED EMPTY: the v3 surface is clean on day one. The set
#     only shrinks; a new residue in the v3 surface fails ``v3_naming_hygiene``. ---
BASELINE_V3_NAMING_ALLOWLIST: frozenset[tuple[str, str]] = frozenset()


def classify(rel_module: str) -> str:
    """Return the version line (``v1`` / ``v3`` / ``shared``) for a module.

    ``rel_module`` is the dotted name relative to ``creator_engine_validator``
    (the package itself is ``""``). Anything not declared in a runtime surface
    is ``shared`` — see the module docstring for why that is safe (the ratchet).
    """
    if rel_module in V1_RUNTIME:
        return V1
    if rel_module in V3_RUNTIME:
        return V3
    return SHARED
