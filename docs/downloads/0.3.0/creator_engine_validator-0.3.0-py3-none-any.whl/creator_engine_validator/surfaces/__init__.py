"""Rented-surface inspection helpers."""

