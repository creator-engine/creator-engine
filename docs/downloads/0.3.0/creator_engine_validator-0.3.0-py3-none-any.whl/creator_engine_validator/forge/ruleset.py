"""Repo ruleset desired-state ops for CE's GitHub forge adapter.

The ruleset surface is plan-by-default and repo-scoped only. It manages a
named repository ruleset with pull-request review requirements and explicit
``bypass_actors`` while refusing ``bypass_mode: "always"`` before any forge
call. Auth lives in the injected ``GhRunner``.
"""
from __future__ import annotations

import json
import re
import subprocess
from collections.abc import Sequence
from dataclasses import dataclass, field

from ..sec7_forge_guard import sec7_forge_refusal
from ._redact import redact_gh_stderr
from .github_repo_config import ForgeConfigError, ForgeConfigRefused, GhRunner

_REPO_RE = re.compile(r"^[^/\s]+/[^/\s]+$")
_ALLOWED_MERGE_METHODS = frozenset({"merge", "squash", "rebase"})
# GitHub's merge_queue rule uses upper-case merge methods, distinct from the
# pull_request rule's lower-case allowed_merge_methods.
_ALLOWED_QUEUE_MERGE_METHODS = frozenset({"MERGE", "SQUASH", "REBASE"})
_ALLOWED_QUEUE_GROUPING = frozenset({"ALLGREEN", "HEADGREEN"})
_MERGE_QUEUE_MAX_ENTRIES_CEILING = 100
_MERGE_QUEUE_WAIT_MINUTES_CEILING = 360
_MERGE_QUEUE_CHECK_TIMEOUT_MINUTES_CEILING = 360
CE_PROTECTION_RULESET_NAME = "ce-reference-protection-floor"


class RulesetRefused(ForgeConfigRefused):
    """A repo-ruleset request was refused before any forge side effect."""

    code = "V3-FORGE-RULESET-REFUSED"


@dataclass(frozen=True)
class RulesetBypassActor:
    """One GitHub ruleset bypass actor."""

    actor_id: int
    actor_type: str = "Integration"
    bypass_mode: str = "pull_request"

    def to_payload(self) -> dict:
        if self.bypass_mode == "always":
            raise RulesetRefused('ruleset bypass_mode "always" is forbidden; use "pull_request"')
        if self.bypass_mode != "pull_request":
            raise RulesetRefused(
                f"unsupported ruleset bypass_mode {self.bypass_mode!r}; only 'pull_request' is allowed"
            )
        if self.actor_type != "Integration":
            raise RulesetRefused("P1 repo ruleset bypass actors must be GitHub App Integrations")
        if self.actor_id <= 0:
            raise RulesetRefused("ruleset bypass actor_id must be positive")
        return {
            "actor_id": self.actor_id,
            "actor_type": self.actor_type,
            "bypass_mode": self.bypass_mode,
        }


@dataclass(frozen=True)
class RulesetPolicy:
    """Desired-state repository ruleset policy."""

    name: str
    branch: str = "main"
    enforcement: str = "active"
    required_status_check_contexts: tuple[str, ...] = ()
    strict_required_status_checks_policy: bool = True
    required_approving_review_count: int = 1
    # GitHub's ``dismiss_stale_reviews_on_push`` is a BLUNT, non-diff-aware flag:
    # it wipes EVERY standing review on ANY head-changing push, including a pure
    # mechanical rebase that carries no net content delta. That breaks CE's
    # rebase-preserves-approval doctrine ([[ce-base-only-refresh-microauth]],
    # ce-ops#151) and silently overrides a repo's branch-protection
    # ``dismiss_stale_reviews=false`` (rulesets layer on top, most-restrictive
    # wins) — observed live on creator-engine#368 where each rebase force-push
    # had the App dismiss dev-3's APPROVED review. CE therefore does NOT emit this
    # blanket flag by default; re-review-on-content-change is a CE-OWNED,
    # diff-aware concern (the ``forge.re_review`` lane / ce-ops#151), which
    # dismisses only when the actual diff changes and never on a pure rebase.
    # A caller that genuinely wants GitHub's blunt behavior may still pass True.
    dismiss_stale_reviews_on_push: bool = False
    require_code_owner_review: bool = False
    require_last_push_approval: bool = True
    required_review_thread_resolution: bool = True
    allowed_merge_methods: tuple[str, ...] = ("squash",)
    bypass_actors: tuple[RulesetBypassActor, ...] = ()
    # Merge queue (ce-ops#39). Opt-in: when require_merge_queue is False (the
    # default) no merge_queue rule is emitted, so existing policies are unchanged.
    # The queue merge method must agree with allowed_merge_methods (squash floor).
    require_merge_queue: bool = False
    merge_queue_merge_method: str = "SQUASH"
    merge_queue_grouping_strategy: str = "ALLGREEN"
    merge_queue_max_entries_to_build: int = 5
    merge_queue_max_entries_to_merge: int = 5
    merge_queue_min_entries_to_merge: int = 1
    merge_queue_min_entries_to_merge_wait_minutes: int = 5
    merge_queue_check_response_timeout_minutes: int = 60

    def _ref_include(self) -> str:
        branch = (self.branch or "").strip()
        if not branch:
            raise RulesetRefused("ruleset branch must be non-empty")
        return branch if branch.startswith("refs/") else f"refs/heads/{branch}"

    def _merge_queue_rule(self, allowed_methods: tuple[str, ...]) -> dict:
        """Build the GitHub ``merge_queue`` ruleset rule (validated).

        The queue merge method must be expressible by the pull_request rule's
        ``allowed_merge_methods`` (e.g. a SQUASH queue under a squash-only floor),
        otherwise GitHub would queue a merge the protection floor forbids.
        """
        method = (self.merge_queue_merge_method or "").upper()
        if method not in _ALLOWED_QUEUE_MERGE_METHODS:
            raise RulesetRefused(
                f"unsupported merge_queue merge_method {self.merge_queue_merge_method!r}; "
                f"one of {sorted(_ALLOWED_QUEUE_MERGE_METHODS)}"
            )
        if method.lower() not in {m.lower() for m in allowed_methods}:
            raise RulesetRefused(
                f"merge_queue merge_method {method!r} is not in the policy's "
                f"allowed_merge_methods {allowed_methods!r}"
            )
        grouping = (self.merge_queue_grouping_strategy or "").upper()
        if grouping not in _ALLOWED_QUEUE_GROUPING:
            raise RulesetRefused(
                f"unsupported merge_queue grouping_strategy {self.merge_queue_grouping_strategy!r}; "
                f"one of {sorted(_ALLOWED_QUEUE_GROUPING)}"
            )
        for label, value, minimum, maximum in (
            ("max_entries_to_build", self.merge_queue_max_entries_to_build, 1, _MERGE_QUEUE_MAX_ENTRIES_CEILING),
            ("max_entries_to_merge", self.merge_queue_max_entries_to_merge, 1, _MERGE_QUEUE_MAX_ENTRIES_CEILING),
            ("min_entries_to_merge", self.merge_queue_min_entries_to_merge, 1, _MERGE_QUEUE_MAX_ENTRIES_CEILING),
            ("min_entries_to_merge_wait_minutes", self.merge_queue_min_entries_to_merge_wait_minutes, 0, _MERGE_QUEUE_WAIT_MINUTES_CEILING),
            ("check_response_timeout_minutes", self.merge_queue_check_response_timeout_minutes, 1, _MERGE_QUEUE_CHECK_TIMEOUT_MINUTES_CEILING),
        ):
            if not isinstance(value, int) or value < minimum or value > maximum:
                raise RulesetRefused(
                    f"merge_queue {label} must be an integer between {minimum} and {maximum}"
                )
        if self.merge_queue_min_entries_to_merge > self.merge_queue_max_entries_to_merge:
            raise RulesetRefused(
                "merge_queue min_entries_to_merge must not exceed max_entries_to_merge"
            )
        return {
            "type": "merge_queue",
            "parameters": {
                "merge_method": method,
                "grouping_strategy": grouping,
                "max_entries_to_build": self.merge_queue_max_entries_to_build,
                "max_entries_to_merge": self.merge_queue_max_entries_to_merge,
                "min_entries_to_merge": self.merge_queue_min_entries_to_merge,
                "min_entries_to_merge_wait_minutes": self.merge_queue_min_entries_to_merge_wait_minutes,
                "check_response_timeout_minutes": self.merge_queue_check_response_timeout_minutes,
            },
        }

    def to_put_payload(self) -> dict:
        """Serialize to the repository rulesets create/update body."""
        name = (self.name or "").strip()
        if not name:
            raise RulesetRefused("ruleset name must be non-empty")
        if self.required_approving_review_count < 1:
            raise RulesetRefused("ruleset requires at least one approving review")
        methods = tuple(m.lower() for m in self.allowed_merge_methods)
        unknown = sorted(set(methods) - _ALLOWED_MERGE_METHODS)
        if unknown:
            raise RulesetRefused(f"unsupported merge methods for ruleset: {unknown}")
        contexts = tuple(sorted({str(c).strip() for c in self.required_status_check_contexts}))
        if any(not c for c in contexts):
            raise RulesetRefused("ruleset required status check contexts must be non-empty")
        rules = []
        if contexts:
            rules.append(
                {
                    "type": "required_status_checks",
                    "parameters": {
                        "strict_required_status_checks_policy": self.strict_required_status_checks_policy,
                        "required_status_checks": [{"context": context} for context in contexts],
                    },
                }
            )
        rules.append(
            {
                "type": "pull_request",
                "parameters": {
                    "required_approving_review_count": self.required_approving_review_count,
                    "dismiss_stale_reviews_on_push": self.dismiss_stale_reviews_on_push,
                    "require_code_owner_review": self.require_code_owner_review,
                    "require_last_push_approval": self.require_last_push_approval,
                    "required_review_thread_resolution": self.required_review_thread_resolution,
                    "allowed_merge_methods": list(methods),
                },
            }
        )
        if self.require_merge_queue:
            rules.append(self._merge_queue_rule(methods))
        return {
            "name": name,
            "target": "branch",
            "enforcement": self.enforcement,
            "conditions": {
                "ref_name": {
                    "include": [self._ref_include()],
                    "exclude": [],
                },
            },
            "bypass_actors": [actor.to_payload() for actor in self.bypass_actors],
            "rules": rules,
        }


@dataclass(frozen=True)
class RulesetResult:
    """Outcome of a planned or applied repo ruleset operation."""

    repo: str
    name: str
    operation: str
    ruleset_id: int | None
    changed: bool
    applied: bool
    verified: bool
    before: dict | None = None
    after: dict | None = None
    actions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "repo": self.repo,
            "name": self.name,
            "operation": self.operation,
            "ruleset_id": self.ruleset_id,
            "changed": self.changed,
            "applied": self.applied,
            "verified": self.verified,
            "before": self.before,
            "after": self.after,
            "actions": list(self.actions),
        }


def _default_gh_runner(
    argv: Sequence[str], input_text: str | None = None
) -> subprocess.CompletedProcess:  # pragma: no cover - live gh
    return subprocess.run(
        list(argv), check=False, capture_output=True, text=True, input=input_text, timeout=60
    )


def _gh_api(
    runner: GhRunner,
    path: str,
    *,
    method: str | None = None,
    body: dict | None = None,
) -> tuple[int, object, str]:
    argv: list[str] = ["gh", "api"]
    if method is not None:
        argv += ["--method", method]
    argv.append(path)
    input_text: str | None = None
    if body is not None:
        argv += ["--input", "-"]
        input_text = json.dumps(body)
    proc = runner(argv, input_text)
    parsed: object = None
    out = (proc.stdout or "").strip()
    if out:
        try:
            parsed = json.loads(out)
        except (json.JSONDecodeError, ValueError):
            parsed = None
    return proc.returncode, parsed, proc.stderr or ""


def _validate_repo(repo: str) -> None:
    if not _REPO_RE.match(repo or ""):
        raise RulesetRefused(
            f"repo {repo!r} is not in owner/name form; P1 supports repository rulesets only"
        )


def _rulesets_from_payload(parsed: object) -> list[dict]:
    if isinstance(parsed, list):
        return [r for r in parsed if isinstance(r, dict)]
    if isinstance(parsed, dict):
        for key in ("rulesets", "items"):
            value = parsed.get(key)
            if isinstance(value, list):
                return [r for r in value if isinstance(r, dict)]
    return []


def _list_rulesets(runner: GhRunner, repo: str) -> list[dict]:
    code, parsed, stderr = _gh_api(runner, f"repos/{repo}/rulesets")
    if code != 0:
        raise ForgeConfigError(
            f"could not list repo rulesets for {repo}: {redact_gh_stderr(stderr) or 'unknown error'}"
        )
    return _rulesets_from_payload(parsed)


def _find_by_name(rulesets: Sequence[dict], name: str) -> dict | None:
    for ruleset in rulesets:
        if ruleset.get("name") == name:
            return ruleset
    return None


def find_ruleset(
    repo: str,
    name: str,
    *,
    gh_runner: GhRunner | None = None,
) -> dict | None:
    """Read a named repository ruleset, returning ``None`` when absent."""
    _validate_repo(repo)
    runner = gh_runner or _default_gh_runner
    return _find_by_name(_list_rulesets(runner, repo), name)


def _project_ruleset(ruleset: dict | None) -> dict | None:
    if not ruleset:
        return None
    return {
        "name": ruleset.get("name"),
        "target": ruleset.get("target"),
        "enforcement": ruleset.get("enforcement"),
        "conditions": ruleset.get("conditions") or {},
        "bypass_actors": ruleset.get("bypass_actors") or [],
        "rules": ruleset.get("rules") or [],
    }


def _rule_by_type(ruleset: dict, rule_type: str) -> dict | None:
    for rule in ruleset.get("rules") or []:
        if isinstance(rule, dict) and rule.get("type") == rule_type:
            return rule
    return None


def _status_contexts(rule: dict | None) -> set[str]:
    if not rule:
        return set()
    params = rule.get("parameters") if isinstance(rule, dict) else None
    checks = params.get("required_status_checks") if isinstance(params, dict) else None
    if not isinstance(checks, list):
        return set()
    return {str(item.get("context")) for item in checks if isinstance(item, dict) and item.get("context")}


def ruleset_satisfies_policy(ruleset: dict | None, policy: RulesetPolicy) -> bool:
    """Return whether ``ruleset`` enforces at least ``policy``'s required floor."""
    live = _project_ruleset(ruleset)
    if not live:
        return False
    desired = policy.to_put_payload()
    if live.get("target") != "branch":
        return False
    if live.get("enforcement") != desired["enforcement"]:
        return False
    ref_name = live.get("conditions", {}).get("ref_name", {})
    if policy._ref_include() not in (ref_name.get("include") or []):
        return False
    if live.get("bypass_actors") != desired["bypass_actors"]:
        return False

    desired_checks = set(policy.required_status_check_contexts)
    if desired_checks:
        status_rule = _rule_by_type(live, "required_status_checks")
        status_params = status_rule.get("parameters", {}) if status_rule else {}
        if not desired_checks <= _status_contexts(status_rule):
            return False
        if policy.strict_required_status_checks_policy and not bool(
            status_params.get("strict_required_status_checks_policy")
        ):
            return False

    pull_rule = _rule_by_type(live, "pull_request")
    pull_params = pull_rule.get("parameters", {}) if pull_rule else {}
    if int(pull_params.get("required_approving_review_count", 0) or 0) < policy.required_approving_review_count:
        return False
    for key, required in (
        ("dismiss_stale_reviews_on_push", policy.dismiss_stale_reviews_on_push),
        ("require_code_owner_review", policy.require_code_owner_review),
        ("require_last_push_approval", policy.require_last_push_approval),
        ("required_review_thread_resolution", policy.required_review_thread_resolution),
    ):
        if required and not bool(pull_params.get(key)):
            return False
    methods = tuple(m.lower() for m in policy.allowed_merge_methods)
    if methods and set(pull_params.get("allowed_merge_methods") or []) != set(methods):
        return False
    if policy.require_merge_queue:
        queue_rule = _rule_by_type(live, "merge_queue")
        if not queue_rule:
            return False
        queue_params = queue_rule.get("parameters", {}) or {}
        desired_queue = _rule_by_type(desired, "merge_queue")
        desired_params = desired_queue.get("parameters", {}) if desired_queue else {}
        for key, expected in desired_params.items():
            actual = queue_params.get(key)
            if key in ("merge_method", "grouping_strategy"):
                if str(actual).upper() != str(expected).upper():
                    return False
            elif actual != expected:
                return False
    return True


def upsert_ruleset(
    repo: str,
    policy: RulesetPolicy,
    *,
    apply: bool = False,
    gh_runner: GhRunner | None = None,
    sec7_context: object | None = None,
) -> RulesetResult:
    """Create or update a named repository ruleset (plan-by-default)."""
    refusal = sec7_forge_refusal("ruleset", sec7_context)
    if refusal is not None:
        raise RulesetRefused(refusal)
    _validate_repo(repo)
    desired = policy.to_put_payload()
    runner = gh_runner or _default_gh_runner
    rulesets = _list_rulesets(runner, repo)
    existing = _find_by_name(rulesets, desired["name"])
    existing_id = int(existing["id"]) if existing and existing.get("id") is not None else None
    before = _project_ruleset(existing)
    after = _project_ruleset(desired)
    changed = before != after
    actions: list[str] = []

    if not changed:
        actions.append("repo ruleset already matches desired policy")
        return RulesetResult(
            repo=repo, name=desired["name"], operation="upsert_ruleset",
            ruleset_id=existing_id, changed=False, applied=False, verified=True,
            before=before, after=after, actions=actions,
        )
    if not apply:
        verb = "update" if existing_id is not None else "create"
        actions.append(f"PLAN: would {verb} repo ruleset {desired['name']!r}")
        return RulesetResult(
            repo=repo, name=desired["name"], operation="upsert_ruleset",
            ruleset_id=existing_id, changed=True, applied=False, verified=False,
            before=before, after=after, actions=actions,
        )

    if existing_id is None:
        code, parsed, stderr = _gh_api(
            runner, f"repos/{repo}/rulesets", method="POST", body=desired
        )
        action = "created"
    else:
        code, parsed, stderr = _gh_api(
            runner, f"repos/{repo}/rulesets/{existing_id}", method="PUT", body=desired
        )
        action = "updated"
    if code != 0 or not isinstance(parsed, dict):
        raise ForgeConfigError(
            f"could not {action[:-1]} repo ruleset {desired['name']!r} for {repo}: "
            f"{redact_gh_stderr(stderr) or 'unknown error'}"
        )
    new_id = int(parsed["id"]) if parsed.get("id") is not None else existing_id
    actions.append(f"APPLIED: {action} repo ruleset {desired['name']!r}")
    reread = _find_by_name(_list_rulesets(runner, repo), desired["name"])
    verified = _project_ruleset(reread) == after
    if not verified:
        actions.append(f"VERIFY MISMATCH: live={_project_ruleset(reread)} desired={after}")
    return RulesetResult(
        repo=repo, name=desired["name"], operation="upsert_ruleset",
        ruleset_id=new_id, changed=True, applied=True, verified=verified,
        before=before, after=after, actions=actions,
    )


def delete_ruleset(
    repo: str,
    name: str,
    *,
    apply: bool = False,
    gh_runner: GhRunner | None = None,
    sec7_context: object | None = None,
) -> RulesetResult:
    """Delete a named repository ruleset when present (plan-by-default)."""
    refusal = sec7_forge_refusal("ruleset", sec7_context)
    if refusal is not None:
        raise RulesetRefused(refusal)
    _validate_repo(repo)
    if not (name or "").strip():
        raise RulesetRefused("ruleset name must be non-empty")
    runner = gh_runner or _default_gh_runner
    existing = _find_by_name(_list_rulesets(runner, repo), name)
    existing_id = int(existing["id"]) if existing and existing.get("id") is not None else None
    before = _project_ruleset(existing)
    actions: list[str] = []

    if existing_id is None:
        actions.append("repo ruleset already absent")
        return RulesetResult(
            repo=repo, name=name, operation="delete_ruleset", ruleset_id=None,
            changed=False, applied=False, verified=True, before=None, after=None,
            actions=actions,
        )
    if not apply:
        actions.append(f"PLAN: would delete repo ruleset {name!r}")
        return RulesetResult(
            repo=repo, name=name, operation="delete_ruleset", ruleset_id=existing_id,
            changed=True, applied=False, verified=False, before=before, after=None,
            actions=actions,
        )

    code, _parsed, stderr = _gh_api(
        runner, f"repos/{repo}/rulesets/{existing_id}", method="DELETE"
    )
    if code != 0:
        raise ForgeConfigError(
            f"could not delete repo ruleset {name!r} for {repo}: "
            f"{redact_gh_stderr(stderr) or 'unknown error'}"
        )
    reread = _find_by_name(_list_rulesets(runner, repo), name)
    verified = reread is None
    actions.append(f"APPLIED: deleted repo ruleset {name!r}")
    if not verified:
        actions.append(f"VERIFY MISMATCH: live ruleset still exists for {name!r}")
    return RulesetResult(
        repo=repo, name=name, operation="delete_ruleset", ruleset_id=existing_id,
        changed=True, applied=True, verified=verified, before=before, after=None,
        actions=actions,
    )
