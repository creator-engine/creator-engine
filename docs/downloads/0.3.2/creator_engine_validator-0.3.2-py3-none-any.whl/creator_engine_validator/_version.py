"""GENERATED build identity — do not edit by hand.

Written by ``python -m creator_engine_validator.version --write-build-file``
(reads ``validators/pyproject.toml`` + ``git rev-parse --verify HEAD``).
Committed BEFORE the wheel build so the wheel==source byte-parity contract
(``packaging_runtime.verify_wheel_matches_source``) still holds. ``BUILD_GIT_SHA``
is the gate's merge-parent HEAD — the baked fallback a no-git wheel install uses.
"""

SEMVER = "0.3.2"
BUILD_GIT_SHA = "43b165c466dcd1fd7590dd8c258d90654770a2df"
