"""v3 G-3.6b — the offline composition root: the production ``run`` driver.

:func:`make_run_driver` returns a callable that drives ONE ratified, audited
agent-seat run end to end and PERSISTS its evidence. It is the first real
composition root — the single place that assembles the already fake-tested seams
into one :func:`~.orchestrator.run_plan` drive:

* the production ``token_minter`` — a closure over ``forge.mint_scoped_token`` /
  ``forge.revoke_scoped_token`` that maps the value-bearing ``ScopedToken`` to the
  value-free :class:`~.orchestrator.MintedCredential` port the orchestrator gates;
* the **minter->runner bridge** — a closure cell holding the ONE live
  ``ScopedToken`` minted for the run, shared from the minter to the
  ``change_opener``'s authenticated ``gh`` runner via
  ``forge.authenticated_gh_runner`` — so the change-opener authenticates AS the
  SAME minted token, while the orchestrator stays value-free (it only ever sees
  the ``MintedCredential``; the live ``value`` never crosses into ``run_plan``);
* the production ``change_opener`` — a closure over
  ``forge.open_change(..., apply=False)`` through that authenticated runner;
* the G-3.5 ``file_evidence_sink`` — wired into the new
  ``run_plan(evidence_sink=…)`` seam so the run's chain persists after teardown.

The drive proves, entirely offline, the full pipeline:
**mint -> authenticated runner -> run -> collect -> typed ``pr_opened`` outcome ->
persisted evidence**, with ZERO live side effects (the backend / ``gh_runner`` /
``spawn`` / ``write`` are all injectable seams; CI drives fakes with
``subprocess`` / ``socket`` / ``Path.write_text`` monkeypatched to explode). It is
the exact entry G-3.7 promotes to live (``apply=True`` + a real installation,
OUTSIDE the CI-purity envelope).

This module is where ``forge`` IS imported and the live ``ScopedToken.value``
lives — the opposite of the pure, forge-free orchestrator. The value lives ONLY
in the closure cell and, at call time, ONLY in the child ``gh`` env; it never
enters the orchestrator, the evidence, argv, input, a log, disk, or the parent
environment. Importing this module performs zero I/O and registers no check and
no backend.

Defensive only — authorization + accountability for our own agent runtime;
never offensive.
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any

from .evidence_sink import file_evidence_sink
from .forge.change import ChangeRef, open_change
from .forge.credential_runner import authenticated_gh_runner
from .forge.github_repo_config import ForgeConfigError, GhRunner
from .forge.merge import MergeResult, merge
from .forge.scoped_token import TokenRequest, mint_scoped_token, revoke_scoped_token
from .orchestrator import (
    ApprovedPlan,
    MintedCredential,
    RatificationBindingRefused,
    merge_change,
    run_plan,
)
from .runner import CollectedEvidence, RunnerBackend

#: The composed driver: drive(runtime_policy, run_id, command, approved_plan, token_request).
RunDriver = Callable[
    [dict[str, Any], str, Sequence[str], ApprovedPlan, TokenRequest], CollectedEvidence
]


def make_run_driver(
    repo: str,
    root: Path,
    *,
    spawn: Any = None,
    write: Any = None,
    backend: RunnerBackend | None = None,
    gh_runner: Any = None,
    live: bool = False,
    head_observer: Callable[[], str] | None = None,
) -> RunDriver:
    """Return a :data:`RunDriver` composing one offline run end to end + persistence.

    ``repo`` is the ``owner/name`` the change is opened against; ``root`` the
    directory the evidence chain persists under. The injectable seams default to
    production: ``backend`` (else resolved from the runtime-policy by ``run_plan``),
    ``gh_runner`` (the App-level mint/revoke transport), ``spawn`` (the child ``gh``
    transport for the authenticated change-opener runner), and ``write`` (the
    evidence-file writer). CI injects fakes for all four.

    **G-3.7.3a — the live-mode seam (default OFF).** ``live`` promotes the
    change-open from ``apply=False`` (the offline default — byte-for-byte the prior
    behavior) to ``apply=True``; the actual live drive (G-3.7.3b) sets it. When
    ``live`` and the plan is SHA-pinned (``approved_plan.ratified_head_sha`` set),
    an injected ``head_observer`` — a host-side read of the LIVE repo head supplied
    by the live-drive runbook — is REQUIRED: ``drive`` reads the observed head and
    passes it to the orchestrator gate (as value-free DATA) so the ratification
    binds the INDEPENDENTLY-observed head, not just the agent-claimed change head;
    a live SHA-pinned drive without an observer is refused before minting. The
    observer is an injectable seam (CI injects a fake → zero live I/O); the real
    authenticated read lives in the 3.7.3b runbook, never here.

    The returned ``drive(runtime_policy, run_id, command, approved_plan,
    token_request)`` mints a JIT per-run credential, shares the live
    ``ScopedToken`` to the change-opener's authenticated ``gh`` runner through a
    closure cell (the orchestrator never sees the value), opens/claims the PR
    plan-by-default, persists the run's evidence chain via the G-3.5 sink, and
    revokes the credential — authenticated AS the token, best-effort — at
    completion (success OR failure).
    """
    root = Path(root)

    def drive(
        runtime_policy: dict[str, Any],
        run_id: str,
        command: Sequence[str],
        approved_plan: ApprovedPlan,
        token_request: TokenRequest,
    ) -> CollectedEvidence:
        # The minter->runner bridge: ONE live ScopedToken, held in a closure cell the
        # change-opener's authenticated runner reads. The cell never crosses into run_plan;
        # the orchestrator sees only the value-free MintedCredential.
        cell: dict[str, Any] = {"token": None}

        def token_minter(policy: dict[str, Any], rid: str) -> MintedCredential:
            token = mint_scoped_token(token_request, gh_runner=gh_runner)
            cell["token"] = token  # share the live token to the runner factory, NOT the orchestrator
            return MintedCredential(
                run_id=token.run_id,
                policy_sha=token.policy_sha,
                secret_name=token.secret_name,
                permissions=token.permissions,
                expires_at=token.expires_at,
                credential_ref=token.token_ref,
            )

        def change_opener(change_set: Any, plan_ref: str) -> Any:
            # Authenticate the change-open AS the minted token — the live value lands in the
            # child gh env only (forge.authenticated_gh_runner), never in argv / here / evidence.
            authed = authenticated_gh_runner(cell["token"], spawn=spawn)
            return open_change(
                repo,
                change_set.branch,
                change_set.base,
                change_set.manifest_paths,
                plan_ref,
                apply=live,  # G-3.7.3a: live mode promotes the change-open to a real apply=True
                gh_runner=authed,
            )

        sink = file_evidence_sink(root, write=write)
        # G-3.7.2b: the value-free binding inputs for the runtime head-SHA assertion. The
        # orchestrator recomputes binding_ref over this {repo, installation_id, permissions,
        # ratified_head_sha} tuple and REFUSES if it (or the change head) drifted from the
        # SHA-pinned ratification on the ApprovedPlan. Only the opaque digest lands in evidence,
        # never these raw identifiers; for an unbound ApprovedPlan the gate is inert.
        binding_inputs: dict[str, Any] = {
            "repo": repo,
            "installation_id": token_request.installation_id,
            "permissions": dict(token_request.permissions),
        }
        # G-3.7.3a: in live mode a SHA-pinned ratification MUST be checked against an
        # INDEPENDENTLY-observed live repo head — refuse a live apply=True without one rather
        # than trusting only the agent-claimed change head. Read the observed head (the injected
        # seam; the real authenticated read is the 3.7.3b runbook's) and pass it to the gate as
        # value-free DATA; the orchestrator asserts observed == ratified before the change-open.
        if live and approved_plan.ratified_head_sha and head_observer is None:
            raise RatificationBindingRefused(
                f"run {run_id!r} live drive of a SHA-pinned ratification requires a head_observer "
                "(refusing apply=True without an independent observed-base-head check)"
            )
        if live and head_observer is not None:
            binding_inputs["observed_head_sha"] = head_observer()
        try:
            return run_plan(
                runtime_policy,
                run_id,
                command,
                approved_plan,
                backend=backend,
                token_minter=token_minter,
                change_opener=change_opener,
                evidence_sink=sink,
                binding_inputs=binding_inputs,
            )
        finally:
            # Defense-in-depth: release the credential the instant the run ends — success OR
            # failure — rather than waiting out its (<=1h) ttl. No mint -> nothing to revoke.
            # DELETE /installation/token must authenticate AS the token being revoked, so route
            # the revoke through an authenticated runner bound to the minted token (NOT the
            # App-level mint runner). Best-effort: a revoke-transport failure must neither mask
            # the run exception nor manufacture a success-path error — it is swallowed and made
            # alertable (value-free), and the token then expires on its own (<=1h) ttl.
            token = cell["token"]
            if token is not None:
                try:
                    revoke_scoped_token(
                        token, gh_runner=authenticated_gh_runner(token, spawn=spawn)
                    )
                except ForgeConfigError:
                    logging.getLogger(__name__).warning(
                        "scoped-token revoke failed for run %s (token_ref %s); "
                        "the token will expire on its ttl",
                        run_id,
                        token.token_ref,
                    )

    return drive


#: The composed merge driver: drive(prior_evidence, *, pr_number, run_id, policy_sha).
MergeDriver = Callable[..., CollectedEvidence]


def make_merge_driver(
    repo: str,
    root: Path,
    *,
    merge_gh_runner: GhRunner,
    write: Any = None,
    live: bool = False,
) -> MergeDriver:
    """Return a driver that drives a gated merge of an already-open, reviewed PR + persists.

    v3 G-3.7b.1 — the merge composition root, the disposition AFTER review. The merge acts on an
    ALREADY-OPEN, gate-eligible PR, so this is a SEPARATE composition from the open/run drive
    (:func:`make_run_driver`).

    **Distinct merge identity (load-bearing).** The merge credential is the injected
    ``merge_gh_runner`` and is **NEVER the per-run scoped token**: the per-run token AUTHORED the
    PR, so it must not merge it (self-merge collision; the merge gate + branch protection assume an
    independent merger — see ``docs/architecture/pilot-deployment-transport.md``). This root
    therefore mints NO per-run token and never reaches for ``authenticated_gh_runner``; the merge
    authenticates ONLY as ``merge_gh_runner`` (CI injects a fake; the real distinct credential is
    provisioned at the out-of-envelope G-3.8 live drive).

    **Plan-by-default.** ``live`` (default OFF) promotes ``forge.merge`` from ``apply=False`` (a
    non-mutating gate-read preview — byte-for-byte the offline default) to ``apply=True``; only the
    G-3.8 live drive sets it. ``pr_merged`` is attested only on an ACTUAL merge.

    The returned ``drive(prior_evidence, *, pr_number, run_id, policy_sha)`` reconstructs the
    value-free merge target from the open drive's ``change_set`` (the PR it merges), composes the
    forge-free ``change_merger`` over ``forge.merge(change, apply=live, gh_runner=merge_gh_runner)``,
    and appends + persists the typed ``pr_merged`` outcome via :func:`~.orchestrator.merge_change`
    (the G-3.5 sink). The prior evidence (the open drive's chain) is supplied at drive time — its
    live read is the G-3.8 runbook's concern, never here. Zero live I/O — every seam is injected.
    """
    root = Path(root)

    def drive(
        prior_evidence: CollectedEvidence,
        *,
        pr_number: int,
        run_id: str,
        policy_sha: str,
    ) -> CollectedEvidence:
        change_set = prior_evidence.change_set
        if change_set is None:
            raise ValueError(
                f"make_merge_driver drive for run {run_id!r} requires the open drive's change_set "
                "(the value-free pointer to the already-open PR being merged)"
            )
        # The value-free merge target: the SAME already-open PR (its number + head to head-pin) the
        # open drive produced. Only repo + pr_number + head_sha are load-bearing for the gated merge.
        change = ChangeRef(
            repo=repo,
            branch=change_set.branch,
            base=change_set.base,
            pr_number=pr_number,
            head_sha=change_set.head_sha,
            manifest_paths=tuple(change_set.manifest_paths),
            plan_ref=policy_sha,
            changed=True,
            applied=True,
            verified=True,
        )

        def change_merger() -> MergeResult:
            # Authenticate the merge AS the DISTINCT merge identity — NEVER the per-run token.
            return merge(change, apply=live, gh_runner=merge_gh_runner)

        sink = file_evidence_sink(root, write=write)
        return merge_change(
            prior_evidence,
            run_id=run_id,
            policy_sha=policy_sha,
            change_merger=change_merger,
            evidence_sink=sink,
        )

    return drive
